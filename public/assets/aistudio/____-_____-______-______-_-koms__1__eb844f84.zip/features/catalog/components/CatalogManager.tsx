export * from '../../../src/components/categories/CatalogManager';
export { default } from '../../../src/components/categories/CatalogManager';
