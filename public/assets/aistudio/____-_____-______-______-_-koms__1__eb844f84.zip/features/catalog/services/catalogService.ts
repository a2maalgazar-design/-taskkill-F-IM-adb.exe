export * from '../../../src/services/catalogService';
export { default } from '../../../src/services/catalogService';
