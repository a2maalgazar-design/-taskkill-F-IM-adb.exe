import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { processInvoiceImageBuffer } from './src/features/ai/api/geminiInvoiceService';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  // Body parser with 25MB payload limit for high resolution invoice captures
  app.use(express.json({ limit: '25mb' }));
  app.use(express.urlencoded({ extended: true, limit: '25mb' }));

  // AI OCR extraction endpoint
  app.post('/api/ocr/invoice', async (req, res) => {
    try {
      const { imageBase64, mimeType, expectedItems } = req.body;
      if (!imageBase64) {
        return res.status(400).json({ error: 'لم يتم توفير صورة الفاتورة (imageBase64 مطلوب)' });
      }

      const extracted = await processInvoiceImageBuffer(
        imageBase64,
        mimeType || 'image/jpeg',
        expectedItems || []
      );

      return res.json(extracted);
    } catch (error: any) {
      console.error('Error processing invoice image buffer with Gemini:', error);
      return res.status(500).json({
        error: error.message || 'حدث خطأ أثناء معالجة الفاتورة عبر الذكاء الاصطناعي',
      });
    }
  });

  // AI Predictive forecasting endpoint
  app.post('/api/predictive-forecast', async (req, res) => {
    try {
      const { historicalSalesByDish, upcomingWeekDates } = req.body;
      const { generateAIPredictiveForecast } = await import('./src/features/menuEngineering/api/geminiForecastService.js');
      const forecast = await generateAIPredictiveForecast(
        historicalSalesByDish || [],
        upcomingWeekDates || []
      );
      return res.json(forecast);
    } catch (error: any) {
      console.error('Error generating predictive forecast with Gemini:', error);
      return res.status(500).json({
        error: error.message || 'حدث خطأ أثناء التنبؤ بالطلب',
      });
    }
  });

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'KOMS AI API', timestamp: new Date().toISOString() });
  });

  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`Server is running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
