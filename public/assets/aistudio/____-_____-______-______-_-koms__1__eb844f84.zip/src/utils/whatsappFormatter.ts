/**
 * صياغة رسائل الواتساب المعتمدة لمطبخ نانا الشيخ زايد
 * مطابقة تماماً للمواصفات المطلوبة:
 * 1. رأس الرسالة: طلبية مطبخ نانا الشيخ زايد
 * 2. كود الطلبية
 * 3. القائم بالطلب
 * 4. الأصناف والكميات المطلوبة
 * 5. إجمالي عدد البنود المطلوب
 * 6. رسالة: يرجى سرعة التأكيد والتوريد في الموعد المتفق عليه.
 */

export interface WhatsAppOrderItem {
  name: string;
  qty: number | string;
  unit: string;
}

export interface FormatWhatsAppOptions {
  orderCode: string;
  requesterName: string;
  items: WhatsAppOrderItem[];
  recipientPhone?: string;
}

export function formatKitchenWhatsAppMessage(options: FormatWhatsAppOptions): string {
  const { orderCode, requesterName, items } = options;

  const itemsList = items
    .filter((it) => (typeof it.qty === 'number' ? it.qty > 0 : parseFloat(it.qty) > 0))
    .map((it, idx) => `${idx + 1}. ${it.name}: ${it.qty} ${it.unit}`)
    .join('\n');

  const count = items.filter((it) =>
    typeof it.qty === 'number' ? it.qty > 0 : parseFloat(it.qty) > 0
  ).length;

  return `طلبية مطبخ نانا الشيخ زايد
كود الطلبية: ${orderCode}
القائم بالطلب: ${requesterName}

الأصناف والكميات المطلوبة:
${itemsList}

إجمالي عدد البنود المطلوب: ${count} بند

يرجى سرعة التأكيد والتوريد في الموعد المتفق عليه.`;
}

/**
 * تنظيف وتنسيق أرقام الهواتف المصرية لتوليد روابط wa.me
 */
export function sanitizeEgyptianPhone(phone: string): string {
  const digitsOnly = (phone || '').replace(/\D/g, '');
  if (digitsOnly.startsWith('01') && digitsOnly.length === 11) {
    return `20${digitsOnly.substring(1)}`;
  }
  if (digitsOnly.startsWith('201') && digitsOnly.length === 12) {
    return digitsOnly;
  }
  if (digitsOnly.length === 10 && digitsOnly.startsWith('1')) {
    return `20${digitsOnly}`;
  }
  return digitsOnly || '201000000000';
}

export function generateKitchenWhatsAppUrl(phone: string, message: string): string {
  const cleanPhone = sanitizeEgyptianPhone(phone);
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}
