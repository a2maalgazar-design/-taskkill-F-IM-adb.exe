import { WorkflowStatus, OrderPriority } from '../types';

export interface StatusMeta {
  labelAr: string;
  labelEn: string;
  bgClass: string;
  textClass: string;
  borderClass: string;
  description: string;
}

export const WORKFLOW_STATUS_CONFIG: Record<WorkflowStatus, StatusMeta> = {
  PLANNED: {
    labelAr: 'مخطط',
    labelEn: 'Planned',
    bgClass: 'bg-stone-800',
    textClass: 'text-stone-300',
    borderClass: 'border-stone-700',
    description: 'طلبية مجدولة لم يحن موعد طلبها بعد',
  },
  DUE: {
    labelAr: 'مستحق للطلب',
    labelEn: 'Due',
    bgClass: 'bg-amber-950/60',
    textClass: 'text-amber-400',
    borderClass: 'border-amber-800',
    description: 'حان وقت إرسال الطلب للمورد',
  },
  ORDERING: {
    labelAr: 'جاري الطلب',
    labelEn: 'Ordering',
    bgClass: 'bg-blue-950/60',
    textClass: 'text-blue-400',
    borderClass: 'border-blue-800',
    description: 'المسؤول يتواصل مع المورد حالياً',
  },
  ORDERED: {
    labelAr: 'تم إرسال الطلب',
    labelEn: 'Ordered',
    bgClass: 'bg-indigo-950/60',
    textClass: 'text-indigo-400',
    borderClass: 'border-indigo-800',
    description: 'تم تأكيد الطلب مع المورد رسمياً',
  },
  AWAITING_DELIVERY: {
    labelAr: 'بانتظار الشحنة',
    labelEn: 'Awaiting Delivery',
    bgClass: 'bg-purple-950/60',
    textClass: 'text-purple-400',
    borderClass: 'border-purple-800',
    description: 'الشحنة في طريقها لباب استلام المطبخ',
  },
  RECEIVING: {
    labelAr: 'جاري الاستلام والفحص',
    labelEn: 'Receiving',
    bgClass: 'bg-cyan-950/60',
    textClass: 'text-cyan-400',
    borderClass: 'border-cyan-800',
    description: 'جاري فحص الأوزان والجودة ودرجات الحرارة',
  },
  INVOICE_PENDING: {
    labelAr: 'بانتظار الفاتورة',
    labelEn: 'Invoice Pending',
    bgClass: 'bg-yellow-950/60',
    textClass: 'text-yellow-400',
    borderClass: 'border-yellow-800',
    description: 'البضاعة استلمت وبانتظار مراجعة الفاتورة والمطابقة',
  },
  VERIFIED: {
    labelAr: 'تمت المطابقة',
    labelEn: 'Verified',
    bgClass: 'bg-teal-950/60',
    textClass: 'text-teal-400',
    borderClass: 'border-teal-800',
    description: 'تم التأكد من صحة الكميات والأسعار مع الفاتورة',
  },
  COMPLETED: {
    labelAr: 'مكتمل ومغلق',
    labelEn: 'Completed',
    bgClass: 'bg-emerald-950/60',
    textClass: 'text-emerald-400',
    borderClass: 'border-emerald-800',
    description: 'أغلقت الطلبية ودخلت السجلات التشغيلية',
  },
  ON_HOLD: {
    labelAr: 'معلق',
    labelEn: 'On Hold',
    bgClass: 'bg-orange-950/60',
    textClass: 'text-orange-400',
    borderClass: 'border-orange-800',
    description: 'موقوف مؤقتاً بانتظار تعليمات الإدارة',
  },
  DELAYED: {
    labelAr: 'متأخر من المورد',
    labelEn: 'Delayed',
    bgClass: 'bg-rose-950/60',
    textClass: 'text-rose-400',
    borderClass: 'border-rose-800',
    description: 'تأخر التوريد عن الموعد المتفق عليه',
  },
  RESCHEDULED: {
    labelAr: 'معاد جدولته',
    labelEn: 'Rescheduled',
    bgClass: 'bg-sky-950/60',
    textClass: 'text-sky-400',
    borderClass: 'border-sky-800',
    description: 'تم ترحيل موعد التوريد لميعاد آخر',
  },
  CANCELLED: {
    labelAr: 'ملغي',
    labelEn: 'Cancelled',
    bgClass: 'bg-red-950/60',
    textClass: 'text-red-400',
    borderClass: 'border-red-800',
    description: 'تم إلغاء الطلبية من الإدارة',
  },
  PARTIALLY_RECEIVED: {
    labelAr: 'استلام جزئي',
    labelEn: 'Partially Received',
    bgClass: 'bg-amber-950/80',
    textClass: 'text-amber-300',
    borderClass: 'border-amber-700',
    description: 'تم استلام بعض البنود وتبقى نواقص',
  },
  PARTIALLY_REJECTED: {
    labelAr: 'رفض جزئي / تالف',
    labelEn: 'Partially Rejected',
    bgClass: 'bg-red-950/80',
    textClass: 'text-red-300',
    borderClass: 'border-red-700',
    description: 'تم رفض بعض البنود لعدم مطابقة مواصفات الجودة',
  },
};

export const PRIORITY_CONFIG: Record<OrderPriority, { labelAr: string; color: string; bg: string }> = {
  normal: { labelAr: 'عادي', color: 'text-stone-300', bg: 'bg-stone-800' },
  urgent: { labelAr: 'عاجل', color: 'text-amber-400', bg: 'bg-amber-950/80' },
  critical: { labelAr: 'حرج جداً', color: 'text-red-400', bg: 'bg-red-950/80' },
};

// Allowed transitions for linear workflow + exceptions
export const ALLOWED_TRANSITIONS: Record<WorkflowStatus, WorkflowStatus[]> = {
  PLANNED: ['DUE', 'ORDERING', 'ON_HOLD', 'CANCELLED'],
  DUE: ['ORDERING', 'DELAYED', 'ON_HOLD', 'CANCELLED'],
  ORDERING: ['ORDERED', 'ON_HOLD', 'CANCELLED'],
  ORDERED: ['AWAITING_DELIVERY', 'DELAYED', 'ON_HOLD', 'CANCELLED'],
  AWAITING_DELIVERY: ['RECEIVING', 'DELAYED', 'ON_HOLD', 'CANCELLED'],
  RECEIVING: ['INVOICE_PENDING', 'PARTIALLY_RECEIVED', 'PARTIALLY_REJECTED', 'VERIFIED', 'COMPLETED'],
  PARTIALLY_RECEIVED: ['AWAITING_DELIVERY', 'INVOICE_PENDING', 'VERIFIED', 'COMPLETED'],
  PARTIALLY_REJECTED: ['INVOICE_PENDING', 'AWAITING_DELIVERY', 'VERIFIED', 'COMPLETED'],
  INVOICE_PENDING: ['VERIFIED', 'COMPLETED', 'ON_HOLD'],
  VERIFIED: ['COMPLETED'],
  COMPLETED: ['RESCHEDULED'],
  ON_HOLD: ['PLANNED', 'DUE', 'ORDERING', 'CANCELLED'],
  DELAYED: ['ORDERED', 'AWAITING_DELIVERY', 'CANCELLED'],
  RESCHEDULED: ['DUE', 'ORDERING'],
  CANCELLED: [],
};

export function formatDateTime(isoString?: string): string {
  if (!isoString) return '—';
  try {
    const d = new Date(isoString);
    return d.toLocaleString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return isoString;
  }
}

export function formatDateOnly(dateStr?: string): string {
  if (!dateStr) return '—';
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
}
