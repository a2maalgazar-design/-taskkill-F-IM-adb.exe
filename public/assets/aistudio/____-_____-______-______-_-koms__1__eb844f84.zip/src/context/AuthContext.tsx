import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { dbService } from '../services/databaseService';
import { User, UserRole, UserProfile, PermissionKey, RoleKey, ROLE_PERMISSIONS_PRESETS } from '../types';
import { authService } from '../services/authService';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  KeyRound,
  LogIn,
  Mail,
  ShieldCheck,
  Sparkles,
  Users,
} from 'lucide-react';

export interface AuthContextType {
  user: UserProfile | null;
  currentUser: User;
  users: User[];
  loading: boolean;
  error: string | null;
  isManager: boolean;
  isAssistant: boolean;
  hasPermission: (permission: PermissionKey) => boolean;
  switchUser: (userId: string) => void;
  signInWithGoogle: () => Promise<void>;
  loginAsDemo: () => void;
  loginAsUser: (targetUser: User) => void;
  loginWithEmail: (email: string) => Promise<void>;
  clearError: () => void;
  signOut: () => Promise<void>;
  refreshUsers: () => Promise<void>;
  updateUserRole: (userId: string, newRole: UserRole) => Promise<void>;
  toggleUserActive: (userId: string) => Promise<void>;
  updateUser: (user: User) => Promise<void>;
  updateUserDomains: (userId: string, domainIds: string[]) => Promise<void>;
  addUser: (userData: Omit<User, 'id' | 'createdAt'>) => Promise<void>;
  deleteUser: (userId: string) => Promise<void>;
}

const DEFAULT_PROFILE: UserProfile = {
  uid: 'user-manager-01',
  email: 'a2m.algazar@gmail.com',
  displayName: 'أحمد الجزار (مدير المطبخ والمشتريات)',
  role: 'manager',
  permissions: ROLE_PERMISSIONS_PRESETS.manager,
  isActive: true,
  createdAt: new Date().toISOString(),
  lastLoginAt: new Date().toISOString(),
};

const AuthContext = createContext<AuthContextType>({
  user: null,
  currentUser: {
    id: DEFAULT_PROFILE.uid,
    name: DEFAULT_PROFILE.displayName,
    email: DEFAULT_PROFILE.email,
    role: DEFAULT_PROFILE.role,
    isActive: true,
    createdAt: DEFAULT_PROFILE.createdAt,
  },
  users: [],
  loading: true,
  error: null,
  isManager: true,
  isAssistant: false,
  hasPermission: () => true,
  switchUser: () => {},
  signInWithGoogle: async () => {},
  loginAsDemo: () => {},
  loginAsUser: () => {},
  loginWithEmail: async () => {},
  clearError: () => {},
  signOut: async () => {},
  refreshUsers: async () => {},
  updateUserRole: async () => {},
  toggleUserActive: async () => {},
  updateUser: async () => {},
  updateUserDomains: async () => {},
  addUser: async () => {},
  deleteUser: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string>('user-manager-01');

  const fetchUsers = async () => {
    try {
      const allUsers = await dbService.getUsers();
      setUsers(allUsers);
    } catch (e) {
      console.error('Error fetching users:', e);
    }
  };

  useEffect(() => {
    fetchUsers();

    // Firebase Auth State Listener
    const unsubscribeAuth = onAuthStateChanged(auth, (firebaseUser) => {
      if (!firebaseUser) {
        setUser(null);
        setLoading(false);
        return;
      }

      const userDocRef = doc(db, 'users', firebaseUser.uid);
      const unsubscribeDoc = onSnapshot(
        userDocRef,
        (snap) => {
          if (snap.exists()) {
            const profile = snap.data() as UserProfile;
            setUser(profile);
            setCurrentUserId(profile.uid);
          } else {
            setUser(null);
          }
          setLoading(false);
        },
        (err) => {
          setError(err.message);
          setLoading(false);
        }
      );

      return () => unsubscribeDoc();
    });

    return () => unsubscribeAuth();
  }, []);

  // Compute active user
  const effectiveUser = user
    ? {
        id: user.uid,
        uid: user.uid,
        name: user.displayName,
        displayName: user.displayName,
        email: user.email,
        role: user.role,
        permissions: user.permissions,
        isActive: user.isActive,
        createdAt: user.createdAt,
      }
    : users.find((u) => u.id === currentUserId) ||
      users[0] || {
        id: DEFAULT_PROFILE.uid,
        name: DEFAULT_PROFILE.displayName,
        email: DEFAULT_PROFILE.email,
        role: DEFAULT_PROFILE.role,
        isActive: true,
        createdAt: DEFAULT_PROFILE.createdAt,
      };

  const isManager = effectiveUser.role === 'manager';
  const isAssistant = effectiveUser.role === 'assistant';

  const hasPermission = (permission: PermissionKey): boolean => {
    if (!effectiveUser.isActive) return false;
    const userPerms =
      effectiveUser.permissions || ROLE_PERMISSIONS_PRESETS[effectiveUser.role] || [];
    return userPerms.includes(permission);
  };

  const switchUser = (userId: string) => {
    const target = users.find((u) => u.id === userId);
    if (target) {
      setCurrentUserId(userId);
    }
  };

  const signInWithGoogle = async () => {
    try {
      setError(null);
      const profile = await authService.signInWithGoogle();
      setUser(profile);
      const matchedUser: User = {
        id: profile.uid,
        uid: profile.uid,
        name: profile.displayName,
        displayName: profile.displayName,
        email: profile.email,
        role: profile.role,
        permissions: profile.permissions,
        isActive: profile.isActive,
        createdAt: profile.createdAt,
        lastLoginAt: profile.lastLoginAt,
      };
      await dbService.saveUser(matchedUser, matchedUser);
      await fetchUsers();
      setCurrentUserId(matchedUser.id);
    } catch (e: any) {
      let friendlyMsg = e?.message || 'فشل تسجيل الدخول عبر Google';
      if (e?.code === 'auth/unauthorized-domain' || e?.message?.includes('unauthorized-domain')) {
        friendlyMsg = 'نطاق المعاينة الحالي غير مدرج في النطاقات المصرح بها (Authorized Domains) في Firebase Authentication.';
      } else if (e?.code === 'auth/popup-blocked' || e?.message?.includes('popup')) {
        friendlyMsg = 'قام المتصفح بحظر النافذة المنبثقة لتسجيل الدخول (Popup Blocked) داخل إطار المعاينة.';
      } else if (e?.code === 'auth/invalid-api-key' || e?.message?.includes('API key')) {
        friendlyMsg = 'مفاتيح مشروع Firebase غير مربوطة بعد. استخدم بطاقات الدخول السريع المباشر.';
      }
      setError(friendlyMsg);
      throw new Error(friendlyMsg);
    }
  };

  const loginAsDemo = () => {
    setUser(DEFAULT_PROFILE);
    setCurrentUserId(DEFAULT_PROFILE.uid);
    setError(null);
  };

  const loginAsUser = (targetUser: User) => {
    const profile: UserProfile = {
      uid: targetUser.id,
      email: targetUser.email,
      displayName: targetUser.name,
      role: targetUser.role,
      permissions: targetUser.permissions || ROLE_PERMISSIONS_PRESETS[targetUser.role] || [],
      isActive: targetUser.isActive,
      assignedOrderTypeIds: targetUser.assignedOrderTypeIds,
      createdAt: targetUser.createdAt,
      lastLoginAt: new Date().toISOString(),
    };
    setUser(profile);
    setCurrentUserId(targetUser.id);
    setError(null);
  };

  const loginWithEmail = async (inputEmail: string) => {
    const cleanEmail = inputEmail.trim().toLowerCase();
    if (!cleanEmail) return;
    const existing = users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      loginAsUser(existing);
      return;
    }
    const isManagerRole = cleanEmail.includes('admin') || cleanEmail.includes('gazar') || cleanEmail === 'a2m.algazar@gmail.com';
    const assignedRole: RoleKey = isManagerRole ? 'manager' : 'assistant';
    const newUser: User = {
      id: `user-${Date.now()}`,
      name: inputEmail.split('@')[0],
      email: cleanEmail,
      role: assignedRole,
      permissions: ROLE_PERMISSIONS_PRESETS[assignedRole],
      isActive: true,
      createdAt: new Date().toISOString(),
    };
    await dbService.saveUser(newUser, newUser);
    await fetchUsers();
    loginAsUser(newUser);
  };

  const clearError = () => {
    setError(null);
  };

  const signOut = async () => {
    try {
      await authService.signOut();
      setUser(null);
    } catch (e: any) {
      setError(e.message);
    }
  };


  const updateUserRole = async (userId: string, newRole: UserRole) => {
    const target = users.find((u) => u.id === userId);
    if (!target) return;
    const updated: User = {
      ...target,
      role: newRole,
      permissions: ROLE_PERMISSIONS_PRESETS[newRole],
    };
    await dbService.saveUser(updated, effectiveUser);
    await fetchUsers();
  };

  const toggleUserActive = async (userId: string) => {
    const target = users.find((u) => u.id === userId);
    if (!target) return;
    const updated: User = { ...target, isActive: !target.isActive };
    await dbService.saveUser(updated, effectiveUser);
    await fetchUsers();
  };

  const updateUser = async (userToUpdate: User) => {
    await dbService.saveUser(userToUpdate, effectiveUser);
    await fetchUsers();
  };

  const updateUserDomains = async (userId: string, domainIds: string[]) => {
    const target = users.find((u) => u.id === userId);
    if (!target) return;
    const updated: User = { ...target, assignedOrderTypeIds: domainIds };
    await dbService.saveUser(updated, effectiveUser);
    await fetchUsers();
  };

  const addUser = async (userData: Omit<User, 'id' | 'createdAt'>) => {
    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}`,
      permissions: ROLE_PERMISSIONS_PRESETS[userData.role],
      createdAt: new Date().toISOString(),
    };
    await dbService.saveUser(newUser, effectiveUser);
    await fetchUsers();
  };

  const deleteUser = async (userId: string) => {
    if (userId === effectiveUser.id) return;
    await dbService.deleteUser(userId, effectiveUser);
    await fetchUsers();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        currentUser: effectiveUser,
        users,
        loading,
        error,
        isManager,
        isAssistant,
        hasPermission,
        switchUser,
        signInWithGoogle,
        loginAsDemo,
        loginAsUser,
        loginWithEmail,
        clearError,
        signOut,
        refreshUsers: fetchUsers,
        updateUserRole,
        toggleUserActive,
        updateUser,
        updateUserDomains,
        addUser,
        deleteUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);

export const AuthGuard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading, error, clearError, signInWithGoogle, loginAsUser, loginWithEmail, users } = useAuth();
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [loginMethod, setLoginMethod] = useState<'quick' | 'email' | 'google'>('quick');
  const [inputEmail, setInputEmail] = useState('');
  const [customError, setCustomError] = useState<string | null>(null);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-stone-950 text-stone-100">
        <div className="text-center p-6 bg-stone-900 rounded-2xl shadow-xl border border-stone-800">
          <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-stone-300 font-medium text-xs">جاري التحقق من هوية الحساب ومزامنة الصلاحيات...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    const managerUser = users.find((u) => u.role === 'manager' || u.email === 'a2m.algazar@gmail.com') || {
      id: 'user-manager-01',
      name: 'أحمد الجزار (مدير المطبخ والمشتريات)',
      email: 'a2m.algazar@gmail.com',
      role: 'manager' as RoleKey,
      isActive: true,
      createdAt: new Date().toISOString(),
    };

    const assistants = users.filter((u) => u.id !== managerUser.id && u.role !== 'manager');

    const handleGoogleAuth = async () => {
      setIsSigningIn(true);
      setCustomError(null);
      clearError();
      try {
        await signInWithGoogle();
      } catch (e: any) {
        console.error('Google Auth Error:', e);
        setCustomError(
          e?.message ||
            'تعذر إتمام تسجيل الدخول عبر Google بسبب قيود النوافذ المنبثقة داخل المعاينة. يمكنك استخدام زر الدخول المباشر أدناه.'
        );
      } finally {
        setIsSigningIn(false);
      }
    };

    const handleEmailSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!inputEmail.trim()) return;
      try {
        await loginWithEmail(inputEmail.trim());
      } catch (err: any) {
        setCustomError(err.message || 'فشل الدخول بالبريد الإلكتروني');
      }
    };

    return (
      <div className="flex items-center justify-center min-h-screen bg-stone-950 p-4 text-stone-100 selection:bg-amber-500 selection:text-stone-950">
        <div className="w-full max-w-lg bg-stone-900 rounded-2xl shadow-2xl p-6 sm:p-8 border border-stone-800 space-y-5">
          {/* Brand Header */}
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-stone-950 font-black text-2xl flex items-center justify-center mx-auto shadow-lg shadow-amber-500/20 border border-amber-400">
              K
            </div>
            <div>
              <h1 className="text-lg font-bold text-stone-100">بوابة تسجيل الدخول | KOMS</h1>
              <p className="text-stone-400 text-xs mt-0.5">نظام إدارة دورة المشتريات وفحص الاستلام بالمطبخ</p>
            </div>
          </div>

          {/* Error Banner with 1-Click Fallback */}
          {(error || customError) && (
            <div className="bg-rose-950/40 border border-rose-900/60 rounded-xl p-3.5 text-xs text-rose-300 space-y-2 text-right">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold text-rose-200">تنبيه في تسجيل الدخول:</p>
                  <p className="text-[11px] text-rose-300/90 mt-0.5 leading-relaxed">
                    {customError || error}
                  </p>
                </div>
              </div>
              <div className="pt-2 border-t border-rose-900/40 flex items-center justify-between">
                <span className="text-[11px] text-rose-400">الحل الفوري الموصى به:</span>
                <button
                  type="button"
                  onClick={() => loginAsUser(managerUser)}
                  className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-3 py-1.5 rounded-lg text-xs transition flex items-center gap-1 shadow-sm"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>دخول مباشر كمدير (a2m.algazar)</span>
                </button>
              </div>
            </div>
          )}

          {/* Login Mode Switcher */}
          <div className="grid grid-cols-3 bg-stone-950 p-1 rounded-xl border border-stone-800 text-xs text-stone-400">
            <button
              type="button"
              onClick={() => setLoginMethod('quick')}
              className={`py-2 rounded-lg font-medium transition ${
                loginMethod === 'quick'
                  ? 'bg-amber-500 text-stone-950 font-bold shadow-sm'
                  : 'hover:text-stone-200'
              }`}
            >
              دخول سريع للفريق
            </button>
            <button
              type="button"
              onClick={() => setLoginMethod('email')}
              className={`py-2 rounded-lg font-medium transition ${
                loginMethod === 'email'
                  ? 'bg-amber-500 text-stone-950 font-bold shadow-sm'
                  : 'hover:text-stone-200'
              }`}
            >
              البريد الإلكتروني
            </button>
            <button
              type="button"
              onClick={() => setLoginMethod('google')}
              className={`py-2 rounded-lg font-medium transition ${
                loginMethod === 'google'
                  ? 'bg-amber-500 text-stone-950 font-bold shadow-sm'
                  : 'hover:text-stone-200'
              }`}
            >
              حساب Google
            </button>
          </div>

          {/* TAB 1: QUICK TEAM LOGIN (1-Click Instant Access) */}
          {loginMethod === 'quick' && (
            <div className="space-y-3">
              <p className="text-[11px] text-stone-400 text-center">
                اختر الحساب المطلوب للدخول الفوري ومباشرة العمليات دون انتظار:
              </p>

              {/* Manager Card */}
              <div className="bg-stone-850/80 hover:bg-stone-800/80 border border-amber-500/30 rounded-xl p-3.5 flex items-center justify-between transition">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center text-sm border border-amber-500/30">
                    أ
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-xs text-stone-100">{managerUser.name}</span>
                      <span className="text-[9px] bg-amber-500/20 text-amber-400 px-1.5 py-0.2 rounded font-bold font-mono">
                        ADMIN
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-400 font-mono mt-0.5">{managerUser.email}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => loginAsUser(managerUser)}
                  className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-3 py-1.5 rounded-lg text-xs transition flex items-center gap-1 shadow-sm"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>دخول كمدير</span>
                </button>
              </div>

              {/* Assistants Cards */}
              <div className="space-y-2 pt-1 max-h-56 overflow-y-auto">
                {assistants.map((ast) => (
                  <div
                    key={ast.id}
                    className="bg-stone-950/60 hover:bg-stone-850 border border-stone-800 rounded-xl p-3 flex items-center justify-between transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-stone-800 text-stone-300 font-bold flex items-center justify-center text-xs">
                        {ast.name.charAt(0)}
                      </div>
                      <div>
                        <span className="font-semibold text-xs text-stone-200 block">{ast.name}</span>
                        <span className="text-[10px] text-stone-400 font-mono">{ast.email}</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => loginAsUser(ast)}
                      className="bg-stone-800 hover:bg-amber-500 hover:text-stone-950 text-stone-300 font-semibold px-2.5 py-1.5 rounded-lg text-xs transition"
                    >
                      دخول كمساعد
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: EMAIL LOGIN */}
          {loginMethod === 'email' && (
            <form onSubmit={handleEmailSubmit} className="space-y-3.5 text-xs text-right">
              <div>
                <label className="block text-stone-300 font-semibold mb-1">البريد الإلكتروني للعمل:</label>
                <div className="relative">
                  <input
                    type="email"
                    value={inputEmail}
                    onChange={(e) => setInputEmail(e.target.value)}
                    placeholder="a2m.algazar@gmail.com"
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl py-2.5 ps-9 pe-3 text-stone-100 font-mono text-xs focus:outline-none focus:border-amber-500 transition"
                    required
                  />
                  <Mail className="w-4 h-4 text-stone-500 absolute top-3 start-3 pointer-events-none" />
                </div>
              </div>

              {/* Quick suggestions */}
              <div className="space-y-1">
                <span className="text-[11px] text-stone-400">حسابات سريعة مقترحة:</span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setInputEmail('a2m.algazar@gmail.com')}
                    className="text-[10px] bg-stone-850 hover:bg-stone-800 text-amber-300 px-2 py-1 rounded-md border border-stone-800 font-mono"
                  >
                    a2m.algazar@gmail.com (مدير)
                  </button>
                  <button
                    type="button"
                    onClick={() => setInputEmail('assistant1@kitchen.internal')}
                    className="text-[10px] bg-stone-850 hover:bg-stone-800 text-stone-300 px-2 py-1 rounded-md border border-stone-800 font-mono"
                  >
                    assistant1@kitchen.internal
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 text-xs mt-3 shadow-sm"
              >
                <LogIn className="w-4 h-4" />
                <span>دخول مباشر إلى النظام</span>
              </button>
            </form>
          )}

          {/* TAB 3: GOOGLE OAUTH */}
          {loginMethod === 'google' && (
            <div className="space-y-3.5 text-center">
              <p className="text-xs text-stone-300 leading-relaxed">
                تسجيل الدخول الموحد بحساب Google عبر Firebase Authentication:
              </p>

              <button
                type="button"
                onClick={handleGoogleAuth}
                disabled={isSigningIn}
                className="w-full py-3 px-4 bg-white text-stone-900 rounded-xl font-bold hover:bg-stone-100 transition flex items-center justify-center gap-2.5 text-xs shadow-md disabled:opacity-50"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>{isSigningIn ? 'جاري فتح نافذة المصادقة...' : 'المتابعة باستخدام Google'}</span>
              </button>

              <div className="bg-stone-950 p-3 rounded-xl border border-stone-800/80 text-[11px] text-stone-400 text-right space-y-1.5">
                <p className="font-semibold text-stone-300 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span>ملاحظة فنية هامة بخصوص نافذة Google:</span>
                </p>
                <p className="leading-relaxed">
                  إذا واجهتك علامة خطأ (Error) في نافذة Google، فالسبب هو قيود المتصفح على النوافذ المنبثقة (Popups) داخل نافذة المعاينة بالـ IFrame، أو عدم إدراج نطاق التطبيق في Firebase Console.
                </p>
                <button
                  type="button"
                  onClick={() => loginAsUser(managerUser)}
                  className="w-full mt-2 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 font-bold py-2 rounded-lg text-xs transition"
                >
                  الدخول الفوري المباشر بحسابك ({managerUser.email})
                </button>
              </div>
            </div>
          )}

          {/* Footer Info */}
          <div className="pt-3 border-t border-stone-800 text-center text-[10px] text-stone-500 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>نظام محمي بالكامل ومطابق لمعايير الأمان RBAC و Cloud Firestore</span>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
