import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { dbService } from '../services/databaseService';
import {
  ActualOrder,
  AppNotification,
  AuditLog,
  InvoiceRecord,
  MasterOrderSchedule,
  OrderType,
  Product,
  ReceivingRecord,
  ScheduleAlertLog,
  Supplier,
  SystemPhoneSettings,
  WorkflowStatus,
} from '../types';
import { useAuth } from './AuthContext';
import { scheduleAlertService, MissedScheduleItem } from '../services/scheduleAlertService';
import { DEFAULT_PHONE_SETTINGS } from '../services/seedData';
import { getWorkWeekString } from '../utils/workWeek';

interface DataContextType {
  orders: ActualOrder[];
  orderTypes: OrderType[];
  products: Product[];
  schedules: MasterOrderSchedule[];
  suppliers: Supplier[];
  receivingRecords: ReceivingRecord[];
  invoices: InvoiceRecord[];
  notifications: AppNotification[];
  auditLogs: AuditLog[];
  missedSchedules: MissedScheduleItem[];
  loading: boolean;
  refreshAll: () => Promise<void>;
  createOrder: (orderData: Partial<ActualOrder>) => Promise<string>;
  updateOrder: (order: ActualOrder, note?: string) => Promise<void>;
  updateOrderStatus: (orderId: string, status: WorkflowStatus, note?: string) => Promise<void>;
  archiveOrder: (orderId: string) => Promise<void>;
  saveCategory: (category: OrderType) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  resetCatalogToDefault: () => Promise<void>;
  saveProduct: (product: Product) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  saveSchedule: (schedule: MasterOrderSchedule) => Promise<void>;
  deleteSchedule: (id: string) => Promise<void>;
  generateOrderFromSchedule: (scheduleId: string) => Promise<string>;
  generateAllDueSchedulesToday: () => Promise<string[]>;
  sendMissedScheduleAlerts: (
    targetDate?: string,
    customEmail?: string
  ) => Promise<{ count: number; mailtoUrl: string; log: ScheduleAlertLog }>;
  createNotification: (notif: Omit<AppNotification, 'id' | 'createdAt' | 'isRead'>) => Promise<void>;
  saveSupplier: (supplier: Supplier) => Promise<void>;
  recordReceiving: (record: ReceivingRecord, updatedOrder: ActualOrder) => Promise<void>;
  saveInvoice: (invoice: InvoiceRecord) => Promise<void>;
  phoneSettings: SystemPhoneSettings;
  savePhoneSettings: (settings: SystemPhoneSettings) => Promise<void>;
  markNotificationRead: (id: string) => Promise<void>;
  getMetrics: () => {
    totalOrders: number;
    completedOrders: number;
    overdueOrders: number;
    rejectedOrders: number;
    inProgressOrders: number;
    awaitingDelivery: number;
    receivingCount: number;
    invoicePending: number;
    onTimeRate: number;
  };
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, users } = useAuth();
  const [orders, setOrders] = useState<ActualOrder[]>([]);
  const [orderTypes, setOrderTypes] = useState<OrderType[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [schedules, setSchedules] = useState<MasterOrderSchedule[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [receivingRecords, setReceivingRecords] = useState<ReceivingRecord[]>([]);
  const [invoices, setInvoices] = useState<InvoiceRecord[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [phoneSettings, setPhoneSettings] = useState<SystemPhoneSettings>(DEFAULT_PHONE_SETTINGS);
  const [loading, setLoading] = useState(true);

  const refreshAll = useCallback(async () => {
    try {
      const [
        fetchedOrders,
        fetchedTypes,
        fetchedProducts,
        fetchedSchedules,
        fetchedSuppliers,
        fetchedReceiving,
        fetchedInvoices,
        fetchedNotifications,
        fetchedAuditLogs,
        fetchedPhoneSettings,
      ] = await Promise.all([
        dbService.getOrders(true),
        dbService.getOrderTypes(),
        dbService.getProducts(),
        dbService.getSchedules(),
        dbService.getSuppliers(),
        dbService.getReceivingRecords(),
        dbService.getInvoices(),
        dbService.getNotifications(currentUser.role === 'manager' ? undefined : currentUser.id),
        dbService.getAuditLogs(),
        dbService.getPhoneSettings(),
      ]);

      setOrders(fetchedOrders);
      setOrderTypes(fetchedTypes);
      setProducts(fetchedProducts);
      setSchedules(fetchedSchedules);
      setSuppliers(fetchedSuppliers);
      setReceivingRecords(fetchedReceiving);
      setInvoices(fetchedInvoices);
      setNotifications(fetchedNotifications);
      setAuditLogs(fetchedAuditLogs);
      setPhoneSettings(fetchedPhoneSettings);
    } catch (e) {
      console.error('Failed to refresh kitchen data:', e);
    } finally {
      setLoading(false);
    }
  }, [currentUser]);

  const savePhoneSettings = async (settings: SystemPhoneSettings) => {
    await dbService.savePhoneSettings(settings, currentUser);
    setPhoneSettings(settings);
  };

  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  const createOrder = async (orderData: Partial<ActualOrder>): Promise<string> => {
    const id = await dbService.generateNextOrderId();
    const now = new Date().toISOString();

    const newOrder: ActualOrder = {
      id,
      orderNumber: orderData.orderNumber || id,
      orderTypeId: orderData.orderTypeId || 'cat-veg',
      orderDate: orderData.orderDate || new Date().toISOString().split('T')[0],
      orderingDeadline: orderData.orderingDeadline || new Date(Date.now() + 12 * 3600 * 1000).toISOString(),
      expectedDeliveryTime: orderData.expectedDeliveryTime,
      fixedArrivalHour: orderData.fixedArrivalHour || '13:00',
      receivingChefArrivalTime: orderData.receivingChefArrivalTime,
      isVeg24hDelayed: orderData.isVeg24hDelayed,
      requesterId: currentUser.id,
      primaryAssigneeId: orderData.primaryAssigneeId || currentUser.id,
      backupAssigneeId: orderData.backupAssigneeId,
      supplierId: orderData.supplierId,
      purchasingChannel: orderData.purchasingChannel || 'واتساب',
      priority: orderData.priority || 'normal',
      status: orderData.status || 'PLANNED',
      items: orderData.items || [],
      requiresApproval: !!orderData.requiresApproval,
      isApproved: orderData.requiresApproval ? false : true,
      masterScheduleId: orderData.masterScheduleId,
      notes: orderData.notes || '',
      workWeek: orderData.workWeek || getWorkWeekString(orderData.orderDate || new Date()),
      recipientType: orderData.recipientType,
      recipientPhone: orderData.recipientPhone,
      recipientName: orderData.recipientName,
      ccSentToChef: orderData.ccSentToChef,
      statusHistory: [
        {
          status: orderData.status || 'PLANNED',
          changedBy: currentUser.id,
          changedByName: currentUser.name,
          timestamp: now,
          note: 'إنشاء الطلبية المبدئية',
        },
      ],
      createdAt: now,
      updatedAt: now,
    };

    await dbService.createOrder(newOrder, currentUser);
    await refreshAll();
    return id;
  };

  const updateOrder = async (order: ActualOrder, note?: string) => {
    await dbService.updateOrder(order, currentUser, note);
    await refreshAll();
  };

  const updateOrderStatus = async (orderId: string, status: WorkflowStatus, note?: string) => {
    await dbService.updateOrderStatus(orderId, status, currentUser, note);
    await refreshAll();
  };

  const archiveOrder = async (orderId: string) => {
    await dbService.archiveOrder(orderId, currentUser);
    await refreshAll();
  };

  const saveCategory = async (category: OrderType) => {
    await dbService.saveOrderType(category, currentUser);
    await refreshAll();
  };

  const deleteCategory = async (id: string) => {
    await dbService.deleteOrderType(id, currentUser);
    await refreshAll();
  };

  const resetCatalogToDefault = async () => {
    await dbService.resetCatalogToDefault(currentUser);
    await refreshAll();
  };

  const saveProduct = async (product: Product) => {
    await dbService.saveProduct(product, currentUser);
    await refreshAll();
  };

  const deleteProduct = async (id: string) => {
    await dbService.deleteProduct(id, currentUser);
    await refreshAll();
  };

  const saveSchedule = async (schedule: MasterOrderSchedule) => {
    await dbService.saveSchedule(schedule, currentUser);
    await refreshAll();
  };

  const deleteSchedule = async (id: string) => {
    await dbService.deleteSchedule(id, currentUser);
    await refreshAll();
  };

  const generateOrderFromSchedule = async (scheduleId: string): Promise<string> => {
    const schedule = schedules.find((s) => s.id === scheduleId);
    if (!schedule) throw new Error('الجدول الدوري غير موجود');

    // Prevent duplicate occurrence for same date
    const today = new Date().toISOString().split('T')[0];
    const existing = orders.find(
      (o) => o.masterScheduleId === scheduleId && o.orderDate === today && !o.isArchived
    );
    if (existing) {
      throw new Error(`تم توليد طلبية مسبقاً لهذا الجدول بتاريخ اليوم (${existing.id})`);
    }

    // Get products for category
    const categoryProducts = products.filter((p) => p.orderTypeId === schedule.orderTypeId && p.isActive);

    const deliveryHours = schedule.requiredDeliveryHours || 12;
    const deadlineTime = new Date();
    deadlineTime.setHours(deadlineTime.getHours() + deliveryHours);

    const orderItems = schedule.itemTemplates && schedule.itemTemplates.length > 0
      ? schedule.itemTemplates.map((t, idx) => ({
          id: `item-${Date.now()}-${idx}-${t.productId}`,
          productId: t.productId,
          productName: t.productNameAr,
          requestedQty: t.defaultRequestedQty || 1,
          unit: t.unit || 'كجم',
          orderedQty: t.defaultRequestedQty || 1,
          receivedQty: 0,
          rejectedQty: 0,
          outstandingQty: t.defaultRequestedQty || 1,
          itemStatus: 'pending' as const,
        }))
      : categoryProducts.map((p) => ({
          id: `item-${Date.now()}-${p.id}`,
          productId: p.id,
          productName: p.nameAr || p.name || 'صنف',
          requestedQty: 1,
          unit: p.defaultUnit || p.unit || 'كجم',
          orderedQty: 1,
          receivedQty: 0,
          rejectedQty: 0,
          outstandingQty: 1,
          itemStatus: 'pending' as const,
        }));

    const orderId = await createOrder({
      orderTypeId: schedule.orderTypeId,
      orderDate: today,
      orderingDeadline: new Date().toISOString(),
      expectedDeliveryTime: deadlineTime.toISOString(),
      primaryAssigneeId: schedule.primaryAssigneeId,
      backupAssigneeId: schedule.backupAssigneeId,
      supplierId: schedule.supplierId,
      purchasingChannel: schedule.purchasingChannel,
      priority: 'normal',
      status: 'DUE',
      requiresApproval: schedule.requiresApproval,
      masterScheduleId: schedule.id,
      items: orderItems,
      notes: `تم توليد هذه الطلبية آلياً من جدول التوريد الدوري: ${schedule.name}`,
    });

    schedule.lastGeneratedDate = today;
    await dbService.saveSchedule(schedule, currentUser);

    return orderId;
  };

  const saveSupplier = async (supplier: Supplier) => {
    await dbService.saveSupplier(supplier, currentUser);
    await refreshAll();
  };

  const recordReceiving = async (record: ReceivingRecord, updatedOrder: ActualOrder) => {
    await dbService.recordReceiving(record, updatedOrder, currentUser);
    await refreshAll();
  };

  const saveInvoice = async (invoice: InvoiceRecord) => {
    await dbService.saveInvoice(invoice, currentUser);
    await refreshAll();
  };

  const markNotificationRead = async (id: string) => {
    await dbService.markNotificationRead(id);
    await refreshAll();
  };

  const createNotification = async (notif: Omit<AppNotification, 'id' | 'createdAt' | 'isRead'>) => {
    await dbService.createNotification(notif);
    await refreshAll();
  };

  const missedSchedules = useMemo(() => {
    return scheduleAlertService.getMissedSchedules(
      schedules,
      orders,
      orderTypes,
      suppliers,
      users
    );
  }, [schedules, orders, orderTypes, suppliers, users]);

  const sendMissedScheduleAlerts = async (targetDate?: string, customEmail?: string) => {
    const missed = scheduleAlertService.getMissedSchedules(
      schedules,
      orders,
      orderTypes,
      suppliers,
      users,
      targetDate
    );

    if (missed.length === 0) {
      throw new Error('لا توجد جداول توريد مستحقة متأخرة عن التوليد اليوم');
    }

    const result = await scheduleAlertService.triggerMissedScheduleAlerts(missed, {
      currentUser,
      createNotification: async (notif) => {
        await dbService.createNotification(notif);
      },
      targetDate,
      customEmail,
    });

    await refreshAll();
    return {
      count: result.count,
      mailtoUrl: result.mailtoUrl,
      log: result.log,
    };
  };

  const generateAllDueSchedulesToday = async (): Promise<string[]> => {
    const today = new Date().toISOString().split('T')[0];
    const missed = scheduleAlertService.getMissedSchedules(
      schedules,
      orders,
      orderTypes,
      suppliers,
      users,
      today
    );

    const generatedIds: string[] = [];
    for (const item of missed) {
      try {
        const id = await generateOrderFromSchedule(item.schedule.id);
        generatedIds.push(id);
      } catch (e) {
        console.warn(`Skipped schedule ${item.schedule.id}:`, e);
      }
    }

    await refreshAll();
    return generatedIds;
  };

  const getMetrics = () => {
    const activeOrders = orders.filter((o) => !o.isArchived);
    const now = new Date();

    const totalOrders = activeOrders.length;
    const completedOrders = activeOrders.filter((o) => o.status === 'COMPLETED').length;
    
    // An order is overdue if deadline passed and it's not yet COMPLETED or VERIFIED
    const overdueOrders = activeOrders.filter((o) => {
      if (['COMPLETED', 'VERIFIED', 'CANCELLED'].includes(o.status)) return false;
      return new Date(o.orderingDeadline).getTime() < now.getTime();
    }).length;

    const rejectedOrders = activeOrders.filter(
      (o) => o.status === 'PARTIALLY_REJECTED' || o.items.some((i) => i.rejectedQty > 0)
    ).length;

    const inProgressOrders = activeOrders.filter((o) =>
      ['DUE', 'ORDERING', 'ORDERED'].includes(o.status)
    ).length;

    const awaitingDelivery = activeOrders.filter((o) => o.status === 'AWAITING_DELIVERY').length;
    const receivingCount = activeOrders.filter((o) =>
      ['RECEIVING', 'PARTIALLY_RECEIVED'].includes(o.status)
    ).length;
    const invoicePending = activeOrders.filter((o) => o.status === 'INVOICE_PENDING').length;

    const onTimeRate = totalOrders > 0
      ? Math.round(((totalOrders - overdueOrders) / totalOrders) * 100)
      : 100;

    return {
      totalOrders,
      completedOrders,
      overdueOrders,
      rejectedOrders,
      inProgressOrders,
      awaitingDelivery,
      receivingCount,
      invoicePending,
      onTimeRate,
    };
  };

  return (
    <DataContext.Provider
      value={{
        orders,
        orderTypes,
        products,
        schedules,
        suppliers,
        receivingRecords,
        invoices,
        notifications,
        auditLogs,
        missedSchedules,
        loading,
        refreshAll,
        createOrder,
        updateOrder,
        updateOrderStatus,
        archiveOrder,
        saveCategory,
        deleteCategory,
        resetCatalogToDefault,
        saveProduct,
        deleteProduct,
        saveSchedule,
        deleteSchedule,
        generateOrderFromSchedule,
        generateAllDueSchedulesToday,
        sendMissedScheduleAlerts,
        createNotification,
        saveSupplier,
        recordReceiving,
        saveInvoice,
        phoneSettings,
        savePhoneSettings,
        markNotificationRead,
        getMetrics,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
