import { 
  assertFails, 
  assertSucceeds, 
  initializeTestEnvironment, 
  RulesTestEnvironment 
} from '@firebase/rules-unit-testing';
import { doc, getDoc, setDoc, deleteDoc } from 'firebase/firestore';
import fs from 'fs';

describe('Firestore Security Rules Unit Tests', () => {
  let testEnv: RulesTestEnvironment;

  beforeAll(async () => {
    testEnv = await initializeTestEnvironment({
      projectId: 'koms-security-test',
      firestore: {
        rules: fs.readFileSync('firestore.rules', 'utf8'),
      },
    });
  });

  afterAll(async () => {
    await testEnv.cleanup();
  });

  beforeEach(async () => {
    await testEnv.clearFirestore();
  });

  test('مدير النظام يمتلك صلاحية قراءة كافة الطلبات', async () => {
    const managerContext = testEnv.authenticatedContext('manager_1', { role: 'manager' });
    // تمهيد بيانات مستند المستخدم كمدير
    await testEnv.withSecurityRulesDisabled(async (context) => {
      await setDoc(doc(context.firestore(), 'users/manager_1'), {
        role: 'manager',
        permissions: ['orders.read.all'],
      });
      await setDoc(doc(context.firestore(), 'orders/ord_100'), {
        orderCode: 'KOMS-2026-0001',
        assignedTo: 'assistant_2',
      });
    });

    const orderRef = doc(managerContext.firestore(), 'orders/ord_100');
    await assertSucceeds(getDoc(orderRef));
  });

  test('المساعد يُحظر عليه قراءة طلب غير مسند إليه', async () => {
    const assistantContext = testEnv.authenticatedContext('assistant_1');
    await testEnv.withSecurityRulesDisabled(async (context) => {
      await setDoc(doc(context.firestore(), 'users/assistant_1'), {
        role: 'assistant',
        permissions: ['orders.read.assigned'],
      });
      await setDoc(doc(context.firestore(), 'orders/ord_200'), {
        orderCode: 'KOMS-2026-0002',
        assignedTo: 'different_user',
      });
    });

    const orderRef = doc(assistantContext.firestore(), 'orders/ord_200');
    await assertFails(getDoc(orderRef));
  });

  test('حظر مسح سجلات التدقيق (auditLogs) نهائياً لجميع المستخدمين', async () => {
    const managerContext = testEnv.authenticatedContext('manager_1');
    await testEnv.withSecurityRulesDisabled(async (context) => {
      await setDoc(doc(context.firestore(), 'users/manager_1'), { role: 'manager' });
      await setDoc(doc(context.firestore(), 'auditLogs/log_1'), {
        action: 'ORDER_CLOSED',
        timestamp: new Date().toISOString(),
      });
    });

    const logRef = doc(managerContext.firestore(), 'auditLogs/log_1');
    await assertFails(deleteDoc(logRef));
  });

  test('حظر اعتماد الفواتير من قبل المساعد دون إذن invoices.verify', async () => {
    const assistantContext = testEnv.authenticatedContext('assistant_1');
    await testEnv.withSecurityRulesDisabled(async (context) => {
      await setDoc(doc(context.firestore(), 'users/assistant_1'), {
        role: 'assistant',
        permissions: ['orders.read.assigned'],
      });
    });

    const invoiceRef = doc(assistantContext.firestore(), 'invoices/inv_1');
    await assertFails(setDoc(invoiceRef, {
      invoiceNumber: 'INV-001',
      invoiceTotalAmountEGP: 5000,
    }));
  });
});
