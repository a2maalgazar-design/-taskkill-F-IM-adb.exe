import React, { useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  FileCheck2,
  Plus,
  ShieldAlert,
  ShieldCheck,
  Thermometer,
  Truck,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { ActualOrder, ReceivingRecord, WorkflowStatus } from '../../types';
import { formatDateTime } from '../../utils/statusLabels';
import { inventoryService } from '../../features/inventory/api/inventoryService';

interface ReceivingViewProps {
  initialOrder?: ActualOrder | null;
}

export const ReceivingView: React.FC<ReceivingViewProps> = ({ initialOrder }) => {
  const { currentUser, isManager } = useAuth();
  const { orders, receivingRecords, recordReceiving, suppliers, orderTypes } = useData();

  // Orders awaiting receiving or in receiving stage
  const eligibleOrders = orders.filter(
    (o) =>
      !o.isArchived &&
      ['AWAITING_DELIVERY', 'RECEIVING', 'PARTIALLY_RECEIVED', 'PARTIALLY_REJECTED', 'ORDERED'].includes(
        o.status
      )
  );

  const [selectedOrderId, setSelectedOrderId] = useState<string>(
    initialOrder?.id || eligibleOrders[0]?.id || ''
  );

  const activeOrder = orders.find((o) => o.id === selectedOrderId);

  // Form states for the selected order
  const [packageCondition, setPackageCondition] = useState<'intact' | 'damaged' | 'opened' | 'acceptable'>(
    'intact'
  );
  const [productCondition, setProductCondition] = useState<
    'fresh_compliant' | 'minor_issues' | 'non_compliant_rejected'
  >('fresh_compliant');
  const [temperatureCelsius, setTemperatureCelsius] = useState<string>('4.0');
  const [expiryDateChecked, setExpiryDateChecked] = useState(true);
  const [inspectionResult, setInspectionResult] = useState<'ACCEPTED' | 'PARTIALLY_ACCEPTED' | 'REJECTED'>(
    'ACCEPTED'
  );
  const [rejectionReason, setRejectionReason] = useState('');
  const [notes, setNotes] = useState('');
  const [chefArrivalTime, setChefArrivalTime] = useState<string>(
    new Date().toISOString().substring(0, 16)
  );

  // Check if vegetable order is delayed > 24 hours past the 1:00 PM fixed deadline
  const isVegOrder = activeOrder?.orderTypeId === 'cat-veg' || (activeOrder?.orderNumber && activeOrder.orderNumber.includes('VEG'));
  const isVeg24hDelayed = React.useMemo(() => {
    if (!activeOrder || !isVegOrder) return false;
    const baseDate = activeOrder.orderDate || new Date().toISOString().split('T')[0];
    const fixedArrivalMs = new Date(`${baseDate}T13:00:00`).getTime();
    return (Date.now() - fixedArrivalMs) / (1000 * 3600) >= 24;
  }, [activeOrder, isVegOrder]);

  const isPastFixedOnePm = React.useMemo(() => {
    if (!chefArrivalTime) return false;
    const arrivalDate = new Date(chefArrivalTime);
    const hours = arrivalDate.getHours();
    const minutes = arrivalDate.getMinutes();
    return hours * 60 + minutes > 13 * 60;
  }, [chefArrivalTime]);

  // Item quantities receiving map
  const [itemsQuantities, setItemsQuantities] = useState<
    Record<string, { received: number; rejected: number; reason: string }>
  >({});

  // Initialize quantities when activeOrder changes
  React.useEffect(() => {
    if (activeOrder) {
      const map: Record<string, { received: number; rejected: number; reason: string }> = {};
      activeOrder.items.forEach((item) => {
        const remaining = item.outstandingQty > 0 ? item.outstandingQty : item.orderedQty;
        map[item.id] = {
          received: remaining,
          rejected: 0,
          reason: '',
        };
      });
      setItemsQuantities(map);
    }
  }, [activeOrder?.id]);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleItemQtyChange = (
    itemId: string,
    field: 'received' | 'rejected' | 'reason',
    val: any
  ) => {
    setItemsQuantities((prev) => ({
      ...prev,
      [itemId]: {
        ...prev[itemId],
        [field]: val,
      },
    }));
  };

  const handleSubmitReceiving = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeOrder) return;

    setIsSubmitting(true);
    setSuccessMessage(null);
    setErrorMessage(null);

    try {
      // Build receiving items list & update order items
      const updatedOrderItems = activeOrder.items.map((item) => {
        const inputs = itemsQuantities[item.id] || {
          received: item.orderedQty,
          rejected: 0,
          reason: '',
        };
        const newReceived = Number(item.receivedQty || 0) + Number(inputs.received || 0);
        const newRejected = Number(item.rejectedQty || 0) + Number(inputs.rejected || 0);
        const newOutstanding = Math.max(0, item.orderedQty - newReceived);

        let itemStatus: any = 'pending';
        if (newReceived >= item.orderedQty) itemStatus = 'received_full';
        else if (newReceived > 0) itemStatus = 'received_partial';
        else if (newRejected > 0) itemStatus = 'rejected';

        return {
          ...item,
          receivedQty: newReceived,
          rejectedQty: newRejected,
          outstandingQty: newOutstanding,
          itemStatus,
          rejectionReason: inputs.reason || item.rejectionReason,
        };
      });

      // Determine new order workflow status
      let newOrderStatus: WorkflowStatus = 'INVOICE_PENDING';
      const hasAnyRejected = updatedOrderItems.some((i) => i.rejectedQty > 0);
      const hasOutstanding = updatedOrderItems.some((i) => i.outstandingQty > 0);

      if (inspectionResult === 'REJECTED') {
        newOrderStatus = 'PARTIALLY_REJECTED';
      } else if (hasOutstanding || inspectionResult === 'PARTIALLY_ACCEPTED') {
        newOrderStatus = 'PARTIALLY_RECEIVED';
      } else {
        newOrderStatus = 'INVOICE_PENDING';
      }

      const receivingRecordId = `rec-${Date.now()}`;
      const newRecord: ReceivingRecord = {
        id: receivingRecordId,
        orderId: activeOrder.id,
        supplierId: activeOrder.supplierId,
        receivedAt: new Date().toISOString(),
        receivedBy: currentUser.id,
        receivedByName: currentUser.name,
        packageCondition,
        productCondition,
        temperatureCelsius: temperatureCelsius ? parseFloat(temperatureCelsius) : undefined,
        expiryDateChecked,
        inspectionResult,
        rejectionReason: rejectionReason || undefined,
        items: updatedOrderItems.map((i) => ({
          itemId: i.id,
          productName: i.productName,
          unit: i.unit,
          orderedQty: i.orderedQty,
          receivedQty: itemsQuantities[i.id]?.received || 0,
          rejectedQty: itemsQuantities[i.id]?.rejected || 0,
          rejectionReason: itemsQuantities[i.id]?.reason,
        })),
        notes,
      };

      const arrivalIso = new Date(chefArrivalTime).toISOString();
      const updatedOrder: ActualOrder = {
        ...activeOrder,
        items: updatedOrderItems,
        status: newOrderStatus,
        actualDeliveryTime: arrivalIso,
        receivingChefArrivalTime: arrivalIso,
        isVeg24hDelayed,
        statusHistory: [
          ...(activeOrder.statusHistory || []),
          {
            status: newOrderStatus,
            changedBy: currentUser.id,
            changedByName: currentUser.name,
            timestamp: new Date().toISOString(),
            note: isPastFixedOnePm
              ? `فحص واستلام البضاعة (محضر #${receivingRecordId}) - تأخر الوصول عن الميعاد الثابت (01:00 م) وتم اعتماد توقيت الشيف المستلم: ${chefArrivalTime.replace('T', ' ')}`
              : `فحص واستلام البضاعة (محضر #${receivingRecordId}) - نتيجة: ${inspectionResult}`,
          },
        ],
        updatedAt: new Date().toISOString(),
      };

      await recordReceiving(newRecord, updatedOrder);

      // ترحيل الكميات المستلمة فعلياً إلى المخزون اللحظي ودفعات الصلاحية
      try {
        const receivedForStock = newRecord.items
          .filter((it) => (it.receivedQty || 0) > 0)
          .map((it) => ({
            productId: it.itemId || it.productName,
            productNameAr: it.productName,
            unit: it.unit,
            qty: it.receivedQty || 0,
          }));

        if (receivedForStock.length > 0) {
          await inventoryService.recordOrderReceiptToInventory(
            activeOrder.id,
            activeOrder.orderNumber || activeOrder.id,
            activeOrder.orderTypeId,
            receivedForStock,
            {
              uid: currentUser.id,
              displayName: currentUser.name,
              email: currentUser.email,
              role: currentUser.role,
              permissions: [],
              isActive: true,
              createdAt: '',
              lastLoginAt: '',
            }
          );
        }
      } catch (invErr) {
        console.warn('Could not sync receiving to inventory automatically:', invErr);
      }

      setSuccessMessage(`تم توثيق محضر الاستلام وفحص الجودة وترحيل البضائع للمخزون بنجاح للطلبية ${activeOrder.id}`);
    } catch (err: any) {
      setErrorMessage(err?.message || 'حدث خطأ أثناء حفظ محضر الاستلام');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getCategory = (catId: string) => orderTypes.find((c) => c.id === catId);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-stone-100 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-cyan-400" />
            <span>الاستلام وفحص الجودة المطبخي (Receiving & QA)</span>
          </h1>
          <p className="text-xs text-stone-400">
            فحص البضائع الواصلة، تسجيل درجات الحرارة والتغليف، رصد النواقص وتوثيق التوالف والمرفوضات
          </p>
        </div>
      </div>

      {successMessage && (
        <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-800 text-emerald-200 text-xs flex items-center justify-between animate-in fade-in">
          <span>{successMessage}</span>
          <button onClick={() => setSuccessMessage(null)}>✕</button>
        </div>
      )}

      {errorMessage && (
        <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-200 text-xs flex items-center justify-between animate-in fade-in">
          <span>{errorMessage}</span>
          <button onClick={() => setErrorMessage(null)}>✕</button>
        </div>
      )}

      {/* Main Receiving Module: Left is Inspection Form, Right is Recent Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Inspection Form (8 cols) */}
        <div className="lg:col-span-8 bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm">
          <div className="pb-3 border-b border-stone-800 flex items-center justify-between">
            <h2 className="font-bold text-sm text-stone-100">
              تسجيل محضر فحص شحنة واصلة للمطبخ
            </h2>
            <div className="flex items-center gap-2">
              <span className="text-xs text-stone-400">اختر الطلبية:</span>
              <select
                value={selectedOrderId}
                onChange={(e) => setSelectedOrderId(e.target.value)}
                className="bg-stone-850 border border-stone-800 rounded-xl px-2.5 py-1.5 text-xs text-stone-100 font-mono"
              >
                {eligibleOrders.length === 0 ? (
                  <option value="">لا توجد طلبيات بانتظار الاستلام</option>
                ) : (
                  eligibleOrders.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.id} - ({getCategory(o.orderTypeId)?.nameAr})
                    </option>
                  ))
                )}
              </select>
            </div>
          </div>

          {!activeOrder ? (
            <div className="p-12 text-center text-stone-500 text-xs">
              لا توجد طلبيات محددة للاستلام حالياً. يمكنك تغيير حالة أي طلبية إلى "بانتظار وصول الشحنة" أولاً.
            </div>
          ) : (
            <form onSubmit={handleSubmitReceiving} className="mt-4 space-y-4 text-xs">
              {/* Order Quick Context */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-stone-850 p-3 rounded-xl border border-stone-800">
                <div>
                  <span className="text-stone-400 block text-[11px]">رقم الطلبية:</span>
                  <span className="font-bold font-mono text-stone-100">{activeOrder.id}</span>
                </div>
                <div>
                  <span className="text-stone-400 block text-[11px]">الفئة:</span>
                  <span className="font-bold text-stone-100">
                    {getCategory(activeOrder.orderTypeId)?.nameAr}
                  </span>
                </div>
                <div>
                  <span className="text-stone-400 block text-[11px]">قناة التوريد:</span>
                  <span className="font-bold text-stone-100">{activeOrder.purchasingChannel}</span>
                </div>
                <div>
                  <span className="text-stone-400 block text-[11px]">الفاحص / المستلم:</span>
                  <span className="font-bold text-amber-400">{currentUser.name}</span>
                </div>
              </div>

              {/* 24-Hour Vegetable Delay Critical Alarm */}
              {isVeg24hDelayed && (
                <div className="p-3.5 rounded-xl bg-rose-950/80 border-2 border-rose-600 text-rose-100 flex items-center gap-3 animate-pulse">
                  <ShieldAlert className="w-6 h-6 text-rose-400 shrink-0" />
                  <div>
                    <h4 className="font-bold text-xs text-rose-300">
                      🚨 إنذار حرج: تأخر طلبية الخضار لأكثر من 24 ساعة!
                    </h4>
                    <p className="text-[11px] text-rose-200 mt-0.5">
                      تجاوزت هذه الطلبية 24 ساعة كاملة عن موعد الوصول الثابت (الساعة 01:00 ظهراً). تم إرسال إشعار فوري لمدير المطبخ ويجب توثيق الاستلام واعتماد وقت الشيف.
                    </p>
                  </div>
                </div>
              )}

              {/* Fixed Arrival Time Policy & Receiving Chef Official Timestamp */}
              <div className="p-3 bg-stone-950/80 border border-stone-800 rounded-xl space-y-2">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                      <Truck className="w-4 h-4" />
                    </span>
                    <div>
                      <span className="font-bold text-stone-200 block text-xs">
                        موعد الوصول الثابت للطلبيات اليومية: الساعة 01:00 مساءً كحد أقصى
                      </span>
                      <span className="text-[11px] text-stone-400">
                        في حال تأخر الوصول عن هذا الميعاد، يعتمد الميعاد الخاص بالشيف المسؤول عن الاستلام
                      </span>
                    </div>
                  </div>

                  <div className="w-full sm:w-auto">
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                      ميعاد وصول الشيف المعتمد:
                    </label>
                    <input
                      type="datetime-local"
                      value={chefArrivalTime}
                      onChange={(e) => setChefArrivalTime(e.target.value)}
                      className="bg-stone-900 border border-stone-750 rounded-lg px-2.5 py-1 text-xs text-amber-400 font-mono font-bold focus:outline-none focus:border-amber-500"
                      required
                    />
                  </div>
                </div>

                {isPastFixedOnePm && (
                  <div className="text-[11px] text-amber-300 bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-lg flex items-center gap-2">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>
                      وصلت الشحنة بعد الميعاد الثابت (01:00 م) — سيتم اعتماد ميعاد الشيف المستلم ({chefArrivalTime.replace('T', ' ')}) كمرجع رسمي لوقت التسليم.
                    </span>
                  </div>
                )}
              </div>

              {/* Physical & Safety Inspection Checks */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Packaging Condition */}
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">
                    حالة العبوات والتغليف:
                  </label>
                  <select
                    value={packageCondition}
                    onChange={(e: any) => setPackageCondition(e.target.value)}
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  >
                    <option value="intact">سليمة ومحكمة الإغلاق (Intact)</option>
                    <option value="acceptable">مقبولة تشغيلياً (Acceptable)</option>
                    <option value="opened">مفتوحة جزئياً (Opened)</option>
                    <option value="damaged">تالفة أو ملوثة (Damaged)</option>
                  </select>
                </div>

                {/* Product Freshness Condition */}
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">
                    حالة ومظهر الأصناف (الفرز):
                  </label>
                  <select
                    value={productCondition}
                    onChange={(e: any) => setProductCondition(e.target.value)}
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  >
                    <option value="fresh_compliant">طازجة ومطابقة لمعايير الشيف (Compliant)</option>
                    <option value="minor_issues">ملاحظات طفيفة مقبولة (Minor Issues)</option>
                    <option value="non_compliant_rejected">غير مطابقة وتالفة (Rejected)</option>
                  </select>
                </div>

                {/* Temperature Celsius */}
                <div>
                  <label className="block font-semibold text-stone-300 mb-1 flex items-center justify-between">
                    <span>درجة الحرارة المقاسة:</span>
                    <Thermometer className="w-3.5 h-3.5 text-amber-400" />
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={temperatureCelsius}
                    onChange={(e) => setTemperatureCelsius(e.target.value)}
                    placeholder="مثال: 4.0 °C"
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono"
                  />
                </div>
              </div>

              {/* Items Quantities Table with Received and Rejected */}
              <div className="border border-stone-800 rounded-xl overflow-hidden bg-stone-950/40">
                <div className="bg-stone-850 p-2.5 border-b border-stone-800 font-bold text-stone-200 flex justify-between items-center">
                  <span>فحص بنود الطلبية والكميات الفعلية</span>
                  <span className="text-[11px] text-stone-400 font-normal">
                    قارن الكمية المسلمة مع الكمية المطلوبة
                  </span>
                </div>

                <div className="p-2 space-y-2 max-h-60 overflow-y-auto">
                  {activeOrder.items.map((item) => {
                    const currentValues = itemsQuantities[item.id] || {
                      received: item.orderedQty,
                      rejected: 0,
                      reason: '',
                    };

                    return (
                      <div
                        key={item.id}
                        className="p-3 bg-stone-900 border border-stone-800 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2"
                      >
                        <div className="flex-1">
                          <div className="font-bold text-stone-100 text-xs">
                            {item.productName}
                          </div>
                          <div className="text-[11px] text-stone-400 mt-0.5">
                            الكمية المطلوبة:{' '}
                            <span className="font-mono text-stone-200">
                              {item.orderedQty} {item.unit}
                            </span>
                          </div>
                        </div>

                        {/* Received Qty */}
                        <div className="flex items-center gap-1.5">
                          <span className="text-[11px] text-emerald-400 font-semibold">مستلم:</span>
                          <input
                            type="number"
                            step="any"
                            min="0"
                            value={currentValues.received}
                            onChange={(e) =>
                              handleItemQtyChange(
                                item.id,
                                'received',
                                parseFloat(e.target.value) || 0
                              )
                            }
                            className="w-20 bg-stone-850 border border-stone-800 rounded-lg p-1.5 text-stone-100 font-mono text-center"
                          />
                          <span className="text-stone-400 text-[10px]">{item.unit}</span>
                        </div>

                        {/* Rejected Qty */}
                        <div className="flex items-center gap-1.5">
                          <span className="text-[11px] text-rose-400 font-semibold">مرفوض/تالف:</span>
                          <input
                            type="number"
                            step="any"
                            min="0"
                            value={currentValues.rejected}
                            onChange={(e) =>
                              handleItemQtyChange(
                                item.id,
                                'rejected',
                                parseFloat(e.target.value) || 0
                              )
                            }
                            className="w-16 bg-stone-850 border border-stone-800 rounded-lg p-1.5 text-rose-300 font-mono text-center"
                          />
                        </div>

                        {/* Rejection Note */}
                        {currentValues.rejected > 0 && (
                          <div className="w-full sm:w-44">
                            <input
                              type="text"
                              value={currentValues.reason}
                              onChange={(e) =>
                                handleItemQtyChange(item.id, 'reason', e.target.value)
                              }
                              placeholder="سبب الرفض (ذابل، منتهي، كسر)..."
                              className="w-full bg-stone-850 border border-rose-900/50 rounded-lg p-1.5 text-stone-100 text-[11px]"
                            />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Overall Decision */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">
                    قرار الاستلام الإجمالي:
                  </label>
                  <select
                    value={inspectionResult}
                    onChange={(e: any) => setInspectionResult(e.target.value)}
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-bold"
                  >
                    <option value="ACCEPTED">استلام كامل ومطابق (ACCEPTED)</option>
                    <option value="PARTIALLY_ACCEPTED">
                      استلام جزئي مع وجود نواقص أو توالف (PARTIALLY ACCEPTED)
                    </option>
                    <option value="REJECTED">رفض الشحنة بالكامل وإرجاعها (REJECTED)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">
                    سبب الرفض العام أو الإرجاع:
                  </label>
                  <input
                    type="text"
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    placeholder="إذا تم الرفض الجزئي أو الكلي، اذكر السبب..."
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-300 mb-1">
                  ملاحظات الفاحص الإضافية:
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="ملاحظات توثيقية إضافية..."
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 h-16 resize-none"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-amber-500 hover:bg-amber-400 active:bg-amber-600 disabled:opacity-50 text-stone-950 font-bold py-3 rounded-xl text-xs transition shadow-md flex items-center justify-center gap-2"
                >
                  <FileCheck2 className="w-4 h-4 stroke-[2.5]" />
                  <span>
                    {isSubmitting ? 'جاري توثيق الاستلام...' : 'اعتماد محضر الاستلام والفحص'}
                  </span>
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Recent QA Inspection Records (4 cols) */}
        <div className="lg:col-span-4 bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm flex flex-col">
          <div className="pb-3 border-b border-stone-800 flex items-center justify-between">
            <h3 className="font-bold text-sm text-stone-100">سجل محاضر الفحص السابقة</h3>
            <span className="text-[11px] font-mono text-stone-400">
              {receivingRecords.length} محضر
            </span>
          </div>

          <div className="mt-3 space-y-2.5 flex-1 overflow-y-auto max-h-[70vh]">
            {receivingRecords.length === 0 ? (
              <p className="text-xs text-stone-500 text-center py-8">
                لم يتم تسجيل أي محاضر فحص سابقة حتى الآن
              </p>
            ) : (
              receivingRecords.map((rec) => (
                <div
                  key={rec.id}
                  className="p-3 bg-stone-850 border border-stone-800 rounded-xl text-xs space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-amber-400">{rec.orderId}</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        rec.inspectionResult === 'ACCEPTED'
                          ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800'
                          : rec.inspectionResult === 'PARTIALLY_ACCEPTED'
                          ? 'bg-amber-950/80 text-amber-300 border border-amber-800'
                          : 'bg-rose-950/80 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {rec.inspectionResult === 'ACCEPTED'
                        ? 'مقبول'
                        : rec.inspectionResult === 'PARTIALLY_ACCEPTED'
                        ? 'قبول جزئي'
                        : 'مرفوض'}
                    </span>
                  </div>

                  <div className="text-[11px] text-stone-400">
                    المستلم: {rec.receivedByName} • {formatDateTime(rec.receivedAt)}
                  </div>

                  {rec.temperatureCelsius !== undefined && (
                    <div className="text-[11px] text-stone-300 font-mono">
                      الحرارة: {rec.temperatureCelsius} °C
                    </div>
                  )}

                  {rec.rejectionReason && (
                    <div className="text-[11px] text-rose-300 bg-rose-950/40 p-1.5 rounded border border-rose-900/50">
                      سبب الرفض: {rec.rejectionReason}
                    </div>
                  )}

                  <div className="text-[10px] text-stone-500">
                    {rec.items.length} أصناف مسجلة بالمحضر
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
