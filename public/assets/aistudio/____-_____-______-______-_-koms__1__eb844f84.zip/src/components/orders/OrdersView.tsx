import React, { useState } from 'react';
import {
  AlertCircle,
  Archive,
  Calendar,
  CheckCircle2,
  ClipboardList,
  Clock,
  Eye,
  Filter,
  Kanban,
  List,
  MoreVertical,
  Plus,
  Search,
  ShieldCheck,
  Truck,
  User,
  Users,
  MessageSquare,
  FileCheck,
  Copy,
  Check,
  FileDown,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { ActualOrder, WorkflowStatus } from '../../types';
import {
  PRIORITY_CONFIG,
  WORKFLOW_STATUS_CONFIG,
  formatDateOnly,
  formatDateTime,
} from '../../utils/statusLabels';
import { OrderModal } from './OrderModal';
import { OrderStatusModal } from './OrderStatusModal';
import { WhatsAppDispatchModal } from './WhatsAppDispatchModal';

interface OrdersViewProps {
  onOpenNewOrder: (categoryId?: string) => void;
  filterAssigneeId?: string;
  onNavigateToReceiving?: (order: ActualOrder) => void;
  onNavigateTab?: (tab: any) => void;
}

export const OrdersView: React.FC<OrdersViewProps> = ({
  onOpenNewOrder,
  filterAssigneeId,
  onNavigateToReceiving,
  onNavigateTab,
}) => {
  const { isManager, currentUser, users } = useAuth();
  const {
    orders,
    orderTypes,
    suppliers,
    updateOrder,
    updateOrderStatus,
    archiveOrder,
  } = useData();

  const [viewMode, setViewMode] = useState<'list' | 'kanban' | 'calendar'>('list');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedAssignee, setSelectedAssignee] = useState<string>(filterAssigneeId || 'all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');

  // Modals state
  const [orderToEdit, setOrderToEdit] = useState<ActualOrder | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [orderForStatusChange, setOrderForStatusChange] = useState<ActualOrder | null>(null);
  const [orderForWhatsApp, setOrderForWhatsApp] = useState<ActualOrder | null>(null);
  const [detailedOrder, setDetailedOrder] = useState<ActualOrder | null>(null);
  const [copiedSummary, setCopiedSummary] = useState(false);

  // Filter orders
  const activeOrders = orders.filter((o) => !o.isArchived);

  const handleCopyOrdersSummary = () => {
    const targetOrders = filteredOrders.length > 0 ? filteredOrders : activeOrders;
    const totalItems = targetOrders.reduce((sum, o) => sum + (o.items?.length || 0), 0);
    const todayAr = new Date().toLocaleDateString('ar-EG', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    const report = `📋 *ملخص تقرير طلبات وتوريدات المطبخ — KOMS*
*تاريخ التقرير:* ${todayAr}
*عدد الطلبيات:* ${targetOrders.length} طلبية | *إجمالي البنود:* ${totalItems} صنفاً
*موعد الوصول الثابت:* الساعة 01:00 مساءً كحد أقصى (وفي حال التأخر يعتمد توقيت الشيف المستلم)

${targetOrders
  .map((o, idx) => {
    const cat = orderTypes.find((c) => c.id === o.orderTypeId);
    const sup = suppliers.find((s) => s.id === o.supplierId);
    const itemsPreview = o.items
      .map((i) => `• ${i.productName}: ${i.requestedQty} ${i.unit}`)
      .join('\n   ');
    return `${idx + 1}. *[${o.orderNumber || o.id}]* — *${cat?.nameAr || 'توريد'}*
   • المورد: ${sup?.name || 'مورد الفئة المعتمد'} (${o.purchasingChannel || 'واتساب'})
   • الحالة: ${WORKFLOW_STATUS_CONFIG[o.status]?.labelAr || o.status}
   • المسؤول: ${getAssigneeName(o.primaryAssigneeId)}
   • الأصناف المطلوبة (${o.items.length}):
   ${itemsPreview}`;
  })
  .join('\n\n')}

_تم التجميع والتوثيق آلياً عبر نظام KOMS لإدارة وتنسيق طلبيات المطبخ_`;

    navigator.clipboard.writeText(report);
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 2500);
  };

  const filteredOrders = activeOrders.filter((ord) => {
    if (filterAssigneeId && ord.primaryAssigneeId !== filterAssigneeId && ord.backupAssigneeId !== filterAssigneeId) {
      return false;
    }
    if (selectedAssignee !== 'all' && ord.primaryAssigneeId !== selectedAssignee && ord.backupAssigneeId !== selectedAssignee) {
      return false;
    }
    if (selectedCategory !== 'all' && ord.orderTypeId !== selectedCategory) {
      return false;
    }
    if (selectedStatus !== 'all' && ord.status !== selectedStatus) {
      return false;
    }
    if (selectedPriority !== 'all' && ord.priority !== selectedPriority) {
      return false;
    }
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchesId = ord.id.toLowerCase().includes(q);
      const matchesNotes = ord.notes?.toLowerCase().includes(q);
      const matchesItems = ord.items.some((i) => i.productName.toLowerCase().includes(q));
      if (!matchesId && !matchesNotes && !matchesItems) return false;
    }
    return true;
  });

  const getAssigneeName = (id?: string) => {
    if (!id) return '—';
    const u = users.find((user) => user.id === id);
    return u ? u.name : id;
  };

  const getCategoryName = (id: string) => {
    const cat = orderTypes.find((c) => c.id === id);
    return cat ? cat.nameAr : id;
  };

  const getSupplierName = (id?: string) => {
    if (!id) return 'TBD (بانتظار التحديد)';
    const sup = suppliers.find((s) => s.id === id);
    return sup ? sup.name : id;
  };

  const isOverdue = (ord: ActualOrder) => {
    if (['COMPLETED', 'VERIFIED', 'CANCELLED'].includes(ord.status)) return false;
    return new Date(ord.orderingDeadline).getTime() < Date.now();
  };

  // Kanban Stage grouping
  const KANBAN_STAGES: { id: string; label: string; statuses: WorkflowStatus[] }[] = [
    { id: 'planned', label: 'المخطط والمستحق', statuses: ['PLANNED', 'DUE'] },
    { id: 'ordering', label: 'جاري الطلب للمورد', statuses: ['ORDERING', 'ORDERED'] },
    { id: 'awaiting', label: 'بانتظار الشحنة والتوريد', statuses: ['AWAITING_DELIVERY', 'DELAYED'] },
    { id: 'receiving', label: 'الاستلام وفحص الجودة', statuses: ['RECEIVING', 'PARTIALLY_RECEIVED', 'PARTIALLY_REJECTED'] },
    { id: 'invoicing', label: 'الفواتير والمطابقة', statuses: ['INVOICE_PENDING', 'VERIFIED'] },
    { id: 'done', label: 'مكتمل ومغلق', statuses: ['COMPLETED'] },
  ];

  // 1. طلبات الخضار المتأخرة لأكثر من 24 ساعة عن موعد الوصول الثابت (الساعة 1:00 ظهراً)
  const veg24hDelayedOrders = activeOrders.filter((ord) => {
    const isVeg = ord.orderTypeId === 'cat-veg' || (ord.orderNumber && ord.orderNumber.includes('VEG'));
    if (!isVeg) return false;
    if (['INVOICE_PENDING', 'VERIFIED', 'COMPLETED', 'CANCELLED'].includes(ord.status)) return false;
    const baseDate = ord.orderDate || ord.orderingDeadline?.split('T')[0];
    const fixedArrivalMs = new Date(`${baseDate}T13:00:00`).getTime();
    return (Date.now() - fixedArrivalMs) / (1000 * 3600) >= 24;
  });

  // 2. طلبات الورديات المتأخرة عن مهلة الطلب التي تتطلب طلب آني فوراً
  const shiftOverdueOrders = activeOrders.filter((ord) => {
    if (!['PLANNED', 'DUE', 'ORDERING'].includes(ord.status)) return false;
    return new Date(ord.orderingDeadline).getTime() < Date.now();
  });

  return (
    <div className="space-y-4">
      {/* 24-Hour Vegetable Delay Critical Alarm Banner */}
      {veg24hDelayedOrders.length > 0 && (
        <div className="p-4 rounded-2xl bg-rose-950/90 border-2 border-rose-500 shadow-xl shadow-rose-950/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-pulse">
          <div className="flex items-center gap-3">
            <span className="p-2 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40">
              <AlertCircle className="w-6 h-6" />
            </span>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base text-rose-200">
                🚨 إنذار حرج: تأخرت طلبية الخضار لأكثر من 24 ساعة عن موعد الوصول الثابت!
              </h3>
              <p className="text-xs text-rose-300 mt-0.5">
                تجاوزت ({veg24hDelayedOrders.length}) طلبية خضار مهلة 24 ساعة كاملة عن موعد التوريد الثابت (الساعة 01:00 ظهراً) دون استلام. يجب التواصل الفوري مع المورد لضمان استمرارية المطبخ.
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setSelectedCategory('cat-veg');
              setViewMode('list');
            }}
            className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shrink-0 transition"
          >
            عرض طلبيات الخضار المتأخرة
          </button>
        </div>
      )}

      {/* Shift Deadline Alert Banner */}
      {shiftOverdueOrders.length > 0 && (
        <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400">
              <Clock className="w-4 h-4" />
            </span>
            <div>
              <span className="font-bold text-xs text-amber-300 block">
                ⚠️ تنبيه لمسؤول الوردية ومدير المطبخ: حان موعد الطلب الفعلي
              </span>
              <span className="text-[11px] text-stone-300">
                يوجد ({shiftOverdueOrders.length}) طلبية تجاوزت مهلة التوريد المقررة للوردية — يجب الطلب الآني فوراً لتفادي تعطيل التجهيزات.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Top Header & Search Filters Bar */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-bold text-stone-100">
              {filterAssigneeId ? 'مهامي التشغيلية المسندة' : 'إدارة ومتابعة كافة الطلبيات'}
            </h1>
            <p className="text-xs text-stone-400">
              إجمالي {filteredOrders.length} طلبيات مطابقة لمعايير البحث
            </p>
          </div>

          {/* View Toggles & New Order */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="bg-stone-850 p-1 rounded-xl border border-stone-800 flex items-center">
              <button
                onClick={() => setViewMode('list')}
                className={`p-1.5 rounded-lg text-xs flex items-center gap-1 transition ${
                  viewMode === 'list'
                    ? 'bg-amber-500 text-stone-950 font-bold'
                    : 'text-stone-400 hover:text-white'
                }`}
                title="جدول تفصيلي"
              >
                <List className="w-4 h-4" />
                <span className="hidden sm:inline">قائمة</span>
              </button>
              <button
                onClick={() => setViewMode('kanban')}
                className={`p-1.5 rounded-lg text-xs flex items-center gap-1 transition ${
                  viewMode === 'kanban'
                    ? 'bg-amber-500 text-stone-950 font-bold'
                    : 'text-stone-400 hover:text-white'
                }`}
                title="مراحل كانبان"
              >
                <Kanban className="w-4 h-4" />
                <span className="hidden sm:inline">كانبان</span>
              </button>
              <button
                onClick={() => setViewMode('calendar')}
                className={`p-1.5 rounded-lg text-xs flex items-center gap-1 transition ${
                  viewMode === 'calendar'
                    ? 'bg-amber-500 text-stone-950 font-bold'
                    : 'text-stone-400 hover:text-white'
                }`}
                title="تقويم"
              >
                <Calendar className="w-4 h-4" />
                <span className="hidden sm:inline">تقويم</span>
              </button>
            </div>

            {/* Quick Vegetable Order Direct Action */}
            <button
              onClick={() => (onNavigateTab ? onNavigateTab('veg-order') : onOpenNewOrder('cat-veg'))}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white px-3 py-2 rounded-xl text-xs font-bold transition shadow-md shadow-emerald-950/40"
              title="واجهة طلب طلبيّة الخضروات والتحويل المباشر للواتساب"
            >
              <span>🥬</span>
              <span className="hidden md:inline">طلبية الخضار (واتساب)</span>
              <span className="md:hidden">خضار</span>
            </button>

            {/* 1-Click Copy Orders Aggregated Summary */}
            <button
              onClick={handleCopyOrdersSummary}
              className="flex items-center gap-1.5 bg-stone-850 hover:bg-stone-800 text-amber-300 px-3 py-2 rounded-xl text-xs font-bold transition border border-stone-750 shadow-sm"
              title="نسخ ملخص تقرير الطلبيات اليومية المجمعة بتنسيق واتساب"
            >
              {copiedSummary ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>تم النسخ!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">نسخ ملخص الطلبات</span>
                </>
              )}
            </button>

            <button
              onClick={() => onOpenNewOrder()}
              className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-stone-950 px-3 py-2 rounded-xl text-xs font-bold transition shadow-sm"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>طلب جديد</span>
            </button>
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 pt-2 border-t border-stone-800/80">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-stone-400 absolute right-3 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="بحث برقم الطلب، صنف، ملاحظة..."
              className="w-full bg-stone-850 border border-stone-800 rounded-xl pr-9 pl-3 py-2 text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-stone-850 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-200 focus:outline-none focus:border-amber-500"
          >
            <option value="all">كافة الفئات (الـ 10 فئات)</option>
            {orderTypes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.nameAr}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-stone-850 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-200 focus:outline-none focus:border-amber-500"
          >
            <option value="all">كافة الحالات التشغيلية</option>
            {Object.entries(WORKFLOW_STATUS_CONFIG).map(([key, meta]) => (
              <option key={key} value={key}>
                {meta.labelAr}
              </option>
            ))}
          </select>

          {/* Assignee Filter */}
          {!filterAssigneeId && (
            <select
              value={selectedAssignee}
              onChange={(e) => setSelectedAssignee(e.target.value)}
              className="bg-stone-850 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-200 focus:outline-none focus:border-amber-500"
            >
              <option value="all">كافة المسؤولين</option>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name}
                </option>
              ))}
            </select>
          )}

          {/* Priority Filter */}
          <select
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
            className="bg-stone-850 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-200 focus:outline-none focus:border-amber-500"
          >
            <option value="all">كافة الأولويات</option>
            <option value="normal">عادي</option>
            <option value="urgent">عاجل</option>
            <option value="critical">حرج جداً</option>
          </select>
        </div>

        {/* Order Information Aggregation Summary */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-3 border-t border-stone-800/80 text-xs">
          <div className="bg-stone-950/70 p-2.5 rounded-xl border border-stone-800 flex items-center justify-between">
            <span className="text-stone-400">إجمالي الطلبيات:</span>
            <strong className="text-stone-100 font-mono text-sm">{filteredOrders.length}</strong>
          </div>
          <div className="bg-stone-950/70 p-2.5 rounded-xl border border-stone-800 flex items-center justify-between">
            <span className="text-stone-400">إجمالي البنود المطلوبة:</span>
            <strong className="text-amber-400 font-mono text-sm">
              {filteredOrders.reduce((sum, o) => sum + (o.items?.length || 0), 0)} صنف
            </strong>
          </div>
          <div className="bg-stone-950/70 p-2.5 rounded-xl border border-stone-800 flex items-center justify-between">
            <span className="text-stone-400">بانتظار الوصول (01:00 م):</span>
            <strong className="text-cyan-400 font-mono text-sm">
              {filteredOrders.filter((o) => ['ORDERING', 'ORDERED', 'AWAITING_DELIVERY'].includes(o.status)).length}
            </strong>
          </div>
          <div className="bg-stone-950/70 p-2.5 rounded-xl border border-stone-800 flex items-center justify-between">
            <span className="text-stone-400">مكتملة ومستلمة:</span>
            <strong className="text-emerald-400 font-mono text-sm">
              {filteredOrders.filter((o) => ['COMPLETED', 'VERIFIED', 'INVOICE_PENDING'].includes(o.status)).length}
            </strong>
          </div>
        </div>
      </div>

      {/* VIEW 1: LIST VIEW */}
      {viewMode === 'list' && (
        <div className="bg-stone-900 border border-stone-800 rounded-2xl overflow-hidden shadow-sm">
          {filteredOrders.length === 0 ? (
            <div className="p-12 text-center text-stone-400">
              <ClipboardList className="w-10 h-10 mx-auto mb-2 text-stone-600" />
              <p className="font-semibold text-sm">لا توجد طلبيات مسجلة مطابقة لمعايير البحث</p>
              <p className="text-xs text-stone-500 mt-1">
                يمكنك الضغط على زر "طلب جديد" أو توليد الطلبيات من جدول التوريد الدوري
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs text-stone-300">
                <thead className="bg-stone-850/80 text-stone-400 border-b border-stone-800 uppercase text-[11px] font-bold">
                  <tr>
                    <th className="p-3">رقم الطلبية</th>
                    <th className="p-3">الفئة</th>
                    <th className="p-3">الأولوية</th>
                    <th className="p-3">الحالة التشغيلية</th>
                    <th className="p-3">البنود والأصناف</th>
                    <th className="p-3">المسؤول</th>
                    <th className="p-3">المورد</th>
                    <th className="p-3">مهلة الطلب / التسليم</th>
                    <th className="p-3 text-center">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-800/60 font-medium">
                  {filteredOrders.map((ord) => {
                    const statusMeta = WORKFLOW_STATUS_CONFIG[ord.status];
                    const priorityMeta = PRIORITY_CONFIG[ord.priority];
                    const overdue = isOverdue(ord);

                    return (
                      <tr
                        key={ord.id}
                        className={`hover:bg-stone-850/60 transition cursor-pointer ${
                          overdue ? 'bg-rose-950/20' : ''
                        }`}
                        onClick={() => setDetailedOrder(ord)}
                      >
                        {/* ID */}
                        <td className="p-3">
                          <div className="font-bold font-mono text-stone-100 flex items-center gap-1.5">
                            <span>{ord.id}</span>
                            {overdue && (
                              <span
                                title="تجاوزت مهلة الإرسال"
                                className="w-2 h-2 rounded-full bg-rose-500 animate-ping"
                              />
                            )}
                          </div>
                          <div className="text-[10px] text-stone-500 font-mono mt-0.5">
                            {formatDateOnly(ord.orderDate)}
                          </div>
                        </td>

                        {/* Category */}
                        <td className="p-3">
                          <span className="font-semibold text-stone-200">
                            {getCategoryName(ord.orderTypeId)}
                          </span>
                        </td>

                        {/* Priority */}
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${priorityMeta.bg} ${priorityMeta.color}`}
                          >
                            {priorityMeta.labelAr}
                          </span>
                        </td>

                        {/* Status */}
                        <td className="p-3">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[11px] font-bold border inline-block ${statusMeta.bgClass} ${statusMeta.textClass} ${statusMeta.borderClass}`}
                          >
                            {statusMeta.labelAr}
                          </span>
                        </td>

                        {/* Items */}
                        <td className="p-3">
                          <div className="text-stone-200 font-semibold">
                            {ord.items.length} أصناف
                          </div>
                          <div className="text-[10px] text-stone-400 truncate max-w-[150px]">
                            {ord.items.map((i) => i.productName).join('، ')}
                          </div>
                        </td>

                        {/* Assignee (Responsible) */}
                        <td className="p-3">
                          <div className="text-stone-200 font-medium truncate max-w-[120px]">
                            {getAssigneeName(ord.primaryAssigneeId)}
                          </div>
                        </td>

                        {/* Supplier */}
                        <td className="p-3">
                          <div className="text-stone-300 truncate max-w-[120px]">
                            {getSupplierName(ord.supplierId)}
                          </div>
                          <div className="text-[10px] text-stone-500">
                            {ord.purchasingChannel}
                          </div>
                        </td>

                        {/* Deadlines: Shift Deadline & Fixed Arrival Rule */}
                        <td className="p-3 text-[11px]">
                          <div className="text-stone-300 font-mono">
                            طلب: {formatDateTime(ord.orderingDeadline)}
                          </div>
                          <div className="text-amber-400 font-mono text-[10px] mt-0.5">
                            وصول ثابت: 01:00 م
                          </div>
                          {ord.receivingChefArrivalTime && (
                            <div className="text-emerald-400 font-mono text-[10px] mt-0.5">
                              شيف مستلم: {formatDateTime(ord.receivingChefArrivalTime)}
                            </div>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="p-3 text-center" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-center gap-1.5">
                            {/* WhatsApp Dispatch */}
                            <button
                              onClick={() => setOrderForWhatsApp(ord)}
                              className="p-1.5 text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/40 rounded-lg border border-emerald-500/20 transition"
                              title="إرسال أمر الشراء عبر WhatsApp"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </button>

                            {/* Update Status */}
                            <button
                              onClick={() => setOrderForStatusChange(ord)}
                              className="px-2.5 py-1 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 rounded-lg text-xs font-semibold transition"
                              title="تحديث الحالة التشغيلية"
                            >
                              الحالة
                            </button>

                            {/* Receiving Action if ready */}
                            {['AWAITING_DELIVERY', 'RECEIVING', 'PARTIALLY_RECEIVED'].includes(
                              ord.status
                            ) &&
                              onNavigateToReceiving && (
                                <button
                                  onClick={() => onNavigateToReceiving(ord)}
                                  className="px-2 py-1 bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 rounded-lg text-xs font-semibold transition"
                                  title="فحص واستلام الشحنة"
                                >
                                  فحص
                                </button>
                              )}

                            {/* Edit */}
                            {isManager && (
                              <button
                                onClick={() => {
                                  setOrderToEdit(ord);
                                  setIsEditModalOpen(true);
                                }}
                                className="p-1 text-stone-400 hover:text-stone-100 rounded-lg hover:bg-stone-800"
                                title="تعديل"
                              >
                                ✎
                              </button>
                            )}

                            {/* Archive if completed */}
                            {ord.status === 'COMPLETED' && isManager && (
                              <button
                                onClick={() => archiveOrder(ord.id)}
                                className="p-1 text-stone-400 hover:text-amber-400 rounded-lg hover:bg-stone-800"
                                title="أرشفة"
                              >
                                <Archive className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: KANBAN VIEW */}
      {viewMode === 'kanban' && (
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3 overflow-x-auto pb-4">
          {KANBAN_STAGES.map((col) => {
            const colOrders = filteredOrders.filter((o) => col.statuses.includes(o.status));

            return (
              <div
                key={col.id}
                className="bg-stone-900 border border-stone-800 rounded-2xl p-3 flex flex-col min-w-[240px]"
              >
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-stone-800">
                  <span className="font-bold text-xs text-stone-200">{col.label}</span>
                  <span className="text-[11px] font-mono bg-stone-800 text-stone-300 px-2 py-0.5 rounded-full font-bold">
                    {colOrders.length}
                  </span>
                </div>

                <div className="space-y-2 flex-1 overflow-y-auto max-h-[70vh]">
                  {colOrders.length === 0 ? (
                    <div className="p-4 text-center text-stone-600 text-[11px]">
                      فارغ حالياً
                    </div>
                  ) : (
                    colOrders.map((ord) => {
                      const statusMeta = WORKFLOW_STATUS_CONFIG[ord.status];
                      const priorityMeta = PRIORITY_CONFIG[ord.priority];
                      const overdue = isOverdue(ord);

                      return (
                        <div
                          key={ord.id}
                          onClick={() => setDetailedOrder(ord)}
                          className={`p-3 rounded-xl bg-stone-850 hover:bg-stone-800/90 border cursor-pointer transition shadow-sm ${
                            overdue
                              ? 'border-rose-800 bg-rose-950/20'
                              : 'border-stone-800 hover:border-stone-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold font-mono text-xs text-stone-100">
                              {ord.id}
                            </span>
                            <span
                              className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${priorityMeta.bg} ${priorityMeta.color}`}
                            >
                              {priorityMeta.labelAr}
                            </span>
                          </div>

                          <div className="text-[11px] font-semibold text-amber-400 mt-1">
                            {getCategoryName(ord.orderTypeId)}
                          </div>

                          <div className="text-[11px] text-stone-400 mt-1">
                            {ord.items.length} أصناف • {getAssigneeName(ord.primaryAssigneeId)}
                          </div>

                          <div className="mt-2.5 pt-2 border-t border-stone-800/80 flex items-center justify-between">
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${statusMeta.bgClass} ${statusMeta.textClass}`}
                            >
                              {statusMeta.labelAr}
                            </span>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setOrderForStatusChange(ord);
                              }}
                              className="text-[10px] bg-stone-800 hover:bg-amber-500 hover:text-stone-950 px-2 py-0.5 rounded text-stone-300 font-semibold transition"
                            >
                              تغيير
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* VIEW 3: CALENDAR VIEW */}
      {viewMode === 'calendar' && (
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4">
          <div className="flex items-center justify-between pb-3 border-b border-stone-800 mb-4">
            <span className="font-bold text-sm text-stone-200">
              تقويم مواعيد الطلبيات ومواعيد الاستلام
            </span>
            <span className="text-xs text-stone-400">
              منظمة بحسب تاريخ الطلب والتسليم
            </span>
          </div>

          <div className="space-y-4">
            {Array.from(new Set(filteredOrders.map((o) => o.orderDate)))
              .sort()
              .reverse()
              .map((date) => {
                const dayOrders = filteredOrders.filter((o) => o.orderDate === date);
                return (
                  <div key={date} className="bg-stone-850 border border-stone-800 rounded-xl p-3">
                    <div className="flex items-center gap-2 mb-2 pb-2 border-b border-stone-800">
                      <Calendar className="w-4 h-4 text-amber-400" />
                      <span className="font-bold text-xs text-stone-200 font-mono">
                        {formatDateOnly(date)}
                      </span>
                      <span className="text-[11px] text-stone-500">
                        ({dayOrders.length} طلبيات)
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                      {dayOrders.map((ord) => {
                        const statusMeta = WORKFLOW_STATUS_CONFIG[ord.status];
                        return (
                          <div
                            key={ord.id}
                            onClick={() => setDetailedOrder(ord)}
                            className="p-2.5 bg-stone-900 border border-stone-800 rounded-lg cursor-pointer hover:border-amber-500/50 transition flex items-center justify-between text-xs"
                          >
                            <div>
                              <div className="font-bold text-stone-100 font-mono">{ord.id}</div>
                              <div className="text-[11px] text-stone-400">
                                {getCategoryName(ord.orderTypeId)} • {ord.items.length} أصناف
                              </div>
                            </div>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${statusMeta.bgClass} ${statusMeta.textClass}`}
                            >
                              {statusMeta.labelAr}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* DETAILED ORDER MODAL */}
      {detailedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-3xl my-6 p-5 text-stone-100 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-lg font-mono text-amber-400">
                    {detailedOrder.id}
                  </span>
                  <span
                    className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                      WORKFLOW_STATUS_CONFIG[detailedOrder.status].bgClass
                    } ${WORKFLOW_STATUS_CONFIG[detailedOrder.status].textClass}`}
                  >
                    {WORKFLOW_STATUS_CONFIG[detailedOrder.status].labelAr}
                  </span>
                </div>
                <p className="text-xs text-stone-400 mt-0.5">
                  فئة {getCategoryName(detailedOrder.orderTypeId)} • تم الإنشاء:{' '}
                  {formatDateTime(detailedOrder.createdAt)}
                </p>
              </div>

              <button
                onClick={() => setDetailedOrder(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-white bg-stone-800"
              >
                ✕
              </button>
            </div>

            {/* Content Details */}
            <div className="mt-4 space-y-4">
              {/* Meta Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-stone-850 p-3 rounded-xl border border-stone-800 text-xs">
                <div>
                  <span className="text-stone-400 block text-[11px]">المسؤول الرئيسي:</span>
                  <span className="font-bold text-stone-200">
                    {getAssigneeName(detailedOrder.primaryAssigneeId)}
                  </span>
                </div>
                <div>
                  <span className="text-stone-400 block text-[11px]">المورد:</span>
                  <span className="font-bold text-stone-200">
                    {getSupplierName(detailedOrder.supplierId)}
                  </span>
                </div>
                <div>
                  <span className="text-stone-400 block text-[11px]">مهلة إرسال الطلب:</span>
                  <span className="font-bold text-stone-200 font-mono">
                    {formatDateTime(detailedOrder.orderingDeadline)}
                  </span>
                </div>
                <div>
                  <span className="text-stone-400 block text-[11px]">موعد وصول الشحنة:</span>
                  <span className="font-bold text-amber-400 font-mono block">
                    01:00 م كحد أقصى (ثابت)
                  </span>
                  {detailedOrder.receivingChefArrivalTime && (
                    <span className="text-[10px] text-emerald-400 font-mono block mt-0.5">
                      توقيت الشيف: {formatDateTime(detailedOrder.receivingChefArrivalTime)}
                    </span>
                  )}
                </div>
              </div>

              {/* Items Table */}
              <div className="border border-stone-800 rounded-xl overflow-hidden">
                <div className="bg-stone-850 px-3 py-2 border-b border-stone-800 font-bold text-xs text-stone-200 flex justify-between">
                  <span>بنود الطلبية المحفوظة ({detailedOrder.items.length} أصناف)</span>
                  <span className="text-[11px] text-stone-400">حالة الصنف والكميات</span>
                </div>
                <div className="overflow-x-auto max-h-56">
                  <table className="w-full text-right text-xs">
                    <thead className="bg-stone-900 text-stone-400 text-[11px]">
                      <tr>
                        <th className="p-2.5">الصنف</th>
                        <th className="p-2.5">المطلوب</th>
                        <th className="p-2.5">المؤكد</th>
                        <th className="p-2.5">المستلم</th>
                        <th className="p-2.5">المرفوض</th>
                        <th className="p-2.5">المتبقي</th>
                        <th className="p-2.5">حالة البند</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-800 text-stone-300">
                      {detailedOrder.items.map((i, idx) => (
                        <tr key={i.id || idx}>
                          <td className="p-2.5 font-semibold text-stone-100">{i.productName}</td>
                          <td className="p-2.5 font-mono">
                            {i.requestedQty} {i.unit}
                          </td>
                          <td className="p-2.5 font-mono">
                            {i.orderedQty} {i.unit}
                          </td>
                          <td className="p-2.5 font-mono text-emerald-400">
                            {i.receivedQty} {i.unit}
                          </td>
                          <td className="p-2.5 font-mono text-red-400">
                            {i.rejectedQty} {i.unit}
                          </td>
                          <td className="p-2.5 font-mono text-amber-400">
                            {i.outstandingQty} {i.unit}
                          </td>
                          <td className="p-2.5 text-[10px]">
                            <span className="bg-stone-800 px-2 py-0.5 rounded text-stone-300">
                              {i.itemStatus}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Status Audit History Timeline */}
              <div className="border border-stone-800 rounded-xl p-3 bg-stone-850/60">
                <span className="font-bold text-xs text-stone-200 block mb-2">
                  سجل تطور الحالة التشغيلية (Audit Trail):
                </span>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {detailedOrder.statusHistory?.map((entry, idx) => {
                    const meta = WORKFLOW_STATUS_CONFIG[entry.status];
                    return (
                      <div
                        key={idx}
                        className="flex items-start gap-2.5 text-xs pb-2 border-b border-stone-800/60 last:border-0"
                      >
                        <div className="w-2 h-2 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-stone-200">
                              {meta.labelAr} (بواسطة {entry.changedByName})
                            </span>
                            <span className="text-[10px] text-stone-500 font-mono">
                              {formatDateTime(entry.timestamp)}
                            </span>
                          </div>
                          {entry.note && (
                            <p className="text-[11px] text-stone-400 mt-0.5">{entry.note}</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Quick Actions in Detail Modal */}
              <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-stone-800">
                <button
                  onClick={() => {
                    setOrderForWhatsApp(detailedOrder);
                    setDetailedOrder(null);
                  }}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-xl text-xs transition flex items-center gap-1.5 shadow-sm"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>إرسال عبر WhatsApp</span>
                </button>

                <button
                  onClick={() => {
                    setOrderForStatusChange(detailedOrder);
                    setDetailedOrder(null);
                  }}
                  className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-4 py-2 rounded-xl text-xs transition"
                >
                  تحديث الحالة التشغيلية
                </button>

                {onNavigateToReceiving && (
                  <button
                    onClick={() => {
                      onNavigateToReceiving(detailedOrder);
                      setDetailedOrder(null);
                    }}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold px-4 py-2 rounded-xl text-xs transition"
                  >
                    تسجيل محضر فحص واستلام
                  </button>
                )}

                <button
                  onClick={() => setDetailedOrder(null)}
                  className="bg-stone-800 hover:bg-stone-750 text-stone-300 px-4 py-2 rounded-xl text-xs transition mr-auto"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* EDIT MODAL */}
      {isEditModalOpen && orderToEdit && (
        <OrderModal
          orderToEdit={orderToEdit}
          onClose={() => {
            setIsEditModalOpen(false);
            setOrderToEdit(null);
          }}
          onSave={async (updatedData) => {
            await updateOrder({ ...orderToEdit, ...updatedData } as ActualOrder);
          }}
        />
      )}

      {/* STATUS TRANSITION MODAL */}
      {orderForStatusChange && (
        <OrderStatusModal
          order={orderForStatusChange}
          onClose={() => setOrderForStatusChange(null)}
          onUpdateStatus={async (newStatus, note) => {
            await updateOrderStatus(orderForStatusChange.id, newStatus, note);
          }}
        />
      )}

      {/* WHATSAPP DISPATCH MODAL */}
      {orderForWhatsApp && (
        <WhatsAppDispatchModal
          order={orderForWhatsApp}
          supplier={suppliers.find((s) => s.id === orderForWhatsApp.supplierId)}
          category={orderTypes.find((c) => c.id === orderForWhatsApp.orderTypeId)}
          onClose={() => setOrderForWhatsApp(null)}
          onDispatched={() => setOrderForWhatsApp(null)}
        />
      )}
    </div>
  );
};
