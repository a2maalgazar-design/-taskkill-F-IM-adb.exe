import React, { useState, useMemo } from 'react';
import {
  AlertTriangle,
  Calendar,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  Edit2,
  ExternalLink,
  Filter,
  Layers,
  MessageCircle,
  Minus,
  Package,
  Plus,
  RotateCcw,
  Search,
  Send,
  BarChart3,
  Settings2,
  Share2,
  Shield,
  Sparkles,
  TableProperties,
  Trash2,
  UserCheck,
  Users,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { OrderType, Product, OrderItem } from '../../types';
import { SHEET_COLUMNS_DEFINITION } from '../../services/seedData';
import { getWorkWeekString, getDayNameAr, formatDateAr } from '../../utils/workWeek';
import { SundayWeeklyOrderAlarmBanner } from '../common/SundayWeeklyOrderAlarmBanner';
import { OrderStatisticsPanel } from './OrderStatisticsPanel';
import {
  formatKitchenWhatsAppMessage,
  generateKitchenWhatsAppUrl,
  sanitizeEgyptianPhone,
} from '../../utils/whatsappFormatter';

interface ColumnarOrderViewProps {
  onNavigateTab?: (tab: any) => void;
}

interface DispatchModalData {
  orderId: string;
  orderTitle: string;
  assistantName: string;
  recipientType: 'supplier' | 'purchasing';
  targetPhone: string;
  chefPhone: string;
  items: { product: Product; qty: number }[];
  whatsappText: string;
  whatsappRecipientUrl: string;
  whatsappChefUrl: string;
}

interface ItemModalData {
  isOpen: boolean;
  mode: 'add' | 'edit';
  productId?: string;
  nameAr: string;
  unit: string;
  parLevel: number;
  categoryId: string;
  sheetColumn?: number;
}

interface ColumnModalData {
  isOpen: boolean;
  mode: 'add' | 'edit';
  categoryId?: string;
  nameAr: string;
  code: string;
  recurrence: 'daily' | 'weekly' | 'monthly';
  scheduleTiming: string;
  defaultAssigneeId: string;
  supplierPhone: string;
  description: string;
}

export const ColumnarOrderView: React.FC<ColumnarOrderViewProps> = ({ onNavigateTab }) => {
  const { currentUser, users, isManager } = useAuth();
  const {
    orderTypes,
    products,
    phoneSettings,
    createOrder,
    saveCategory,
    deleteCategory,
    saveProduct,
    deleteProduct,
    savePhoneSettings,
    resetCatalogToDefault,
  } = useData();

  const canManage = isManager || currentUser.role === 'manager';

  // Toggle for manager editing tools (to avoid accidental taps during busy service)
  const [managerToolsActive, setManagerToolsActive] = useState<boolean>(true);

  // Layout mode: 'sheet' (exact 5 photo columns x 36 items) or 'assistants' (5 assistants roles)
  const [layoutMode, setLayoutMode] = useState<'sheet' | 'assistants'>('sheet');

  // Assistant selector: default to currentUser id if assistant, else 'ALL'
  const [selectedAssistantId, setSelectedAssistantId] = useState<string>(
    currentUser.role === 'assistant' ? currentUser.id : 'ALL'
  );

  // Search query across all 180 items
  const [searchQuery, setSearchQuery] = useState('');

  // Show only items with quantity > 0
  const [showOnlyWithQty, setShowOnlyWithQty] = useState(false);

  // Local state for quantity inputs: { [productId]: number }
  const [quantities, setQuantities] = useState<Record<string, number>>({});

  // Recipient selection per category/column: { [id]: 'supplier' | 'purchasing' }
  const [recipientTypes, setRecipientTypes] = useState<Record<string, 'supplier' | 'purchasing'>>({});

  // Dynamic transfer assignee state per category/column: { [categoryId]: userId }
  const [columnAssignees, setColumnAssignees] = useState<Record<string, string>>({});

  // Recurrence Filter: 'ALL' | 'daily' | 'weekly' | 'monthly'
  const [selectedRecurrenceFilter, setSelectedRecurrenceFilter] = useState<'ALL' | 'daily' | 'weekly' | 'monthly'>('ALL');

  // Statistics panel toggle (Weekly & Monthly Statistics Table per order)
  const [showStatistics, setShowStatistics] = useState(false);

  // Toggle for showing optional unassigned orders for assistant
  const [showOptionalColumns, setShowOptionalColumns] = useState(false);

  // Toast feedback message
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Dispatch modal state
  const [dispatchModal, setDispatchModal] = useState<DispatchModalData | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [ccSent, setCcSent] = useState(false);

  // Item Add/Edit Modal state
  const [itemModal, setItemModal] = useState<ItemModalData>({
    isOpen: false,
    mode: 'add',
    nameAr: '',
    unit: 'كجم',
    parLevel: 10,
    categoryId: orderTypes[0]?.id || 'cat-veg',
    sheetColumn: 1,
  });

  // Column Add/Edit Modal state
  const [columnModal, setColumnModal] = useState<ColumnModalData>({
    isOpen: false,
    mode: 'add',
    nameAr: '',
    code: '',
    recurrence: 'weekly',
    scheduleTiming: '',
    defaultAssigneeId: 'user-assistant-01',
    supplierPhone: '+201011122233',
    description: '',
  });

  // List of the 5 assistants
  const assistantsList = useMemo(() => {
    return users.filter((u) => u.role === 'assistant');
  }, [users]);

  // Active assistant object (if not 'ALL')
  const activeAssistant = useMemo(() => {
    if (selectedAssistantId === 'ALL') return null;
    return users.find((u) => u.id === selectedAssistantId) || null;
  }, [selectedAssistantId, users]);

  // Current work week and dates
  const currentWorkWeek = useMemo(() => getWorkWeekString(), []);
  const todayDay = useMemo(() => getDayNameAr(), []);
  const todayDateFormatted = useMemo(() => formatDateAr(), []);

  // Filter categories based on selected assistant (for Assistants Mode)
  const visibleCategories = useMemo(() => {
    if (selectedAssistantId === 'ALL') {
      return orderTypes.filter((c) => c.isActive);
    }
    const assistant = users.find((u) => u.id === selectedAssistantId);
    if (!assistant) return orderTypes.filter((c) => c.isActive);

    const assignedIds = assistant.assignedOrderTypeIds || [];
    return orderTypes.filter(
      (c) => c.isActive && (assignedIds.includes(c.id) || c.defaultAssigneeId === assistant.id)
    );
  }, [selectedAssistantId, orderTypes, users]);

  // Group products by category
  const productsByCategory = useMemo(() => {
    const map: Record<string, Product[]> = {};
    for (const cat of orderTypes) {
      map[cat.id] = products
        .filter((p) => p.orderTypeId === cat.id && p.isActive)
        .sort((a, b) => (a.sheetRow || 0) - (b.sheetRow || 0));
    }
    return map;
  }, [orderTypes, products]);

  // Group products by Sheet Column (1 to 10, plus any custom columns)
  const productsBySheetColumn = useMemo(() => {
    const map: Record<number, Product[]> = { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: [], 8: [], 9: [], 10: [] };
    for (const p of products) {
      if (p.isActive) {
        const col = p.sheetColumn || 1;
        if (!map[col]) map[col] = [];
        map[col].push(p);
      }
    }
    for (const colKey in map) {
      map[colKey].sort((a, b) => (a.sheetRow || 0) - (b.sheetRow || 0));
    }
    return map;
  }, [products]);

  // Detect custom sheet columns added by manager (> 10)
  const customSheetColumnNumbers = useMemo(() => {
    const cols = Object.keys(productsBySheetColumn).map(Number).filter((c) => c > 10);
    return cols.sort((a, b) => a - b);
  }, [productsBySheetColumn]);

  // Recurrence summary statistics across order types
  const recurrenceStats = useMemo(() => {
    let daily = 0;
    let weekly = 0;
    let monthly = 0;
    for (const c of orderTypes) {
      if (c.recurrence === 'daily') daily++;
      else if (c.recurrence === 'monthly') monthly++;
      else weekly++;
    }
    return { daily, weekly, monthly, total: orderTypes.length };
  }, [orderTypes]);

  // Fast recurrence change by manager
  const handleQuickChangeRecurrence = async (
    categoryId: string,
    recurrence: 'daily' | 'weekly' | 'monthly'
  ) => {
    const cat = orderTypes.find((c) => c.id === categoryId);
    if (!cat) return;
    const updated: OrderType = { ...cat, recurrence, updatedAt: new Date().toISOString() };
    await saveCategory(updated);
    const label = recurrence === 'daily' ? 'يومية ☀️' : recurrence === 'weekly' ? 'أسبوعية 📅' : 'شهرية 🗓️';
    showToast(`تم تحديث دورية "${cat.nameAr}" إلى (${label}) بنجاح`);
  };

  // Filtered sheet columns based on selected recurrence
  const visibleSheetColumns = useMemo(() => {
    return SHEET_COLUMNS_DEFINITION.filter((sheetCol) => {
      if (selectedRecurrenceFilter === 'ALL') return true;
      const primaryCatId = sheetCol.categoryIds[0];
      const cat = orderTypes.find((c) => c.id === primaryCatId);
      const rec = cat?.recurrence || 'weekly';
      return rec === selectedRecurrenceFilter;
    });
  }, [selectedRecurrenceFilter, orderTypes]);

  // Filtered categories based on selected recurrence for Assistants mode
  const visibleCategoriesFiltered = useMemo(() => {
    return visibleCategories.filter((c) => {
      if (selectedRecurrenceFilter === 'ALL') return true;
      return (c.recurrence || 'weekly') === selectedRecurrenceFilter;
    });
  }, [visibleCategories, selectedRecurrenceFilter]);

  // Determine if logged in user is an assistant
  const isAssistantUser = currentUser.role === 'assistant';

  // Assistant's assigned category IDs
  const myAssignedCatIds = useMemo(() => {
    const ids = new Set<string>(currentUser.assignedOrderTypeIds || []);
    for (const cat of orderTypes) {
      if (cat.defaultAssigneeId === currentUser.id) {
        ids.add(cat.id);
      }
    }
    return ids;
  }, [currentUser, orderTypes]);

  // Check if a sheet column is assigned to the current user
  const isColumnAssignedToUser = (sheetCol: (typeof SHEET_COLUMNS_DEFINITION)[0]) => {
    return sheetCol.categoryIds.some((catId) => myAssignedCatIds.has(catId));
  };

  // Partition sheet columns for assistant: assigned first, other optional
  const { assignedSheetCols, optionalSheetCols } = useMemo(() => {
    if (!isAssistantUser) {
      return { assignedSheetCols: visibleSheetColumns, optionalSheetCols: [] };
    }
    const assigned: typeof visibleSheetColumns = [];
    const optional: typeof visibleSheetColumns = [];
    for (const col of visibleSheetColumns) {
      if (isColumnAssignedToUser(col)) {
        assigned.push(col);
      } else {
        optional.push(col);
      }
    }
    return { assignedSheetCols: assigned, optionalSheetCols: optional };
  }, [visibleSheetColumns, isAssistantUser, myAssignedCatIds]);

  // Ordered sheet columns for display:
  // For assistants: their assigned columns appear FIRST, then remaining orders optionally
  const orderedSheetColumnsForDisplay = useMemo(() => {
    if (!isAssistantUser) return visibleSheetColumns;
    if (showOptionalColumns) {
      return [...assignedSheetCols, ...optionalSheetCols];
    }
    return assignedSheetCols.length > 0 ? assignedSheetCols : visibleSheetColumns;
  }, [visibleSheetColumns, isAssistantUser, assignedSheetCols, optionalSheetCols, showOptionalColumns]);

  // Ordered categories for display (Assistants mode)
  const orderedCategoriesForDisplay = useMemo(() => {
    if (!isAssistantUser) return visibleCategoriesFiltered;
    const assigned = visibleCategoriesFiltered.filter((c) => myAssignedCatIds.has(c.id));
    const optional = visibleCategoriesFiltered.filter((c) => !myAssignedCatIds.has(c.id));
    if (showOptionalColumns) {
      return [...assigned, ...optional];
    }
    return assigned.length > 0 ? assigned : visibleCategoriesFiltered;
  }, [visibleCategoriesFiltered, isAssistantUser, myAssignedCatIds, showOptionalColumns]);

  // =========================================================
  // ASSIGNEE TRANSFER & DELEGATION (التحويل بين المدير والمساعدين)
  // =========================================================
  const handleTransferAssignee = async (categoryId: string, targetUserId: string) => {
    setColumnAssignees((prev) => ({ ...prev, [categoryId]: targetUserId }));
    const targetUser = users.find((u) => u.id === targetUserId);
    const targetName = targetUser ? targetUser.name.split('(')[0].trim() : 'المسؤول المحدد';

    // If manager, persist the new assignee in orderTypes
    if (canManage) {
      const cat = orderTypes.find((c) => c.id === categoryId);
      if (cat) {
        await saveCategory({
          ...cat,
          defaultAssigneeId: targetUserId,
        });
      }
    }

    showToast(`تم تحويل مسؤولية الطلبية إلى ${targetName} بنجاح ✓`);
  };

  // Helper to resolve effective assignee for a category
  const getEffectiveAssignee = (category: OrderType) => {
    const overrideId = columnAssignees[category.id];
    if (overrideId) {
      const u = users.find((usr) => usr.id === overrideId);
      if (u) return u;
    }
    if (activeAssistant) return activeAssistant;
    if (category.defaultAssigneeId) {
      const u = users.find((usr) => usr.id === category.defaultAssigneeId);
      if (u) return u;
    }
    return currentUser;
  };

  // =========================================================
  // QUANTITY OPERATIONS (إضافة وحذف وتعديل الكميات)
  // =========================================================
  const handleQtyChange = (productId: string, val: string | number) => {
    const num = typeof val === 'number' ? val : parseFloat(val);
    if (isNaN(num) || num < 0) {
      setQuantities((prev) => ({ ...prev, [productId]: 0 }));
    } else {
      setQuantities((prev) => ({ ...prev, [productId]: num }));
    }
  };

  const handleStepQty = (productId: string, delta: number) => {
    const current = quantities[productId] || 0;
    const next = Math.max(0, current + delta);
    setQuantities((prev) => ({ ...prev, [productId]: next }));
  };

  const handleDeleteItemQty = (productId: string) => {
    setQuantities((prev) => {
      const copy = { ...prev };
      delete copy[productId];
      return copy;
    });
  };

  // Quick fill column with par level
  const handleFillParLevelForProducts = (targetProducts: Product[]) => {
    const updates: Record<string, number> = {};
    for (const p of targetProducts) {
      updates[p.id] = p.averageDailyDemand && p.averageDailyDemand > 0 ? p.averageDailyDemand : 10;
    }
    setQuantities((prev) => ({ ...prev, ...updates }));
    showToast(`تمت تعبئة رصيد الأمان لـ ${targetProducts.length} صنفاً بنجاح.`);
  };

  // Quick clear column quantities
  const handleClearProductsQuantities = (targetProducts: Product[]) => {
    setQuantities((prev) => {
      const copy = { ...prev };
      for (const p of targetProducts) {
        delete copy[p.id];
      }
      return copy;
    });
    showToast(`تم تفريغ كميات ${targetProducts.length} صنفاً.`);
  };

  // Global clear all quantities
  const handleClearAllQuantities = () => {
    if (window.confirm('هل تريد تفريغ وحذف جميع الكميات المطلوبة في كافة الأعمدة؟')) {
      setQuantities({});
      showToast('تم تفريغ كافة الكميات بنجاح.');
    }
  };

  // Global fill all with par level
  const handleFillAllParLevels = () => {
    const updates: Record<string, number> = {};
    for (const p of products) {
      if (p.isActive) {
        updates[p.id] = p.averageDailyDemand && p.averageDailyDemand > 0 ? p.averageDailyDemand : 10;
      }
    }
    setQuantities(updates);
    showToast(`تمت تعبئة رصيد الأمان لكافة الأصناف (${products.length} صنف).`);
  };

  const totalOrderedItemsCount = useMemo(() => {
    return Object.values(quantities).filter((q) => q > 0).length;
  }, [quantities]);

  // =========================================================
  // ITEM OPERATIONS (إضافة، تعديل الاسم، وحذف الأصناف)
  // =========================================================
  const handleOpenAddItem = (preselectedCategory?: string, preselectedSheetCol?: number) => {
    setItemModal({
      isOpen: true,
      mode: 'add',
      nameAr: '',
      unit: 'كجم',
      parLevel: 10,
      categoryId: preselectedCategory || orderTypes[0]?.id || 'cat-veg',
      sheetColumn: preselectedSheetCol || 1,
    });
  };

  const handleOpenEditItem = (prod: Product) => {
    setItemModal({
      isOpen: true,
      mode: 'edit',
      productId: prod.id,
      nameAr: prod.nameAr,
      unit: prod.defaultUnit || prod.unit || 'كجم',
      parLevel: prod.averageDailyDemand || 0,
      categoryId: prod.orderTypeId,
      sheetColumn: prod.sheetColumn || 1,
    });
  };

  const handleSaveItemModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemModal.nameAr.trim()) {
      alert('يرجى إدخال اسم الصنف.');
      return;
    }

    if (itemModal.mode === 'edit' && itemModal.productId) {
      const existing = products.find((p) => p.id === itemModal.productId);
      if (existing) {
        const updated: Product = {
          ...existing,
          nameAr: itemModal.nameAr.trim(),
          name: itemModal.nameAr.trim(),
          defaultUnit: itemModal.unit,
          unit: itemModal.unit,
          averageDailyDemand: Number(itemModal.parLevel) || 0,
          orderTypeId: itemModal.categoryId,
          sheetColumn: itemModal.sheetColumn,
          updatedAt: new Date().toISOString(),
        };
        await saveProduct(updated);
        showToast(`تم تعديل الصنف "${itemModal.nameAr}" بنجاح.`);
      }
    } else {
      const newProd: Product = {
        id: `prod-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        nameAr: itemModal.nameAr.trim(),
        name: itemModal.nameAr.trim(),
        defaultUnit: itemModal.unit,
        unit: itemModal.unit,
        averageDailyDemand: Number(itemModal.parLevel) || 0,
        orderTypeId: itemModal.categoryId,
        sheetColumn: itemModal.sheetColumn || 1,
        sheetRow: products.filter((p) => p.sheetColumn === (itemModal.sheetColumn || 1)).length + 1,
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      await saveProduct(newProd);
      showToast(`تمت إضافة الصنف "${itemModal.nameAr}" بنجاح.`);
    }

    setItemModal((prev) => ({ ...prev, isOpen: false }));
  };

  const handleDeleteItem = async (prod: Product) => {
    if (window.confirm(`هل أنت متأكد من حذف الصنف "${prod.nameAr}" نهائياً من المطبخ؟`)) {
      await deleteProduct(prod.id);
      handleDeleteItemQty(prod.id);
      showToast(`تم حذف الصنف "${prod.nameAr}".`);
    }
  };

  // =========================================================
  // COLUMN OPERATIONS (إضافة، تعديل الموعد والدورية، وحذف الأعمدة)
  // =========================================================
  const handleOpenAddColumn = () => {
    setColumnModal({
      isOpen: true,
      mode: 'add',
      nameAr: '',
      code: '',
      recurrence: 'weekly',
      scheduleTiming: 'كل يوم سبت الساعة 09:00 ص',
      defaultAssigneeId: 'user-assistant-01',
      supplierPhone: '+201011122233',
      description: '',
    });
  };

  const handleOpenEditColumn = (category: OrderType) => {
    const existingPhone = phoneSettings.supplierPhones[category.id] || '+201011122233';
    setColumnModal({
      isOpen: true,
      mode: 'edit',
      categoryId: category.id,
      nameAr: category.nameAr,
      code: category.code,
      recurrence: category.recurrence || 'weekly',
      scheduleTiming: category.scheduleTiming || '',
      defaultAssigneeId: category.defaultAssigneeId || 'user-assistant-01',
      supplierPhone: existingPhone,
      description: category.description || '',
    });
  };

  const handleSaveColumnModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!columnModal.nameAr.trim()) {
      alert('يرجى إدخال اسم العمود / الطلبية.');
      return;
    }

    const catId = columnModal.categoryId || `cat-${Date.now()}`;
    const code = (columnModal.code || columnModal.nameAr.substring(0, 4)).toUpperCase();

    const catPayload: OrderType = {
      id: catId,
      code,
      nameAr: columnModal.nameAr.trim(),
      description: columnModal.description.trim(),
      recurrence: columnModal.recurrence,
      scheduleTiming: columnModal.scheduleTiming.trim(),
      defaultAssigneeId: columnModal.defaultAssigneeId,
      isActive: true,
      createdAt: new Date().toISOString(),
    };

    await saveCategory(catPayload);

    // Save phone settings for this category
    if (columnModal.supplierPhone.trim()) {
      await savePhoneSettings({
        ...phoneSettings,
        supplierPhones: {
          ...phoneSettings.supplierPhones,
          [catId]: columnModal.supplierPhone.trim(),
        },
      });
    }

    showToast(
      columnModal.mode === 'edit'
        ? `تم تحديث بيانات وموعد العمود "${columnModal.nameAr}".`
        : `تمت إضافة العمود "${columnModal.nameAr}" بنجاح.`
    );

    setColumnModal((prev) => ({ ...prev, isOpen: false }));
  };

  const handleDeleteColumn = async (category: OrderType) => {
    const categoryProds = productsByCategory[category.id] || [];
    const confirmText =
      categoryProds.length > 0
        ? `تحذير: يحتوي هذا العمود على (${categoryProds.length}) أصناف مسجلة.\nهل أنت متأكد من حذف العمود "${category.nameAr}" بالكامل؟`
        : `هل أنت متأكد من حذف العمود "${category.nameAr}"؟`;

    if (window.confirm(confirmText)) {
      await deleteCategory(category.id);
      showToast(`تم حذف العمود "${category.nameAr}" بنجاح.`);
    }
  };

  // Helper to get phone
  const getRecipientPhone = (key: string, recipientType: 'supplier' | 'purchasing'): string => {
    if (recipientType === 'purchasing') {
      return phoneSettings.purchasingPhone || '+201099887766';
    }
    return phoneSettings.supplierPhones[key] || '+201011122233';
  };

  // =========================================================
  // WHATSAPP DISPATCH ENGINE
  // =========================================================
  const handleDispatch = async (opts: {
    title: string;
    code: string;
    items: Product[];
    categoryKey: string;
    assigneeName?: string;
    recurrence?: 'daily' | 'weekly' | 'monthly';
    scheduleTiming?: string;
  }) => {
    const orderedItems = opts.items
      .filter((p) => (quantities[p.id] || 0) > 0)
      .map((p) => ({ product: p, qty: quantities[p.id] }));

    if (orderedItems.length === 0) {
      alert(`برجاء إدخال كمية مطلوبة لصنف واحد على الأقل في "${opts.title}" قبل الإرسال.`);
      return;
    }

    const recipientType = recipientTypes[opts.categoryKey] || 'supplier';
    const targetPhone = getRecipientPhone(opts.categoryKey, recipientType);
    const chefPhone = phoneSettings.headChefPhone || '+201000000000';

    const assistantName = opts.assigneeName || currentUser.name;

    const orderItemsPayload: OrderItem[] = orderedItems.map((item, idx) => ({
      id: `item-${Date.now()}-${idx}-${item.product.id}`,
      productId: item.product.id,
      productName: item.product.nameAr,
      requestedQty: item.qty,
      unit: item.product.defaultUnit || item.product.unit || 'كجم',
      averageDailyDemand: item.product.averageDailyDemand || 0,
      orderedQty: item.qty,
      receivedQty: 0,
      rejectedQty: 0,
      outstandingQty: item.qty,
      itemStatus: 'pending',
    }));

    const orderId = await createOrder({
      orderTypeId: opts.categoryKey.startsWith('col-') ? 'cat-veg' : opts.categoryKey,
      primaryAssigneeId: activeAssistant ? activeAssistant.id : currentUser.id,
      status: 'ORDERED',
      items: orderItemsPayload,
      purchasingChannel: 'واتساب',
      recipientType,
      recipientPhone: targetPhone,
      recipientName: recipientType === 'supplier' ? 'المورد المباشر المعتمد' : 'مدير المشتريات والمستودع',
      workWeek: currentWorkWeek,
      notes: `تم التوريد عبر واجهة الأعمدة المعتمدة (${opts.title}) بواسطة ${assistantName}`,
    });

    // Simplified standardized WhatsApp message format:
    // رأس الرسالة طلبية مطبخ نانا الشيخ زايد، ثم كود الطلبية، ثم القائم بالطلب، ثم الأصناف والكميات المطلوبة، ثم إجمالي عدد البنود، ثم يرجى سرعة التأكيد والتوريد
    const message = formatKitchenWhatsAppMessage({
      orderCode: `${orderId} (${opts.code})`,
      requesterName: assistantName,
      items: orderedItems.map((it) => ({
        name: it.product.nameAr,
        qty: it.qty,
        unit: it.product.defaultUnit || it.product.unit || 'كجم',
      })),
    });

    const whatsappRecipientUrl = generateKitchenWhatsAppUrl(targetPhone, message);
    const whatsappChefUrl = generateKitchenWhatsAppUrl(chefPhone, message);

    setDispatchModal({
      orderId,
      orderTitle: opts.title,
      assistantName,
      recipientType,
      targetPhone,
      chefPhone,
      items: orderedItems,
      whatsappText: message,
      whatsappRecipientUrl,
      whatsappChefUrl,
    });
    setCcSent(false);
    setIsCopied(false);
  };

  const handleCopyMessage = () => {
    if (!dispatchModal) return;
    navigator.clipboard.writeText(dispatchModal.whatsappText);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  return (
    <div className="space-y-4">
      {/* Toast Notification Alert */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-stone-900 border border-emerald-500/40 text-emerald-300 px-5 py-2.5 rounded-2xl text-xs font-bold shadow-2xl flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Sunday Weekly Orders Alarm & Supervisor Reviews Banner */}
      <SundayWeeklyOrderAlarmBanner
        onFilterWeeklyOnly={() =>
          setSelectedRecurrenceFilter(selectedRecurrenceFilter === 'weekly' ? 'ALL' : 'weekly')
        }
        isWeeklyFilterActive={selectedRecurrenceFilter === 'weekly'}
      />

      {/* 2. Weekly & Monthly Statistical Table Panel (when toggled) */}
      {showStatistics && (
        <OrderStatisticsPanel
          quantities={quantities}
          onClose={() => setShowStatistics(false)}
        />
      )}

      {/* Top Banner & Control Center */}
      <div className="bg-stone-900 border border-stone-800 rounded-3xl p-4 lg:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-36 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header Row */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-stone-800/80 pb-4">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-2xl">📋</span>
              <h1 className="text-xl lg:text-2xl font-black text-stone-100">
                طلبيات مطبخ نانا الشيخ زايد
              </h1>
              <span className="bg-amber-500/15 text-amber-300 border border-amber-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold">
                {products.length} صنفاً • {orderTypes.length} أعمدة وطلبيات
              </span>
            </div>
            <p className="text-xs text-stone-400 mt-1">
              حصر كميات المطبخ ومتابعة دوريات الطلب مع التحويل السريع للمسؤولية بين المدير والمساعدين.
            </p>
          </div>

          {/* Quick Date Badges & Statistics Toggle Button */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Toggle Statistical Table (Weekly & Monthly per order) */}
            <button
              type="button"
              onClick={() => setShowStatistics(!showStatistics)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition shadow-sm ${
                showStatistics
                  ? 'bg-amber-500 text-stone-950 border-amber-400 shadow-amber-500/20'
                  : 'bg-stone-850 hover:bg-stone-800 text-amber-300 border-amber-500/30'
              }`}
              title="عرض الجدول الإحصائي لكميات الطلب الأسبوعي والشهري لكل طلبية"
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>{showStatistics ? 'إخفاء الإحصائيات' : 'الإحصائيات الأسبوعية والشهرية'}</span>
            </button>

            <div className="flex items-center gap-1.5 bg-stone-950 px-3 py-1.5 rounded-xl border border-stone-800 text-stone-300">
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              <span>{todayDay}، {todayDateFormatted}</span>
            </div>
            <div className="flex items-center gap-1.5 bg-amber-500/10 px-3 py-1.5 rounded-xl border border-amber-500/30 text-amber-300 font-bold">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>{currentWorkWeek}</span>
            </div>
            {onNavigateTab && (
              <button
                onClick={() => onNavigateTab('weekly-archive')}
                className="flex items-center gap-1 bg-stone-800 hover:bg-stone-700 text-stone-200 px-3 py-1.5 rounded-xl border border-stone-700 transition"
              >
                <span>📂</span>
                <span>الملف الأسبوعي</span>
              </button>
            )}
          </div>
        </div>

        {/* Manager Power Toolbar: Add Column, Add Item, Quantity Batch Actions, Tools Toggle */}
        {canManage && (
          <div className="mt-3.5 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-wrap items-center justify-between gap-2.5">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-amber-300">
                صلاحيات المدير (الشيف العمومي):
              </span>
              <button
                type="button"
                onClick={() => setManagerToolsActive(!managerToolsActive)}
                className={`text-[11px] px-2.5 py-1 rounded-lg font-bold border transition flex items-center gap-1.5 ${
                  managerToolsActive
                    ? 'bg-amber-500 text-stone-950 border-amber-400'
                    : 'bg-stone-900 text-stone-400 border-stone-700 hover:text-stone-200'
                }`}
              >
                <Settings2 className="w-3 h-3" />
                <span>{managerToolsActive ? 'أزرار التعديل والحذف: مفعلة' : 'أزرار التعديل والحذف: معطلة'}</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Add Column Button */}
              <button
                type="button"
                onClick={handleOpenAddColumn}
                className="flex items-center gap-1 bg-amber-500 hover:bg-amber-400 text-stone-950 px-3 py-1.5 rounded-xl text-xs font-black transition shadow-sm"
              >
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
                <span>إضافة عمود / طلبية جديدة</span>
              </button>

              {/* Add Item Button */}
              <button
                type="button"
                onClick={() => handleOpenAddItem()}
                className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-xl text-xs font-black transition shadow-sm"
              >
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
                <span>إضافة صنف جديد</span>
              </button>

              {/* Fill all Par levels */}
              <button
                type="button"
                onClick={handleFillAllParLevels}
                className="flex items-center gap-1 bg-stone-800 hover:bg-stone-750 text-amber-300 px-2.5 py-1.5 rounded-xl text-xs font-bold border border-amber-500/20 transition"
                title="وضع الكمية المطلوبة مساوية لرصيد الأمان لكافة الأصناف"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>تعبئة رصيد الأمان للكل</span>
              </button>

              {/* Clear all quantities */}
              {totalOrderedItemsCount > 0 && (
                <button
                  type="button"
                  onClick={handleClearAllQuantities}
                  className="flex items-center gap-1 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 px-2.5 py-1.5 rounded-xl text-xs font-bold transition"
                  title="حذف وتفريغ كافة الكميات المطلوبة"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>تفريغ كافة الكميات ({totalOrderedItemsCount})</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* View Mode Switcher + Search & Filter Toolbar */}
        <div className="mt-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Mode Tabs */}
          <div className="flex items-center gap-1.5 bg-stone-950 p-1 rounded-2xl border border-stone-800">
            <button
              type="button"
              onClick={() => setLayoutMode('sheet')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition ${
                layoutMode === 'sheet'
                  ? 'bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <TableProperties className="w-4 h-4" />
              <span>قوائم الطلبيات المعتمدة (10 أعمدة)</span>
            </button>

            <button
              type="button"
              onClick={() => setLayoutMode('assistants')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition ${
                layoutMode === 'assistants'
                  ? 'bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>توزيع المساعدين الخمسة والتحويل ({orderTypes.length} طلبيات)</span>
            </button>
          </div>

          {/* Search Input & Action Badges */}
          <div className="flex items-center gap-2 flex-1 md:max-w-md">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-stone-500 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="بحث فوري بالاسم أو رقم البند..."
                className="w-full bg-stone-950 border border-stone-800 rounded-xl pr-9 pl-8 py-2 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-500"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-300"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Filter: Only With Qty */}
            <button
              type="button"
              onClick={() => setShowOnlyWithQty(!showOnlyWithQty)}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 border ${
                showOnlyWithQty
                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                  : 'bg-stone-950 text-stone-400 border-stone-800 hover:text-stone-200'
              }`}
              title="تصفية الأصناف التي تم إدخال كمية لها فقط"
            >
              <Filter className="w-3.5 h-3.5" />
              <span>المطلوب فقط ({totalOrderedItemsCount})</span>
            </button>
          </div>
        </div>

        {/* In Assistant Mode: Fast Selector for the 5 Assistants */}
        {layoutMode === 'assistants' && (
          <div className="mt-4 pt-3 border-t border-stone-800/80">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-stone-300 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-amber-400" />
                <span>المساعد القائم بالطلب (تصفية فورية للأعمدة وحجب الباقي):</span>
              </span>
              {activeAssistant && (
                <span className="text-xs text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  مفعل حالياً: {activeAssistant.name} ({visibleCategories.length} طلبيات موكلة)
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1.5 scrollbar-thin">
              {/* Chef Button (Show All) */}
              <button
                onClick={() => setSelectedAssistantId('ALL')}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap shrink-0 ${
                  selectedAssistantId === 'ALL'
                    ? 'bg-amber-500 text-stone-950 shadow-lg shadow-amber-500/20 ring-2 ring-amber-400'
                    : 'bg-stone-800/80 hover:bg-stone-800 text-stone-300 border border-stone-700'
                }`}
              >
                <span>👨‍🍳</span>
                <span>الشيف العمومي (عرض الكل)</span>
                <span className="bg-stone-950/40 text-stone-200 px-1.5 py-0.2 rounded text-[11px]">
                  {orderTypes.length}
                </span>
              </button>

              {/* The 5 Assistants */}
              {assistantsList.map((asst, idx) => {
                const isSelected = selectedAssistantId === asst.id;
                const assignedCount = (asst.assignedOrderTypeIds || []).length;
                return (
                  <button
                    key={asst.id}
                    onClick={() => setSelectedAssistantId(asst.id)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap shrink-0 ${
                      isSelected
                        ? 'bg-emerald-500 text-stone-950 shadow-lg shadow-emerald-500/25 ring-2 ring-emerald-400'
                        : 'bg-stone-800/80 hover:bg-stone-800 text-stone-300 border border-stone-700'
                    }`}
                  >
                    <span>🧑‍🍳</span>
                    <span>{asst.name.split('(')[0].trim() || `مساعد ${idx + 1}`}</span>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] ${
                        isSelected ? 'bg-stone-950 text-emerald-300' : 'bg-stone-900 text-stone-400'
                      }`}
                    >
                      {assignedCount} طلبيات
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Recurrence Filter Bar (دورية الطلبية: يومي، أسبوعي، شهري) */}
        <div className="mt-4 pt-3 border-t border-stone-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-stone-200">
              تصفية الأعمدة حسب دورية الطلب:
            </span>
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
            <button
              type="button"
              onClick={() => setSelectedRecurrenceFilter('ALL')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                selectedRecurrenceFilter === 'ALL'
                  ? 'bg-stone-800 text-stone-100 ring-1 ring-stone-600 shadow'
                  : 'bg-stone-950 text-stone-400 hover:text-stone-200 border border-stone-800'
              }`}
            >
              <span>🔘 كافة الأعمدة</span>
              <span className="bg-stone-900 px-1.5 py-0.2 rounded text-[10px] font-mono">
                {recurrenceStats.total}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedRecurrenceFilter('daily')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                selectedRecurrenceFilter === 'daily'
                  ? 'bg-emerald-600 text-white ring-2 ring-emerald-400 shadow-lg shadow-emerald-950/40'
                  : 'bg-stone-950 text-emerald-400 hover:bg-emerald-950/20 border border-emerald-900/40'
              }`}
            >
              <span>☀️ طلبيات يومية</span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${selectedRecurrenceFilter === 'daily' ? 'bg-emerald-800 text-white' : 'bg-emerald-950 text-emerald-300'}`}>
                {recurrenceStats.daily}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedRecurrenceFilter('weekly')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                selectedRecurrenceFilter === 'weekly'
                  ? 'bg-blue-600 text-white ring-2 ring-blue-400 shadow-lg shadow-blue-950/40'
                  : 'bg-stone-950 text-blue-400 hover:bg-blue-950/20 border border-blue-900/40'
              }`}
            >
              <span>📅 طلبيات أسبوعية</span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${selectedRecurrenceFilter === 'weekly' ? 'bg-blue-800 text-white' : 'bg-blue-950 text-blue-300'}`}>
                {recurrenceStats.weekly}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedRecurrenceFilter('monthly')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                selectedRecurrenceFilter === 'monthly'
                  ? 'bg-purple-600 text-white ring-2 ring-purple-400 shadow-lg shadow-purple-950/40'
                  : 'bg-stone-950 text-purple-400 hover:bg-purple-950/20 border border-purple-900/40'
              }`}
            >
              <span>🗓️ طلبيات شهرية</span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${selectedRecurrenceFilter === 'monthly' ? 'bg-purple-800 text-white' : 'bg-purple-950 text-purple-300'}`}>
                {recurrenceStats.monthly}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Assistant Priority Notice & Optional Columns Toggle */}
      {isAssistantUser && (
        <div className="bg-stone-900 border border-amber-500/30 rounded-2xl p-3.5 mb-5 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center text-xl shrink-0 font-bold border border-amber-500/30">
              🧑‍🍳
            </div>
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center gap-1.5">
                <h4 className="font-bold text-stone-100 text-sm">
                  مرحباً بك: {currentUser.name.split('(')[0].trim()} ({currentUser.employeeNumber || 'مساعد'})
                </h4>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] px-2 py-0.5 rounded font-bold w-fit">
                  بصمة بيومترية مسجلة وموثقة 👆
                </span>
              </div>
              <p className="text-xs text-stone-400 mt-0.5">
                تظهر لك طلبياتك الموكلة أولاً لتسهيل طلبك، مع إمكانية عرض باقي طلبيات المطبخ أدناه كخيار إضافي.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowOptionalColumns(!showOptionalColumns)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap shadow-md ${
              showOptionalColumns
                ? 'bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-600'
                : 'bg-gradient-to-r from-amber-500 to-amber-600 text-stone-950 hover:brightness-110 font-black'
            }`}
          >
            <span>{showOptionalColumns ? '👁️ إخفاء باقي الطلبيات' : '➕ إظهار باقي طلبيات المطبخ (اختياري)'}</span>
          </button>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODE 1: SHEET COLUMNS VIEW (Exact Columns of Kitchen Order Lists) */}
      {/* ======================================================== */}
      {layoutMode === 'sheet' && (
        <div className="flex flex-col lg:flex-row items-stretch gap-4 overflow-x-auto pb-6 scrollbar-thin">
          {visibleSheetColumns.length === 0 ? (
            <div className="w-full bg-stone-900 border border-stone-800 rounded-2xl p-8 text-center my-6">
              <span className="text-3xl block mb-2">⏱️</span>
              <h3 className="font-bold text-stone-200 text-sm mb-1">
                لا توجد طلبيات مطابقة للدورية المحددة ({selectedRecurrenceFilter === 'daily' ? 'يومية' : selectedRecurrenceFilter === 'weekly' ? 'أسبوعية' : 'شهرية'})
              </h3>
              <p className="text-xs text-stone-400 mb-4">
                يمكنك تغيير دورية أي طلبية من لوحة التحكم أو عرض كافة الأعمدة.
              </p>
              <button
                type="button"
                onClick={() => setSelectedRecurrenceFilter('ALL')}
                className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-4 py-2 rounded-xl text-xs transition"
              >
                عرض كافة الأعمدة ({recurrenceStats.total})
              </button>
            </div>
          ) : (
            orderedSheetColumnsForDisplay.map((sheetCol) => {
              const rawProducts = productsBySheetColumn[sheetCol.colNumber] || [];

              // Apply search & filter
              const filteredProducts = rawProducts.filter((p) => {
                const matchesSearch =
                  !searchQuery.trim() ||
                  p.nameAr.includes(searchQuery.trim()) ||
                  (p.name && p.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
                  String(p.sheetRow).includes(searchQuery.trim());
                const matchesQty = !showOnlyWithQty || (quantities[p.id] || 0) > 0;
                return matchesSearch && matchesQty;
              });

              const colKey = `col-${sheetCol.colNumber}`;
              const currentRecipient = recipientTypes[colKey] || 'supplier';
              const primaryCatId = sheetCol.categoryIds[0] || 'cat-veg';
              const primaryCat = orderTypes.find((c) => c.id === primaryCatId);
              const targetPhone = getRecipientPhone(primaryCatId, currentRecipient);
              const itemsWithQty = rawProducts.filter((p) => (quantities[p.id] || 0) > 0);

              // Assignee for this sheet column
              const chosenUserId = columnAssignees[colKey] || (primaryCat ? primaryCat.defaultAssigneeId : 'user-manager-01');
              const chosenUser = users.find((u) => u.id === chosenUserId) || currentUser;

              const isDaily = primaryCat?.recurrence === 'daily';
              const isMonthly = primaryCat?.recurrence === 'monthly';

              return (
                <div
                  key={`sheet-col-${sheetCol.colNumber}`}
                  className={`w-full lg:w-[360px] xl:w-[380px] shrink-0 bg-stone-900 border rounded-2xl flex flex-col shadow-lg overflow-hidden transition hover:border-stone-600 ${
                    isDaily
                      ? 'border-emerald-900/60 ring-1 ring-emerald-500/20'
                      : isMonthly
                      ? 'border-purple-900/60 ring-1 ring-purple-500/20'
                      : 'border-blue-900/60 ring-1 ring-blue-500/20'
                  }`}
                >
                  {/* Column Header */}
                  <div
                    className={`p-4 border-b ${
                      isDaily
                        ? 'bg-gradient-to-r from-emerald-950/60 via-stone-900 to-stone-900 border-emerald-900/50'
                        : isMonthly
                        ? 'bg-gradient-to-r from-purple-950/60 via-stone-900 to-stone-900 border-purple-900/50'
                        : 'bg-gradient-to-r from-blue-950/60 via-stone-900 to-stone-900 border-blue-900/50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{sheetCol.icon}</span>
                          <h3 className="font-black text-sm lg:text-base text-stone-100">
                            {sheetCol.title}
                          </h3>
                        </div>
                        <span className="text-[11px] font-mono text-stone-400 mt-0.5 block">
                          {rawProducts.length} صنفاً مسجلاً في هذا العمود
                        </span>
                        {primaryCat?.scheduleTiming && (
                          <span className="text-[10px] text-amber-300 font-mono flex items-center gap-1 mt-1 bg-stone-950 px-2 py-0.5 rounded border border-amber-500/20 w-fit">
                            <Clock className="w-2.5 h-2.5 text-amber-400" />
                            <span>{primaryCat.scheduleTiming}</span>
                          </span>
                        )}
                      </div>

                      <div className="flex flex-col items-end gap-1">
                        <div className="flex items-center gap-1">
                          {isAssistantUser && (
                            <span
                              className={`text-[9px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 border ${
                                isColumnAssignedToUser(sheetCol)
                                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                                  : 'bg-stone-800 text-stone-400 border-stone-700'
                              }`}
                            >
                              {isColumnAssignedToUser(sheetCol) ? '⭐ طلبيتك المكلف بها' : '👁️ عرض اختياري'}
                            </span>
                          )}
                          <span className="bg-stone-950/80 text-stone-300 border border-stone-800 text-[10px] px-2 py-0.5 rounded-full font-mono font-bold shrink-0">
                            عمود {sheetCol.colNumber}
                          </span>
                        </div>

                        {/* Interactive Manager Recurrence Changer vs Static Badge */}
                        {canManage && managerToolsActive && primaryCat ? (
                          <select
                            value={primaryCat.recurrence || 'weekly'}
                            onChange={(e) =>
                              handleQuickChangeRecurrence(primaryCat.id, e.target.value as any)
                            }
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full border cursor-pointer focus:outline-none ${
                              primaryCat.recurrence === 'daily'
                                ? 'bg-emerald-950 text-emerald-300 border-emerald-500/50'
                                : primaryCat.recurrence === 'monthly'
                                ? 'bg-purple-950 text-purple-300 border-purple-500/50'
                                : 'bg-blue-950 text-blue-300 border-blue-500/50'
                            }`}
                            title="تغيير دورية الطلبية للمدير (يومي / أسبوعي / شهري)"
                          >
                            <option value="daily">☀️ يومية</option>
                            <option value="weekly">📅 أسبوعية</option>
                            <option value="monthly">🗓️ شهرية</option>
                          </select>
                        ) : (
                          primaryCat && (
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                                primaryCat.recurrence === 'daily'
                                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                                  : primaryCat.recurrence === 'monthly'
                                  ? 'bg-purple-500/20 text-purple-400 border-purple-500/30'
                                  : 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                              }`}
                            >
                              {primaryCat.recurrence === 'daily'
                                ? '☀️ يومية'
                                : primaryCat.recurrence === 'monthly'
                                ? '🗓️ شهرية'
                                : '📅 أسبوعية'}
                            </span>
                          )
                        )}
                      </div>
                    </div>

                  {/* Transfer Option from Manager to Assistant */}
                  <div className="mt-2.5 pt-2 border-t border-stone-800/60 flex items-center justify-between text-xs gap-1.5">
                    <span className="text-[11px] font-bold text-stone-400 flex items-center gap-1 shrink-0">
                      <UserCheck className="w-3.5 h-3.5 text-amber-400" />
                      <span>المسؤول (خيار التحويل):</span>
                    </span>

                    <select
                      value={chosenUserId}
                      onChange={(e) => handleTransferAssignee(colKey, e.target.value)}
                      className="bg-stone-950 border border-stone-800 text-amber-300 text-[11px] font-bold rounded-lg px-2 py-1 focus:outline-none focus:border-amber-400 max-w-[175px] truncate"
                      title="خيار التحويل من المدير إلى المساعد"
                    >
                      <option value="user-manager-01">👨‍🍳 الشيف العمومي (المدير)</option>
                      <optgroup label="المساعدون الخمسة">
                        {assistantsList.map((asst) => (
                          <option key={asst.id} value={asst.id}>
                            🧑‍🍳 {asst.name.split('(')[0].trim()}
                          </option>
                        ))}
                      </optgroup>
                    </select>
                  </div>

                  {/* Column Stats & Quick Manager Column Actions */}
                  <div className="mt-2 flex items-center justify-between text-xs text-stone-400 pt-1.5 border-t border-stone-800/40">
                    <span className="text-stone-300">
                      المعروض: <strong className="text-amber-400 font-mono">{filteredProducts.length}</strong> من {rawProducts.length}
                    </span>
                    <span className="bg-stone-950 px-2 py-0.5 rounded text-[11px] text-emerald-400 font-bold">
                      المطلوب: {itemsWithQty.length} صنف
                    </span>
                  </div>

                  {/* Manager In-Column Quick Action Buttons */}
                  {canManage && managerToolsActive && (
                    <div className="mt-2.5 pt-2 border-t border-stone-800/50 flex items-center justify-between gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleOpenAddItem(primaryCatId, sheetCol.colNumber)}
                        className="flex items-center gap-1 text-[11px] bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-1 rounded-lg font-bold transition"
                        title="إضافة صنف جديد لهذا العمود"
                      >
                        <Plus className="w-3 h-3" />
                        <span>إضافة صنف</span>
                      </button>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleFillParLevelForProducts(rawProducts)}
                          className="flex items-center gap-1 text-[10px] bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-1 rounded-lg font-semibold transition"
                          title="تعبئة الكمية المطلوبة برصيد الأمان لهذا العمود"
                        >
                          <Sparkles className="w-3 h-3 text-amber-400" />
                          <span>رصيد الأمان</span>
                        </button>

                        {itemsWithQty.length > 0 && (
                          <button
                            type="button"
                            onClick={() => handleClearProductsQuantities(rawProducts)}
                            className="flex items-center gap-1 text-[10px] bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-1 rounded-lg font-semibold transition"
                            title="تفريغ كميات هذا العمود"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>تفريغ</span>
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Items List (Rows 1 to 36) */}
                <div className="flex-1 p-3 overflow-y-auto max-h-[520px] space-y-1.5 divide-y divide-stone-800/40">
                  {filteredProducts.length === 0 ? (
                    <div className="text-center py-12 text-stone-500 text-xs">
                      لا توجد أصناف مطابقة للبحث في هذا العمود
                    </div>
                  ) : (
                    filteredProducts.map((prod) => {
                      const currentQty = quantities[prod.id] || 0;
                      return (
                        <div
                          key={prod.id}
                          className={`pt-1.5 first:pt-0 p-2 rounded-xl transition group ${
                            currentQty > 0
                              ? 'bg-amber-500/10 border border-amber-500/30 shadow-sm'
                              : 'hover:bg-stone-800/40'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <div className="flex items-center gap-2 min-w-0">
                              <span className="w-5 h-5 rounded-md bg-stone-950 text-stone-400 font-mono text-[10px] font-bold flex items-center justify-center shrink-0 border border-stone-800">
                                {prod.sheetRow || '•'}
                              </span>
                              <span className="font-bold text-xs text-stone-200 leading-snug truncate">
                                {prod.nameAr}
                              </span>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              <span className="text-[10px] font-medium text-amber-400 bg-stone-950 px-1.5 py-0.5 rounded border border-stone-800">
                                {prod.defaultUnit || prod.unit || 'كجم'}
                              </span>

                              {/* Manager Edit/Delete buttons on each item */}
                              {canManage && managerToolsActive && (
                                <div className="flex items-center gap-0.5 mr-1">
                                  <button
                                    type="button"
                                    onClick={() => handleOpenEditItem(prod)}
                                    className="p-1 text-stone-400 hover:text-amber-300 hover:bg-stone-800 rounded transition"
                                    title="تعديل اسم الصنف ووحدته ورصيد الأمان"
                                  >
                                    <Edit2 className="w-3 h-3" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteItem(prod)}
                                    className="p-1 text-stone-400 hover:text-rose-400 hover:bg-stone-800 rounded transition"
                                    title="حذف الصنف نهائياً من المطبخ"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center justify-between gap-2 mt-1">
                            <div className="bg-stone-950/80 px-2 py-0.5 rounded-lg border border-stone-800 text-[10px] text-stone-400 shrink-0">
                              <span className="text-stone-500">رصيد الأمان: </span>
                              <span className="font-mono text-stone-300 font-bold">
                                {prod.averageDailyDemand || 0}
                              </span>
                            </div>

                            {/* Quantity Controls: Steppers + Number Input + Quick Clear */}
                            <div className="flex items-center gap-1">
                              {currentQty > 0 && (
                                <button
                                  type="button"
                                  onClick={() => handleDeleteItemQty(prod.id)}
                                  className="w-5 h-6 text-stone-500 hover:text-rose-400 flex items-center justify-center text-xs transition"
                                  title="حذف وتصفير الكمية"
                                >
                                  ✕
                                </button>
                              )}

                              <button
                                type="button"
                                onClick={() => handleStepQty(prod.id, -1)}
                                className="w-6 h-6 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center transition active:scale-95"
                                title="إنقاص الكمية"
                              >
                                <Minus className="w-3 h-3" />
                              </button>

                              <input
                                type="number"
                                min="0"
                                step="any"
                                value={currentQty === 0 ? '' : currentQty}
                                placeholder="0"
                                onChange={(e) => handleQtyChange(prod.id, e.target.value)}
                                className={`w-14 h-6 text-center rounded-lg font-mono font-bold text-xs border transition focus:outline-none focus:ring-1 ${
                                  currentQty > 0
                                    ? 'bg-amber-500/25 text-amber-300 border-amber-500/50 focus:ring-amber-400'
                                    : 'bg-stone-950 text-stone-200 border-stone-800 focus:ring-stone-600'
                                }`}
                              />

                              <button
                                type="button"
                                onClick={() => handleStepQty(prod.id, 1)}
                                className="w-6 h-6 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center transition active:scale-95"
                                title="زيادة الكمية"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Column Footer: Recipient + Green WhatsApp button */}
                <div className="p-3 bg-stone-950/95 border-t border-stone-800 space-y-2.5">
                  <div>
                    <div className="text-[11px] font-bold text-stone-400 mb-1 flex items-center justify-between">
                      <span>جهة الإرسال:</span>
                      <span className="font-mono text-amber-400 text-[10px]">{targetPhone}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-1 bg-stone-900 p-1 rounded-xl border border-stone-800">
                      <button
                        type="button"
                        onClick={() =>
                          setRecipientTypes((prev) => ({ ...prev, [colKey]: 'supplier' }))
                        }
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1 ${
                          currentRecipient === 'supplier'
                            ? 'bg-amber-500 text-stone-950 shadow-sm'
                            : 'text-stone-400 hover:text-stone-200'
                        }`}
                      >
                        <span>🏢</span>
                        <span>المورد المباشر</span>
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setRecipientTypes((prev) => ({ ...prev, [colKey]: 'purchasing' }))
                        }
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1 ${
                          currentRecipient === 'purchasing'
                            ? 'bg-amber-500 text-stone-950 shadow-sm'
                            : 'text-stone-400 hover:text-stone-200'
                        }`}
                      >
                        <span>👔</span>
                        <span>مدير المشتريات</span>
                      </button>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      handleDispatch({
                        title: sheetCol.title,
                        code: `COL-${sheetCol.colNumber}`,
                        items: rawProducts,
                        categoryKey: primaryCatId,
                        assigneeName: chosenUser.name,
                        recurrence: primaryCat?.recurrence || 'weekly',
                        scheduleTiming: primaryCat?.scheduleTiming,
                      })
                    }
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-black transition flex items-center justify-center gap-2 shadow-lg active:scale-[0.98] ${
                      itemsWithQty.length > 0
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/40 ring-1 ring-emerald-400/30'
                        : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                    }`}
                    disabled={itemsWithQty.length === 0}
                  >
                    <MessageCircle className="w-4 h-4 fill-white shrink-0" />
                    <span>إرسال طلبيّة العمود عبر WhatsApp</span>
                    {itemsWithQty.length > 0 && (
                      <span className="bg-emerald-800/80 text-emerald-100 text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                        ({itemsWithQty.length} صنف)
                      </span>
                    )}
                  </button>
                </div>
              </div>
            );
          }))}

          {/* Any Custom Sheet Columns added (> 5) */}
          {customSheetColumnNumbers.map((colNum) => {
            const rawProducts = productsBySheetColumn[colNum] || [];
            const colKey = `col-${colNum}`;
            const currentRecipient = recipientTypes[colKey] || 'supplier';
            const targetPhone = phoneSettings.purchasingPhone || '+201099887766';
            const itemsWithQty = rawProducts.filter((p) => (quantities[p.id] || 0) > 0);

            return (
              <div
                key={`custom-col-${colNum}`}
                className="w-full lg:w-[360px] xl:w-[380px] shrink-0 bg-stone-900 border border-stone-800 rounded-2xl flex flex-col shadow-lg overflow-hidden transition hover:border-stone-700"
              >
                <div className="p-4 border-b bg-gradient-to-r from-purple-950/40 via-stone-900 to-stone-900 border-purple-900/40">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-black text-sm lg:text-base text-stone-100">
                        عمود إضافي مخصص #{colNum}
                      </h3>
                      <span className="text-[11px] font-mono text-purple-400 mt-0.5 block">
                        {rawProducts.length} صنفاً مضافاً
                      </span>
                    </div>
                    <span className="bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold">
                      عمود {colNum}
                    </span>
                  </div>

                  {canManage && managerToolsActive && (
                    <div className="mt-2.5 pt-2 border-t border-stone-800/50 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => handleOpenAddItem(undefined, colNum)}
                        className="flex items-center gap-1 text-[11px] bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 px-2 py-1 rounded-lg font-bold"
                      >
                        <Plus className="w-3 h-3" />
                        <span>إضافة صنف</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleFillParLevelForProducts(rawProducts)}
                        className="text-[10px] bg-amber-500/10 text-amber-300 px-2 py-1 rounded-lg font-bold"
                      >
                        رصيد الأمان
                      </button>
                    </div>
                  )}
                </div>

                {/* Items */}
                <div className="flex-1 p-3 overflow-y-auto max-h-[520px] space-y-1.5 divide-y divide-stone-800/40">
                  {rawProducts.map((prod) => {
                    const currentQty = quantities[prod.id] || 0;
                    return (
                      <div key={prod.id} className="pt-1.5 first:pt-0 p-2 rounded-xl">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bold text-xs text-stone-200">{prod.nameAr}</span>
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] text-amber-400 bg-stone-950 px-1.5 py-0.5 rounded border border-stone-800">
                              {prod.defaultUnit || prod.unit || 'كجم'}
                            </span>
                            {canManage && managerToolsActive && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => handleOpenEditItem(prod)}
                                  className="p-1 text-stone-400 hover:text-amber-300"
                                >
                                  <Edit2 className="w-3 h-3" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteItem(prod)}
                                  className="p-1 text-stone-400 hover:text-rose-400"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center justify-between gap-2 mt-1">
                          <span className="text-[10px] text-stone-400 font-mono">
                            المتوقع: {prod.averageDailyDemand || 0}
                          </span>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleStepQty(prod.id, -1)}
                              className="w-6 h-6 rounded-lg bg-stone-800 text-stone-300 flex items-center justify-center"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <input
                              type="number"
                              min="0"
                              value={currentQty === 0 ? '' : currentQty}
                              placeholder="0"
                              onChange={(e) => handleQtyChange(prod.id, e.target.value)}
                              className="w-14 h-6 text-center rounded-lg font-mono font-bold text-xs bg-stone-950 text-stone-200 border border-stone-800"
                            />
                            <button
                              type="button"
                              onClick={() => handleStepQty(prod.id, 1)}
                              className="w-6 h-6 rounded-lg bg-stone-800 text-stone-300 flex items-center justify-center"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="p-3 bg-stone-950/95 border-t border-stone-800">
                  <button
                    type="button"
                    onClick={() =>
                      handleDispatch({
                        title: `عمود مخصص #${colNum}`,
                        code: `COL-${colNum}`,
                        items: rawProducts,
                        categoryKey: colKey,
                      })
                    }
                    className="w-full py-2.5 px-4 rounded-xl text-xs font-black bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center gap-2"
                    disabled={itemsWithQty.length === 0}
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>إرسال الطلبية عبر WhatsApp ({itemsWithQty.length})</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ======================================================== */}
      {/* MODE 2: ASSISTANTS VIEW (Filtered Categories by Assistant) */}
      {/* ======================================================== */}
      {layoutMode === 'assistants' && (
        <div className="flex flex-col lg:flex-row items-stretch gap-4 overflow-x-auto pb-6 scrollbar-thin">
          {visibleCategoriesFiltered.length === 0 ? (
            <div className="w-full bg-stone-900 border border-stone-800 rounded-2xl p-8 text-center my-6">
              <span className="text-3xl block mb-2">⏱️</span>
              <h3 className="font-bold text-stone-200 text-sm mb-1">
                لا توجد طلبيات مطابقة للدورية المحددة ({selectedRecurrenceFilter === 'daily' ? 'يومية' : selectedRecurrenceFilter === 'weekly' ? 'أسبوعية' : 'شهرية'})
              </h3>
              <p className="text-xs text-stone-400 mb-4">
                يمكنك تغيير دورية أي طلبية من لوحة التحكم أو عرض كافة الطلبيات.
              </p>
              <button
                type="button"
                onClick={() => setSelectedRecurrenceFilter('ALL')}
                className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-4 py-2 rounded-xl text-xs transition"
              >
                عرض كافة الطلبيات ({recurrenceStats.total})
              </button>
            </div>
          ) : (
            orderedCategoriesForDisplay.map((category) => {
              const catProducts = productsByCategory[category.id] || [];
              const filteredProducts = catProducts.filter((p) => {
                const matchesSearch =
                  !searchQuery.trim() ||
                  p.nameAr.includes(searchQuery.trim()) ||
                  (p.name && p.name.toLowerCase().includes(searchQuery.toLowerCase()));
                const matchesQty = !showOnlyWithQty || (quantities[p.id] || 0) > 0;
                return matchesSearch && matchesQty;
              });

              const currentRecipient = recipientTypes[category.id] || 'supplier';
              const targetPhone = getRecipientPhone(category.id, currentRecipient);
              const itemsWithQty = catProducts.filter((p) => (quantities[p.id] || 0) > 0);

              // Effective assignee with transfer option
              const effectiveAssignee = getEffectiveAssignee(category);

              const isDaily = category.recurrence === 'daily';
              const isMonthly = category.recurrence === 'monthly';

              return (
                <div
                  key={category.id}
                  className={`w-full lg:w-[360px] xl:w-[380px] shrink-0 bg-stone-900 border rounded-2xl flex flex-col shadow-lg overflow-hidden transition hover:border-stone-600 ${
                    isDaily
                      ? 'border-emerald-900/60 ring-1 ring-emerald-500/20'
                      : isMonthly
                      ? 'border-purple-900/60 ring-1 ring-purple-500/20'
                      : 'border-blue-900/60 ring-1 ring-blue-500/20'
                  }`}
                >
                  {/* Header */}
                  <div
                    className={`p-4 border-b ${
                      isDaily
                        ? 'bg-gradient-to-r from-emerald-950/60 to-stone-900 border-emerald-900/50'
                        : isMonthly
                        ? 'bg-gradient-to-r from-purple-950/60 to-stone-900 border-purple-900/50'
                        : 'bg-gradient-to-r from-blue-950/60 to-stone-900 border-blue-900/50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xl">
                            {category.id === 'cat-veg'
                              ? '🥬'
                              : category.id === 'cat-meat'
                              ? '🥩'
                              : category.id === 'cat-poultry'
                              ? '🍗'
                              : category.id === 'cat-sauces'
                              ? '🫙'
                              : category.id === 'cat-frozen-oils'
                              ? '❄️'
                              : category.id === 'cat-falahi-bread'
                              ? '🥖'
                              : category.id === 'cat-brioche'
                              ? '🥐'
                              : category.id === 'cat-packaging'
                              ? '📦'
                              : category.id === 'cat-cleaning'
                              ? '🧼'
                              : category.id === 'cat-cashier'
                              ? '🧾'
                              : '📋'}
                          </span>
                          <h3 className="font-extrabold text-base text-stone-100">{category.nameAr}</h3>
                        </div>
                        <span className="text-[11px] font-mono text-stone-400 mt-0.5 block">
                          كود: {category.code}
                        </span>
                      </div>

                      <div className="flex flex-col items-end gap-1">
                        {isAssistantUser && (
                          <span
                            className={`text-[9px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 border ${
                              myAssignedCatIds.has(category.id)
                                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                                : 'bg-stone-800 text-stone-400 border-stone-700'
                            }`}
                          >
                            {myAssignedCatIds.has(category.id) ? '⭐ طلبيتك المكلف بها' : '👁️ عرض اختياري'}
                          </span>
                        )}
                        <div className="flex items-center gap-1">
                          {/* Manager Quick Recurrence Selector vs Static Badge */}
                          {canManage && managerToolsActive ? (
                            <select
                              value={category.recurrence || 'weekly'}
                              onChange={(e) =>
                                handleQuickChangeRecurrence(category.id, e.target.value as any)
                              }
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full border cursor-pointer focus:outline-none ${
                                isDaily
                                  ? 'bg-emerald-950 text-emerald-300 border-emerald-500/50'
                                  : isMonthly
                                  ? 'bg-purple-950 text-purple-300 border-purple-500/50'
                                  : 'bg-blue-950 text-blue-300 border-blue-500/50'
                              }`}
                              title="تغيير دورية الطلبية للمدير (يومي / أسبوعي / شهري)"
                            >
                              <option value="daily">☀️ يومية</option>
                              <option value="weekly">📅 أسبوعية</option>
                              <option value="monthly">🗓️ شهرية</option>
                            </select>
                          ) : (
                            <span
                              className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${
                                isDaily
                                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                                  : isMonthly
                                  ? 'bg-purple-500/20 text-purple-400 border-purple-500/30'
                                  : 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                              }`}
                            >
                              {isDaily ? '☀️ يومية' : isMonthly ? '🗓️ شهرية' : '📅 أسبوعية'}
                            </span>
                          )}

                          {/* Manager Column Actions (Edit & Delete Column) */}
                          {canManage && managerToolsActive && (
                            <div className="flex items-center gap-1 mr-1">
                              <button
                                type="button"
                                onClick={() => handleOpenEditColumn(category)}
                                className="p-1 rounded-lg bg-stone-800 text-stone-300 hover:text-amber-400 transition"
                                title="تعديل موعد ودورية وبيانات الطلبية"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteColumn(category)}
                                className="p-1 rounded-lg bg-stone-800 text-stone-300 hover:text-rose-400 transition"
                                title="حذف هذا العمود بالكامل"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>

                      {/* Display schedule timing if configured */}
                      {category.scheduleTiming && (
                        <span className="text-[10px] text-amber-300/95 font-mono bg-stone-950 px-2 py-0.5 rounded border border-amber-500/20 flex items-center gap-1">
                          <Clock className="w-2.5 h-2.5 text-amber-400" />
                          <span>{category.scheduleTiming}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Transfer Option from Manager to Assistant in Column Header */}
                  <div className="mt-2.5 flex items-center justify-between text-xs text-stone-300 pt-2 border-t border-stone-800/60 gap-2">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <UserCheck className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span className="text-[11px] text-stone-400 font-bold shrink-0">المسؤول:</span>
                      <select
                        value={effectiveAssignee.id}
                        onChange={(e) => handleTransferAssignee(category.id, e.target.value)}
                        className="bg-stone-950 border border-stone-800 text-amber-300 text-[11px] font-bold rounded-lg px-2 py-1 focus:outline-none focus:border-amber-400 cursor-pointer max-w-[175px] truncate"
                        title="خيار التحويل من المدير إلى المساعد"
                      >
                        <option value="user-manager-01">👨‍🍳 الشيف العمومي (المدير)</option>
                        <optgroup label="المساعدون الخمسة">
                          {assistantsList.map((asst) => (
                            <option key={asst.id} value={asst.id}>
                              🧑‍🍳 {asst.name.split('(')[0].trim()}
                            </option>
                          ))}
                        </optgroup>
                      </select>
                    </div>

                    <span className="bg-stone-950 px-2 py-0.5 rounded text-[11px] text-stone-400 shrink-0 font-mono">
                      {catProducts.length} صنف
                    </span>
                  </div>

                  {/* Manager In-Column Quick Action Buttons */}
                  {canManage && managerToolsActive && (
                    <div className="mt-2.5 pt-2 border-t border-stone-800/50 flex items-center justify-between gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleOpenAddItem(category.id)}
                        className="flex items-center gap-1 text-[11px] bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-1 rounded-lg font-bold transition"
                        title="إضافة صنف جديد لهذه الطلبية"
                      >
                        <Plus className="w-3 h-3" />
                        <span>إضافة صنف</span>
                      </button>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleFillParLevelForProducts(catProducts)}
                          className="flex items-center gap-1 text-[10px] bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-1 rounded-lg font-semibold transition"
                          title="تعبئة الكميات برصيد الأمان لهذه الطلبية"
                        >
                          <Sparkles className="w-3 h-3 text-amber-400" />
                          <span>رصيد الأمان</span>
                        </button>

                        {itemsWithQty.length > 0 && (
                          <button
                            type="button"
                            onClick={() => handleClearProductsQuantities(catProducts)}
                            className="flex items-center gap-1 text-[10px] bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-1 rounded-lg font-semibold transition"
                            title="تفريغ كميات هذه الطلبية"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>تفريغ</span>
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Items List */}
                <div className="flex-1 p-3 overflow-y-auto max-h-[500px] space-y-2 divide-y divide-stone-800/40">
                  {filteredProducts.length === 0 ? (
                    <div className="text-center py-8 text-stone-500 text-xs">
                      لا توجد أصناف مطابقة للبحث في هذه الطلبية
                    </div>
                  ) : (
                    filteredProducts.map((prod) => {
                      const currentQty = quantities[prod.id] || 0;
                      return (
                        <div
                          key={prod.id}
                          className={`pt-2 first:pt-0 p-2 rounded-xl transition group ${
                            currentQty > 0
                              ? 'bg-amber-500/10 border border-amber-500/20'
                              : 'hover:bg-stone-800/40'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 mb-1.5">
                            <span className="font-bold text-xs text-stone-200 leading-snug">
                              {prod.nameAr}
                            </span>
                            <div className="flex items-center gap-1 shrink-0">
                              <span className="text-[11px] font-medium text-amber-400 bg-stone-950 px-1.5 py-0.5 rounded border border-stone-800">
                                {prod.defaultUnit || prod.unit || 'كجم'}
                              </span>

                              {/* Manager Item Controls */}
                              {canManage && managerToolsActive && (
                                <div className="flex items-center gap-0.5 mr-1">
                                  <button
                                    type="button"
                                    onClick={() => handleOpenEditItem(prod)}
                                    className="p-1 text-stone-400 hover:text-amber-300 hover:bg-stone-800 rounded transition"
                                    title="تعديل اسم الصنف ووحدته ورصيد الأمان"
                                  >
                                    <Edit2 className="w-3 h-3" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteItem(prod)}
                                    className="p-1 text-stone-400 hover:text-rose-400 hover:bg-stone-800 rounded transition"
                                    title="حذف الصنف نهائياً من المطبخ"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center justify-between gap-2 mt-1">
                            <div className="bg-stone-950/80 px-2 py-1 rounded-lg border border-stone-800 text-[11px] text-stone-400 shrink-0">
                              <span className="text-stone-500">رصيد الأمان: </span>
                              <span className="font-mono text-stone-300 font-bold">
                                {prod.averageDailyDemand || 0}
                              </span>
                            </div>

                            <div className="flex items-center gap-1">
                              {currentQty > 0 && (
                                <button
                                  type="button"
                                  onClick={() => handleDeleteItemQty(prod.id)}
                                  className="w-5 h-7 text-stone-500 hover:text-rose-400 flex items-center justify-center text-xs transition"
                                  title="حذف وتصفير الكمية"
                                >
                                  ✕
                                </button>
                              )}

                              <button
                                type="button"
                                onClick={() => handleStepQty(prod.id, -1)}
                                className="w-7 h-7 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center transition active:scale-95"
                                title="إنقاص الكمية"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>

                              <input
                                type="number"
                                min="0"
                                step="any"
                                value={currentQty === 0 ? '' : currentQty}
                                placeholder="0"
                                onChange={(e) => handleQtyChange(prod.id, e.target.value)}
                                className={`w-16 h-7 text-center rounded-lg font-mono font-bold text-xs border transition focus:outline-none focus:ring-1 ${
                                  currentQty > 0
                                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 focus:ring-amber-400'
                                    : 'bg-stone-950 text-stone-200 border-stone-800 focus:ring-stone-600'
                                }`}
                              />

                              <button
                                type="button"
                                onClick={() => handleStepQty(prod.id, 1)}
                                className="w-7 h-7 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center transition active:scale-95"
                                title="زيادة الكمية"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Footer */}
                <div className="p-3 bg-stone-950/90 border-t border-stone-800 space-y-2.5">
                  <div>
                    <div className="text-[11px] font-bold text-stone-400 mb-1 flex items-center justify-between">
                      <span>جهة الإرسال:</span>
                      <span className="font-mono text-amber-400 text-[10px]">{targetPhone}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5 bg-stone-900 p-1 rounded-xl border border-stone-800">
                      <button
                        type="button"
                        onClick={() =>
                          setRecipientTypes((prev) => ({ ...prev, [category.id]: 'supplier' }))
                        }
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                          currentRecipient === 'supplier'
                            ? 'bg-amber-500 text-stone-950 shadow-sm'
                            : 'text-stone-400 hover:text-stone-200'
                        }`}
                      >
                        <span>🏢</span>
                        <span>المورد المباشر</span>
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setRecipientTypes((prev) => ({ ...prev, [category.id]: 'purchasing' }))
                        }
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                          currentRecipient === 'purchasing'
                            ? 'bg-amber-500 text-stone-950 shadow-sm'
                            : 'text-stone-400 hover:text-stone-200'
                        }`}
                      >
                        <span>👔</span>
                        <span>مدير المشتريات</span>
                      </button>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      handleDispatch({
                        title: category.nameAr,
                        code: category.code,
                        items: catProducts,
                        categoryKey: category.id,
                        assigneeName: effectiveAssignee.name,
                        recurrence: category.recurrence,
                        scheduleTiming: category.scheduleTiming,
                      })
                    }
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-black transition flex items-center justify-center gap-2 shadow-lg active:scale-[0.98] ${
                      itemsWithQty.length > 0
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/40 ring-1 ring-emerald-400/30'
                        : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                    }`}
                    disabled={itemsWithQty.length === 0}
                  >
                    <MessageCircle className="w-4 h-4 fill-white shrink-0" />
                    <span>إرسال الطلبية عبر WhatsApp</span>
                    {itemsWithQty.length > 0 && (
                      <span className="bg-emerald-800/80 text-emerald-100 text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                        ({itemsWithQty.length} صنف)
                      </span>
                    )}
                  </button>
                </div>
              </div>
            );
          }))}
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 1: ADD / EDIT ITEM (إضافة أو تعديل اسم الصنف) */}
      {/* ======================================================== */}
      {itemModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col text-stone-100">
            <div className="p-4 bg-stone-850 border-b border-stone-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xl">{itemModal.mode === 'edit' ? '✏️' : '➕'}</span>
                <h3 className="font-black text-sm text-stone-100">
                  {itemModal.mode === 'edit' ? 'تعديل بيانات الصنف واسمه' : 'إضافة صنف جديد للمطبخ'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setItemModal((prev) => ({ ...prev, isOpen: false }))}
                className="w-7 h-7 rounded-full bg-stone-800 text-stone-400 hover:text-white flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveItemModal} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block text-stone-300 font-bold mb-1">اسم الصنف باللغة العربية:</label>
                <input
                  type="text"
                  required
                  value={itemModal.nameAr}
                  onChange={(e) => setItemModal((prev) => ({ ...prev, nameAr: e.target.value }))}
                  placeholder="مثال: لحم استيك بقري، طماطم، كمون ناعم..."
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 font-bold focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-300 font-bold mb-1">وحدة القياس:</label>
                  <select
                    value={itemModal.unit}
                    onChange={(e) => setItemModal((prev) => ({ ...prev, unit: e.target.value }))}
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 focus:outline-none focus:border-amber-500 font-semibold"
                  >
                    <option value="كجم">كجم</option>
                    <option value="حبة">حبة</option>
                    <option value="لتر">لتر</option>
                    <option value="كرتونة">كرتونة</option>
                    <option value="شوال / كيس">شوال / كيس</option>
                    <option value="باكت">باكت</option>
                    <option value="علبة">علبة</option>
                    <option value="رول">رول</option>
                    <option value="طرد">طرد</option>
                  </select>
                </div>

                <div>
                  <label className="block text-stone-300 font-bold mb-1">رصيد الأمان (المتوقع):</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={itemModal.parLevel}
                    onChange={(e) =>
                      setItemModal((prev) => ({ ...prev, parLevel: parseFloat(e.target.value) || 0 }))
                    }
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 font-mono font-bold focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-300 font-bold mb-1">الطلبية / الفئة المندرجة تحتها:</label>
                <select
                  value={itemModal.categoryId}
                  onChange={(e) => setItemModal((prev) => ({ ...prev, categoryId: e.target.value }))}
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 focus:outline-none focus:border-amber-500"
                >
                  {orderTypes.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.nameAr} ({cat.recurrence === 'daily' ? 'يومية' : cat.recurrence === 'monthly' ? 'شهرية' : 'أسبوعية'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-stone-300 font-bold mb-1">العمود في جدول المطبخ (1-5):</label>
                <select
                  value={itemModal.sheetColumn || 1}
                  onChange={(e) =>
                    setItemModal((prev) => ({ ...prev, sheetColumn: Number(e.target.value) }))
                  }
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 focus:outline-none focus:border-amber-500"
                >
                  <option value={1}>العمود 1: اللحوم والدواجن والألبان والجبن</option>
                  <option value={2}>العمود 2: الخضروات والمخللات</option>
                  <option value={3}>العمود 3: التوابل والعطارة والبهارات</option>
                  <option value={4}>العمود 4: البقالة والزيوت والصوصات والمخبوزات</option>
                  <option value={5}>العمود 5: التغليف والأدوات والعلب</option>
                </select>
              </div>

              <div className="pt-3 border-t border-stone-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setItemModal((prev) => ({ ...prev, isOpen: false }))}
                  className="px-4 py-2 bg-stone-800 hover:bg-stone-750 text-stone-300 rounded-xl font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-xl font-black shadow-lg shadow-amber-950/40"
                >
                  {itemModal.mode === 'edit' ? 'حفظ التعديلات' : 'إضافة الصنف الآن'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 2: ADD / EDIT COLUMN & SCHEDULE & ASSIGNEE TRANSFER */}
      {/* ======================================================== */}
      {columnModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col text-stone-100">
            <div className="p-4 bg-stone-850 border-b border-stone-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xl">{columnModal.mode === 'edit' ? '✏️' : '➕'}</span>
                <h3 className="font-black text-sm text-stone-100">
                  {columnModal.mode === 'edit'
                    ? 'ضبط وتعديل موعد ودورية وبيانات الطلبية'
                    : 'إضافة عمود / طلبية جديدة للمطبخ'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setColumnModal((prev) => ({ ...prev, isOpen: false }))}
                className="w-7 h-7 rounded-full bg-stone-800 text-stone-400 hover:text-white flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveColumnModal} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block text-stone-300 font-bold mb-1">اسم العمود / الطلبية:</label>
                <input
                  type="text"
                  required
                  value={columnModal.nameAr}
                  onChange={(e) => setColumnModal((prev) => ({ ...prev, nameAr: e.target.value }))}
                  placeholder="مثال: طلبية الأسماك، طلبية المشروبات، بوفيه الإفطار..."
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 font-bold focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-300 font-bold mb-1">كود مميز (لاتيني):</label>
                  <input
                    type="text"
                    required
                    value={columnModal.code}
                    onChange={(e) =>
                      setColumnModal((prev) => ({ ...prev, code: e.target.value.toUpperCase() }))
                    }
                    placeholder="FISH, CAFE..."
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 font-mono font-bold focus:outline-none focus:border-amber-500"
                  />
                </div>

                {/* Recurrence Selector: Daily / Weekly / Monthly */}
                <div>
                  <label className="block text-stone-300 font-bold mb-1">
                    دورية الطلبية (ضبط المدير):
                  </label>
                  <select
                    value={columnModal.recurrence}
                    onChange={(e) =>
                      setColumnModal((prev) => ({
                        ...prev,
                        recurrence: e.target.value as 'daily' | 'weekly' | 'monthly',
                      }))
                    }
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 focus:outline-none focus:border-amber-500 font-bold"
                  >
                    <option value="daily">☀️ دورية يومية</option>
                    <option value="weekly">📅 دورية أسبوعية</option>
                    <option value="monthly">🗓️ دورية شهرية</option>
                  </select>
                </div>
              </div>

              {/* Specific Timing / Schedule setting */}
              <div>
                <label className="block text-stone-300 font-bold mb-1 flex items-center justify-between">
                  <span>موعد وتوقيت الطلبية المحدد (من المدير):</span>
                  <span className="text-[10px] text-amber-400 font-mono">اختياري</span>
                </label>
                <input
                  type="text"
                  value={columnModal.scheduleTiming}
                  onChange={(e) =>
                    setColumnModal((prev) => ({ ...prev, scheduleTiming: e.target.value }))
                  }
                  placeholder="مثال: الساعة 07:00 ص كحد أقصى، كل سبت، أول كل شهر..."
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 font-mono focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Transfer/Assignee Option from Manager to Assistant */}
              <div>
                <label className="block text-stone-300 font-bold mb-1">
                  المسؤول عن الطلبية (خيار التحويل من المدير إلى المساعد):
                </label>
                <select
                  value={columnModal.defaultAssigneeId}
                  onChange={(e) =>
                    setColumnModal((prev) => ({ ...prev, defaultAssigneeId: e.target.value }))
                  }
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 font-bold focus:outline-none focus:border-amber-500"
                >
                  <option value="user-manager-01">👨‍🍳 الشيف العمومي (مدير المطبخ - Admin)</option>
                  <optgroup label="المساعدون الخمسة">
                    {assistantsList.map((asst) => (
                      <option key={asst.id} value={asst.id}>
                        🧑‍🍳 {asst.name}
                      </option>
                    ))}
                  </optgroup>
                </select>
              </div>

              <div>
                <label className="block text-stone-300 font-bold mb-1">رقم هاتف المورد المعني بالواتساب:</label>
                <input
                  type="text"
                  required
                  value={columnModal.supplierPhone}
                  onChange={(e) =>
                    setColumnModal((prev) => ({ ...prev, supplierPhone: e.target.value }))
                  }
                  placeholder="+201012345678"
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 font-mono focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-stone-300 font-bold mb-1">وصف أو ملاحظات:</label>
                <input
                  type="text"
                  value={columnModal.description}
                  onChange={(e) =>
                    setColumnModal((prev) => ({ ...prev, description: e.target.value }))
                  }
                  placeholder="ملاحظات توضيحية..."
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-stone-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="pt-3 border-t border-stone-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setColumnModal((prev) => ({ ...prev, isOpen: false }))}
                  className="px-4 py-2 bg-stone-800 hover:bg-stone-750 text-stone-300 rounded-xl font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-xl font-black shadow-lg shadow-amber-950/40"
                >
                  {columnModal.mode === 'edit' ? 'حفظ التعديلات' : 'إضافة العمود الآن'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* DUAL WHATSAPP DISPATCH MODAL WITH CHEF CC */}
      {/* ======================================================== */}
      {dispatchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col text-stone-100">
            {/* Modal Header */}
            <div className="p-5 bg-gradient-to-r from-emerald-950/70 via-stone-900 to-stone-900 border-b border-stone-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-base text-stone-100">
                    تم تجهيز وأرشفة الطلبية بنجاح!
                  </h3>
                  <span className="text-xs text-stone-400 font-mono">
                    كود: {dispatchModal.orderId} • {dispatchModal.orderTitle}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setDispatchModal(null)}
                className="w-8 h-8 rounded-full bg-stone-800 text-stone-400 hover:text-white flex items-center justify-center transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4 overflow-y-auto max-h-[65vh]">
              <div className="bg-stone-950 p-3.5 rounded-2xl border border-stone-800 space-y-2 text-xs">
                <div className="flex justify-between items-center text-stone-300">
                  <span>جهة الاستلام المختارة:</span>
                  <span className="font-bold text-amber-400">
                    {dispatchModal.recipientType === 'supplier' ? '🏢 المورد المباشر المعتمد' : '👔 مدير المشتريات والمستودع'}
                  </span>
                </div>
                <div className="flex justify-between items-center text-stone-300">
                  <span>القائم بالحصر والطلب:</span>
                  <span className="font-bold text-emerald-400">{dispatchModal.assistantName}</span>
                </div>
                <div className="flex justify-between items-center text-stone-300">
                  <span>رقم الهاتف الموجه إليه:</span>
                  <span className="font-mono text-emerald-400 font-bold">{dispatchModal.targetPhone}</span>
                </div>
                <div className="flex justify-between items-center text-stone-300">
                  <span>عدد الأصناف المطلوبة:</span>
                  <span className="font-bold text-stone-100">{dispatchModal.items.length} صنف</span>
                </div>
                <div className="flex justify-between items-center text-stone-300">
                  <span>الأسبوع المؤرشف فيه:</span>
                  <span className="text-stone-300 font-medium">{currentWorkWeek}</span>
                </div>
              </div>

              {/* Action 1: Open WhatsApp to Chosen Recipient */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-300 flex items-center gap-1.5">
                  <Send className="w-3.5 h-3.5 text-emerald-400" />
                  <span>الخطوة 1: الإرسال للجهة المعنية عبر WhatsApp:</span>
                </label>
                <a
                  href={dispatchModal.whatsappRecipientUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 rounded-xl font-black text-sm bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50 transition active:scale-[0.99]"
                >
                  <MessageCircle className="w-5 h-5 fill-white" />
                  <span>فتح WhatsApp وإرسال الطلبية للمستلم</span>
                  <ExternalLink className="w-4 h-4 ml-1" />
                </a>
              </div>

              {/* Action 2: Chef Carbon Copy (النسخة المطابقة للشيف العمومي) */}
              <div className="space-y-1.5 pt-2 border-t border-stone-800">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <Share2 className="w-3.5 h-3.5 text-amber-400" />
                    <span>الخطوة 2: إرسال نسخة مطابقة للشيف العمومي (Chef CC):</span>
                  </label>
                  <span className="font-mono text-[10px] text-stone-400">{dispatchModal.chefPhone}</span>
                </div>

                <a
                  href={dispatchModal.whatsappChefUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setCcSent(true)}
                  className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition active:scale-[0.99] border ${
                    ccSent
                      ? 'bg-stone-800 text-emerald-400 border-emerald-500/40'
                      : 'bg-amber-500 hover:bg-amber-450 text-stone-950 border-amber-400 shadow-md shadow-amber-950/40'
                  }`}
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>
                    {ccSent
                      ? '✓ تم فتح إرسال النسخة المطابقة للشيف العمومي'
                      : 'إرسال نسخة مطابقة للشيف العمومي (WhatsApp CC)'}
                  </span>
                  <ExternalLink className="w-3.5 h-3.5 ml-1" />
                </a>
              </div>

              {/* Action 3: Fallback Copy Text */}
              <div className="space-y-1.5 pt-2 border-t border-stone-800">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-stone-400">معاينة نص الرسالة الرسمية:</span>
                  <button
                    type="button"
                    onClick={handleCopyMessage}
                    className="flex items-center gap-1 text-xs text-amber-400 hover:text-amber-300 font-bold"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{isCopied ? 'تم النسخ للحافظة ✓' : 'نسخ النص'}</span>
                  </button>
                </div>
                <pre className="bg-stone-950 p-3 rounded-xl border border-stone-800 text-[11px] font-mono text-stone-300 whitespace-pre-wrap max-h-36 overflow-y-auto leading-relaxed">
                  {dispatchModal.whatsappText}
                </pre>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-stone-950 border-t border-stone-800 flex items-center justify-between gap-3">
              {onNavigateTab && (
                <button
                  type="button"
                  onClick={() => {
                    setDispatchModal(null);
                    onNavigateTab('weekly-archive');
                  }}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-stone-800 hover:bg-stone-700 text-stone-200 transition"
                >
                  📂 فتح الملف الأسبوعي
                </button>
              )}
              <button
                type="button"
                onClick={() => setDispatchModal(null)}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-stone-950 transition ml-auto"
              >
                إغلاق والمتابعة
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
