import React, { useState } from 'react';
import { ActualOrder, Supplier, OrderType } from '../../types';
import { whatsappService } from '../../features/dispatch/services/whatsappService';
import { PurchaseOrderPayload } from '../../features/dispatch/types';
import { MessageSquare, X, Copy, Check, ExternalLink, Send, Phone, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';

interface WhatsAppDispatchModalProps {
  order: ActualOrder;
  supplier?: Supplier;
  category?: OrderType;
  onClose: () => void;
  onDispatched?: () => void;
}

export const WhatsAppDispatchModal: React.FC<WhatsAppDispatchModalProps> = ({
  order,
  supplier,
  category,
  onClose,
  onDispatched,
}) => {
  const { currentUser } = useAuth();
  const { updateOrderStatus } = useData();

  const [supplierPhone, setSupplierPhone] = useState(supplier?.phone || '01012345678');
  const [copied, setCopied] = useState(false);
  const [statusUpdated, setStatusUpdated] = useState(false);
  const [loading, setLoading] = useState(false);

  const payload: PurchaseOrderPayload = {
    orderId: order.id,
    orderCode: order.orderNumber || order.id,
    orderTypeNameAr: category?.nameAr || 'طلبية مطبخ عامة',
    supplierNameAr: supplier?.name || 'المورد المعتمد',
    supplierPhone: supplierPhone,
    targetDate: order.expectedDeliveryTime
      ? order.expectedDeliveryTime.split('T')[0]
      : order.orderDate,
    notes: order.notes,
    items: order.items.map((i) => ({
      productNameAr: i.productName,
      unit: i.unit,
      quantity: i.orderedQty || i.requestedQty,
    })),
  };

  const formattedMessage = whatsappService.buildOrderMessage(payload);
  const whatsappUrl = whatsappService.generateWhatsAppUrl(payload);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(formattedMessage);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (e) {
      console.warn('Clipboard write failed:', e);
    }
  };

  const handleMarkAsOrdered = async () => {
    setLoading(true);
    try {
      if (order.status !== 'ORDERED') {
        await updateOrderStatus(
          order.id,
          'ORDERED',
          `تم إرسال أمر الشراء للمورد (${payload.supplierNameAr}) عبر واتساب على الرقم ${payload.supplierPhone}`
        );
      }
      setStatusUpdated(true);
      if (onDispatched) onDispatched();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm">
      <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-xl p-5 text-stone-100 shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-100">
                إرسال أمر التوريد عبر WhatsApp
              </h3>
              <span className="text-[11px] font-mono text-amber-400">{order.id}</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white bg-stone-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 text-xs">
          {/* Supplier details card */}
          <div className="p-3.5 bg-stone-950/70 border border-stone-800 rounded-xl space-y-2.5">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <div>
                <span className="text-stone-400 block text-[11px]">المورد المستهدف:</span>
                <span className="font-bold text-stone-200 text-sm">{payload.supplierNameAr}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-stone-400" />
                <span className="text-[11px] text-stone-400">رقم الهاتف:</span>
                <input
                  type="text"
                  value={supplierPhone}
                  onChange={(e) => setSupplierPhone(e.target.value)}
                  placeholder="01xxxxxxxxx"
                  className="w-32 bg-stone-900 border border-stone-750 rounded-lg px-2 py-1 font-mono text-emerald-400 font-bold focus:outline-none focus:border-emerald-500 text-center"
                />
              </div>
            </div>
            <div className="flex items-center justify-between text-[11px] pt-2 border-t border-stone-800/60 text-stone-400">
              <span>الفئة: <strong className="text-stone-300">{payload.orderTypeNameAr}</strong></span>
              <span>موعد الوصول الثابت: <strong className="font-mono text-amber-400">01:00 م كحد أقصى</strong></span>
              <span>عدد البنود: <strong className="font-mono text-stone-200">{payload.items.length} صنف</strong></span>
            </div>
          </div>

          {/* Rendered WhatsApp Markdown Message */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-stone-300">معاينة نص الرسالة بتنسيق واتساب:</span>
              <button
                type="button"
                onClick={handleCopy}
                className="text-[11px] px-2.5 py-1 bg-stone-800 hover:bg-stone-700 text-amber-300 rounded-lg font-semibold flex items-center gap-1 transition"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>تم النسخ بنجاح!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>نسخ الرسالة</span>
                  </>
                )}
              </button>
            </div>

            <div className="p-3 bg-stone-950 border border-stone-800 rounded-xl font-mono text-[11px] text-stone-300 whitespace-pre-wrap leading-relaxed max-h-56 overflow-y-auto selection:bg-emerald-500/30">
              {formattedMessage}
            </div>
          </div>

          {statusUpdated && (
            <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>تم تحديث حالة الطلبية إلى "تم الطلب للمورد (ORDERED)" وتوثيق العملية في سجل التدقيق.</span>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="pt-3 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            {!statusUpdated && order.status !== 'ORDERED' && (
              <button
                type="button"
                onClick={handleMarkAsOrdered}
                disabled={loading}
                className="px-3 py-2 bg-stone-800 hover:bg-stone-700 text-amber-300 rounded-xl text-xs font-semibold transition"
              >
                {loading ? 'جاري التحديث...' : 'تحديث الحالة إلى "تم الطلب"'}
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-stone-800 hover:bg-stone-750 text-stone-300 rounded-xl text-xs font-semibold transition"
            >
              إغلاق
            </button>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => {
                if (order.status !== 'ORDERED') {
                  handleMarkAsOrdered();
                }
              }}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-emerald-600/20"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>فتح محادثة واتساب للمورد</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
