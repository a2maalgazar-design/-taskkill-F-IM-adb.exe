import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  Calendar,
  ChevronDown,
  Download,
  Filter,
  Layers,
  Printer,
  Sparkles,
  TrendingUp,
  Users,
  X,
  FileSpreadsheet,
} from 'lucide-react';
import { OrderType, Product, User } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';

interface OrderStatisticsPanelProps {
  initialCategoryId?: string;
  onClose?: () => void;
  quantities?: Record<string, number>;
}

export const OrderStatisticsPanel: React.FC<OrderStatisticsPanelProps> = ({
  initialCategoryId,
  onClose,
  quantities = {},
}) => {
  const { currentUser, isManager, users } = useAuth();
  const { orderTypes, products } = useData();

  // Filter allowed categories: Manager sees all, Assistant sees his assigned categories
  const allowedCategories = useMemo(() => {
    if (isManager || currentUser.role === 'manager') return orderTypes;
    const assignedIds = currentUser.assignedOrderTypeIds || [];
    const filtered = orderTypes.filter((c) => assignedIds.includes(c.id));
    return filtered.length > 0 ? filtered : orderTypes;
  }, [orderTypes, currentUser, isManager]);

  const [selectedCatId, setSelectedCatId] = useState<string>(
    initialCategoryId && allowedCategories.some((c) => c.id === initialCategoryId)
      ? initialCategoryId
      : allowedCategories[0]?.id || 'cat-veg'
  );

  const [searchQuery, setSearchQuery] = useState('');

  const currentCategory = useMemo(() => {
    return orderTypes.find((c) => c.id === selectedCatId) || orderTypes[0];
  }, [orderTypes, selectedCatId]);

  const assignedUser = useMemo(() => {
    if (!currentCategory) return null;
    return users.find((u) => u.id === currentCategory.defaultAssigneeId);
  }, [users, currentCategory]);

  // Products belonging to the selected order type
  const categoryProducts = useMemo(() => {
    if (!currentCategory) return [];
    return products
      .filter((p) => p.isActive && p.orderTypeId === currentCategory.id)
      .sort((a, b) => (a.sheetRow || 0) - (b.sheetRow || 0));
  }, [products, currentCategory]);

  const filteredItems = useMemo(() => {
    if (!searchQuery.trim()) return categoryProducts;
    const q = searchQuery.toLowerCase().trim();
    return categoryProducts.filter((p) => p.nameAr.toLowerCase().includes(q));
  }, [categoryProducts, searchQuery]);

  // Calculate weekly & monthly aggregations
  const statsSummary = useMemo(() => {
    let totalItems = categoryProducts.length;
    let totalDailyDemand = 0;
    let totalWeeklyDemand = 0;
    let totalMonthlyDemand = 0;
    let totalCurrentQuantities = 0;

    for (const p of categoryProducts) {
      const daily = p.averageDailyDemand || 0;
      totalDailyDemand += daily;
      totalWeeklyDemand += daily * 7;
      totalMonthlyDemand += daily * 30;
      totalCurrentQuantities += quantities[p.id] || 0;
    }

    return {
      totalItems,
      totalDailyDemand,
      totalWeeklyDemand,
      totalMonthlyDemand,
      totalCurrentQuantities,
    };
  }, [categoryProducts, quantities]);

  const handleExportCSV = () => {
    if (!currentCategory) return;
    const headers = [
      'رقم البند',
      'اسم الصنف',
      'الوحدة',
      'الاستهلاك اليومي (حد الأمان)',
      'كمية الطلب الأسبوعي (7 أيام)',
      'كمية الطلب الشهري (30 يوماً)',
      'الكمية المطلوبة حالياً',
    ];
    const rows = categoryProducts.map((p, idx) => [
      p.sheetRow || idx + 1,
      `"${p.nameAr}"`,
      p.defaultUnit || p.unit || 'كجم',
      p.averageDailyDemand || 0,
      (p.averageDailyDemand || 0) * 7,
      (p.averageDailyDemand || 0) * 30,
      quantities[p.id] || 0,
    ]);

    const csvContent =
      '\uFEFF' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `احصائيات_${currentCategory.nameAr}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-stone-900 border border-stone-800 rounded-2xl shadow-2xl overflow-hidden mb-5 animate-fadeIn">
      {/* Header Bar */}
      <div className="p-4 bg-gradient-to-r from-stone-900 via-stone-850 to-stone-900 border-b border-stone-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center shrink-0">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-black text-sm md:text-base text-stone-100">
                الجدول الإحصائي للطلب الأسبوعي والشهري لكل طلبية
              </h3>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 font-mono px-2 py-0.5 rounded-full font-bold">
                تحليل الاستهلاك
              </span>
            </div>
            <p className="text-xs text-stone-400 mt-0.5">
              مخصص للشيف العمومي والمسؤول عن الطلبية لإعطاء رؤية دقيقة لحجم التوريد الأسبوعي والشهري
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">تصدير Excel/CSV</span>
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-750 text-stone-400 hover:text-stone-200 border border-stone-700"
              title="إغلاق اللوحة الإحصائية"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Category Tabs & Quick Stats Toolbar */}
      <div className="p-4 border-b border-stone-800 bg-stone-950/60 space-y-3">
        <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 scrollbar-thin">
          <div className="flex items-center gap-1.5">
            {allowedCategories.map((cat) => {
              const isSelected = cat.id === selectedCatId;
              const prodsCount = products.filter((p) => p.orderTypeId === cat.id && p.isActive).length;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCatId(cat.id)}
                  className={`px-3 py-2 rounded-xl text-xs font-bold transition shrink-0 flex items-center gap-2 border ${
                    isSelected
                      ? 'bg-amber-500 text-stone-950 border-amber-400 shadow-md shadow-amber-500/20'
                      : 'bg-stone-900 text-stone-300 border-stone-800 hover:bg-stone-850'
                  }`}
                >
                  <span>{cat.nameAr}</span>
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                      isSelected ? 'bg-stone-950 text-amber-300' : 'bg-stone-800 text-stone-400'
                    }`}
                  >
                    {prodsCount}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Current Order Summary KPI Cards */}
        {currentCategory && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
            <div className="bg-stone-900 border border-stone-800 rounded-xl p-3">
              <span className="text-[10px] text-stone-400 block">إجمالي أصناف الطلبية:</span>
              <span className="text-base font-black text-amber-400 font-mono mt-0.5 block">
                {statsSummary.totalItems} صنف
              </span>
              <span className="text-[10px] text-stone-500 mt-0.5 block font-mono">
                كود: {currentCategory.code}
              </span>
            </div>

            <div className="bg-stone-900 border border-stone-800 rounded-xl p-3">
              <span className="text-[10px] text-stone-400 block">المسؤول عن الطلبية:</span>
              <span className="text-xs font-black text-stone-200 mt-1 block truncate">
                {assignedUser ? assignedUser.name.split('(')[0] : 'الشيف العمومي'}
              </span>
              <span className="text-[10px] text-amber-500/80 font-mono block">
                دورية: {currentCategory.recurrence === 'daily' ? 'يومية' : currentCategory.recurrence === 'monthly' ? 'شهرية' : 'أسبوعية (الأحد)'}
              </span>
            </div>

            <div className="bg-stone-900 border border-stone-800 rounded-xl p-3">
              <span className="text-[10px] text-stone-400 block">إجمالي الطلب الأسبوعي التقديري:</span>
              <span className="text-base font-black text-blue-400 font-mono mt-0.5 block">
                {statsSummary.totalWeeklyDemand.toLocaleString()} وحدة
              </span>
              <span className="text-[10px] text-stone-500 block">حاصل استهلاك 7 أيام</span>
            </div>

            <div className="bg-stone-900 border border-stone-800 rounded-xl p-3">
              <span className="text-[10px] text-stone-400 block">إجمالي الطلب الشهري التقديري:</span>
              <span className="text-base font-black text-purple-400 font-mono mt-0.5 block">
                {statsSummary.totalMonthlyDemand.toLocaleString()} وحدة
              </span>
              <span className="text-[10px] text-stone-500 block">حاصل استهلاك 30 يوماً</span>
            </div>
          </div>
        )}
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto max-h-[480px]">
        <table className="w-full text-right text-xs">
          <thead className="sticky top-0 bg-stone-950 text-stone-400 border-b border-stone-800 z-10">
            <tr>
              <th className="py-3 px-3.5 font-mono">#</th>
              <th className="py-3 px-3.5 font-bold">اسم الصنف</th>
              <th className="py-3 px-3.5">الوحدة</th>
              <th className="py-3 px-3.5 font-mono">الاستهلاك اليومي (حد الأمان)</th>
              <th className="py-3 px-3.5 font-mono text-blue-300 bg-blue-950/20">كمية الطلب الأسبوعي (7 أيام)</th>
              <th className="py-3 px-3.5 font-mono text-purple-300 bg-purple-950/20">كمية الطلب الشهري (30 يوماً)</th>
              <th className="py-3 px-3.5 font-mono text-emerald-300">المطلوب حالياً</th>
              <th className="py-3 px-3.5 text-center">مؤشر الاستهلاك</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-800/60 bg-stone-900/60">
            {filteredItems.map((prod, idx) => {
              const daily = prod.averageDailyDemand || 0;
              const weekly = daily * 7;
              const monthly = daily * 30;
              const currentQty = quantities[prod.id] || 0;

              return (
                <tr key={prod.id} className="hover:bg-stone-850/80 transition">
                  <td className="py-2.5 px-3.5 font-mono text-stone-500">{prod.sheetRow || idx + 1}</td>
                  <td className="py-2.5 px-3.5 font-bold text-stone-100">{prod.nameAr}</td>
                  <td className="py-2.5 px-3.5">
                    <span className="bg-stone-950 text-stone-300 px-2 py-0.5 rounded border border-stone-800 text-[11px]">
                      {prod.defaultUnit || prod.unit || 'كجم'}
                    </span>
                  </td>
                  <td className="py-2.5 px-3.5 font-mono font-bold text-stone-300">
                    {daily > 0 ? daily : '—'}
                  </td>
                  <td className="py-2.5 px-3.5 font-mono font-black text-blue-300 bg-blue-950/10">
                    {weekly > 0 ? weekly : '—'}
                  </td>
                  <td className="py-2.5 px-3.5 font-mono font-black text-purple-300 bg-purple-950/10">
                    {monthly > 0 ? monthly : '—'}
                  </td>
                  <td className="py-2.5 px-3.5 font-mono font-black text-emerald-400">
                    {currentQty > 0 ? (
                      <span className="bg-emerald-500/10 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30">
                        {currentQty}
                      </span>
                    ) : (
                      <span className="text-stone-600 font-normal">0</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3.5 text-center">
                    {daily > 0 ? (
                      <span className="text-[10px] text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded-full border border-emerald-500/30">
                        منتظم ✓
                      </span>
                    ) : (
                      <span className="text-[10px] text-amber-400 bg-amber-950/50 px-2 py-0.5 rounded-full border border-amber-500/30">
                        حسب الطلب
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Footer Summary Row */}
      <div className="p-3.5 bg-stone-950 border-t border-stone-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-stone-400">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>إجمالي البنود المعروضة: <strong className="text-stone-200">{filteredItems.length}</strong> صنف</span>
        </div>

        <div className="flex items-center gap-4 text-stone-300">
          <span>مجموع الأسبوع: <strong className="text-blue-300 font-mono font-bold">{statsSummary.totalWeeklyDemand}</strong></span>
          <span>مجموع الشهر: <strong className="text-purple-300 font-mono font-bold">{statsSummary.totalMonthlyDemand}</strong></span>
          <span>مجموع المطلوب بالسلة: <strong className="text-emerald-300 font-mono font-bold">{statsSummary.totalCurrentQuantities}</strong></span>
        </div>
      </div>
    </div>
  );
};
