import React, { useState, useMemo } from 'react';
import {
  Calendar,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  Download,
  Filter,
  Layers,
  MessageCircle,
  Package,
  Printer,
  Search,
  Share2,
  User,
  Users,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { ActualOrder, OrderType } from '../../types';
import { getWorkWeekString, formatDateAr, getDayNameAr } from '../../utils/workWeek';

interface WeeklyFileArchiveViewProps {
  onSelectOrder?: (order: ActualOrder) => void;
}

export const WeeklyFileArchiveView: React.FC<WeeklyFileArchiveViewProps> = ({ onSelectOrder }) => {
  const { currentUser, users } = useAuth();
  const { orders, orderTypes, phoneSettings } = useData();

  // Current work week
  const currentWeek = useMemo(() => getWorkWeekString(), []);

  // Collect all unique work weeks in orders, plus current week
  const allWeeks = useMemo(() => {
    const set = new Set<string>();
    set.add(currentWeek);
    orders.forEach((o) => {
      if (o.workWeek) set.add(o.workWeek);
      else if (o.orderDate) set.add(getWorkWeekString(o.orderDate));
    });
    return Array.from(set);
  }, [orders, currentWeek]);

  // Selected work week
  const [selectedWeek, setSelectedWeek] = useState<string>(currentWeek);

  // Filters
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedAssistant, setSelectedAssistant] = useState<string>('ALL');
  const [selectedRecipient, setSelectedRecipient] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Expanded order card ids
  const [expandedOrderIds, setExpandedOrderIds] = useState<Record<string, boolean>>({});

  const toggleExpand = (orderId: string) => {
    setExpandedOrderIds((prev) => ({ ...prev, [orderId]: !prev[orderId] }));
  };

  // Filter orders for the chosen week
  const weekOrders = useMemo(() => {
    return orders.filter((o) => {
      const orderWeek = o.workWeek || (o.orderDate ? getWorkWeekString(o.orderDate) : currentWeek);
      return orderWeek === selectedWeek;
    });
  }, [orders, selectedWeek, currentWeek]);

  // Apply sub-filters
  const filteredOrders = useMemo(() => {
    return weekOrders.filter((o) => {
      if (selectedCategory !== 'ALL' && o.orderTypeId !== selectedCategory) return false;
      if (selectedAssistant !== 'ALL' && o.primaryAssigneeId !== selectedAssistant) return false;
      if (selectedRecipient !== 'ALL' && o.recipientType !== selectedRecipient) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const cat = orderTypes.find((c) => c.id === o.orderTypeId);
        const matchCat = cat?.nameAr.toLowerCase().includes(q) || false;
        const matchId = o.id.toLowerCase().includes(q);
        const matchItem = o.items.some((it) => it.productName.toLowerCase().includes(q));
        if (!matchCat && !matchId && !matchItem) return false;
      }
      return true;
    });
  }, [weekOrders, selectedCategory, selectedAssistant, selectedRecipient, searchQuery, orderTypes]);

  // Metrics for selected week
  const weekMetrics = useMemo(() => {
    const totalOrders = weekOrders.length;
    const totalItems = weekOrders.reduce((sum, o) => sum + (o.items ? o.items.length : 0), 0);
    const uniqueCategories = new Set(weekOrders.map((o) => o.orderTypeId)).size;
    const uniqueAssistants = new Set(weekOrders.map((o) => o.primaryAssigneeId)).size;
    return { totalOrders, totalItems, uniqueCategories, uniqueAssistants };
  }, [weekOrders]);

  // Trigger print
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls (Hidden when printing) */}
      <div className="print:hidden space-y-4">
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">📂</span>
              <h1 className="text-xl lg:text-2xl font-black text-stone-100">
                الملف الأسبوعي للطلبيات والأرشيف التراكمي
              </h1>
              <span className="bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold">
                Weekly File Archive
              </span>
            </div>
            <p className="text-xs text-stone-400 mt-1">
              أرشفة وتجميع تلقائي لكافة طلبيات المطبخ المرسلة للواتساب مع الفرز والطباعة لمدير المطبخ
            </p>
          </div>

          {/* Print Button */}
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-450 active:bg-amber-600 text-stone-950 px-4 py-2.5 rounded-xl font-black text-xs transition shadow-lg shadow-amber-950/40"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة ملخص الأسبوع بالكامل</span>
          </button>
        </div>

        {/* Work Week Selector & Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Week Selector Dropdown Card */}
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-3.5 sm:col-span-2 flex flex-col justify-between">
            <span className="text-xs font-bold text-stone-400 flex items-center gap-1.5 mb-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>اختر أسبوع العمل المراد استعراضه:</span>
            </span>
            <select
              value={selectedWeek}
              onChange={(e) => setSelectedWeek(e.target.value)}
              className="w-full bg-stone-950 border border-stone-700 text-amber-300 font-bold text-sm rounded-xl px-3 py-2 focus:ring-1 focus:ring-amber-500"
            >
              {allWeeks.map((wk) => (
                <option key={wk} value={wk}>
                  {wk} {wk === currentWeek ? '(الأسبوع الحالي)' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Metric 1 */}
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-3.5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-stone-400 block">إجمالي الطلبيات</span>
              <span className="text-lg font-black text-stone-100">{weekMetrics.totalOrders} طلبية</span>
            </div>
          </div>

          {/* Metric 2 */}
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-3.5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-stone-400 block">الأصناف المطلوبة</span>
              <span className="text-lg font-black text-stone-100">{weekMetrics.totalItems} بند</span>
            </div>
          </div>

          {/* Metric 3 */}
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-3.5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-stone-400 block">المساعدون المشاركون</span>
              <span className="text-lg font-black text-stone-100">{weekMetrics.uniqueAssistants} مساعد</span>
            </div>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-stone-300">
            <Filter className="w-3.5 h-3.5 text-amber-400" />
            <span>تصفية وفرز طلبيات الأسبوع:</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {/* Category Filter */}
            <div>
              <label className="text-[11px] text-stone-400 block mb-1">اسم الطلبية (الفئة):</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full bg-stone-950 border border-stone-800 text-stone-200 text-xs rounded-xl px-3 py-2"
              >
                <option value="ALL">كافة الطلبيات (الكل)</option>
                {orderTypes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.nameAr}
                  </option>
                ))}
              </select>
            </div>

            {/* Assistant Filter */}
            <div>
              <label className="text-[11px] text-stone-400 block mb-1">اسم المساعد:</label>
              <select
                value={selectedAssistant}
                onChange={(e) => setSelectedAssistant(e.target.value)}
                className="w-full bg-stone-950 border border-stone-800 text-stone-200 text-xs rounded-xl px-3 py-2"
              >
                <option value="ALL">كافة المساعدين</option>
                {users
                  .filter((u) => u.role === 'assistant')
                  .map((asst) => (
                    <option key={asst.id} value={asst.id}>
                      {asst.name}
                    </option>
                  ))}
              </select>
            </div>

            {/* Recipient Filter */}
            <div>
              <label className="text-[11px] text-stone-400 block mb-1">جهة الإرسال:</label>
              <select
                value={selectedRecipient}
                onChange={(e) => setSelectedRecipient(e.target.value)}
                className="w-full bg-stone-950 border border-stone-800 text-stone-200 text-xs rounded-xl px-3 py-2"
              >
                <option value="ALL">الكل (المورد والمشتريات)</option>
                <option value="supplier">المورد المباشر</option>
                <option value="purchasing">مدير المشتريات</option>
              </select>
            </div>

            {/* Search Input */}
            <div>
              <label className="text-[11px] text-stone-400 block mb-1">بحث برقم الطلبية أو صنف:</label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-stone-500 absolute right-3 top-2.5" />
                <input
                  type="text"
                  placeholder="بحث..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-800 text-stone-200 text-xs rounded-xl pr-8 pl-3 py-2"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Orders List View (Interactive) */}
      <div className="print:hidden space-y-3">
        {filteredOrders.length === 0 ? (
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-12 text-center text-stone-400">
            <Package className="w-12 h-12 text-stone-600 mx-auto mb-3" />
            <h3 className="font-bold text-base text-stone-200">لا توجد سجلات طلبيات مطابقة في هذا الأسبوع</h3>
            <p className="text-xs text-stone-500 mt-1">
              اختر أسبوعاً آخر من القائمة أو قم بحصر طلبية جديدة من واجهة الأعمدة
            </p>
          </div>
        ) : (
          filteredOrders.map((order) => {
            const cat = orderTypes.find((c) => c.id === order.orderTypeId);
            const asst = users.find((u) => u.id === order.primaryAssigneeId);
            const isExpanded = !!expandedOrderIds[order.id];

            return (
              <div
                key={order.id}
                className="bg-stone-900 border border-stone-800 rounded-2xl overflow-hidden transition shadow hover:border-stone-700"
              >
                {/* Order Summary Row */}
                <div
                  onClick={() => toggleExpand(order.id)}
                  className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 cursor-pointer hover:bg-stone-850"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 text-lg">
                      📋
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-amber-400">{order.id}</span>
                        <h4 className="font-extrabold text-sm text-stone-100">
                          {cat ? cat.nameAr : 'طلبية مطبخ'}
                        </h4>
                        <span className="text-[10px] bg-stone-950 text-stone-400 px-2 py-0.5 rounded border border-stone-800">
                          {cat?.recurrence === 'daily' ? 'يومية' : 'أسبوعية'}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-xs text-stone-400 mt-1">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-stone-500" />
                          <span>{order.orderDate}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3 text-stone-500" />
                          <span>القائم بالطلب: {asst ? asst.name.split('(')[0].trim() : 'غير محدد'}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <span>الجهة: </span>
                          <span className="text-stone-300 font-medium">
                            {order.recipientType === 'purchasing' ? 'مدير المشتريات' : 'المورد المباشر'}
                          </span>
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 self-end md:self-center">
                    <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs px-2.5 py-1 rounded-xl font-bold">
                      {order.items ? order.items.length : 0} صنف
                    </span>
                    <button
                      type="button"
                      className="w-8 h-8 rounded-lg bg-stone-800 text-stone-400 hover:text-white flex items-center justify-center"
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Expanded Details: Table of Items */}
                {isExpanded && (
                  <div className="p-4 bg-stone-950/80 border-t border-stone-800/80 space-y-3">
                    <div className="flex items-center justify-between text-xs text-stone-400">
                      <span className="font-bold text-stone-300">قائمة الأصناف المحصورة والمطلوبة:</span>
                      <span className="font-mono text-stone-500">{order.notes}</span>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-right text-xs">
                        <thead>
                          <tr className="border-b border-stone-800 text-stone-400">
                            <th className="py-2 px-3">#</th>
                            <th className="py-2 px-3">اسم الصنف</th>
                            <th className="py-2 px-3">الكمية المطلوبة</th>
                            <th className="py-2 px-3">وحدة القياس</th>
                            <th className="py-2 px-3">رصيد الأمان (المتوقع)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-stone-800/40">
                          {order.items.map((item, idx) => (
                            <tr key={item.id || idx} className="hover:bg-stone-900/60">
                              <td className="py-2 px-3 font-mono text-stone-500">{idx + 1}</td>
                              <td className="py-2 px-3 font-bold text-stone-200">{item.productName}</td>
                              <td className="py-2 px-3 font-mono font-bold text-amber-400">
                                {item.requestedQty}
                              </td>
                              <td className="py-2 px-3 text-stone-400">{item.unit}</td>
                              <td className="py-2 px-3 font-mono text-stone-500">
                                {item.averageDailyDemand || 0}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Printable Weekly Report Sheet (Designed specifically for window.print and review) */}
      <div className="hidden print:block bg-white text-black p-8 font-sans leading-relaxed">
        {/* Printable Header */}
        <div className="border-b-2 border-black pb-4 mb-6 flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-black">تقرير الملف الأسبوعي التجميعي للطلبيات والمشتريات</h1>
            <p className="text-sm font-bold text-gray-700 mt-1">
              نظام إدارة طلبيات المطبخ المركزي (KOMS PRO)
            </p>
          </div>
          <div className="text-left font-mono text-xs">
            <p><strong>أسبوع العمل:</strong> {selectedWeek}</p>
            <p><strong>تاريخ الطباعة:</strong> {new Date().toLocaleDateString('ar-EG')}</p>
          </div>
        </div>

        {/* Printable Week Metrics */}
        <div className="grid grid-cols-3 gap-4 border border-black p-4 mb-6 text-center text-sm">
          <div>
            <span className="block text-gray-600 text-xs">إجمالي الطلبيات المسجلة</span>
            <span className="font-bold text-lg">{filteredOrders.length} طلبية</span>
          </div>
          <div>
            <span className="block text-gray-600 text-xs">إجمالي البنود المطلوبة</span>
            <span className="font-bold text-lg">{weekMetrics.totalItems} صنف</span>
          </div>
          <div>
            <span className="block text-gray-600 text-xs">فئات المطبخ المغطاة</span>
            <span className="font-bold text-lg">{weekMetrics.uniqueCategories} فئة</span>
          </div>
        </div>

        {/* Orders Breakdown */}
        <div className="space-y-6">
          {filteredOrders.map((ord, idx) => {
            const cat = orderTypes.find((c) => c.id === ord.orderTypeId);
            const asst = users.find((u) => u.id === ord.primaryAssigneeId);

            return (
              <div key={ord.id} className="border border-gray-400 p-4 break-inside-avoid">
                <div className="flex justify-between items-center border-b border-gray-300 pb-2 mb-3">
                  <div>
                    <span className="font-bold text-base">
                      {idx + 1}. {cat ? cat.nameAr : 'طلبية'} ({ord.id})
                    </span>
                    <span className="text-xs text-gray-600 mr-2">
                      [{cat?.recurrence === 'daily' ? 'دورية يومية' : 'دورية أسبوعية'}]
                    </span>
                  </div>
                  <div className="text-xs text-left">
                    <span>التاريخ: {ord.orderDate} | القائم بالحصر: {asst?.name || 'مساعد'}</span>
                  </div>
                </div>

                <table className="w-full text-right text-xs border-collapse">
                  <thead>
                    <tr className="bg-gray-100 border-b border-gray-300">
                      <th className="p-1 border border-gray-300">#</th>
                      <th className="p-1 border border-gray-300">الصنف</th>
                      <th className="p-1 border border-gray-300">الكمية المطلوبة</th>
                      <th className="p-1 border border-gray-300">الوحدة</th>
                      <th className="p-1 border border-gray-300">المتوقع / أمان</th>
                    </tr>
                  </thead>
                  <tbody>
                    {ord.items.map((it, i) => (
                      <tr key={it.id || i} className="border-b border-gray-200">
                        <td className="p-1 border border-gray-300">{i + 1}</td>
                        <td className="p-1 border border-gray-300 font-bold">{it.productName}</td>
                        <td className="p-1 border border-gray-300 font-bold">{it.requestedQty}</td>
                        <td className="p-1 border border-gray-300">{it.unit}</td>
                        <td className="p-1 border border-gray-300">{it.averageDailyDemand || 0}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          })}
        </div>

        {/* Official Signatures Box */}
        <div className="mt-12 pt-6 border-t-2 border-black grid grid-cols-3 gap-6 text-center text-xs break-inside-avoid">
          <div>
            <p className="font-bold mb-8">الشيف العمومي (مدير المطبخ)</p>
            <p className="border-b border-dashed border-black w-3/4 mx-auto"></p>
            <p className="text-[10px] text-gray-500 mt-1">التوقيع والاعتماد</p>
          </div>
          <div>
            <p className="font-bold mb-8">مسؤول المشتريات والتوريد</p>
            <p className="border-b border-dashed border-black w-3/4 mx-auto"></p>
            <p className="text-[10px] text-gray-500 mt-1">التوقيع والمراجعة</p>
          </div>
          <div>
            <p className="font-bold mb-8">أمين المخازن والاستلام</p>
            <p className="border-b border-dashed border-black w-3/4 mx-auto"></p>
            <p className="text-[10px] text-gray-500 mt-1">ختم الاستلام والمطابقة</p>
          </div>
        </div>
      </div>
    </div>
  );
};
