import React, { useState, useEffect } from 'react';
import { ActualOrder, OrderItem, Supplier } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { INITIAL_PRODUCTS } from '../../services/seedData';
import { whatsappService } from '../../features/dispatch/services/whatsappService';
import {
  formatKitchenWhatsAppMessage,
  generateKitchenWhatsAppUrl,
} from '../../utils/whatsappFormatter';
import {
  AlertCircle,
  Clock,
  CheckCircle2,
  ShieldAlert,
  MessageSquare,
  Copy,
  Check,
  ExternalLink,
  Plus,
  Trash2,
  Sparkles,
  RotateCcw,
  Send,
  Calendar,
  UserCheck,
  Truck,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface VegetableOrderViewProps {
  onNavigateTab?: (tab: any) => void;
}

interface VegItemRow {
  id: string;
  productId?: string;
  productName: string;
  averageDailyDemand: number;
  requestedQty: string; // Initially EMPTY for employee to fill in based on restaurant inventory!
  unit: string;
  notes?: string;
}

export const VegetableOrderView: React.FC<VegetableOrderViewProps> = ({ onNavigateTab }) => {
  const { users, currentUser } = useAuth();
  const { products, suppliers, createOrder, orderTypes } = useData();

  const [orderDate, setOrderDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [orderingDeadline, setOrderingDeadline] = useState(() => {
    return new Date(Date.now() + 6 * 3600 * 1000).toISOString().substring(0, 16);
  });
  const [primaryAssigneeId, setPrimaryAssigneeId] = useState(() => currentUser.id);
  const [notes, setNotes] = useState('');
  const [showOnlyFilled, setShowOnlyFilled] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // WhatsApp Dialog State
  const [whatsAppModalPayload, setWhatsAppModalPayload] = useState<{
    whatsappUrl: string;
    messageText: string;
    supplierName: string;
    supplierPhone: string;
    orderCode: string;
    itemCount: number;
  } | null>(null);
  const [copiedText, setCopiedText] = useState(false);

  // Resolve vegetable supplier
  const vegSupplier: Supplier | undefined =
    suppliers.find((s) => s.orderTypeIds?.includes('cat-veg') || s.suppliedOrderTypeIds?.includes('cat-veg') || s.nameAr?.includes('خضار')) ||
    suppliers[0];

  const [selectedSupplierId, setSelectedSupplierId] = useState<string>(vegSupplier?.id || '');

  // Initialize vegetable items with empty requestedQty
  const loadInitialVegItems = (): VegItemRow[] => {
    // Check if products in dataContext have authentic vegetable products
    const authenticVegProducts = products.filter(
      (p) => p.orderTypeId === 'cat-veg' && p.isActive
    );

    const baseList = authenticVegProducts.length > 0
      ? authenticVegProducts
      : INITIAL_PRODUCTS.filter((p) => p.orderTypeId === 'cat-veg');

    return baseList.map((p, idx) => ({
      id: `veg-item-${p.id || idx}`,
      productId: p.id,
      productName: p.nameAr || p.name || `مكون #${idx + 1}`,
      averageDailyDemand: p.averageDailyDemand || 15,
      requestedQty: '', // Strictly empty initially!
      unit: p.defaultUnit || p.unit || 'كجم',
      notes: '',
    }));
  };

  const [items, setItems] = useState<VegItemRow[]>(() => loadInitialVegItems());

  // Re-sync if products were loaded asynchronously
  useEffect(() => {
    const hasVegetables = items.some(
      (i) => i.productName.includes('طماطم') || i.productName.includes('بصل')
    );
    if (!hasVegetables || items.length < 30) {
      setItems(loadInitialVegItems());
    }
  }, [products]);

  // Handle changing an item's field
  const handleItemFieldChange = (index: number, field: keyof VegItemRow, value: string) => {
    setItems((prev) => {
      const copy = [...prev];
      copy[index] = { ...copy[index], [field]: value };
      return copy;
    });
  };

  // Add custom ingredient
  const handleAddCustomItem = () => {
    setItems((prev) => [
      ...prev,
      {
        id: `custom-veg-${Date.now()}-${prev.length}`,
        productName: '',
        averageDailyDemand: 10,
        requestedQty: '',
        unit: 'كجم',
        notes: '',
      },
    ]);
  };

  // Remove item
  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  // Quick action: Autofill with daily average demand
  const handleAutofillDailyDemand = () => {
    setItems((prev) =>
      prev.map((i) => ({
        ...i,
        requestedQty: i.averageDailyDemand ? String(i.averageDailyDemand) : '10',
      }))
    );
    setError(null);
  };

  // Quick action: Clear all quantities
  const handleClearAllQuantities = () => {
    setItems((prev) =>
      prev.map((i) => ({
        ...i,
        requestedQty: '',
      }))
    );
  };

  // Calculate filled items count
  const filledItems = items.filter(
    (i) => i.productName.trim() && i.requestedQty.trim() !== '' && parseFloat(i.requestedQty) > 0
  );

  const displayedItems = showOnlyFilled ? filledItems : items;

  // Submit and save order
  const handleProcessOrder = async (directWhatsApp: boolean) => {
    if (filledItems.length === 0) {
      setError(
        'يرجى إدخال الكميات المطلوبة في خانة (ما يجب طلبه) لصنف واحد على الأقل بناءً على ما تراه متواجداً في المطعم.'
      );
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const convertedItems: OrderItem[] = filledItems.map((item, idx) => {
        const qty = parseFloat(item.requestedQty) || 0;
        return {
          id: item.id || `veg-ord-item-${Date.now()}-${idx}`,
          productId: item.productId,
          productName: item.productName.trim(),
          averageDailyDemand: item.averageDailyDemand,
          requestedQty: qty,
          orderedQty: qty,
          receivedQty: 0,
          rejectedQty: 0,
          outstandingQty: qty,
          unit: item.unit,
          itemStatus: 'pending',
          notes: item.notes,
        };
      });

      // Fixed arrival is strictly 1:00 PM (13:00) on order date
      const fixedArrivalIso = `${orderDate}T13:00:00.000Z`;
      const targetSupplier = suppliers.find((s) => s.id === selectedSupplierId) || vegSupplier;

      const newOrderId = await createOrder({
        orderTypeId: 'cat-veg',
        orderDate,
        orderingDeadline: new Date(orderingDeadline).toISOString(),
        expectedDeliveryTime: fixedArrivalIso,
        fixedArrivalHour: '13:00',
        primaryAssigneeId,
        supplierId: targetSupplier?.id || vegSupplier?.id,
        purchasingChannel: 'واتساب',
        status: directWhatsApp ? 'ORDERED' : 'PLANNED',
        priority: 'normal',
        requiresApproval: false,
        notes,
        items: convertedItems,
      });

      const effectiveOrderCode = newOrderId || `ORD-VEG-${Date.now().toString().slice(-6)}`;

      if (directWhatsApp) {
        const supplierName = targetSupplier?.name || targetSupplier?.nameAr || 'مزارع الوادي للخضروات الطازجة';
        const rawPhone = targetSupplier?.phone || '+201011122233';
        const sanitizedPhone = whatsappService.sanitizeEgyptianPhoneNumber(rawPhone);

        const assignee = users.find((u) => u.id === primaryAssigneeId);
        const requesterName = assignee ? assignee.name : currentUser.name;

        const messageText = formatKitchenWhatsAppMessage({
          orderCode: effectiveOrderCode,
          requesterName,
          items: filledItems.map((item) => ({
            name: item.productName.trim(),
            qty: item.requestedQty,
            unit: item.unit,
          })),
        });

        const whatsappUrl = generateKitchenWhatsAppUrl(rawPhone, messageText);

        setWhatsAppModalPayload({
          whatsappUrl,
          messageText,
          supplierName,
          supplierPhone: rawPhone,
          orderCode: effectiveOrderCode,
          itemCount: filledItems.length,
        });
      } else {
        if (onNavigateTab) {
          onNavigateTab('orders');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'تعذر حفظ وإرسال أمر التوريد.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyMessage = () => {
    if (!whatsAppModalPayload) return;
    navigator.clipboard.writeText(whatsAppModalPayload.messageText);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2500);
  };

  return (
    <div className="space-y-4 max-w-6xl mx-auto pb-16">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-l from-stone-900 via-stone-850 to-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-6 text-stone-100 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xl">
              🥬
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black text-stone-100">
                  واجهة طلب طلبيّة الخضروات والتحويل المباشر للواتساب
                </h1>
                <span className="text-[10px] font-mono uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                  {items.length} صنفاً معتمداً
                </span>
              </div>
              <p className="text-xs text-stone-400 mt-1">
                عرض المكونات المعتمدة من جدول المطبخ مع رصيد الأمان، وإدخال ما يجب طلبه بالكيلوجرام أو بالعدد بناءً على ما تراه متواجداً في المطعم، ثم التحويل الفوري للواتساب.
              </p>
            </div>
          </div>
        </div>

        {onNavigateTab && (
          <button
            onClick={() => onNavigateTab('orders')}
            className="flex items-center gap-1.5 text-xs text-stone-400 hover:text-stone-200 bg-stone-800/80 hover:bg-stone-800 px-3 py-1.5 rounded-xl border border-stone-750 transition shrink-0"
          >
            <span>العودة لإدارة الطلبيات</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Fixed Arrival Policy & Delay Alarm Banner */}
      <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
        <div className="flex items-center gap-2.5 text-amber-300">
          <Clock className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            <strong>موعد الوصول الثابت:</strong> الساعة <strong>01:00 مساءً</strong> كحد أقصى للطلبية اليومية. وفي حال تأخر الوصول يعتمد ميعاد الشيف المسؤول عن الاستلام.
          </span>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-stone-300 bg-stone-900/90 px-3 py-1.5 rounded-xl border border-stone-800 shrink-0">
          <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
          <span>إنذار تأخر طلبية الخضار التلقائي يظهر بعد 24 ساعة من موعد الوصول</span>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="p-3.5 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-200 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Controls Bar: Date, Shift Supervisor, Deadline, Supplier */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
        {/* Order Date */}
        <div>
          <label className="block text-[11px] font-bold text-stone-300 mb-1 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <span>تاريخ الطلب والتوريد:</span>
          </label>
          <input
            type="date"
            value={orderDate}
            onChange={(e) => setOrderDate(e.target.value)}
            className="w-full bg-stone-850 border border-stone-750 rounded-xl px-3 py-2 text-stone-100 font-mono focus:outline-none focus:border-amber-500"
            required
          />
        </div>

        {/* Shift Responsible Assignee */}
        <div>
          <label className="block text-[11px] font-bold text-stone-300 mb-1 flex items-center gap-1.5">
            <UserCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>مسؤول الوردية عن الطلب:</span>
          </label>
          <select
            value={primaryAssigneeId}
            onChange={(e) => setPrimaryAssigneeId(e.target.value)}
            className="w-full bg-stone-850 border border-stone-750 rounded-xl px-3 py-2 text-stone-100 focus:outline-none focus:border-amber-500"
          >
            {users.map((u) => (
              <option key={u.id} value={u.id}>
                {u.name} ({u.role === 'manager' ? 'مدير المطبخ' : 'مسؤول الوردية'})
              </option>
            ))}
          </select>
        </div>

        {/* Ordering Deadline with Shift Alert */}
        <div>
          <label className="block text-[11px] font-bold text-stone-300 mb-1 flex items-center justify-between">
            <span>مهلة الطلب للوردية:</span>
            <span className="text-[10px] text-amber-400 font-mono">إنذار آلي</span>
          </label>
          <input
            type="datetime-local"
            value={orderingDeadline}
            onChange={(e) => setOrderingDeadline(e.target.value)}
            className="w-full bg-stone-850 border border-stone-750 rounded-xl px-3 py-2 text-stone-100 font-mono focus:outline-none focus:border-amber-500"
            required
          />
        </div>

        {/* Supplier */}
        <div>
          <label className="block text-[11px] font-bold text-stone-300 mb-1 flex items-center gap-1.5">
            <Truck className="w-3.5 h-3.5 text-emerald-400" />
            <span>مورد الخضار المعتمد:</span>
          </label>
          <select
            value={selectedSupplierId}
            onChange={(e) => setSelectedSupplierId(e.target.value)}
            className="w-full bg-stone-850 border border-stone-750 rounded-xl px-3 py-2 text-stone-100 focus:outline-none focus:border-emerald-500"
          >
            {suppliers.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name || s.nameAr} ({s.phone})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Specialist Table Card */}
      <div className="bg-stone-900 border border-stone-800 rounded-3xl overflow-hidden shadow-lg flex flex-col">
        {/* Table Toolbar */}
        <div className="bg-stone-850 px-4 py-3 border-b border-stone-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-sm text-amber-300">
              قائمة مكونات الخضار والمخللات ({items.length} صنفاً)
            </span>
            <span className="text-xs text-stone-400">
              — خانة &quot;ما يجب طلبه&quot; فارغة لملئها بناءً على الفحص الفعلي
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            {/* Quick Fill with Average Button */}
            <button
              type="button"
              onClick={handleAutofillDailyDemand}
              className="flex items-center gap-1.5 text-xs text-amber-300 hover:text-amber-200 bg-amber-500/10 hover:bg-amber-500/20 px-3 py-1.5 rounded-xl border border-amber-500/30 font-semibold transition"
              title="تعبئة الكميات المطلوبة بنفس قيم المتوسط اليومي بنقرة واحدة"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>تعبئة بالمتوسط المطلوب</span>
            </button>

            {/* Clear all */}
            {filledItems.length > 0 && (
              <button
                type="button"
                onClick={handleClearAllQuantities}
                className="flex items-center gap-1 text-xs text-stone-400 hover:text-rose-400 bg-stone-800 hover:bg-stone-750 px-2.5 py-1.5 rounded-xl border border-stone-700 transition"
                title="تفريغ جميع خانات الطلب"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>تفريغ</span>
              </button>
            )}

            {/* Filter filled items */}
            {filledItems.length > 0 && (
              <button
                type="button"
                onClick={() => setShowOnlyFilled(!showOnlyFilled)}
                className="text-xs px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 transition"
              >
                {showOnlyFilled ? `عرض الـ 24 صنفاً` : `عرض ما تم إدخاله فقط (${filledItems.length})`}
              </button>
            )}

            {/* Add custom item */}
            <button
              type="button"
              onClick={handleAddCustomItem}
              className="flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 px-3 py-1.5 rounded-xl border border-emerald-500/30 font-semibold transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إضافة صنف</span>
            </button>
          </div>
        </div>

        {/* Table Column Headers - Exact Arabic Headers from Prompts 3 & 5 */}
        <div className="grid grid-cols-12 gap-2 px-4 py-2.5 bg-stone-950 border-b border-stone-800 text-xs font-bold text-stone-300 select-none">
          <div className="col-span-1 text-center font-mono text-stone-500">م</div>
          <div className="col-span-4 sm:col-span-4">اسم المكون</div>
          <div className="col-span-3 sm:col-span-2 text-center text-amber-400">
            المتوسط المطلوب
          </div>
          <div className="col-span-2 sm:col-span-3 text-center text-emerald-400">
            ما يجب طلبه
          </div>
          <div className="col-span-2 sm:col-span-1 text-center">الوحدة</div>
          <div className="hidden sm:block sm:col-span-1 text-center">حذف</div>
        </div>

        {/* Table Rows */}
        <div className="p-3 space-y-2 max-h-[60vh] overflow-y-auto">
          {displayedItems.map((item, idx) => {
            const actualIndex = items.findIndex((i) => i.id === item.id);
            const isFilled = item.requestedQty.trim() !== '' && parseFloat(item.requestedQty) > 0;

            return (
              <div
                key={item.id}
                className={`grid grid-cols-12 gap-2 items-center p-2.5 rounded-2xl border transition text-xs ${
                  isFilled
                    ? 'bg-emerald-950/30 border-emerald-500/40 shadow-sm shadow-emerald-950/20'
                    : 'bg-stone-900/80 hover:bg-stone-900 border-stone-800'
                }`}
              >
                {/* Index Number */}
                <div className="col-span-1 text-center font-mono text-stone-500 text-xs">
                  {actualIndex + 1}
                </div>

                {/* Component Name */}
                <div className="col-span-4 sm:col-span-4">
                  <input
                    type="text"
                    value={item.productName}
                    onChange={(e) => handleItemFieldChange(actualIndex, 'productName', e.target.value)}
                    placeholder="اسم المكون..."
                    className="w-full bg-stone-850 border border-stone-750 rounded-xl px-3 py-2 text-xs font-bold text-stone-100 placeholder-stone-500 focus:outline-none focus:border-emerald-500"
                    required
                  />
                </div>

                {/* Average Required / Daily Demand */}
                <div className="col-span-3 sm:col-span-2 text-center">
                  <span className="inline-block px-2.5 py-1.5 rounded-xl bg-stone-800/90 border border-stone-750 text-xs font-mono font-semibold text-amber-300">
                    {item.averageDailyDemand} {item.unit}
                  </span>
                </div>

                {/* "ما يجب طلبه": EMPTY input for user to type in kg or count */}
                <div className="col-span-2 sm:col-span-3">
                  <input
                    type="number"
                    step="any"
                    min="0"
                    value={item.requestedQty}
                    onChange={(e) => handleItemFieldChange(actualIndex, 'requestedQty', e.target.value)}
                    placeholder="أدخل الكمية..."
                    className={`w-full text-center font-mono font-black text-sm rounded-xl px-3 py-2 border transition focus:outline-none ${
                      isFilled
                        ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200 ring-1 ring-emerald-500/50'
                        : 'bg-stone-850 border-stone-700 text-stone-100 placeholder-stone-600 focus:border-amber-500'
                    }`}
                  />
                </div>

                {/* Unit selector */}
                <div className="col-span-2 sm:col-span-1">
                  <select
                    value={item.unit}
                    onChange={(e) => handleItemFieldChange(actualIndex, 'unit', e.target.value)}
                    className="w-full bg-stone-850 border border-stone-750 rounded-xl px-1.5 py-2 text-xs text-stone-200 text-center focus:outline-none focus:border-emerald-500 font-semibold"
                  >
                    <option value="كجم">كجم</option>
                    <option value="بالعدد / حبة">حبة</option>
                    <option value="ربطة">ربطة</option>
                    <option value="كرتونة">كرتونة</option>
                    <option value="شوال / كيس">شوال</option>
                  </select>
                </div>

                {/* Delete button */}
                <div className="hidden sm:flex sm:col-span-1 items-center justify-center">
                  <button
                    type="button"
                    onClick={() => handleRemoveItem(actualIndex)}
                    disabled={items.length <= 1}
                    className="p-2 text-stone-500 hover:text-rose-400 disabled:opacity-20 rounded-xl hover:bg-stone-800 transition"
                    title="حذف هذا المكون"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Additional Notes Row */}
        <div className="p-3 border-t border-stone-800 bg-stone-950/40">
          <input
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="ملاحظات تسليم خاصة للشيف أو المورد (مثل: يرجى فرز أول طازج صباحاً)..."
            className="w-full bg-stone-850 border border-stone-800 rounded-xl px-3.5 py-2 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-stone-800 bg-stone-850/90 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="text-xs text-stone-300 flex items-center gap-2">
            <span>الأصناف المحددة في (ما يجب طلبه):</span>
            <strong className="text-emerald-400 font-mono text-sm px-2 py-0.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
              {filledItems.length}
            </strong>
            <span>من إجمالي {items.length} مكون</span>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Save as internal order */}
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleProcessOrder(false)}
              className="px-4 py-2.5 rounded-xl text-xs font-bold bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 transition disabled:opacity-50"
            >
              حفظ أمر التوريد في النظام
            </button>

            {/* Direct WhatsApp Conversion Button - Core Feature */}
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleProcessOrder(true)}
              className="flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl text-xs font-extrabold bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white shadow-xl shadow-emerald-950/60 transition disabled:opacity-50"
              title="تحويل ما يجب طلبه مباشرة عبر الواتساب للمورد الخاص بطلبية الخضار"
            >
              {isSubmitting ? (
                <span>جاري المعالجة...</span>
              ) : (
                <>
                  <MessageSquare className="w-4 h-4 fill-emerald-100 text-emerald-800" />
                  <span>تحويل ما يجب طلبه مباشرة عبر الواتساب للمورد 💬</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* WhatsApp Dispatch Success Modal Overlay */}
      {whatsAppModalPayload && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-stone-950/90 backdrop-blur-md">
          <div className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-xl p-5 sm:p-6 text-stone-100 shadow-2xl animate-in fade-in zoom-in-95 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center text-lg">
                  🥬
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-stone-100">
                    تم تحويل طلبية الخضار للواتساب بنجاح!
                  </h3>
                  <p className="text-xs text-stone-400">
                    كود الطلب: <span className="font-mono text-amber-400 font-bold">{whatsAppModalPayload.orderCode}</span>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setWhatsAppModalPayload(null)}
                className="p-1.5 rounded-xl text-stone-400 hover:text-white bg-stone-800"
              >
                ✕
              </button>
            </div>

            {/* Supplier & Details card */}
            <div className="p-3.5 bg-stone-950/80 rounded-2xl border border-stone-800 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-stone-400">مورد الخضار المعتمد:</span>
                <strong className="text-emerald-300 font-bold text-sm">{whatsAppModalPayload.supplierName}</strong>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-stone-400">رقم هاتف المورد:</span>
                <span className="font-mono text-stone-200 font-bold">{whatsAppModalPayload.supplierPhone}</span>
              </div>
              <div className="flex items-center justify-between border-t border-stone-800/80 pt-2 text-[11px]">
                <span>الأصناف المحولة: <strong className="text-amber-400 font-mono font-bold">{whatsAppModalPayload.itemCount} صنفاً</strong></span>
                <span>موعد الوصول الثابت: <strong className="text-amber-400 font-mono font-bold">01:00 ظهراً كحد أقصى</strong></span>
              </div>
            </div>

            {/* Formatted Markdown Preview */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-stone-300">
                  معاينة نص الرسالة بتنسيق واتساب:
                </span>
                <button
                  type="button"
                  onClick={handleCopyMessage}
                  className="flex items-center gap-1.5 text-xs text-amber-300 bg-stone-800 hover:bg-stone-750 px-3 py-1 rounded-xl transition font-semibold"
                >
                  {copiedText ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>تم النسخ بنجاح!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ نص الطلب</span>
                    </>
                  )}
                </button>
              </div>
              <div className="bg-stone-950 border border-stone-800 rounded-2xl p-3.5 font-mono text-xs text-stone-300 whitespace-pre-wrap leading-relaxed max-h-52 overflow-y-auto selection:bg-emerald-500/30">
                {whatsAppModalPayload.messageText}
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-stone-800 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setWhatsAppModalPayload(null)}
                className="px-4 py-2 bg-stone-800 hover:bg-stone-750 text-stone-300 rounded-xl text-xs font-semibold transition"
              >
                إغلاق
              </button>
              <a
                href={whatsAppModalPayload.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  setTimeout(() => setWhatsAppModalPayload(null), 500);
                }}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-xl shadow-emerald-950/60"
              >
                <ExternalLink className="w-4 h-4" />
                <span>فتح محادثة واتساب للمورد وإرسال الطلب الآن</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
