import React, { useState } from 'react';
import { ActualOrder, WorkflowStatus } from '../../types';
import { ALLOWED_TRANSITIONS, WORKFLOW_STATUS_CONFIG } from '../../utils/statusLabels';
import { CheckCircle2, AlertCircle, X } from 'lucide-react';

interface OrderStatusModalProps {
  order: ActualOrder;
  onClose: () => void;
  onUpdateStatus: (newStatus: WorkflowStatus, note: string) => Promise<void>;
}

export const OrderStatusModal: React.FC<OrderStatusModalProps> = ({
  order,
  onClose,
  onUpdateStatus,
}) => {
  const allowed = ALLOWED_TRANSITIONS[order.status] || [];
  const [selectedStatus, setSelectedStatus] = useState<WorkflowStatus>(
    allowed[0] || order.status
  );
  const [note, setNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStatus) return;
    setIsSubmitting(true);
    setError(null);
    try {
      await onUpdateStatus(selectedStatus, note);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'حدث خطأ أثناء تغيير الحالة');
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentMeta = WORKFLOW_STATUS_CONFIG[order.status];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm">
      <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-md p-5 text-stone-100 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-stone-800">
          <div>
            <h3 className="font-bold text-base text-stone-100">تحديث حالة الطلبية</h3>
            <span className="text-xs font-mono text-amber-400">{order.id}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-stone-400 hover:text-white bg-stone-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {/* Current Status */}
          <div className="bg-stone-850 p-3 rounded-xl border border-stone-800 flex items-center justify-between">
            <span className="text-xs text-stone-400">الحالة الراهنة:</span>
            <span className={`text-xs px-2.5 py-1 rounded-full font-bold ${currentMeta.bgClass} ${currentMeta.textClass}`}>
              {currentMeta.labelAr}
            </span>
          </div>

          {/* New Status Selection */}
          <div>
            <label className="block text-xs font-semibold text-stone-300 mb-2">
              الحالة الجديدة المستهدفة:
            </label>
            {allowed.length === 0 ? (
              <div className="p-3 rounded-xl bg-stone-800/60 text-xs text-stone-400 text-center">
                هذه الطلبية في حالة نهائية ولا تملك انتقالات أخرى متاحة
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto">
                {allowed.map((st) => {
                  const meta = WORKFLOW_STATUS_CONFIG[st];
                  const isSelected = selectedStatus === st;
                  return (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setSelectedStatus(st)}
                      className={`w-full text-right p-2.5 rounded-xl border transition text-xs flex items-center justify-between ${
                        isSelected
                          ? 'border-amber-500 bg-amber-500/10 text-amber-300 font-bold'
                          : 'border-stone-800 bg-stone-850 hover:bg-stone-800 text-stone-300'
                      }`}
                    >
                      <div>
                        <div className="font-semibold">{meta.labelAr}</div>
                        <div className="text-[10px] text-stone-400">{meta.description}</div>
                      </div>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Transition Notes */}
          <div>
            <label className="block text-xs font-semibold text-stone-300 mb-1">
              ملاحظات التحول / السبب التشغيلي:
            </label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="مثال: تم التواصل هاتفياً مع المندوب وأكد وصول الشحنة خلال ساعة..."
              className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500 resize-none h-20"
            />
          </div>

          {error && (
            <div className="p-2.5 rounded-xl bg-rose-950/60 border border-rose-800 text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-2">
            <button
              type="submit"
              disabled={isSubmitting || allowed.length === 0}
              className="flex-1 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 disabled:opacity-50 text-stone-950 font-bold py-2.5 rounded-xl text-xs transition"
            >
              {isSubmitting ? 'جاري الحفظ...' : 'تأكيد تغيير الحالة وتوثيقها'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="bg-stone-800 hover:bg-stone-750 text-stone-300 py-2.5 px-4 rounded-xl text-xs transition"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
