import React, { useState, useEffect } from 'react';
import { ActualOrder, OrderItem, OrderPriority, Supplier } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { INITIAL_PRODUCTS } from '../../services/seedData';
import { whatsappService } from '../../features/dispatch/services/whatsappService';
import {
  formatKitchenWhatsAppMessage,
  generateKitchenWhatsAppUrl,
} from '../../utils/whatsappFormatter';
import {
  AlertCircle,
  Plus,
  Trash2,
  X,
  Clock,
  CheckCircle2,
  Layers,
  ShieldAlert,
  MessageSquare,
  Copy,
  Check,
  ExternalLink,
  Send,
  Sparkles,
} from 'lucide-react';

interface OrderModalProps {
  orderToEdit?: ActualOrder | null;
  defaultCategoryId?: string;
  onClose: () => void;
  onSave: (orderData: Partial<ActualOrder>) => Promise<string | void>;
}

interface EditableItemRow {
  id: string;
  productId?: string;
  productName: string;
  averageDailyDemand?: number;
  requestedQty: string; // Empty string by default so field is completely blank for the employee!
  unit: string;
  notes?: string;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  orderToEdit,
  defaultCategoryId,
  onClose,
  onSave,
}) => {
  const { users, currentUser } = useAuth();
  const { orderTypes, products, suppliers } = useData();

  // If assistant has assigned order types, default to their primary assigned domain
  const userDomainId = currentUser.assignedOrderTypeIds?.[0];
  const initialCategory =
    orderToEdit?.orderTypeId ||
    defaultCategoryId ||
    userDomainId ||
    orderTypes[0]?.id ||
    'cat-veg';

  const [orderTypeId, setOrderTypeId] = useState(initialCategory);
  const [orderDate, setOrderDate] = useState(
    orderToEdit?.orderDate || new Date().toISOString().split('T')[0]
  );
  const [orderingDeadline, setOrderingDeadline] = useState(
    orderToEdit?.orderingDeadline
      ? orderToEdit.orderingDeadline.substring(0, 16)
      : new Date(Date.now() + 6 * 3600 * 1000).toISOString().substring(0, 16)
  );
  const [primaryAssigneeId, setPrimaryAssigneeId] = useState(
    orderToEdit?.primaryAssigneeId || currentUser.id
  );
  const [supplierId, setSupplierId] = useState(orderToEdit?.supplierId || '');
  const [purchasingChannel, setPurchasingChannel] = useState(
    orderToEdit?.purchasingChannel || 'واتساب'
  );
  const [priority, setPriority] = useState<OrderPriority>(
    orderToEdit?.priority || 'normal'
  );
  const [requiresApproval, setRequiresApproval] = useState(
    orderToEdit?.requiresApproval || false
  );
  const [notes, setNotes] = useState(orderToEdit?.notes || '');

  // Filter state inside the modal (e.g. view only filled items vs view all)
  const [showOnlyFilled, setShowOnlyFilled] = useState(false);

  // WhatsApp Dispatch State Modal
  const [whatsAppDispatchPayload, setWhatsAppDispatchPayload] = useState<{
    whatsappUrl: string;
    messageText: string;
    supplierName: string;
    supplierPhone: string;
    orderCode: string;
    itemCount: number;
  } | null>(null);
  const [copiedText, setCopiedText] = useState(false);

  // Helper to load category components with EMPTY quantity inputs for employee to enter
  const loadCategoryItems = (catId: string): EditableItemRow[] => {
    if (catId === 'cat-veg') {
      const vegProds = products.filter(
        (p) => p.orderTypeId === 'cat-veg' && p.isActive && !p.nameAr?.includes('TBD') && !p.name?.includes('TBD')
      );
      const prodsToUse = vegProds.length >= 24 ? vegProds : INITIAL_PRODUCTS.filter((p) => p.orderTypeId === 'cat-veg');
      return prodsToUse.map((p, idx) => ({
        id: `veg-item-${p.id}-${idx}`,
        productId: p.id,
        productName: p.nameAr || p.name || `مكون #${idx + 1}`,
        averageDailyDemand: p.averageDailyDemand || 15,
        requestedQty: '', // BLANK by default as requested!
        unit: p.defaultUnit || p.unit || 'كجم',
        notes: '',
      }));
    }

    let catProds = products.filter((p) => p.orderTypeId === catId && p.isActive);
    if (catProds.length === 0) {
      catProds = INITIAL_PRODUCTS.filter((p) => p.orderTypeId === catId && p.isActive);
    }
    if (catProds.length > 0) {
      return catProds.map((p, idx) => ({
        id: `item-${p.id}-${idx}`,
        productId: p.id,
        productName: p.nameAr || p.name || `مكون #${idx + 1}`,
        averageDailyDemand: p.averageDailyDemand,
        requestedQty: '', // BLANK by default as requested!
        unit: p.defaultUnit || p.unit || 'كجم',
        notes: '',
      }));
    }
    return [
      {
        id: `item-${Date.now()}-0`,
        productName: '',
        requestedQty: '',
        unit: 'كجم',
        notes: '',
      },
    ];
  };

  // Pre-load items
  const [items, setItems] = useState<EditableItemRow[]>(() => {
    if (orderToEdit?.items && orderToEdit.items.length > 0) {
      return orderToEdit.items.map((i) => ({
        id: i.id,
        productId: i.productId,
        productName: i.productName,
        averageDailyDemand: i.averageDailyDemand,
        requestedQty: i.requestedQty > 0 ? String(i.requestedQty) : '',
        unit: i.unit || 'كجم',
        notes: i.notes || '',
      }));
    }
    return loadCategoryItems(initialCategory);
  });

  // Listen for defaultCategoryId updates
  useEffect(() => {
    if (defaultCategoryId && defaultCategoryId !== orderTypeId && !orderToEdit) {
      setOrderTypeId(defaultCategoryId);
      setItems(loadCategoryItems(defaultCategoryId));
    }
  }, [defaultCategoryId]);

  // Re-sync if products loaded asynchronously or if veg category needs genuine items
  useEffect(() => {
    if (!orderToEdit) {
      if (orderTypeId === 'cat-veg') {
        const hasVegetables = items.some(
          (i) => i.productName.includes('باذنجان') || i.productName.includes('طماطم') || i.productName.includes('بصل')
        );
        if (!hasVegetables || items.length < 24) {
          setItems(loadCategoryItems('cat-veg'));
        }
      } else if (items.length <= 1 && items[0]?.productName === '') {
        setItems(loadCategoryItems(orderTypeId));
      }
    }
  }, [products, orderTypeId]);

  // When changing category for a new order, auto-populate category components
  const handleCategoryChange = (newCatId: string) => {
    setOrderTypeId(newCatId);
    if (!orderToEdit) {
      setItems(loadCategoryItems(newCatId));
    }
  };

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAddItem = () => {
    setItems((prev) => [
      ...prev,
      {
        id: `custom-item-${Date.now()}-${prev.length}`,
        productName: '',
        requestedQty: '',
        unit: 'كجم',
        notes: '',
      },
    ]);
  };

  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleItemFieldChange = (
    index: number,
    field: keyof EditableItemRow,
    value: string
  ) => {
    setItems((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const currentCategory = orderTypes.find((c) => c.id === orderTypeId);
  const isVegetableCategory =
    orderTypeId === 'cat-veg' || currentCategory?.code === 'VEG' || currentCategory?.nameAr?.includes('خضار');

  // Resolve target supplier
  const getTargetSupplier = (): Supplier | undefined => {
    if (supplierId) {
      return suppliers.find((s) => s.id === supplierId);
    }
    // Find supplier mapped to this category
    const mapped = suppliers.find(
      (s) =>
        s.orderTypeIds?.includes(orderTypeId) ||
        s.suppliedOrderTypeIds?.includes(orderTypeId)
    );
    if (mapped) return mapped;
    // Default fallback for vegetables
    if (isVegetableCategory) {
      return (
        suppliers.find((s) => s.category?.includes('خضار') || s.nameAr?.includes('خضار')) ||
        suppliers[0]
      );
    }
    return suppliers[0];
  };

  // Save order handler
  const saveOrderInternal = async (directToWhatsApp: boolean = false) => {
    // Filter items that have a product name and a filled positive quantity ("ما يجب طلبه")
    const validFilledItems = items.filter(
      (i) => i.productName.trim() && i.requestedQty.trim() && parseFloat(i.requestedQty) > 0
    );

    if (validFilledItems.length === 0) {
      setError(
        'يرجى إدخال الكميات المطلوبة في خانة (ما يجب طلبه) لصنف واحد على الأقل بناءً على ما تراه متواجداً في المطعم.'
      );
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const convertedItems: OrderItem[] = validFilledItems.map((i, idx) => {
        const qty = parseFloat(i.requestedQty) || 0;
        return {
          id: i.id || `item-${Date.now()}-${idx}`,
          productId: i.productId,
          productName: i.productName.trim(),
          averageDailyDemand: i.averageDailyDemand,
          requestedQty: qty,
          orderedQty: qty,
          receivedQty: 0,
          rejectedQty: 0,
          outstandingQty: qty,
          unit: i.unit || 'كجم',
          itemStatus: 'pending',
          notes: i.notes,
        };
      });

      // Fixed expected delivery time is strictly 1:00 PM (13:00) on the order date
      const fixedArrivalIso = `${orderDate}T13:00:00.000Z`;
      const targetSupplier = getTargetSupplier();
      const resolvedSupplierId = targetSupplier?.id || supplierId || undefined;

      const orderPayload: Partial<ActualOrder> = {
        orderTypeId,
        orderDate,
        orderingDeadline: new Date(orderingDeadline).toISOString(),
        expectedDeliveryTime: fixedArrivalIso,
        fixedArrivalHour: '13:00',
        primaryAssigneeId,
        supplierId: resolvedSupplierId,
        purchasingChannel: directToWhatsApp ? 'واتساب' : purchasingChannel,
        status: directToWhatsApp ? 'ORDERED' : orderToEdit?.status || 'PLANNED',
        priority,
        requiresApproval,
        notes,
        items: convertedItems,
      };

      const savedId = await onSave(orderPayload);
      const effectiveOrderCode = orderToEdit?.orderNumber || (typeof savedId === 'string' ? savedId : `ORD-${Date.now().toString().slice(-6)}`);

      if (directToWhatsApp) {
        // Generate formatted WhatsApp message
        const supplierName = targetSupplier?.name || targetSupplier?.nameAr || 'المورد المعتمد';
        const rawPhone = targetSupplier?.phone || '01011122233';
        const sanitizedPhone = whatsappService.sanitizeEgyptianPhoneNumber(rawPhone);

        const assignee = users.find((u) => u.id === primaryAssigneeId);
        const requesterName = assignee ? assignee.name : currentUser.name;

        const messageText = formatKitchenWhatsAppMessage({
          orderCode: effectiveOrderCode,
          requesterName,
          items: validFilledItems.map((item) => ({
            name: item.productName.trim(),
            qty: item.requestedQty,
            unit: item.unit,
          })),
        });

        const whatsappUrl = generateKitchenWhatsAppUrl(rawPhone, messageText);

        setWhatsAppDispatchPayload({
          whatsappUrl,
          messageText,
          supplierName,
          supplierPhone: rawPhone,
          orderCode: effectiveOrderCode,
          itemCount: validFilledItems.length,
        });
      } else {
        onClose();
      }
    } catch (err: any) {
      setError(err?.message || 'تعذر حفظ وإرسال بيانات الطلبية');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filledCount = items.filter(
    (i) => i.requestedQty.trim() !== '' && parseFloat(i.requestedQty) > 0
  ).length;

  const displayedItems = showOnlyFilled
    ? items.filter((i) => i.requestedQty.trim() !== '' && parseFloat(i.requestedQty) > 0)
    : items;

  const handleCopyMessage = () => {
    if (!whatsAppDispatchPayload) return;
    navigator.clipboard.writeText(whatsAppDispatchPayload.messageText);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-stone-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-4xl my-4 p-5 sm:p-6 text-stone-100 shadow-2xl animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-stone-800 shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <Layers className="w-5 h-5" />
              </span>
              <h2 className="font-bold text-base sm:text-lg text-stone-100 flex items-center gap-2">
                {orderToEdit
                  ? `تعديل طلبية التوريد: ${orderToEdit.orderNumber || orderToEdit.id}`
                  : isVegetableCategory
                  ? 'واجهة طلب طلبية الخضار والتحويل المباشر للواتساب'
                  : 'واجهة طلب التوريد للمتخصصين'}
              </h2>
            </div>
            <p className="text-xs text-stone-400 mt-1">
              {isVegetableCategory
                ? 'عرض مكونات الخضار (24 صنفاً) مع المتوسط المطلوب، وإدخال ما يجب طلبه بالكيلوجرام أو بالعدد ثم التحويل الفوري للواتساب'
                : 'إدخال الاحتياجات الفعلية لمكونات الوردية بالكيلوجرام أو بالعدد، مع موعد وصول ثابت'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-white bg-stone-800/80 hover:bg-stone-750 transition"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Fixed Policy Banner */}
        <div className="mt-3 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2 text-xs text-amber-300">
            <Clock className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>موعد الوصول الثابت:</strong> الساعة <strong>01:00 مساءً</strong> كحد أقصى للطلبية اليومية. وفي حال تأخر الوصول يعتمد توقيت الشيف المستلم.
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-stone-300 bg-stone-900/80 px-2.5 py-1 rounded-lg border border-stone-800">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            <span>إنذار تأخر الخضار التلقائي يظهر بعد 24 ساعة من الموعد الثابت</span>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mt-2.5 p-3 rounded-xl bg-rose-950/70 border border-rose-800 text-rose-200 text-xs flex items-center gap-2 shrink-0">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Form Body */}
        <div className="flex-1 flex flex-col overflow-hidden mt-3 space-y-3.5">
          {/* Top Controls: Category & Shift Assignee */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-stone-850/60 p-3 rounded-2xl border border-stone-800 shrink-0">
            {/* Category / Specialty Selection */}
            <div>
              <label className="block text-xs font-bold text-stone-200 mb-1.5 flex items-center justify-between">
                <span>فئة التوريد والتخصص:</span>
                {isVegetableCategory && (
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded font-bold">
                    خضار طازج
                  </span>
                )}
              </label>
              <select
                value={orderTypeId}
                onChange={(e) => handleCategoryChange(e.target.value)}
                className="w-full bg-stone-900 border border-stone-750 rounded-xl px-3 py-2 text-xs text-stone-100 font-semibold focus:outline-none focus:border-amber-500"
              >
                {orderTypes.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.nameAr} ({cat.nameEn || cat.code})
                  </option>
                ))}
              </select>
            </div>

            {/* Order Date */}
            <div>
              <label className="block text-xs font-bold text-stone-200 mb-1.5">
                تاريخ الطلب والتشغيل:
              </label>
              <input
                type="date"
                value={orderDate}
                onChange={(e) => setOrderDate(e.target.value)}
                className="w-full bg-stone-900 border border-stone-750 rounded-xl px-3 py-2 text-xs text-stone-100 font-mono focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            {/* Shift Responsible Assignee */}
            <div>
              <label className="block text-xs font-bold text-stone-200 mb-1.5">
                المسؤول عن الوردية والطلب:
              </label>
              <select
                value={primaryAssigneeId}
                onChange={(e) => setPrimaryAssigneeId(e.target.value)}
                className="w-full bg-stone-900 border border-stone-750 rounded-xl px-3 py-2 text-xs text-stone-100 focus:outline-none focus:border-amber-500"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.role === 'manager' ? 'مدير المطبخ' : 'مسؤول الوردية'})
                  </option>
                ))}
              </select>
            </div>

            {/* Shift Order Deadline */}
            <div>
              <label className="block text-xs font-bold text-stone-200 mb-1.5 flex items-center justify-between">
                <span>مهلة إرسال الطلب:</span>
                <span className="text-[10px] text-amber-400 font-mono">إنذار آلي للوردية</span>
              </label>
              <input
                type="datetime-local"
                value={orderingDeadline}
                onChange={(e) => setOrderingDeadline(e.target.value)}
                className="w-full bg-stone-900 border border-stone-750 rounded-xl px-3 py-2 text-xs text-stone-100 font-mono focus:outline-none focus:border-amber-500"
                required
              />
            </div>
          </div>

          {/* Secondary Controls: Supplier & Channel */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-stone-850/40 p-2.5 rounded-2xl border border-stone-800/80 shrink-0">
            <div>
              <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                المورد المستهدف:
              </label>
              <select
                value={supplierId}
                onChange={(e) => setSupplierId(e.target.value)}
                className="w-full bg-stone-900 border border-stone-800 rounded-xl px-2.5 py-1.5 text-xs text-stone-200 focus:outline-none focus:border-amber-500"
              >
                <option value="">-- مورد الفئة التلقائي ({getTargetSupplier()?.name || 'مزارع الوادي'}) --</option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name || s.nameAr} ({s.phone})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                قناة التوريد المعتمدة:
              </label>
              <select
                value={purchasingChannel}
                onChange={(e) => setPurchasingChannel(e.target.value)}
                className="w-full bg-stone-900 border border-stone-800 rounded-xl px-2.5 py-1.5 text-xs text-stone-200 focus:outline-none focus:border-amber-500"
              >
                <option value="واتساب">واتساب (WhatsApp - تحويل مباشر)</option>
                <option value="مكالمة هاتفية">مكالمة هاتفية مباشرة</option>
                <option value="بريد إلكتروني">بريد إلكتروني</option>
              </select>
            </div>

            <div className="flex items-center gap-2 pt-3.5">
              <input
                type="checkbox"
                id="reqApprToggle"
                checked={requiresApproval}
                onChange={(e) => setRequiresApproval(e.target.checked)}
                className="w-4 h-4 rounded text-amber-500 bg-stone-800 border-stone-700 focus:ring-0"
              />
              <label htmlFor="reqApprToggle" className="text-xs text-stone-300 cursor-pointer select-none">
                تتطلب اعتماد مدير المطبخ قبل الإرسال
              </label>
            </div>
          </div>

          {/* Specialist Table: Clear Column Headers and Clean Row Inputs */}
          <div className="flex-1 border border-stone-800 rounded-2xl bg-stone-950/60 flex flex-col overflow-hidden min-h-[220px]">
            {/* Table Header Bar */}
            <div className="bg-stone-850/90 px-3.5 py-2 border-b border-stone-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs text-amber-300">
                  {isVegetableCategory
                    ? 'مكونات طلبية الخضار (24 صنفاً أساسياً)'
                    : `قائمة أصناف ${currentCategory?.nameAr || 'القسم'}`}
                </span>
                <span className="text-[11px] text-stone-400">
                  (أدخل الكمية في خانة &quot;ما يجب طلبه&quot; بناءً على ما تراه متواجداً في المطعم)
                </span>
              </div>

              <div className="flex items-center gap-2">
                {filledCount > 0 && (
                  <button
                    type="button"
                    onClick={() => setShowOnlyFilled(!showOnlyFilled)}
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-750 text-stone-300 border border-stone-700 transition"
                  >
                    {showOnlyFilled ? `عرض الكل (${items.length})` : `عرض المدخل فقط (${filledCount})`}
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 px-3 py-1 rounded-xl border border-amber-500/25 font-bold transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة مكون غير مدرج</span>
                </button>
              </div>
            </div>

            {/* Table Column Headers as Explicitly Requested in Prompt 3 & 5 */}
            <div className="grid grid-cols-12 gap-2 px-3 py-2 bg-stone-900 border-b border-stone-800/80 text-[11px] font-bold text-stone-300 shrink-0 select-none">
              <div className="col-span-1 text-center font-mono text-stone-500">م</div>
              <div className="col-span-4 sm:col-span-4">
                {isVegetableCategory ? 'اسم المكون' : 'اسم الصنف'}
              </div>
              <div className="col-span-3 sm:col-span-2 text-center text-amber-400">
                {isVegetableCategory ? 'المتوسط المطلوب' : 'متوسط الطلب اليومي'}
              </div>
              <div className="col-span-2 sm:col-span-3 text-center text-emerald-400">
                {isVegetableCategory ? 'ما يجب طلبه' : 'الكمية المطلوبة'}
              </div>
              <div className="col-span-2 sm:col-span-1 text-center">الوحدة</div>
              <div className="hidden sm:block sm:col-span-1 text-center">حذف</div>
            </div>

            {/* Scrollable Table Body */}
            <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
              {displayedItems.map((item, idx) => {
                const actualIndex = items.findIndex((i) => i.id === item.id);
                const hasValue = item.requestedQty.trim() !== '' && parseFloat(item.requestedQty) > 0;
                return (
                  <div
                    key={item.id}
                    className={`grid grid-cols-12 gap-2 items-center p-2 rounded-xl border transition text-xs ${
                      hasValue
                        ? 'bg-emerald-950/20 border-emerald-500/30'
                        : 'bg-stone-900/60 hover:bg-stone-900 border-stone-800/80'
                    }`}
                  >
                    {/* Row Number */}
                    <div className="col-span-1 text-center font-mono text-stone-500 text-[11px]">
                      {actualIndex + 1}
                    </div>

                    {/* Component / Ingredient Name */}
                    <div className="col-span-4 sm:col-span-4">
                      <input
                        type="text"
                        value={item.productName}
                        onChange={(e) =>
                          handleItemFieldChange(actualIndex, 'productName', e.target.value)
                        }
                        placeholder={isVegetableCategory ? 'اسم المكون...' : 'اسم الصنف...'}
                        className="w-full bg-stone-850 border border-stone-750 rounded-lg px-2.5 py-1.5 text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500 font-semibold"
                        required
                      />
                    </div>

                    {/* Daily Average Order / Required Reference */}
                    <div className="col-span-3 sm:col-span-2 text-center">
                      <span className="inline-block px-2 py-1 rounded-md bg-stone-800/80 border border-stone-750 text-[11px] font-mono text-amber-300">
                        {item.averageDailyDemand
                          ? `${item.averageDailyDemand} ${item.unit}`
                          : '— استرشادي'}
                      </span>
                    </div>

                    {/* "ما يجب طلبه": EMPTY by default for employee to enter! */}
                    <div className="col-span-2 sm:col-span-3">
                      <input
                        type="number"
                        step="any"
                        min="0"
                        value={item.requestedQty}
                        onChange={(e) =>
                          handleItemFieldChange(actualIndex, 'requestedQty', e.target.value)
                        }
                        placeholder="ما يجب طلبه..."
                        className={`w-full text-center font-mono font-bold text-xs rounded-lg px-2 py-1.5 border transition focus:outline-none ${
                          hasValue
                            ? 'bg-emerald-950/50 border-emerald-500 text-emerald-300'
                            : 'bg-stone-850 border-stone-700 text-stone-100 placeholder-stone-600 focus:border-amber-500'
                        }`}
                      />
                    </div>

                    {/* Unit: Kilograms (كجم) or Count (بالعدد / حبة) */}
                    <div className="col-span-2 sm:col-span-1">
                      <select
                        value={item.unit}
                        onChange={(e) =>
                          handleItemFieldChange(actualIndex, 'unit', e.target.value)
                        }
                        className="w-full bg-stone-850 border border-stone-750 rounded-lg px-1 py-1.5 text-xs text-stone-200 text-center focus:outline-none focus:border-amber-500"
                      >
                        <option value="كجم">كجم</option>
                        <option value="بالعدد / حبة">حبة</option>
                        <option value="ربطة">ربطة</option>
                        <option value="كرتونة">كرتونة</option>
                        <option value="شوال / كيس">شوال</option>
                        <option value="لتر">لتر</option>
                      </select>
                    </div>

                    {/* Delete button */}
                    <div className="hidden sm:flex sm:col-span-1 items-center justify-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(actualIndex)}
                        disabled={items.length <= 1}
                        className="p-1.5 text-stone-500 hover:text-rose-400 disabled:opacity-20 rounded-lg transition"
                        title="حذف هذا الصنف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Notes Input */}
          <div className="shrink-0">
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="ملاحظات توريد خاصة للشيف أو المورد (اختياري)..."
              className="w-full bg-stone-850 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Footer Action Buttons */}
          <div className="pt-2 border-t border-stone-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shrink-0">
            <div className="text-[11px] text-stone-400 flex items-center gap-2">
              <span>الأصناف المحددة في (ما يجب طلبه):</span>
              <strong className="text-emerald-400 font-mono text-xs">
                {filledCount}
              </strong>
              <span>من أصل {items.length} صنف</span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold text-stone-300 hover:text-white bg-stone-800 hover:bg-stone-750 transition"
              >
                إلغاء
              </button>

              {/* Standard Save */}
              <button
                type="button"
                disabled={isSubmitting}
                onClick={() => saveOrderInternal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-stone-750 hover:bg-stone-700 text-stone-100 border border-stone-650 transition disabled:opacity-50"
              >
                حفظ أمر التوريد
              </button>

              {/* Direct WhatsApp Dispatch Button - Prompt 5 Core Requirement */}
              <button
                type="button"
                disabled={isSubmitting}
                onClick={() => saveOrderInternal(true)}
                className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-950/40 transition disabled:opacity-50"
                title="تحويل ما يجب طلبه مباشرة عبر الواتساب للمورد الخاص بطلبية الخضار"
              >
                {isSubmitting ? (
                  <span>جاري التجهيز...</span>
                ) : (
                  <>
                    <MessageSquare className="w-4 h-4 fill-emerald-100 text-emerald-800" />
                    <span>تحويل ما يجب طلبه مباشرة عبر الواتساب للمورد 💬</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* WhatsApp Dispatch Success Modal (Prompt 5 Completion View) */}
        {whatsAppDispatchPayload && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-stone-950/90 backdrop-blur-md">
            <div className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-xl p-5 sm:p-6 text-stone-100 shadow-2xl animate-in fade-in zoom-in-95 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-stone-100">
                      تم تحويل طلبية الخضار للواتساب بنجاح!
                    </h3>
                    <p className="text-[11px] text-stone-400">
                      كود الطلب: <span className="font-mono text-amber-400">{whatsAppDispatchPayload.orderCode}</span>
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setWhatsAppDispatchPayload(null);
                    onClose();
                  }}
                  className="p-1.5 rounded-lg text-stone-400 hover:text-white bg-stone-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Summary Card */}
              <div className="p-3 bg-stone-950/80 rounded-2xl border border-stone-800 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-stone-400">مورد الخضار:</span>
                  <strong className="text-emerald-300 font-bold">{whatsAppDispatchPayload.supplierName}</strong>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-stone-400">رقم الهاتف:</span>
                  <span className="font-mono text-stone-200">{whatsAppDispatchPayload.supplierPhone}</span>
                </div>
                <div className="flex items-center justify-between border-t border-stone-800/80 pt-2 text-[11px]">
                  <span>عدد الأصناف المحولة: <strong className="text-amber-400 font-mono">{whatsAppDispatchPayload.itemCount} صنف</strong></span>
                  <span>موعد الوصول الثابت: <strong className="text-amber-400 font-mono">01:00 ظهراً كحد أقصى</strong></span>
                </div>
              </div>

              {/* Message Preview */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-stone-300">
                    نص أمر التوريد المحول للواتساب:
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyMessage}
                    className="flex items-center gap-1 text-[11px] text-amber-300 bg-stone-800 hover:bg-stone-750 px-2.5 py-1 rounded-lg transition"
                  >
                    {copiedText ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>تم النسخ!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>نسخ النص</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="bg-stone-950 border border-stone-800 rounded-xl p-3 font-mono text-[11px] text-stone-300 whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto selection:bg-emerald-500/30">
                  {whatsAppDispatchPayload.messageText}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-stone-800 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setWhatsAppDispatchPayload(null);
                    onClose();
                  }}
                  className="px-4 py-2 bg-stone-800 hover:bg-stone-750 text-stone-300 rounded-xl text-xs font-semibold transition"
                >
                  إغلاق
                </button>
                <a
                  href={whatsAppDispatchPayload.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => {
                    setTimeout(() => {
                      setWhatsAppDispatchPayload(null);
                      onClose();
                    }, 500);
                  }}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-emerald-950/50"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>فتح محادثة واتساب للمورد وإرسال الطلب الآن</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
