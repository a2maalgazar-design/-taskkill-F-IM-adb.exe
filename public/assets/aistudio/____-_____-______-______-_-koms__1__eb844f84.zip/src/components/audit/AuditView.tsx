import React, { useState } from 'react';
import { History, Search, ShieldCheck } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { formatDateTime } from '../../utils/statusLabels';

export const AuditView: React.FC = () => {
  const { auditLogs } = useData();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLogs = auditLogs.filter((log) => {
    if (!searchTerm.trim()) return true;
    const q = searchTerm.toLowerCase();
    return (
      log.details.toLowerCase().includes(q) ||
      log.userName.toLowerCase().includes(q) ||
      log.entityId.toLowerCase().includes(q) ||
      log.action.toLowerCase().includes(q)
    );
  });

  const getActionBadge = (action: string) => {
    switch (action) {
      case 'CREATE':
        return 'bg-emerald-950/80 text-emerald-400 border border-emerald-800';
      case 'STATUS_CHANGE':
        return 'bg-amber-950/80 text-amber-300 border border-amber-800';
      case 'RECEIVE':
        return 'bg-cyan-950/80 text-cyan-300 border border-cyan-800';
      case 'VERIFY_INVOICE':
        return 'bg-yellow-950/80 text-yellow-300 border border-yellow-800';
      case 'ARCHIVE':
        return 'bg-purple-950/80 text-purple-300 border border-purple-800';
      default:
        return 'bg-stone-800 text-stone-300 border border-stone-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-stone-100 flex items-center gap-2">
            <History className="w-5 h-5 text-amber-400" />
            <span>سجل العمليات والتدقيق الأمني (Immutable Audit Trail)</span>
          </h1>
          <p className="text-xs text-stone-400">
            سجل نظام غير قابل للتعديل يوثق كل إجراء، تغيير حالة، استلام بضاعة، واعتماد فواتير مع اسم الفاعل وتوقيته
          </p>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/40 px-3 py-1.5 rounded-full border border-emerald-800">
          <ShieldCheck className="w-4 h-4" />
          <span>سجل تدقيق محمي وغير قابل للحذف</span>
        </div>
      </div>

      {/* Search and Table */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-stone-400 absolute right-3 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="بحث في سجل العمليات باسم الموظف أو رقم الحركة..."
              className="w-full bg-stone-850 border border-stone-800 rounded-xl pr-9 pl-3 py-2 text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500"
            />
          </div>
          <span className="text-xs text-stone-400 font-mono">
            {filteredLogs.length} حركة موثقة
          </span>
        </div>

        <div className="border border-stone-800 rounded-xl overflow-hidden">
          <table className="w-full text-right text-xs text-stone-300">
            <thead className="bg-stone-850 text-stone-400 text-[11px] uppercase">
              <tr>
                <th className="p-3">التوقيت والتاريخ</th>
                <th className="p-3">المستخدم (الفاعل)</th>
                <th className="p-3">نوع الحركة</th>
                <th className="p-3">الكائن المعني</th>
                <th className="p-3">تفاصيل الإجراء والملاحظات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-800/80">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-10 text-center text-stone-500">
                    لا توجد سجلات تدقيق مطابقة.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-stone-850/60 transition">
                    <td className="p-3 font-mono text-stone-400 text-[11px] whitespace-nowrap">
                      {formatDateTime(log.timestamp)}
                    </td>
                    <td className="p-3 font-semibold text-stone-200">
                      {log.userName}
                    </td>
                    <td className="p-3">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-bold font-mono ${getActionBadge(
                          log.action
                        )}`}
                      >
                        {log.action}
                      </span>
                    </td>
                    <td className="p-3 font-mono text-amber-400 text-[11px]">
                      {log.entityType} ({log.entityId})
                    </td>
                    <td className="p-3 text-stone-300 leading-relaxed">
                      {log.details}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
