import React, { useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  Calendar,
  CheckCircle2,
  Clock,
  Edit2,
  FileText,
  Mail,
  Play,
  Plus,
  RefreshCw,
  Send,
  Settings,
  ShieldAlert,
  Trash2,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { MasterOrderSchedule, RecurrenceType } from '../../types';
import { ScheduleAlertModal } from './ScheduleAlertModal';
import { scheduleAlertService } from '../../services/scheduleAlertService';

export const MasterScheduleView: React.FC = () => {
  const { isManager, users, currentUser } = useAuth();
  const {
    orders,
    schedules,
    orderTypes,
    suppliers,
    saveSchedule,
    deleteSchedule,
    generateOrderFromSchedule,
    generateAllDueSchedulesToday,
    missedSchedules,
    sendMissedScheduleAlerts,
    refreshAll,
  } = useData();

  const [editingSchedule, setEditingSchedule] = useState<MasterOrderSchedule | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAlertModalOpen, setIsAlertModalOpen] = useState(false);
  const [alertModalTab, setAlertModalTab] = useState<'missed' | 'email' | 'settings' | 'logs'>('missed');
  const [generatingId, setGeneratingId] = useState<string | null>(null);
  const [isGeneratingAll, setIsGeneratingAll] = useState(false);
  const [isSendingAlert, setIsSendingAlert] = useState(false);
  const [actionMessage, setActionMessage] = useState<{ type: 'success' | 'error'; text: string; link?: string } | null>(null);

  const handleCreateNew = () => {
    setEditingSchedule({
      id: `sched-${Date.now()}`,
      name: '',
      orderTypeId: orderTypes[0]?.id || 'cat-veg',
      primaryAssigneeId: users[1]?.id || users[0]?.id,
      orderingDay: 'يومي',
      orderingTime: '08:00',
      requiredDeliveryHours: 12,
      purchasingChannel: 'واتساب',
      requiresApproval: false,
      recurrenceRule: 'daily',
      isActive: true,
      alertIfMissed: true,
      alertCutoffTime: '09:30',
      managerEmail: 'a2m.algazar@gmail.com',
      notes: '',
      createdAt: new Date().toISOString(),
    });
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSchedule) return;
    try {
      await saveSchedule(editingSchedule);
      setIsModalOpen(false);
      setEditingSchedule(null);
      setActionMessage({ type: 'success', text: 'تم حفظ الجدول الدوري بنجاح' });
    } catch (err: any) {
      setActionMessage({ type: 'error', text: err?.message || 'فشل حفظ الجدول الدوري' });
    }
  };

  const handleGenerate = async (scheduleId: string) => {
    setGeneratingId(scheduleId);
    setActionMessage(null);
    try {
      const orderId = await generateOrderFromSchedule(scheduleId);
      setActionMessage({
        type: 'success',
        text: `تم توليد الطلبية الفعلية بنجاح برقم (${orderId}) دون تكرار`,
      });
    } catch (err: any) {
      setActionMessage({
        type: 'error',
        text: err?.message || 'تعذر توليد الطلبية',
      });
    } finally {
      setGeneratingId(null);
    }
  };

  const handleQuickSendAlerts = async () => {
    setIsSendingAlert(true);
    setActionMessage(null);
    try {
      const res = await sendMissedScheduleAlerts(todayStr);
      setActionMessage({
        type: 'success',
        text: `تم بنجاح إرسال تنبيهات بريدية ونظامية للمدير (${res.log.managerEmail}) لـ (${res.count}) جداول متأخرة`,
        link: res.mailtoUrl,
      });
    } catch (err: any) {
      setActionMessage({
        type: 'error',
        text: err?.message || 'تعذر إرسال التنبيهات',
      });
    } finally {
      setIsSendingAlert(false);
    }
  };

  const handleQuickGenerateAll = async () => {
    setIsGeneratingAll(true);
    setActionMessage(null);
    try {
      const generated = await generateAllDueSchedulesToday();
      setActionMessage({
        type: 'success',
        text: `تم بنجاح توليد (${generated.length}) طلبية فعلية لجميع الجداول المستحقة اليوم`,
      });
      await refreshAll();
    } catch (err: any) {
      setActionMessage({
        type: 'error',
        text: err?.message || 'فشل التوليد الشامل',
      });
    } finally {
      setIsGeneratingAll(false);
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const activeSchedules = schedules.filter((s) => s.isActive);
  const dueTodaySchedules = activeSchedules.filter((s) =>
    scheduleAlertService.isScheduleDueToday(s, todayStr)
  );
  const generatedTodayCount = dueTodaySchedules.filter((s) => {
    return (
      orders.some(
        (o) =>
          (o.masterScheduleId === s.id || (o as any).scheduleId === s.id) &&
          o.orderDate === todayStr &&
          !o.isArchived
      ) || s.lastGeneratedDate === todayStr
    );
  }).length;

  const getCategoryName = (id: string) => {
    return orderTypes.find((c) => c.id === id)?.nameAr || id;
  };

  const getUserName = (id?: string) => {
    return users.find((u) => u.id === id)?.name || id || '—';
  };

  const getSupplierName = (id?: string) => {
    return suppliers.find((s) => s.id === id)?.name || 'غير محدد (TBD)';
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-stone-100">
            جداول التوريد الدورية (Master Order Schedules)
          </h1>
          <p className="text-xs text-stone-400">
            إعداد جداول المشتريات المتكررة (يومياً، أسبوعياً، كل أسبوعين) لتوليد طلبيات المطبخ تلقائياً
          </p>
        </div>

        {isManager && (
          <button
            onClick={handleCreateNew}
            className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>إنشاء جدول دوري جديد</span>
          </button>
        )}
      </div>

      {/* Workday Generation Monitor & Alerts Banner */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 border-b border-stone-800/80 pb-3">
          <div className="flex items-center gap-2.5">
            <div
              className={`p-2 rounded-xl ${
                missedSchedules.length > 0
                  ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                  : 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
              }`}
            >
              {missedSchedules.length > 0 ? (
                <AlertTriangle className="w-5 h-5 stroke-[2.2]" />
              ) : (
                <CheckCircle2 className="w-5 h-5 stroke-[2.2]" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-stone-100">
                  مراقبة التوليد التلقائي لورديات اليوم ({todayStr})
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-stone-800 text-stone-300">
                  GMT+2 القاهرة
                </span>
              </div>
              <p className="text-xs text-stone-400">
                متابعة الجداول اليومية المستحقة وتوجيه إنذارات للمدير المسؤول في حال عدم التوليد
              </p>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center gap-2 text-xs">
            <div className="bg-stone-950 px-3 py-1.5 rounded-xl border border-stone-800">
              <span className="text-stone-400">مستحق اليوم: </span>
              <strong className="text-stone-100 font-mono">{dueTodaySchedules.length}</strong>
            </div>
            <div className="bg-stone-950 px-3 py-1.5 rounded-xl border border-stone-800">
              <span className="text-emerald-400">تم توليدها: </span>
              <strong className="text-emerald-400 font-mono">{generatedTodayCount}</strong>
            </div>
            <div
              className={`px-3 py-1.5 rounded-xl border font-bold ${
                missedSchedules.length > 0
                  ? 'bg-rose-950/60 border-rose-800 text-rose-300 animate-pulse'
                  : 'bg-stone-950 border-stone-800 text-stone-400'
              }`}
            >
              <span>لم تُولّد بعد: </span>
              <span className="font-mono">{missedSchedules.length}</span>
            </div>
          </div>
        </div>

        {/* If Missed Schedules exist, show actionable callout */}
        {missedSchedules.length > 0 ? (
          <div className="bg-rose-950/30 border border-rose-800/60 rounded-xl p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5 font-bold text-rose-300 text-[13px]">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                <span>تنبيه عاجل: ({missedSchedules.length}) جداول توريد دورية لم تُولّد طلباتها تلقائياً اليوم!</span>
              </div>
              <p className="text-stone-400 text-[11px]">
                يوجد خطر نقص في الخضار أو المخبوزات أو اللحوم قبل بدء الوردية. يمكنك إرسال بريد رسمي للمدير المسؤول أو توليدها بنقرة واحدة.
              </p>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={handleQuickSendAlerts}
                disabled={isSendingAlert}
                className="flex-1 sm:flex-initial bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition shadow"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>{isSendingAlert ? 'جاري الإرسال...' : 'إرسال تنبيه للمدير'}</span>
              </button>

              <button
                onClick={handleQuickGenerateAll}
                disabled={isGeneratingAll}
                className="flex-1 sm:flex-initial bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition shadow"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isGeneratingAll ? 'جاري التوليد...' : 'توليد الكل الآن'}</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="text-[11px] text-emerald-400/90 flex items-center gap-1.5 pt-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>جميع جداول التوريد المستحقة لوردية اليوم تم توليدها بنجاح ودون أي تأخير تشغيلي.</span>
          </div>
        )}

        {/* Manager Tool Actions */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-stone-800/80 text-xs">
          <div className="flex items-center gap-2 text-stone-400">
            <span>مركز تنبيهات المدير:</span>
            <button
              onClick={() => {
                setAlertModalTab('missed');
                setIsAlertModalOpen(true);
              }}
              className="text-amber-400 hover:text-amber-300 font-bold underline-offset-4 hover:underline"
            >
              فحص الجداول المتأخرة ({missedSchedules.length})
            </button>
            <span>•</span>
            <button
              onClick={() => {
                setAlertModalTab('email');
                setIsAlertModalOpen(true);
              }}
              className="text-stone-300 hover:text-white"
            >
              معاينة رسالة البريد للمدير
            </button>
            <span>•</span>
            <button
              onClick={() => {
                setAlertModalTab('logs');
                setIsAlertModalOpen(true);
              }}
              className="text-stone-300 hover:text-white"
            >
              سجل الإرسال التاريخي
            </button>
          </div>

          <button
            onClick={() => {
              setAlertModalTab('settings');
              setIsAlertModalOpen(true);
            }}
            className="text-stone-400 hover:text-stone-200 flex items-center gap-1 text-[11px] bg-stone-850 px-2.5 py-1 rounded-lg border border-stone-800 hover:border-stone-700 transition"
          >
            <Settings className="w-3 h-3 text-amber-400" />
            <span>إعدادات تنبيهات البريد للمدير</span>
          </button>
        </div>
      </div>

      {actionMessage && (
        <div
          className={`p-3 rounded-xl border text-xs flex items-center justify-between animate-in fade-in ${
            actionMessage.type === 'success'
              ? 'bg-emerald-950/60 border-emerald-800 text-emerald-200'
              : 'bg-rose-950/60 border-rose-800 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{actionMessage.text}</span>
          </div>
          <div className="flex items-center gap-2">
            {actionMessage.link && (
              <a
                href={actionMessage.link}
                className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-bold px-2 py-0.5 rounded border border-emerald-500/40 text-[11px]"
              >
                فتح البريد
              </a>
            )}
            <button onClick={() => setActionMessage(null)} className="text-stone-400 hover:text-white">
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Schedules List Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {schedules.length === 0 ? (
          <div className="col-span-full p-12 bg-stone-900 border border-stone-800 rounded-2xl text-center text-stone-400">
            <Calendar className="w-10 h-10 mx-auto mb-2 text-stone-600" />
            <p className="font-semibold text-sm">لا توجد جداول دورية مضافة حتى الآن</p>
            <p className="text-xs text-stone-500 mt-1">
              قم بإنشاء جدول دوري لمشتريات الخضار أو اللحوم لتسهيل وتوحيد دورة التوريد
            </p>
          </div>
        ) : (
          schedules.map((sch) => {
            const isGeneratedToday =
              orders.some(
                (o) =>
                  (o.masterScheduleId === sch.id || (o as any).scheduleId === sch.id) &&
                  o.orderDate === todayStr &&
                  !o.isArchived
              ) || sch.lastGeneratedDate === todayStr;

            const isDueToday = scheduleAlertService.isScheduleDueToday(sch, todayStr);
            const isMissedToday = sch.isActive && isDueToday && !isGeneratedToday;

            return (
              <div
                key={sch.id}
                className={`bg-stone-900 border rounded-2xl p-4 flex flex-col justify-between transition ${
                  isMissedToday
                    ? 'border-rose-800/80 hover:border-rose-600 bg-gradient-to-b from-stone-900 to-rose-950/20 shadow-sm'
                    : sch.isActive
                    ? 'border-stone-800 hover:border-stone-700'
                    : 'border-stone-850 opacity-60'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-400 font-mono">
                      {getCategoryName(sch.orderTypeId)}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {isGeneratedToday ? (
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-800 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>تم توليد اليوم</span>
                        </span>
                      ) : isMissedToday ? (
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-rose-950/90 text-rose-300 border border-rose-800 flex items-center gap-1 animate-pulse">
                          <AlertTriangle className="w-3 h-3" />
                          <span>لم يُولّد اليوم!</span>
                        </span>
                      ) : (
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            sch.isActive
                              ? 'bg-stone-800 text-stone-300'
                              : 'bg-stone-850 text-stone-500'
                          }`}
                        >
                          {sch.isActive ? 'مفعل دورياً' : 'متوقف'}
                        </span>
                      )}
                    </div>
                  </div>

                  <h3 className="font-bold text-sm text-stone-100 mt-2">{sch.name}</h3>
                  {sch.notes && (
                    <p className="text-[11px] text-stone-400 mt-1 leading-relaxed">{sch.notes}</p>
                  )}

                  <div className="mt-4 pt-3 border-t border-stone-800/80 space-y-1.5 text-xs text-stone-300">
                    <div className="flex justify-between">
                      <span className="text-stone-400">دورة التكرار:</span>
                      <span className="font-semibold text-stone-200">
                        {sch.recurrenceRule === 'daily'
                          ? 'يومي'
                          : sch.recurrenceRule === 'weekly'
                          ? 'أسبوعي'
                          : sch.recurrenceRule === 'biweekly'
                          ? 'كل أسبوعين'
                          : sch.recurrenceRule === 'monthly'
                          ? 'شهري'
                          : sch.recurrenceRule}
                        {' — '}({sch.orderingDay})
                      </span>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-stone-400">وقت الطلب والمهلة:</span>
                      <span className="font-mono text-stone-200">
                        الساعة {sch.orderingTime} (وصول خلال {sch.requiredDeliveryHours} س)
                      </span>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-stone-400">تنبيه المدير:</span>
                      <span className="text-stone-300 flex items-center gap-1">
                        {sch.alertIfMissed !== false ? (
                          <>
                            <Mail className="w-3 h-3 text-amber-400" />
                            <span className="text-amber-300 font-mono text-[11px]">
                              إنذار عند {sch.alertCutoffTime || '09:30'}
                            </span>
                          </>
                        ) : (
                          <span className="text-stone-500 text-[11px]">معطل</span>
                        )}
                      </span>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-stone-400">المسؤول المكلف:</span>
                      <span className="text-stone-200 truncate max-w-[150px]">
                        {getUserName(sch.primaryAssigneeId)}
                      </span>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-stone-400">المورد المقترح:</span>
                      <span className="text-stone-200 truncate max-w-[150px]">
                        {getSupplierName(sch.supplierId)}
                      </span>
                    </div>

                    {sch.lastGeneratedDate && (
                      <div className="flex justify-between text-[11px] text-stone-400 pt-1">
                        <span>آخر توليد:</span>
                        <span className="font-mono text-amber-400">{sch.lastGeneratedDate}</span>
                      </div>
                    )}
                  </div>
                </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-stone-800 flex items-center justify-between gap-2">
                <button
                  onClick={() => handleGenerate(sch.id)}
                  disabled={generatingId === sch.id || !sch.isActive}
                  className="flex-1 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 disabled:opacity-40 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{generatingId === sch.id ? 'جاري التوليد...' : 'توليد الطلبية الآن'}</span>
                </button>

                {isManager && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        setEditingSchedule(sch);
                        setIsModalOpen(true);
                      }}
                      className="p-2 text-stone-400 hover:text-white bg-stone-800 rounded-xl"
                      title="تعديل"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteSchedule(sch.id)}
                      className="p-2 text-stone-400 hover:text-rose-400 bg-stone-800 rounded-xl"
                      title="حذف"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })
      )}
    </div>

      {/* CREATE / EDIT MODAL */}
      {isModalOpen && editingSchedule && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-xl p-5 text-stone-100 shadow-2xl my-6">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <h3 className="font-bold text-base text-stone-100">
                {editingSchedule.name ? `تعديل جدول: ${editingSchedule.name}` : 'إنشاء جدول توريد دوري جديد'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-white bg-stone-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-stone-300 mb-1">اسم الجدول الدوري:</label>
                <input
                  type="text"
                  value={editingSchedule.name}
                  onChange={(e) => setEditingSchedule({ ...editingSchedule, name: e.target.value })}
                  placeholder="مثال: توريد الخضار اليومي الصباحي، لحوم نصف الأسبوع..."
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">فئة التوريد:</label>
                  <select
                    value={editingSchedule.orderTypeId}
                    onChange={(e) =>
                      setEditingSchedule({ ...editingSchedule, orderTypeId: e.target.value })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  >
                    {orderTypes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.nameAr}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">قاعدة التكرار:</label>
                  <select
                    value={editingSchedule.recurrenceRule}
                    onChange={(e) =>
                      setEditingSchedule({
                        ...editingSchedule,
                        recurrenceRule: e.target.value as RecurrenceType,
                      })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  >
                    <option value="daily">يومي (Daily)</option>
                    <option value="weekly">أسبوعي (Weekly)</option>
                    <option value="biweekly">كل أسبوعين (Every two weeks)</option>
                    <option value="monthly">شهري (Monthly)</option>
                    <option value="custom">مخصص (Custom)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">يوم الطلب:</label>
                  <input
                    type="text"
                    value={editingSchedule.orderingDay}
                    onChange={(e) =>
                      setEditingSchedule({ ...editingSchedule, orderingDay: e.target.value })
                    }
                    placeholder="مثلاً: يومياً، السبت، الإثنين والأربعاء..."
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">وقت الطلب المعتاد:</label>
                  <input
                    type="time"
                    value={editingSchedule.orderingTime}
                    onChange={(e) =>
                      setEditingSchedule({ ...editingSchedule, orderingTime: e.target.value })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">
                    المسؤول الأساسي (Primary):
                  </label>
                  <select
                    value={editingSchedule.primaryAssigneeId}
                    onChange={(e) =>
                      setEditingSchedule({ ...editingSchedule, primaryAssigneeId: e.target.value })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  >
                    {users.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">
                    المسؤول البديل (Backup):
                  </label>
                  <select
                    value={editingSchedule.backupAssigneeId || ''}
                    onChange={(e) =>
                      setEditingSchedule({
                        ...editingSchedule,
                        backupAssigneeId: e.target.value || undefined,
                      })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  >
                    <option value="">-- اختياري --</option>
                    {users.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">المورد:</label>
                  <select
                    value={editingSchedule.supplierId || ''}
                    onChange={(e) =>
                      setEditingSchedule({
                        ...editingSchedule,
                        supplierId: e.target.value || undefined,
                      })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  >
                    <option value="">غير محدد (TBD)</option>
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">
                    مهلة التوريد المقررة (بالساعات):
                  </label>
                  <input
                    type="number"
                    value={editingSchedule.requiredDeliveryHours}
                    onChange={(e) =>
                      setEditingSchedule({
                        ...editingSchedule,
                        requiredDeliveryHours: Number(e.target.value),
                      })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono"
                    min="1"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-300 mb-1">
                  ملاحظات وتعليمات التشغيل:
                </label>
                <textarea
                  value={editingSchedule.notes || ''}
                  onChange={(e) =>
                    setEditingSchedule({ ...editingSchedule, notes: e.target.value })
                  }
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 h-16 resize-none"
                  placeholder="شروط خاصة أو تعليمات دورية..."
                />
              </div>

              <div className="space-y-2 pt-2 border-t border-stone-800">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingSchedule.requiresApproval}
                    onChange={(e) =>
                      setEditingSchedule({
                        ...editingSchedule,
                        requiresApproval: e.target.checked,
                      })
                    }
                    className="w-4 h-4 rounded text-amber-500"
                  />
                  <span>تتطلب اعتماد المدير عند كل دورة توليد</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingSchedule.isActive}
                    onChange={(e) =>
                      setEditingSchedule({
                        ...editingSchedule,
                        isActive: e.target.checked,
                      })
                    }
                    className="w-4 h-4 rounded text-amber-500"
                  />
                  <span>الجدول نشط وجاهز للتوليد التشغيلي</span>
                </label>

                {/* Manager Missed Schedule Alert Settings */}
                <div className="pt-2 border-t border-stone-800 space-y-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingSchedule.alertIfMissed ?? true}
                      onChange={(e) =>
                        setEditingSchedule({
                          ...editingSchedule,
                          alertIfMissed: e.target.checked,
                        })
                      }
                      className="w-4 h-4 rounded text-amber-500"
                    />
                    <span className="font-semibold text-amber-400">
                      تنبيه المدير المسؤول في حال عدم التوليد التلقائي خلال يوم العمل
                    </span>
                  </label>

                  {(editingSchedule.alertIfMissed ?? true) && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-stone-900 rounded-xl border border-stone-800 text-xs mt-1">
                      <div>
                        <label className="block text-stone-300 mb-1">وقت الإنذار الحرج (Cutoff):</label>
                        <input
                          type="time"
                          value={editingSchedule.alertCutoffTime || '09:30'}
                          onChange={(e) =>
                            setEditingSchedule({
                              ...editingSchedule,
                              alertCutoffTime: e.target.value,
                            })
                          }
                          className="w-full bg-stone-850 border border-stone-800 rounded-lg p-2 text-stone-100 font-mono"
                        />
                        <span className="text-[10px] text-stone-500 mt-0.5 block">
                          يرسل إشعار وبريد إذا لم يُولّد بحلول هذا الوقت
                        </span>
                      </div>
                      <div>
                        <label className="block text-stone-300 mb-1">بريد مخصص للمدير (اختياري):</label>
                        <input
                          type="email"
                          value={editingSchedule.managerEmail || ''}
                          onChange={(e) =>
                            setEditingSchedule({
                              ...editingSchedule,
                              managerEmail: e.target.value,
                            })
                          }
                          placeholder="a2m.algazar@gmail.com"
                          className="w-full bg-stone-850 border border-stone-800 rounded-lg p-2 text-stone-100 font-mono"
                        />
                        <span className="text-[10px] text-stone-500 mt-0.5 block">
                          اتركه فارغاً لاستخدام البريد الافتراضي للمدير
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3">
                <button
                  type="submit"
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold py-2.5 rounded-xl transition"
                >
                  حفظ الجدول الدوري
                </button>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="bg-stone-800 text-stone-300 py-2.5 px-4 rounded-xl"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Schedule Alert & Email Management Modal */}
      <ScheduleAlertModal
        isOpen={isAlertModalOpen}
        onClose={() => setIsAlertModalOpen(false)}
        onGenerateOrder={handleGenerate}
        initialTab={alertModalTab}
      />
    </div>
  );
};

