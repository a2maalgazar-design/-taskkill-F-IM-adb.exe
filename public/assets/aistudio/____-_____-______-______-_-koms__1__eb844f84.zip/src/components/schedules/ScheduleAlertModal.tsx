import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Bell,
  CheckCircle2,
  Clock,
  Copy,
  ExternalLink,
  Mail,
  Play,
  RefreshCw,
  Send,
  Settings,
  ShieldAlert,
  Trash2,
  Users,
  X,
  FileText,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import {
  scheduleAlertService,
  DEFAULT_MANAGER_ALERT_SETTINGS,
  MissedScheduleItem,
} from '../../services/scheduleAlertService';
import { ManagerAlertSettings, ScheduleAlertLog } from '../../types';

interface ScheduleAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerateOrder: (scheduleId: string) => Promise<void>;
  initialTab?: 'missed' | 'email' | 'settings' | 'logs';
}

export const ScheduleAlertModal: React.FC<ScheduleAlertModalProps> = ({
  isOpen,
  onClose,
  onGenerateOrder,
  initialTab = 'missed',
}) => {
  const { currentUser, isManager } = useAuth();
  const {
    missedSchedules,
    sendMissedScheduleAlerts,
    generateAllDueSchedulesToday,
    createNotification,
    refreshAll,
  } = useData();

  const [activeTab, setActiveTab] = useState<'missed' | 'email' | 'settings' | 'logs'>(initialTab);
  const [settings, setSettings] = useState<ManagerAlertSettings>(scheduleAlertService.getSettings());
  const [logs, setLogs] = useState<ScheduleAlertLog[]>(scheduleAlertService.getAlertLogs());
  const [isSending, setIsSending] = useState(false);
  const [isGeneratingAll, setIsGeneratingAll] = useState(false);
  const [generatingId, setGeneratingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string; link?: string } | null>(null);
  const [selectedLog, setSelectedLog] = useState<ScheduleAlertLog | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSettings(scheduleAlertService.getSettings());
      setLogs(scheduleAlertService.getAlertLogs());
      setFeedback(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const todayStr = new Date().toISOString().split('T')[0];
  const emailData = scheduleAlertService.generateEmailContent(missedSchedules, settings, todayStr);

  const handleSendAlertsNow = async () => {
    setIsSending(true);
    setFeedback(null);
    try {
      const res = await sendMissedScheduleAlerts(todayStr, settings.managerEmail);
      setLogs(scheduleAlertService.getAlertLogs());
      setFeedback({
        type: 'success',
        text: `تم بنجاح إرسال تنبيه تشغيلي وإشعار رسمي للمدير المسؤول (${res.log.managerEmail}) لـ (${res.count}) جداول متأخرة`,
        link: res.mailtoUrl,
      });
      setActiveTab('email');
    } catch (err: any) {
      setFeedback({
        type: 'error',
        text: err?.message || 'فشل إرسال التنبيه',
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleGenerateAll = async () => {
    setIsGeneratingAll(true);
    setFeedback(null);
    try {
      const generated = await generateAllDueSchedulesToday();
      setFeedback({
        type: 'success',
        text: `تم توليد (${generated.length}) طلبيات بنجاح للجداول المستحقة اليوم`,
      });
      await refreshAll();
    } catch (err: any) {
      setFeedback({
        type: 'error',
        text: err?.message || 'تعذر توليد الطلبيات دفعة واحدة',
      });
    } finally {
      setIsGeneratingAll(false);
    }
  };

  const handleGenerateSingle = async (scheduleId: string) => {
    setGeneratingId(scheduleId);
    setFeedback(null);
    try {
      await onGenerateOrder(scheduleId);
      setFeedback({
        type: 'success',
        text: 'تم توليد الطلبية بنجاح لهذا الجدول',
      });
      await refreshAll();
    } catch (err: any) {
      setFeedback({
        type: 'error',
        text: err?.message || 'فشل توليد الطلبية',
      });
    } finally {
      setGeneratingId(null);
    }
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    scheduleAlertService.saveSettings(settings);
    setFeedback({
      type: 'success',
      text: 'تم حفظ إعدادات تنبيهات البريد للمدير بنجاح',
    });
  };

  const handleSendTest = async () => {
    setIsSending(true);
    setFeedback(null);
    try {
      const res = await scheduleAlertService.sendTestAlert({
        currentUser,
        targetEmail: settings.managerEmail,
        createNotification,
      });
      setLogs(scheduleAlertService.getAlertLogs());
      setFeedback({
        type: 'success',
        text: `تم إرسال بريد وتنبيه تجريبي بنجاح إلى (${settings.managerEmail})`,
        link: res.mailtoUrl,
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        text: err?.message || 'فشل إرسال البريد التجريبي',
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleCopyEmailText = () => {
    navigator.clipboard.writeText(emailData.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClearLogs = () => {
    scheduleAlertService.clearAlertLogs();
    setLogs([]);
    setSelectedLog(null);
    setFeedback({
      type: 'success',
      text: 'تم مسح سجل تنبيهات المدير بنجاح',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-4xl p-5 sm:p-6 text-stone-100 shadow-2xl my-6 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-stone-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Mail className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-stone-100">
                  تنبيهات عدم التوليد التلقائي للجداول (Manager Alert System)
                </h2>
                <span className="text-[10px] font-mono bg-rose-500/15 text-rose-300 border border-rose-500/30 px-2 py-0.5 rounded-full font-bold">
                  {missedSchedules.length} متأخر اليوم
                </span>
              </div>
              <p className="text-xs text-stone-400">
                إرسال إشعارات وبريد إلكتروني فوري للمدير المسؤول في حال تعثر أو عدم توليد طلبيات المطبخ خلال يوم العمل
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-white bg-stone-800 hover:bg-stone-750 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center gap-2 mt-4 pb-2 border-b border-stone-800 text-xs overflow-x-auto">
          <button
            onClick={() => {
              setActiveTab('missed');
              setFeedback(null);
            }}
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-1.5 transition whitespace-nowrap ${
              activeTab === 'missed'
                ? 'bg-amber-500 text-stone-950 shadow-sm'
                : 'bg-stone-800 text-stone-300 hover:bg-stone-750'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>الجداول المتأخرة اليوم ({missedSchedules.length})</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('email');
              setFeedback(null);
            }}
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-1.5 transition whitespace-nowrap ${
              activeTab === 'email'
                ? 'bg-amber-500 text-stone-950 shadow-sm'
                : 'bg-stone-800 text-stone-300 hover:bg-stone-750'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>معاينة وإرسال البريد</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('settings');
              setFeedback(null);
            }}
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-1.5 transition whitespace-nowrap ${
              activeTab === 'settings'
                ? 'bg-amber-500 text-stone-950 shadow-sm'
                : 'bg-stone-800 text-stone-300 hover:bg-stone-750'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>إعدادات تنبيهات المدير</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('logs');
              setFeedback(null);
            }}
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-1.5 transition whitespace-nowrap ${
              activeTab === 'logs'
                ? 'bg-amber-500 text-stone-950 shadow-sm'
                : 'bg-stone-800 text-stone-300 hover:bg-stone-750'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>سجل الإرسال ({logs.length})</span>
          </button>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div
            className={`mt-3 p-3 rounded-xl border text-xs flex items-center justify-between animate-in fade-in ${
              feedback.type === 'success'
                ? 'bg-emerald-950/60 border-emerald-800 text-emerald-200'
                : 'bg-rose-950/60 border-rose-800 text-rose-200'
            }`}
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{feedback.text}</span>
            </div>
            {feedback.link && (
              <a
                href={feedback.link}
                className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-bold px-2.5 py-1 rounded-lg border border-emerald-500/40 flex items-center gap-1 ms-2"
              >
                <ExternalLink className="w-3 h-3" />
                <span>فتح في برنامج البريد</span>
              </a>
            )}
          </div>
        )}

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto mt-3 pr-1 text-xs space-y-4">
          {/* TAB 1: MISSED SCHEDULES */}
          {activeTab === 'missed' && (
            <div className="space-y-4">
              {/* Summary Card */}
              <div className="bg-stone-950 border border-stone-800 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-stone-200 text-sm">حالة جداول يوم العمل ({todayStr})</span>
                    <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded text-[11px] font-mono">
                      توقيت القاهرة GMT+2
                    </span>
                  </div>
                  <p className="text-stone-400 text-xs">
                    المدير المسؤول عن التنبيهات: <strong className="text-stone-200">{settings.managerName}</strong> (
                    <span className="text-amber-400 font-mono">{settings.managerEmail}</span>)
                  </p>
                </div>

                <div className="flex items-center gap-2 w-full md:w-auto">
                  <button
                    onClick={handleSendAlertsNow}
                    disabled={isSending || missedSchedules.length === 0}
                    className="flex-1 md:flex-initial bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-stone-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition shadow"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isSending ? 'جاري الإرسال...' : 'إرسال تنبيه للمدير الآن'}</span>
                  </button>

                  <button
                    onClick={handleGenerateAll}
                    disabled={isGeneratingAll || missedSchedules.length === 0}
                    className="flex-1 md:flex-initial bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition shadow"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>{isGeneratingAll ? 'جاري التوليد...' : 'توليد الكل الآن'}</span>
                  </button>
                </div>
              </div>

              {/* Table or Empty State */}
              {missedSchedules.length === 0 ? (
                <div className="p-10 border border-stone-800 bg-stone-950/60 rounded-2xl text-center">
                  <CheckCircle2 className="w-10 h-10 mx-auto mb-2 text-emerald-400" />
                  <h3 className="font-bold text-sm text-stone-200">جميع طلبيات الجداول المجدولة تم توليدها اليوم بنجاح!</h3>
                  <p className="text-stone-400 text-xs mt-1 max-w-md mx-auto">
                    لا يوجد أي جدول توريد دوري متعثر أو متأخر عن التوليد لتاريخ اليوم ({todayStr}).
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-stone-300">
                      الجداول التي لم تُولّد طلباتها اليوم ({missedSchedules.length}):
                    </span>
                    <span className="text-stone-500 text-[11px]">
                      انقر "توليد فوري" لإنشاء طلبية فعلية وإغلاق التنبيه
                    </span>
                  </div>

                  <div className="grid grid-cols-1 gap-2.5">
                    {missedSchedules.map((item) => (
                      <div
                        key={item.schedule.id}
                        className="bg-stone-950 border border-rose-900/40 hover:border-rose-700/60 rounded-2xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                              {item.categoryName}
                            </span>
                            <span className="font-bold text-sm text-stone-100">{item.schedule.name}</span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                              {item.delayText}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-4 text-[11px] text-stone-400 pt-0.5">
                            <span className="flex items-center gap-1 font-mono text-stone-300">
                              <Clock className="w-3 h-3 text-amber-400" />
                              وقت الطلب المعتاد: {item.scheduledTime}
                            </span>
                            <span>المورد: <strong className="text-stone-300">{item.supplierName}</strong></span>
                            <span>المسؤول: <strong className="text-stone-300">{item.assigneeName}</strong></span>
                            <span>تكرار: <strong className="text-stone-300">{item.schedule.orderingDay}</strong></span>
                          </div>
                        </div>

                        <button
                          onClick={() => handleGenerateSingle(item.schedule.id)}
                          disabled={generatingId === item.schedule.id}
                          className="w-full sm:w-auto bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 hover:text-amber-200 font-bold px-3 py-1.5 rounded-xl text-xs flex items-center justify-center gap-1.5 transition"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>{generatingId === item.schedule.id ? 'جاري التوليد...' : 'توليد فوري للطلبية'}</span>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: EMAIL PREVIEW & DISPATCH */}
          {activeTab === 'email' && (
            <div className="space-y-4">
              <div className="bg-stone-950 border border-stone-800 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-bold text-sm text-stone-200">معاينة البريد الإلكتروني الرسمي للمدير</h3>
                  <p className="text-stone-400 text-xs">
                    المرسل إليه: <span className="text-amber-400 font-mono font-bold">{settings.managerEmail}</span> ({settings.managerName})
                  </p>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={handleCopyEmailText}
                    className="flex-1 sm:flex-initial bg-stone-800 hover:bg-stone-750 text-stone-200 font-bold px-3 py-1.5 rounded-xl text-xs flex items-center justify-center gap-1.5 transition"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copied ? 'تم النسخ!' : 'نسخ نص البريد'}</span>
                  </button>

                  <a
                    href={emailData.mailtoUrl}
                    className="flex-1 sm:flex-initial bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-3.5 py-1.5 rounded-xl text-xs flex items-center justify-center gap-1.5 transition shadow"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>فتح في Gmail / العميل الخارجي</span>
                  </a>
                </div>
              </div>

              {/* Subject Bar */}
              <div className="bg-stone-950 border border-stone-800 rounded-xl p-3 text-xs space-y-1">
                <div className="text-stone-400 font-semibold">عنوان الرسالة (Subject):</div>
                <div className="text-stone-100 font-bold font-mono text-[13px] bg-stone-900 p-2 rounded-lg border border-stone-800">
                  {emailData.subject}
                </div>
              </div>

              {/* Email HTML Visual Frame */}
              <div className="border border-stone-800 rounded-2xl overflow-hidden bg-white text-stone-900 shadow-md">
                <div className="bg-stone-900 text-white px-4 py-2 border-b border-stone-800 text-[11px] flex items-center justify-between font-mono">
                  <span>من: KOMS Automated Dispatcher &lt;no-reply@kitchen.internal&gt;</span>
                  <span>إلى: {settings.managerEmail}</span>
                </div>
                <div
                  className="p-5 overflow-x-auto max-h-[380px] text-right"
                  dangerouslySetInnerHTML={{ __html: emailData.html }}
                />
              </div>
            </div>
          )}

          {/* TAB 3: MANAGER SETTINGS */}
          {activeTab === 'settings' && (
            <form onSubmit={handleSaveSettings} className="space-y-4">
              <div className="bg-stone-950 border border-stone-800 rounded-2xl p-4 space-y-4">
                <h3 className="font-bold text-sm text-stone-200 border-b border-stone-800 pb-2">
                  بيانات وقنوات تنبيه المدير المسؤول
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-stone-300 mb-1">اسم المدير المسؤول:</label>
                    <input
                      type="text"
                      value={settings.managerName}
                      onChange={(e) => setSettings({ ...settings, managerName: e.target.value })}
                      className="w-full bg-stone-900 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-300 mb-1">البريد الإلكتروني للتنبيهات:</label>
                    <input
                      type="email"
                      value={settings.managerEmail}
                      onChange={(e) => setSettings({ ...settings, managerEmail: e.target.value })}
                      placeholder="manager@kitchen.com"
                      className="w-full bg-stone-900 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono"
                      required
                    />
                    <span className="text-[10px] text-stone-500 mt-1 block">
                      سيتم توجيه جميع رسائل الإنذار بخصوص عدم التوليد لهذا البريد
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block font-semibold text-stone-300 mb-1">توقيت الفحص التلقائي الحرج:</label>
                    <input
                      type="time"
                      value={settings.checkCutoffTime}
                      onChange={(e) => setSettings({ ...settings, checkCutoffTime: e.target.value })}
                      className="w-full bg-stone-900 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono"
                      required
                    />
                    <span className="text-[10px] text-stone-500 mt-1 block">
                      الحد الأقصى في يوم العمل الذي يجب بعده إنذار المدير في حال عدم التوليد
                    </span>
                  </div>

                  <div>
                    <label className="block font-semibold text-stone-300 mb-1">آخر فحص تشغيلي:</label>
                    <div className="w-full bg-stone-900 border border-stone-800 rounded-xl p-2.5 text-stone-400 font-mono">
                      {settings.lastAuditTimestamp
                        ? new Date(settings.lastAuditTimestamp).toLocaleString('ar-EG')
                        : 'لم يتم الفحص بعد اليوم'}
                    </div>
                  </div>
                </div>

                {/* Channel Toggles */}
                <div className="space-y-2.5 pt-3 border-t border-stone-800">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.enabled}
                      onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
                      className="w-4 h-4 rounded text-amber-500"
                    />
                    <span className="font-semibold text-stone-200">
                      تفعيل نظام تنبيهات الجداول المتعثرة بالكامل
                    </span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.sendEmail}
                      onChange={(e) => setSettings({ ...settings, sendEmail: e.target.checked })}
                      className="w-4 h-4 rounded text-amber-500"
                    />
                    <span>إرسال بريد إلكتروني رسمي للمدير المسؤول (Official Email Dispatch)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.sendInApp}
                      onChange={(e) => setSettings({ ...settings, sendInApp: e.target.checked })}
                      className="w-4 h-4 rounded text-amber-500"
                    />
                    <span>إرسال إشعار فوري داخل نظام KOMS لشريط التنبيهات 🔔</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.autoCheckOnWorkday}
                      onChange={(e) => setSettings({ ...settings, autoCheckOnWorkday: e.target.checked })}
                      className="w-4 h-4 rounded text-amber-500"
                    />
                    <span>فحص تلقائي عند فتح النظام ومقارنة توقيت وردية العمل</span>
                  </label>
                </div>

                {/* Action buttons */}
                <div className="flex items-center justify-between pt-4 border-t border-stone-800">
                  <button
                    type="submit"
                    className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-5 py-2.5 rounded-xl transition"
                  >
                    حفظ التغييرات
                  </button>

                  <button
                    type="button"
                    onClick={handleSendTest}
                    disabled={isSending}
                    className="bg-stone-800 hover:bg-stone-750 text-stone-200 font-bold px-4 py-2.5 rounded-xl flex items-center gap-1.5 transition"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isSending ? 'جاري إرسال التجربة...' : 'إرسال بريد وتنبيه تجريبي للمدير'}</span>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* TAB 4: ALERT LOGS */}
          {activeTab === 'logs' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-300">سجل الإرسال التاريخي للتنبيهات البريدية:</span>
                {logs.length > 0 && (
                  <button
                    onClick={handleClearLogs}
                    className="text-stone-400 hover:text-rose-400 text-xs flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>مسح السجل</span>
                  </button>
                )}
              </div>

              {logs.length === 0 ? (
                <div className="p-8 border border-stone-800 bg-stone-950/60 rounded-2xl text-center text-stone-400">
                  لا توجد تنبيهات مرسلة حتى الآن.
                </div>
              ) : (
                <div className="space-y-2">
                  {logs.map((log) => (
                    <div
                      key={log.id}
                      className="bg-stone-950 border border-stone-800 rounded-xl p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-stone-200">{log.subject}</span>
                          <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono">
                            تم الإرسال
                          </span>
                        </div>
                        <div className="text-[11px] text-stone-400 flex flex-wrap gap-3">
                          <span>المرسل إليه: <strong className="text-amber-400 font-mono">{log.managerEmail}</strong></span>
                          <span>التاريخ: <strong className="text-stone-300">{new Date(log.timestamp).toLocaleString('ar-EG')}</strong></span>
                          <span>الجداول المشمولة: <strong className="text-stone-300">{log.missedSchedules.length}</strong></span>
                        </div>
                      </div>

                      <button
                        onClick={() => setSelectedLog(log)}
                        className="text-xs bg-stone-800 hover:bg-stone-750 text-stone-200 px-3 py-1.5 rounded-lg whitespace-nowrap"
                      >
                        عرض تفاصيل البريد
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Selected Log Detail Modal */}
        {selectedLog && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-stone-950/90">
            <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-2xl p-5 text-stone-100 shadow-2xl space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                <h4 className="font-bold text-sm text-stone-100">تفاصيل الإرسال: {selectedLog.subject}</h4>
                <button
                  onClick={() => setSelectedLog(null)}
                  className="p-1 rounded-lg text-stone-400 hover:text-white bg-stone-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="text-xs space-y-2 text-stone-300">
                <div>المرسل إليه: <strong className="text-amber-400 font-mono">{selectedLog.managerEmail}</strong></div>
                <div>وقت الإرسال: <strong className="text-stone-200">{new Date(selectedLog.timestamp).toLocaleString('ar-EG')}</strong></div>
                <div className="bg-stone-950 p-3 rounded-xl border border-stone-800 text-[11px] whitespace-pre-wrap font-mono text-stone-300 max-h-60 overflow-y-auto">
                  {selectedLog.emailContentText}
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setSelectedLog(null)}
                  className="bg-stone-800 text-stone-200 px-4 py-2 rounded-xl text-xs"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
