import React, { useState } from 'react';
import { Edit2, Phone, Plus, Search, Truck, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { Supplier } from '../../types';

export const SuppliersView: React.FC = () => {
  const { isManager } = useAuth();
  const { suppliers, saveSupplier, orderTypes, orders } = useData();

  const [searchTerm, setSearchTerm] = useState('');
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const filteredSuppliers = suppliers.filter((s) => {
    if (!searchTerm.trim()) return true;
    const q = searchTerm.toLowerCase();
    const supName = (s.nameAr || s.name || '').toLowerCase();
    const supContact = (s.contactPerson || '').toLowerCase();
    const supPhone = s.phone || '';
    return (
      supName.includes(q) ||
      supContact.includes(q) ||
      supPhone.includes(q)
    );
  });

  const handleCreateNew = () => {
    setEditingSupplier({
      id: `sup-${Date.now()}`,
      nameAr: '',
      name: '',
      category: 'خضار وفاكهة',
      contactPerson: '',
      phone: '',
      email: '',
      orderTypeIds: [orderTypes[0]?.id || 'cat-veg'],
      suppliedOrderTypeIds: [orderTypes[0]?.id || 'cat-veg'],
      deliveryDays: 'يومياً (صباحاً)',
      deliveryTimes: '06:00 ص - 09:00 ص',
      paymentTerms: 'آجل 15 يوم',
      isActive: true,
      notes: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSupplier) return;
    const finalName = editingSupplier.nameAr || editingSupplier.name || '';
    const finalTypes = editingSupplier.orderTypeIds?.length
      ? editingSupplier.orderTypeIds
      : editingSupplier.suppliedOrderTypeIds || [orderTypes[0]?.id || 'cat-veg'];
    await saveSupplier({
      ...editingSupplier,
      nameAr: finalName,
      name: finalName,
      orderTypeIds: finalTypes,
      suppliedOrderTypeIds: finalTypes,
      createdAt: editingSupplier.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    setIsModalOpen(false);
    setEditingSupplier(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-stone-100 flex items-center gap-2">
            <Truck className="w-5 h-5 text-amber-400" />
            <span>دليل موردي المطبخ (Suppliers Directory)</span>
          </h1>
          <p className="text-xs text-stone-400">
            إدارة بيانات الموردين، أيام ومواعيد التسليم، شروط السداد وسجل التوريدات السابقة
          </p>
        </div>

        {isManager && (
          <button
            onClick={handleCreateNew}
            className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>إضافة مورد جديد</span>
          </button>
        )}
      </div>

      {/* Search Bar */}
      <div className="flex items-center justify-between gap-3 bg-stone-900 border border-stone-800 p-3 rounded-2xl">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-3.5 h-3.5 text-stone-400 absolute right-3 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث باسم المورد أو رقم الهاتف..."
            className="w-full bg-stone-850 border border-stone-800 rounded-xl pr-9 pl-3 py-2 text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500"
          />
        </div>
        <span className="text-xs text-stone-400 font-mono">
          {filteredSuppliers.length} موردين معتمدين
        </span>
      </div>

      {/* Suppliers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSuppliers.length === 0 ? (
          <div className="col-span-full p-12 bg-stone-900 border border-stone-800 rounded-2xl text-center text-stone-400">
            <Truck className="w-10 h-10 mx-auto mb-2 text-stone-600" />
            <p className="font-semibold text-sm">لا يوجد موردون مسجلون حالياً</p>
            <p className="text-xs text-stone-500 mt-1">
              انقر على "إضافة مورد جديد" لإدخال بيانات جهات التوريد المعتمدة للمطبخ
            </p>
          </div>
        ) : (
          filteredSuppliers.map((sup) => {
            const supplierOrders = orders.filter((o) => o.supplierId === sup.id);

            return (
              <div
                key={sup.id}
                className="bg-stone-900 border border-stone-800 rounded-2xl p-4 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-400">{sup.category}</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        sup.isActive
                          ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800'
                          : 'bg-stone-800 text-stone-400'
                      }`}
                    >
                      {sup.isActive ? 'نشط' : 'معطل'}
                    </span>
                  </div>

                  <h3 className="font-bold text-sm text-stone-100 mt-2">{sup.name}</h3>

                  <div className="mt-3 space-y-1.5 text-xs text-stone-300">
                    <div className="flex items-center justify-between">
                      <span className="text-stone-400">المسؤول:</span>
                      <span className="font-semibold text-stone-200">{sup.contactPerson || '—'}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-stone-400">الهاتف:</span>
                      <span className="font-mono text-stone-200 dir-ltr">{sup.phone}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-stone-400">أيام التسليم:</span>
                      <span className="text-stone-300">{sup.deliveryDays}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-stone-400">مواعيد التوريد:</span>
                      <span className="text-stone-300">{sup.deliveryTimes}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-stone-400">شروط السداد:</span>
                      <span className="text-stone-300">{sup.paymentTerms}</span>
                    </div>

                    <div className="pt-2 border-t border-stone-800/80 flex items-center justify-between text-[11px]">
                      <span className="text-stone-400">سجل التوريدات:</span>
                      <span className="font-mono font-bold text-amber-400">
                        {supplierOrders.length} طلبيات منفذة
                      </span>
                    </div>
                  </div>
                </div>

                {isManager && (
                  <div className="mt-4 pt-3 border-t border-stone-800 flex justify-end">
                    <button
                      onClick={() => {
                        setEditingSupplier(sup);
                        setIsModalOpen(true);
                      }}
                      className="px-3 py-1.5 bg-stone-800 hover:bg-stone-750 text-stone-200 rounded-xl text-xs flex items-center gap-1 transition"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>تعديل البيانات</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* CREATE / EDIT MODAL */}
      {isModalOpen && editingSupplier && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-lg p-5 text-stone-100 shadow-2xl my-6">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <h3 className="font-bold text-sm text-stone-100">
                {editingSupplier.name ? `تعديل المورد: ${editingSupplier.name}` : 'إضافة مورد جديد'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-white bg-stone-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">اسم المورد / الشركة:</label>
                  <input
                    type="text"
                    value={editingSupplier.name}
                    onChange={(e) =>
                      setEditingSupplier({ ...editingSupplier, name: e.target.value })
                    }
                    placeholder="مثال: شركة النيل للحوم، مزارع الخير للخضار..."
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">تصنيف المورد:</label>
                  <input
                    type="text"
                    value={editingSupplier.category}
                    onChange={(e) =>
                      setEditingSupplier({ ...editingSupplier, category: e.target.value })
                    }
                    placeholder="خضار، لحوم، دواجن، عطارة..."
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">الشخص المسؤول:</label>
                  <input
                    type="text"
                    value={editingSupplier.contactPerson}
                    onChange={(e) =>
                      setEditingSupplier({ ...editingSupplier, contactPerson: e.target.value })
                    }
                    placeholder="اسم المندوب أو المدير المسؤول..."
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">رقم الهاتف / الواتساب:</label>
                  <input
                    type="text"
                    value={editingSupplier.phone}
                    onChange={(e) =>
                      setEditingSupplier({ ...editingSupplier, phone: e.target.value })
                    }
                    placeholder="+2010..."
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">أيام التسليم:</label>
                  <input
                    type="text"
                    value={editingSupplier.deliveryDays}
                    onChange={(e) =>
                      setEditingSupplier({ ...editingSupplier, deliveryDays: e.target.value })
                    }
                    placeholder="مثلاً: يومياً، السبت والإثنين والخميس..."
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">مواعيد التوريد:</label>
                  <input
                    type="text"
                    value={editingSupplier.deliveryTimes}
                    onChange={(e) =>
                      setEditingSupplier({ ...editingSupplier, deliveryTimes: e.target.value })
                    }
                    placeholder="07:00 ص - 10:00 ص"
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-300 mb-1">شروط السداد:</label>
                <input
                  type="text"
                  value={editingSupplier.paymentTerms}
                  onChange={(e) =>
                    setEditingSupplier({ ...editingSupplier, paymentTerms: e.target.value })
                  }
                  placeholder="نقداً عند الاستلام، آجل 15 يوم، أسبوعي..."
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-300 mb-1">ملاحظات وعنوان المورد:</label>
                <textarea
                  value={editingSupplier.notes || ''}
                  onChange={(e) =>
                    setEditingSupplier({ ...editingSupplier, notes: e.target.value })
                  }
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 h-16 resize-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-stone-800">
                <input
                  type="checkbox"
                  id="supActive"
                  checked={editingSupplier.isActive}
                  onChange={(e) =>
                    setEditingSupplier({ ...editingSupplier, isActive: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-amber-500"
                />
                <label htmlFor="supActive" className="text-stone-300 cursor-pointer">
                  المورد نشط ومتاح للاختيار في الطلبيات
                </label>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-stone-800">
                <button
                  type="submit"
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold py-2.5 rounded-xl transition"
                >
                  حفظ المورد
                </button>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="bg-stone-800 text-stone-300 py-2.5 px-4 rounded-xl"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
