import React, { useState } from 'react';
import { Archive, Clock, Eye, Search } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { WORKFLOW_STATUS_CONFIG, formatDateOnly, formatDateTime } from '../../utils/statusLabels';
import { ActualOrder } from '../../types';

interface ArchiveViewProps {
  onSelectOrder: (order: ActualOrder) => void;
}

export const ArchiveView: React.FC<ArchiveViewProps> = ({ onSelectOrder }) => {
  const { orders, orderTypes } = useData();
  const [searchTerm, setSearchTerm] = useState('');

  // Archived or completed orders
  const archivedOrders = orders.filter((o) => o.isArchived || o.status === 'COMPLETED');

  const filtered = archivedOrders.filter((o) => {
    if (!searchTerm.trim()) return true;
    const q = searchTerm.toLowerCase();
    return o.id.toLowerCase().includes(q) || (o.notes || '').toLowerCase().includes(q);
  });

  const getCategoryName = (id: string) => {
    return orderTypes.find((c) => c.id === id)?.nameAr || id;
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-stone-100 flex items-center gap-2">
            <Archive className="w-5 h-5 text-amber-400" />
            <span>الأرشيف التاريخي للطلبيات المكتملة</span>
          </h1>
          <p className="text-xs text-stone-400">
            سجل دائم لا يحذف يحفظ كافة بيانات ومحاضر وفواتير الطلبيات المكتملة للرجوع إليها والتدقيق
          </p>
        </div>
      </div>

      {/* Search and Table */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm space-y-4">
        <div className="relative max-w-sm">
          <Search className="w-3.5 h-3.5 text-stone-400 absolute right-3 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث برقم الطلبية المؤرشفة أو الملاحظات..."
            className="w-full bg-stone-850 border border-stone-800 rounded-xl pr-9 pl-3 py-2 text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="border border-stone-800 rounded-xl overflow-hidden">
          <table className="w-full text-right text-xs text-stone-300">
            <thead className="bg-stone-850 text-stone-400 text-[11px] uppercase">
              <tr>
                <th className="p-3">رقم الطلبية</th>
                <th className="p-3">تاريخ الطلب</th>
                <th className="p-3">فئة التوريد</th>
                <th className="p-3">عدد الأصناف</th>
                <th className="p-3">الحالة النهائية</th>
                <th className="p-3">تاريخ الإغلاق / التحديث</th>
                <th className="p-3 text-center">عرض السجل</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-800/80">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-10 text-center text-stone-500">
                    لا توجد طلبيات مؤرشفة بعد. الطلبيات المكتملة ستظهر تلقائياً هنا في الأرشيف الدائم.
                  </td>
                </tr>
              ) : (
                filtered.map((ord) => {
                  const statusMeta = WORKFLOW_STATUS_CONFIG[ord.status];
                  return (
                    <tr
                      key={ord.id}
                      onClick={() => onSelectOrder(ord)}
                      className="hover:bg-stone-850/60 transition cursor-pointer"
                    >
                      <td className="p-3 font-mono font-bold text-amber-400">{ord.id}</td>
                      <td className="p-3 font-mono text-stone-300">{formatDateOnly(ord.orderDate)}</td>
                      <td className="p-3 font-semibold text-stone-200">
                        {getCategoryName(ord.orderTypeId)}
                      </td>
                      <td className="p-3">{ord.items.length} أصناف</td>
                      <td className="p-3">
                        <span
                          className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${statusMeta.bgClass} ${statusMeta.textClass}`}
                        >
                          {statusMeta.labelAr}
                        </span>
                      </td>
                      <td className="p-3 font-mono text-stone-400 text-[11px]">
                        {formatDateTime(ord.updatedAt)}
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectOrder(ord);
                          }}
                          className="px-2.5 py-1 bg-stone-800 hover:bg-stone-750 text-stone-200 rounded-lg text-xs transition"
                        >
                          عرض التفاصيل
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
