import React, { useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  Calendar,
  CheckCircle2,
  Clock,
  Layers,
  Mail,
  Package,
  Plus,
  RefreshCw,
  Send,
  ShieldAlert,
  TrendingUp,
  Truck,
  Users,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { WORKFLOW_STATUS_CONFIG, formatDateTime } from '../../utils/statusLabels';
import { ActualOrder } from '../../types';

export interface DashboardViewProps {
  isLoading?: boolean;
  error?: string | null;
  onOpenNewOrder?: (categoryId?: string) => void;
  onSelectOrder?: (order: ActualOrder) => void;
  onNavigateTab?: (tab: any) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  isLoading = false,
  error = null,
  onOpenNewOrder = () => {},
  onSelectOrder = () => {},
  onNavigateTab = () => {},
}) => {
  const { isManager, currentUser } = useAuth();
  const {
    orders,
    orderTypes,
    schedules,
    getMetrics,
    missedSchedules,
    sendMissedScheduleAlerts,
    refreshAll,
  } = useData();

  const [sendingAlert, setSendingAlert] = useState(false);
  const [alertSuccess, setAlertSuccess] = useState<string | null>(null);
  const [alertError, setAlertError] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-12">
        <p className="text-slate-500 font-medium">جاري مزامنة مؤشرات المطبخ...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-sm">
        <span className="font-bold">خطأ في استرجاع البيانات:</span> {error}
      </div>
    );
  }

  const metrics = getMetrics();
  const activeOrders = orders.filter((o) => !o.isArchived);
  const now = new Date();

  // Filter today's operations
  const todayStr = now.toISOString().split('T')[0];
  const ordersDueToday = activeOrders.filter((o) => o.orderDate === todayStr);

  const overdueList = activeOrders.filter((o) => {
    if (['COMPLETED', 'VERIFIED', 'CANCELLED'].includes(o.status)) return false;
    return new Date(o.orderingDeadline).getTime() < now.getTime();
  });

  const awaitingDeliveryList = activeOrders.filter((o) => o.status === 'AWAITING_DELIVERY');
  const receivingList = activeOrders.filter((o) =>
    ['RECEIVING', 'PARTIALLY_RECEIVED'].includes(o.status)
  );
  const invoicePendingList = activeOrders.filter((o) => o.status === 'INVOICE_PENDING');

  // طلبات الخضار المتأخرة لأكثر من 24 ساعة عن موعد الوصول الثابت (الساعة 1:00 ظهراً)
  const veg24hDelayedList = activeOrders.filter((ord) => {
    const isVeg = ord.orderTypeId === 'cat-veg' || (ord.orderNumber && ord.orderNumber.includes('VEG'));
    if (!isVeg) return false;
    if (['INVOICE_PENDING', 'VERIFIED', 'COMPLETED', 'CANCELLED'].includes(ord.status)) return false;
    const baseDate = ord.orderDate || ord.orderingDeadline?.split('T')[0];
    const fixedArrivalMs = new Date(`${baseDate}T13:00:00`).getTime();
    return (now.getTime() - fixedArrivalMs) / (1000 * 3600) >= 24;
  });

  // طلبات الورديات المتأخرة عن مهلة الطلب التي تتطلب طلب آني فوراً
  const shiftOverdueList = activeOrders.filter((ord) => {
    if (!['PLANNED', 'DUE', 'ORDERING'].includes(ord.status)) return false;
    return new Date(ord.orderingDeadline).getTime() < now.getTime();
  });

  // Explicit empty state if no active orders exist yet
  if (activeOrders.length === 0) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900">نظرة عامة على التشغيل</h2>
          <span className="text-xs text-slate-400">توقيت القاهرة (GMT+2)</span>
        </div>

        {/* الحالة الفارغة الصريحة */}
        <div className="border-2 border-dashed border-slate-200 rounded-xl p-8 text-center bg-white shadow-sm">
          <h3 className="font-semibold text-slate-700 mb-1">لا توجد طلبات جارية اليوم</h3>
          <p className="text-slate-500 text-sm max-w-sm mx-auto mb-4">
            لم يتم إنشاء جدول توريد أو توليد أوامر شراء بعد. يمكنك بدء تعريف الأصناف والموردين في المرحلة التالية.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
            <span className="inline-block text-xs bg-slate-100 text-slate-600 px-3 py-1 rounded-full font-mono">
              بانتظار تهيئة كتالوج المرحلة 2
            </span>
            <button
              onClick={() => onOpenNewOrder()}
              className="text-xs bg-slate-900 hover:bg-slate-800 text-white font-semibold px-4 py-1.5 rounded-full transition"
            >
              + إنشاء طلبية جديدة
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Overview Top Header with GMT info */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-200">
        <h2 className="text-lg font-bold text-slate-900">نظرة عامة على التشغيل والمشتريات</h2>
        <span className="text-xs text-slate-400 font-mono">توقيت القاهرة (GMT+2)</span>
      </div>

      {/* 24-Hour Vegetable Delay Critical Alarm Banner */}
      {veg24hDelayedList.length > 0 && (
        <div className="p-4 rounded-2xl bg-rose-950/90 border-2 border-rose-500 shadow-xl shadow-rose-950/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-stone-100 animate-pulse">
          <div className="flex items-center gap-3">
            <span className="p-2 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40 shrink-0">
              <AlertCircle className="w-6 h-6" />
            </span>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base text-rose-200">
                🚨 إنذار حرج: تأخرت طلبية الخضار لأكثر من 24 ساعة عن موعد الوصول الثابت!
              </h3>
              <p className="text-xs text-rose-300 mt-0.5">
                تجاوزت ({veg24hDelayedList.length}) طلبية خضار مهلة 24 ساعة عن موعد التوريد الثابت (الساعة 01:00 ظهراً) دون استلام. يرجى التواصل الفوري مع المورد لضمان استمرارية تشغيل المطبخ.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('orders')}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shrink-0 transition"
          >
            متابعة الطلبية المتأخرة
          </button>
        </div>
      )}

      {/* Shift Deadline Alert Banner */}
      {shiftOverdueList.length > 0 && (
        <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-stone-100">
          <div className="flex items-center gap-2.5">
            <span className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
              <Clock className="w-4 h-4" />
            </span>
            <div>
              <span className="font-bold text-xs text-amber-300 block">
                ⚠️ تنبيه لمسؤول الوردية ومدير المطبخ: حان موعد الطلب الفعلي
              </span>
              <span className="text-[11px] text-stone-300">
                يوجد ({shiftOverdueList.length}) طلبية تجاوزت مهلة التوريد المقررة للوردية — يجب الطلب الآني فوراً.
              </span>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('orders')}
            className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold shrink-0 transition"
          >
            عرض الطلبيات
          </button>
        </div>
      )}

      {/* Welcome Banner & Quick Action */}
      <div className="bg-gradient-to-l from-stone-900 via-stone-850 to-stone-900 border border-stone-800 rounded-2xl p-5 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-stone-100">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl md:text-2xl font-bold">
              مرحباً، {currentUser.name}
            </h1>
            <span className="text-xs bg-amber-500/20 text-amber-400 font-semibold px-2 py-0.5 rounded-full border border-amber-500/30">
              {isManager ? 'إدارة المطبخ والمشتريات' : 'فريق التشغيل'}
            </span>
          </div>
          <p className="text-stone-400 text-xs md:text-sm mt-1">
            اليوم {new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} — متابعة دورة التوريد والفحص
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Quick Vegetable Order Button */}
          <button
            onClick={() => (onNavigateTab ? onNavigateTab('veg-order') : onOpenNewOrder('cat-veg'))}
            className="flex-1 md:flex-initial flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white px-4 py-2.5 rounded-xl font-bold text-xs shadow-md shadow-emerald-950/40 transition"
            title="طلب طلبية الخضار اليومية وتحويلها مباشرة عبر الواتساب للمورد"
          >
            <span className="text-sm">🥬</span>
            <span>طلب طلبية الخضار (واتساب)</span>
          </button>

          <button
            onClick={() => onOpenNewOrder()}
            className="flex-1 md:flex-initial flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-stone-950 px-4 py-2.5 rounded-xl font-bold text-xs shadow-md transition"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>إنشاء طلبية أخرى</span>
          </button>
          {isManager && (
            <button
              onClick={() => onNavigateTab('schedules')}
              className="flex-1 md:flex-initial flex items-center justify-center gap-2 bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 px-3.5 py-2.5 rounded-xl font-semibold text-xs transition"
            >
              <Calendar className="w-4 h-4 text-amber-400" />
              <span>الجداول الدورية</span>
            </button>
          )}
        </div>
      </div>

      {/* Missed Schedules Alert Widget for Manager */}
      {missedSchedules.length > 0 && (
        <div className="bg-gradient-to-r from-rose-950 via-stone-900 to-rose-950 border border-rose-800/80 rounded-2xl p-4 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-rose-600/30 text-rose-300 border border-rose-500/40 shrink-0">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-rose-200">
                  تنبيه تشغيلي عاجل: ({missedSchedules.length}) جداول توريد لم تُولّد طلباتها اليوم!
                </span>
                <span className="bg-rose-500/20 text-rose-300 text-[10px] px-2 py-0.5 rounded-full border border-rose-500/30 font-bold animate-pulse">
                  خطر نقص التوريد
                </span>
              </div>
              <p className="text-xs text-stone-300 mt-1">
                الجداول المتأخرة: <strong className="text-amber-300">{missedSchedules.map((i) => i.schedule.name).join('، ')}</strong>. يرجى إشعار المدير المسؤول أو توليدها لتجنب تأخر الإمدادات للمطبخ.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto">
            <button
              onClick={async () => {
                setSendingAlert(true);
                setAlertSuccess(null);
                setAlertError(null);
                try {
                  const res = await sendMissedScheduleAlerts();
                  setAlertSuccess(`تم إرسال تنبيه رسمي وبريد إلكتروني للمدير (${res.log.managerEmail})`);
                } catch (err: any) {
                  setAlertError(err?.message || 'فشل إرسال التنبيه للمدير المسؤول');
                } finally {
                  setSendingAlert(false);
                }
              }}
              disabled={sendingAlert}
              className="flex-1 md:flex-initial bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition shadow"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{sendingAlert ? 'جاري الإرسال...' : 'إرسال تنبيه للمدير'}</span>
            </button>
            <button
              onClick={() => onNavigateTab('schedules')}
              className="flex-1 md:flex-initial bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 font-semibold px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition"
            >
              <span>مراجعة الجداول</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {alertSuccess && (
        <div className="p-3 bg-emerald-950/70 border border-emerald-800 text-emerald-200 rounded-xl text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{alertSuccess}</span>
          </div>
          <button onClick={() => setAlertSuccess(null)} className="text-stone-400 hover:text-white">✕</button>
        </div>
      )}

      {alertError && (
        <div className="p-3 bg-rose-950/70 border border-rose-800 text-rose-200 rounded-xl text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{alertError}</span>
          </div>
          <button onClick={() => setAlertError(null)} className="text-stone-400 hover:text-white">✕</button>
        </div>
      )}

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">إجمالي الطلبيات النشطة</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-black text-slate-900 font-mono">
              {metrics.totalOrders}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
              <span>قيد المعالجة:</span>
              <span className="font-bold text-amber-600">{metrics.inProgressOrders}</span>
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">نسبة الالتزام بالمواعيد</span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-black text-emerald-600 font-mono">
              %{metrics.onTimeRate}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
              <span>مكتملة بنجاح:</span>
              <span className="font-bold text-emerald-600">{metrics.completedOrders}</span>
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">طلبيات متأخرة</span>
            <div className="p-2 rounded-xl bg-rose-50 text-rose-600">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className={`text-2xl font-black font-mono ${metrics.overdueOrders > 0 ? 'text-rose-600' : 'text-slate-800'}`}>
              {metrics.overdueOrders}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {metrics.overdueOrders > 0 ? 'تجاوزت مهلة الطلب المحددة' : 'لا توجد تأخيرات حالياً'}
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">بنود مرفوضة / تالفة</span>
            <div className="p-2 rounded-xl bg-red-50 text-red-600">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className={`text-2xl font-black font-mono ${metrics.rejectedOrders > 0 ? 'text-red-600' : 'text-slate-800'}`}>
              {metrics.rejectedOrders}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              بانتظار التعويض أو الخصم
            </div>
          </div>
        </div>
      </div>

      {/* Critical Operational Stages */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Stage 1: Awaiting Delivery */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-purple-600" />
              <h3 className="font-bold text-sm text-slate-800">بانتظار وصول الشحنة</h3>
            </div>
            <span className="text-xs font-mono bg-purple-50 text-purple-700 px-2 py-0.5 rounded-full font-bold">
              {awaitingDeliveryList.length}
            </span>
          </div>

          <div className="mt-3 space-y-2 flex-1 overflow-y-auto max-h-60">
            {awaitingDeliveryList.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-6">لا توجد شحنات في الطريق حالياً</p>
            ) : (
              awaitingDeliveryList.map((ord) => (
                <div
                  key={ord.id}
                  onClick={() => onSelectOrder(ord)}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 cursor-pointer transition text-xs flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-slate-900 font-mono">{ord.id}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      توقع الوصول: {formatDateTime(ord.expectedDeliveryTime)}
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400" />
                </div>
              ))
            )}
          </div>
        </div>

        {/* Stage 2: Quality Inspection / Receiving */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-600" />
              <h3 className="font-bold text-sm text-slate-800">الاستلام وفحص الجودة</h3>
            </div>
            <span className="text-xs font-mono bg-cyan-50 text-cyan-700 px-2 py-0.5 rounded-full font-bold">
              {receivingList.length}
            </span>
          </div>

          <div className="mt-3 space-y-2 flex-1 overflow-y-auto max-h-60">
            {receivingList.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-6">لا توجد طلبيات تحت الفحص حالياً</p>
            ) : (
              receivingList.map((ord) => (
                <div
                  key={ord.id}
                  onClick={() => onSelectOrder(ord)}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-cyan-100 cursor-pointer transition text-xs flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-cyan-800 font-mono">{ord.id}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      {ord.items.length} أصناف تحت الفحص
                    </div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigateTab('receiving');
                    }}
                    className="text-[10px] bg-cyan-100 hover:bg-cyan-200 text-cyan-800 px-2 py-1 rounded-lg font-semibold"
                  >
                    فحص الآن
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Stage 3: Invoice Matching */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-amber-600" />
              <h3 className="font-bold text-sm text-slate-800">بانتظار مطابقة الفاتورة</h3>
            </div>
            <span className="text-xs font-mono bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full font-bold">
              {invoicePendingList.length}
            </span>
          </div>

          <div className="mt-3 space-y-2 flex-1 overflow-y-auto max-h-60">
            {invoicePendingList.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-6">تمت مطابقة جميع الفواتير</p>
            ) : (
              invoicePendingList.map((ord) => (
                <div
                  key={ord.id}
                  onClick={() => onSelectOrder(ord)}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-amber-100 cursor-pointer transition text-xs flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-amber-800 font-mono">{ord.id}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      استلمت الشحنة - بانتظار الفاتورة
                    </div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigateTab('invoices');
                    }}
                    className="text-[10px] bg-amber-100 hover:bg-amber-200 text-amber-800 px-2 py-1 rounded-lg font-semibold"
                  >
                    مطابقة
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Overdue Alerts Section if any */}
      {overdueList.length > 0 && (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 text-rose-800">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-5 h-5 text-rose-600" />
            <h3 className="font-bold text-sm">
              تنبيه حرج: توجد {overdueList.length} طلبيات تجاوزت المهلة المحددة
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {overdueList.map((ord) => {
              const meta = WORKFLOW_STATUS_CONFIG[ord.status];
              return (
                <div
                  key={ord.id}
                  onClick={() => onSelectOrder(ord)}
                  className="p-3 bg-white rounded-xl border border-rose-200 cursor-pointer hover:border-rose-400 transition flex items-center justify-between text-xs shadow-sm"
                >
                  <div>
                    <div className="font-bold text-slate-900 font-mono">{ord.id}</div>
                    <div className="text-[11px] text-rose-600 mt-0.5">
                      المهلة: {formatDateTime(ord.orderingDeadline)}
                    </div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${meta.bgClass} ${meta.textClass}`}>
                    {meta.labelAr}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Categories Snapshot */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-sm text-slate-900">فئات التوريد الـ 10 المعتمدة</h3>
            <p className="text-[11px] text-slate-500">
              الخضار (24 صنف جاهزة للتهيئة)، اللحوم، العيش الفلاحي، البريوش، الدواجن، التغليف، العطارة، المنظفات، الزيوت، البقالة
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('categories')}
            className="text-xs text-amber-600 hover:text-amber-700 font-semibold"
          >
            إدارة الفئات والأصناف ←
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5 mt-3">
          {orderTypes.map((cat) => {
            const catOrders = orders.filter((o) => o.orderTypeId === cat.id && !o.isArchived);
            return (
              <div
                key={cat.id}
                onClick={() => onNavigateTab('categories')}
                className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl cursor-pointer transition text-center"
              >
                <div className="font-bold text-xs text-slate-800">{cat.nameAr}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">{cat.nameEn}</div>
                <div className="mt-2 text-[11px] font-mono font-bold text-amber-600">
                  {catOrders.length} طلبيات
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
