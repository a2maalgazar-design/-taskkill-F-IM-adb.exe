import React, { useState } from 'react';
import {
  AlertCircle,
  Check,
  Edit2,
  Layers,
  Package,
  Plus,
  ShieldCheck,
  Trash2,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { OrderType, Product, SYSTEM_ORDER_TYPES, OrderTypeCode } from '../../types';
import { CatalogManager } from './CatalogManager';

export const CategoriesProductsView: React.FC = () => {
  const { isManager, users } = useAuth();
  const { orderTypes, products, saveCategory, saveProduct, deleteProduct, suppliers } = useData();

  const [viewMode, setViewMode] = useState<'detailed' | 'catalog'>('detailed');
  const [selectedCatId, setSelectedCatId] = useState<string>(orderTypes[0]?.id || 'cat-veg');
  const [productFilter, setProductFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [editingCategory, setEditingCategory] = useState<OrderType | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isNewCategoryModal, setIsNewCategoryModal] = useState(false);
  const [isNewProductModal, setIsNewProductModal] = useState(false);

  const selectedCategory = orderTypes.find((c) => c.id === selectedCatId) || orderTypes[0];
  const rawCategoryProducts = products.filter((p) => p.orderTypeId === selectedCategory?.id);
  const categoryProducts = rawCategoryProducts.filter((p) => {
    if (productFilter === 'active') return p.isActive;
    if (productFilter === 'inactive') return !p.isActive;
    return true;
  });

  const handleToggleCategoryActive = async (cat: OrderType) => {
    if (!isManager) return;
    await saveCategory({ ...cat, isActive: !cat.isActive });
  };

  const handleToggleProductActive = async (p: Product) => {
    if (!isManager) return;
    await saveProduct({
      ...p,
      isActive: !p.isActive,
      updatedAt: new Date().toISOString(),
    });
  };

  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory) return;
    await saveCategory({
      ...editingCategory,
      createdAt: editingCategory.createdAt || new Date().toISOString(),
    });
    setEditingCategory(null);
    setIsNewCategoryModal(false);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    const finalName = editingProduct.nameAr || editingProduct.name || '';
    const finalUnit = editingProduct.defaultUnit || editingProduct.unit || 'كجم';
    await saveProduct({
      ...editingProduct,
      nameAr: finalName,
      name: finalName,
      defaultUnit: finalUnit,
      unit: finalUnit,
      specifications: editingProduct.specifications || editingProduct.notes || '',
      isTBD: false, // Once saved with manager data, it's no longer TBD
      isActive: editingProduct.isActive !== undefined ? editingProduct.isActive : true,
      createdAt: editingProduct.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    setEditingProduct(null);
    setIsNewProductModal(false);
  };


  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-stone-100">
            فئات الطلبيات ودليل الأصناف
          </h1>
          <p className="text-xs text-stone-400">
            إدارة الفئات الـ 10 المعتمدة، وضبط أصناف الخضار الـ 24 المخصصة بانتظار إدخال المسميات
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* View mode toggle */}
          <div className="flex bg-stone-950 p-1 rounded-xl border border-stone-800 text-xs">
            <button
              onClick={() => setViewMode('detailed')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                viewMode === 'detailed'
                  ? 'bg-amber-500 text-stone-950 font-bold'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              عرض الفئات التفصيلي
            </button>
            <button
              onClick={() => setViewMode('catalog')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                viewMode === 'catalog'
                  ? 'bg-amber-500 text-stone-950 font-bold'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              الكتالوج الموحد (Firestore)
            </button>
          </div>

          {isManager && viewMode === 'detailed' && (
            <button
              onClick={() => {
                setEditingCategory({
                  id: `cat-${Date.now()}`,
                  code: 'CUSTOM' as any,
                  nameAr: '',
                  nameEn: '',
                  description: '',
                  defaultLeadTimeHours: 24,
                  requiresTemperatureCheck: false,
                  requiresExpiryCheck: false,
                  requiresApproval: false,
                  isActive: true,
                  createdAt: new Date().toISOString(),
                });
                setIsNewCategoryModal(true);
              }}
              className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 transition"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>إضافة فئة توريد جديدة</span>
            </button>
          )}
        </div>
      </div>

      {viewMode === 'catalog' ? (
        <CatalogManager />
      ) : (
        <>
          {/* Main Grid: Categories Selector on Left, Products Table on Right */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Categories Tabs (4 cols) */}
        <div className="lg:col-span-4 space-y-2">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-3">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-stone-800">
              <span className="font-bold text-xs text-stone-200">فئات التوريد الـ 10</span>
              <span className="text-[11px] text-stone-400 font-mono">
                {orderTypes.length} فئات
              </span>
            </div>

            <div className="space-y-1.5 max-h-[75vh] overflow-y-auto">
              {orderTypes.map((cat) => {
                const isSelected = cat.id === selectedCategory?.id;
                const count = products.filter((p) => p.orderTypeId === cat.id).length;

                return (
                  <div
                    key={cat.id}
                    onClick={() => setSelectedCatId(cat.id)}
                    className={`p-3 rounded-xl border transition cursor-pointer text-xs flex items-center justify-between ${
                      isSelected
                        ? 'bg-amber-500/15 border-amber-500/40 text-amber-300'
                        : 'bg-stone-850 hover:bg-stone-800 border-stone-800 text-stone-300'
                    } ${!cat.isActive ? 'opacity-50' : ''}`}
                  >
                    <div>
                      <div className="flex items-center gap-1.5 font-bold">
                        <span>{cat.nameAr}</span>
                        <span className="text-[10px] text-stone-400 font-normal">
                          ({cat.nameEn})
                        </span>
                        {!cat.isActive && (
                          <span className="text-[9px] bg-red-950/80 text-red-400 px-1.5 py-0.2 rounded border border-red-800">
                            معطلة
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-stone-400 mt-0.5 truncate max-w-[200px]">
                        {cat.description}
                      </div>
                      <div className="text-[10px] text-stone-500 mt-1 flex items-center gap-2">
                        <span>المهلة: {cat.defaultLeadTimeHours} ساعة</span>
                        {cat.requiresTemperatureCheck && <span>• فحص حرارة</span>}
                      </div>
                    </div>

                    <div className="text-left flex flex-col items-end gap-1">
                      <span className="font-mono text-[11px] bg-stone-800 px-2 py-0.5 rounded-full text-stone-300 font-semibold">
                        {count} أصناف
                      </span>
                      {isManager && (
                        <div className="flex items-center gap-1.5 mt-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditingCategory(cat);
                            }}
                            className="text-[10px] text-stone-400 hover:text-amber-400 font-semibold"
                          >
                            تعديل
                          </button>
                          <span className="text-stone-700">•</span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleCategoryActive(cat);
                            }}
                            title={cat.isActive ? 'تعطيل الفئة (Soft-delete)' : 'إعادة تفعيل الفئة'}
                            className={`text-[10px] font-semibold transition ${
                              cat.isActive
                                ? 'text-stone-400 hover:text-rose-400'
                                : 'text-emerald-400 hover:text-emerald-300'
                            }`}
                          >
                            {cat.isActive ? 'تعطيل' : 'تفعيل'}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Selected Category Details and its Products (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {selectedCategory && (
            <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-stone-800 gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-stone-100">
                      أصناف فئة: {selectedCategory.nameAr} ({selectedCategory.nameEn})
                    </h2>
                    {selectedCategory.id === 'cat-veg' && (
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold border border-emerald-500/30">
                        24 صنف خضار مجهزة
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-stone-400 mt-0.5">
                    {selectedCategory.description}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {isManager && (
                    <button
                      onClick={() => {
                        setEditingProduct({
                          id: `prod-${Date.now()}`,
                          orderTypeId: selectedCategory.id,
                          nameAr: '',
                          name: '',
                          defaultUnit: 'كجم',
                          unit: 'كجم',
                          isActive: true,
                          isTBD: false,
                          createdAt: new Date().toISOString(),
                          updatedAt: new Date().toISOString(),
                        });
                        setIsNewProductModal(true);
                      }}
                      className="bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition"
                    >
                      <Plus className="w-3.5 h-3.5 text-amber-400" />
                      <span>إضافة صنف لهذه الفئة</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Notice for Vegetables items */}
              {selectedCategory.id === 'cat-veg' && (
                <div className="mt-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-200 text-xs flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    تم اعتماد وتثبيت قائمة أصناف الخضار الـ 24 المحددة للمطبخ بنجاح (باذنجان، بصل، بطاطس، طماطم، ورقيات، فلفل، كرنب، ليمون، ثوم، كوسة...). يمكنك تعديل أي صنف أو ضبط مورده المفضل.
                  </span>
                </div>
              )}

              {/* Product Filtering Bar */}
              <div className="flex items-center justify-between gap-2 mt-4">
                <div className="flex items-center gap-1.5 text-xs">
                  <button
                    onClick={() => setProductFilter('all')}
                    className={`px-2.5 py-1 rounded-lg font-medium transition ${
                      productFilter === 'all'
                        ? 'bg-amber-500 text-stone-950 font-bold'
                        : 'bg-stone-850 text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    كافة الأصناف ({rawCategoryProducts.length})
                  </button>
                  <button
                    onClick={() => setProductFilter('active')}
                    className={`px-2.5 py-1 rounded-lg font-medium transition ${
                      productFilter === 'active'
                        ? 'bg-emerald-500 text-stone-950 font-bold'
                        : 'bg-stone-850 text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    النشطة ({rawCategoryProducts.filter(p => p.isActive).length})
                  </button>
                  <button
                    onClick={() => setProductFilter('inactive')}
                    className={`px-2.5 py-1 rounded-lg font-medium transition ${
                      productFilter === 'inactive'
                        ? 'bg-rose-500 text-stone-950 font-bold'
                        : 'bg-stone-850 text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    المعطلة (Soft-Deleted: {rawCategoryProducts.filter(p => !p.isActive).length})
                  </button>
                </div>
              </div>

              {/* Products Table */}
              <div className="mt-3 border border-stone-800 rounded-xl overflow-hidden">
                <div className="overflow-x-auto max-h-[60vh]">
                  <table className="w-full text-right text-xs text-stone-300">
                    <thead className="bg-stone-850 text-stone-400 text-[11px] uppercase">
                      <tr>
                        <th className="p-3">#</th>
                        <th className="p-3">اسم الصنف</th>
                        <th className="p-3">الوحدة</th>
                        <th className="p-3">المواصفات الفنية والجودة</th>
                        <th className="p-3">المورد المفضل</th>
                        <th className="p-3">الحالة</th>
                        <th className="p-3 text-center">إجراءات المدير</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-800/80">
                      {categoryProducts.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="p-8 text-center text-stone-500">
                            لا توجد أصناف مطابقة للتصفية في هذه الفئة.
                          </td>
                        </tr>
                      ) : (
                        categoryProducts.map((p, idx) => {
                          const preferredSup = suppliers.find((s) => s.id === p.defaultSupplierId);
                          return (
                            <tr key={p.id} className={`hover:bg-stone-850/60 transition ${!p.isActive ? 'opacity-60 bg-stone-950/30' : ''}`}>
                              <td className="p-3 text-stone-500 font-mono">{idx + 1}</td>
                              <td className="p-3 font-semibold text-stone-100">
                                <div className="flex items-center gap-2">
                                  <span>{p.nameAr || p.name}</span>
                                  {p.isTBD && (
                                    <span className="text-[10px] bg-stone-800 text-amber-400 px-1.5 py-0.5 rounded font-mono">
                                      TBD
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="p-3 font-mono text-stone-300">{p.defaultUnit || p.unit}</td>
                              <td className="p-3 text-stone-400 text-[11px] max-w-[180px] truncate">
                                {p.specifications || p.notes || '—'}
                              </td>
                              <td className="p-3 text-stone-300 text-[11px]">
                                {preferredSup ? (
                                  <span className="text-amber-400/90 font-medium">{preferredSup.name}</span>
                                ) : (
                                  <span className="text-stone-500">غير محدد</span>
                                )}
                              </td>
                              <td className="p-3">
                                {p.isActive ? (
                                  <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-800">
                                    نشط
                                  </span>
                                ) : (
                                  <span className="text-[10px] text-rose-300 bg-rose-950/60 px-2 py-0.5 rounded-full border border-rose-900">
                                    معطل (Soft-Deleted)
                                  </span>
                                )}
                              </td>
                              <td className="p-3 text-center">
                                {isManager && (
                                  <div className="flex items-center justify-center gap-1.5">
                                    <button
                                      onClick={() => setEditingProduct(p)}
                                      className="px-2 py-1 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 rounded text-xs transition font-semibold"
                                    >
                                      {p.isTBD ? 'تسمية' : 'تعديل'}
                                    </button>
                                    <button
                                      onClick={() => handleToggleProductActive(p)}
                                      title={p.isActive ? 'تعطيل الصنف لحفظ التاريخ' : 'إعادة تفعيل الصنف'}
                                      className={`px-2 py-1 rounded text-xs transition font-semibold border ${
                                        p.isActive
                                          ? 'bg-rose-950/40 text-rose-300 border-rose-900/40 hover:bg-rose-900/40'
                                          : 'bg-emerald-950/40 text-emerald-300 border-emerald-900/40 hover:bg-emerald-900/40'
                                      }`}
                                    >
                                      {p.isActive ? 'تعطيل' : 'تفعيل'}
                                    </button>
                                    <button
                                      onClick={() => deleteProduct(p.id)}
                                      className="p-1 text-stone-500 hover:text-rose-400 transition"
                                      title="حذف نهائي"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                )}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* EDIT / CREATE CATEGORY MODAL */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-lg p-5 text-stone-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <h3 className="font-bold text-sm text-stone-100">
                {isNewCategoryModal ? 'إضافة فئة توريد جديدة' : `تعديل فئة: ${editingCategory.nameAr}`}
              </h3>
              <button
                onClick={() => setEditingCategory(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-white bg-stone-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCategory} className="mt-4 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">الاسم بالعربية:</label>
                  <input
                    type="text"
                    value={editingCategory.nameAr}
                    onChange={(e) => setEditingCategory({ ...editingCategory, nameAr: e.target.value })}
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">الاسم بالإنجليزية:</label>
                  <input
                    type="text"
                    value={editingCategory.nameEn}
                    onChange={(e) => setEditingCategory({ ...editingCategory, nameEn: e.target.value })}
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-300 mb-1">الوصف:</label>
                <textarea
                  value={editingCategory.description}
                  onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 h-16 resize-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-300 mb-1">
                  المهلة الافتراضية للتوريد (بالساعات):
                </label>
                <input
                  type="number"
                  value={editingCategory.defaultLeadTimeHours}
                  onChange={(e) =>
                    setEditingCategory({
                      ...editingCategory,
                      defaultLeadTimeHours: Number(e.target.value),
                    })
                  }
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono"
                  min="1"
                  required
                />
              </div>

              <div className="space-y-2 pt-2 border-t border-stone-800">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingCategory.requiresTemperatureCheck}
                    onChange={(e) =>
                      setEditingCategory({
                        ...editingCategory,
                        requiresTemperatureCheck: e.target.checked,
                      })
                    }
                    className="w-4 h-4 rounded text-amber-500"
                  />
                  <span>تتطلب فحص وقياس درجة الحرارة عند الاستلام</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingCategory.requiresExpiryCheck}
                    onChange={(e) =>
                      setEditingCategory({
                        ...editingCategory,
                        requiresExpiryCheck: e.target.checked,
                      })
                    }
                    className="w-4 h-4 rounded text-amber-500"
                  />
                  <span>تتطلب التحقق من تاريخ الصلاحية عند الاستلام</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingCategory.isActive}
                    onChange={(e) =>
                      setEditingCategory({
                        ...editingCategory,
                        isActive: e.target.checked,
                      })
                    }
                    className="w-4 h-4 rounded text-amber-500"
                  />
                  <span>الفئة نشطة في النظام</span>
                </label>
              </div>

              <div className="flex items-center gap-2 pt-3">
                <button
                  type="submit"
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold py-2.5 rounded-xl transition"
                >
                  حفظ الفئة
                </button>
                <button
                  type="button"
                  onClick={() => setEditingCategory(null)}
                  className="bg-stone-800 text-stone-300 py-2.5 px-4 rounded-xl"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT / CREATE PRODUCT MODAL */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-md p-5 text-stone-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <h3 className="font-bold text-sm text-stone-100">
                {editingProduct.isTBD ? 'تسمية وتخصيص الصنف' : 'تعديل بيانات الصنف'}
              </h3>
              <button
                onClick={() => setEditingProduct(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-white bg-stone-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-stone-300 mb-1">اسم الصنف:</label>
                <input
                  type="text"
                  value={editingProduct.name}
                  onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                  placeholder="مثال: طماطم بلدي طازجة، صدور دجاج مخلية..."
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">وحدة القياس:</label>
                  <select
                    value={editingProduct.unit}
                    onChange={(e) => setEditingProduct({ ...editingProduct, unit: e.target.value })}
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  >
                    <option value="كجم">كجم</option>
                    <option value="جرام">جرام</option>
                    <option value="كرتونة">كرتونة</option>
                    <option value="شوال / كيس">شوال</option>
                    <option value="ربطة">ربطة</option>
                    <option value="قطعة / حبة">حبة</option>
                    <option value="لتر">لتر</option>
                    <option value="طرد / باكت">طرد</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">المورد المفضل:</label>
                  <select
                    value={editingProduct.defaultSupplierId || ''}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        defaultSupplierId: e.target.value || undefined,
                      })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                  >
                    <option value="">غير محدد</option>
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-300 mb-1">
                  المواصفات الفنية ومعايير الجودة (Specifications):
                </label>
                <input
                  type="text"
                  value={editingProduct.specifications || ''}
                  onChange={(e) =>
                    setEditingProduct({ ...editingProduct, specifications: e.target.value })
                  }
                  placeholder="مثال: حجم متوسط، نسبة دهن لا تتجاوز 15%، تعبئة مفرغة من الهواء..."
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-300 mb-1">
                  ملاحظات إضافية:
                </label>
                <textarea
                  value={editingProduct.notes || ''}
                  onChange={(e) =>
                    setEditingProduct({ ...editingProduct, notes: e.target.value })
                  }
                  placeholder="مثال: درجة أولى، خالي من التلف، توريد صباحي فقط..."
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 h-16 resize-none"
                />
              </div>

              <div className="pt-2 border-t border-stone-800">
                <label className="flex items-center gap-2 cursor-pointer text-xs">
                  <input
                    type="checkbox"
                    checked={editingProduct.isActive !== undefined ? editingProduct.isActive : true}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        isActive: e.target.checked,
                      })
                    }
                    className="w-4 h-4 rounded text-amber-500"
                  />
                  <span>الصنف نشط ومتاح للطلبيات (إلغاء التحديد للتعطيل المنطقي Soft-Delete)</span>
                </label>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold py-2.5 rounded-xl transition"
                >
                  حفظ الصنف
                </button>
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="bg-stone-800 text-stone-300 py-2.5 px-4 rounded-xl"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
        </>
      )}
    </div>
  );
};
