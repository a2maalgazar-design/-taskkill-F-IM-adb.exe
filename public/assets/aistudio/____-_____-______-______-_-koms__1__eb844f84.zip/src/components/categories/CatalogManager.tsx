import React, { useEffect, useState } from 'react';
import { catalogService } from '../../services/catalogService';
import { OrderType, Product, Supplier, SYSTEM_ORDER_TYPES } from '../../types';
import { Layers, Package, Truck, Plus, RefreshCw, CheckCircle, AlertCircle } from 'lucide-react';

export const CatalogManager: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'categories' | 'products' | 'suppliers'>('categories');
  const [orderTypes, setOrderTypes] = useState<OrderType[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [selectedTypeId, setSelectedTypeId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // New product form state
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [newProductName, setNewProductName] = useState('');
  const [newProductUnit, setNewProductUnit] = useState('كجم');
  const [newProductTypeId, setNewProductTypeId] = useState('');

  // New supplier form state
  const [isAddingSupplier, setIsAddingSupplier] = useState(false);
  const [newSupplierName, setNewSupplierName] = useState('');
  const [newSupplierPhone, setNewSupplierPhone] = useState('');
  const [newSupplierTypeIds, setNewSupplierTypeIds] = useState<string[]>([]);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);
      await catalogService.ensureSeedOrderTypes();
      const [types, prods, sups] = await Promise.all([
        catalogService.getOrderTypes(),
        catalogService.getProducts(),
        catalogService.getSuppliers(),
      ]);
      setOrderTypes(types);
      setProducts(prods);
      setSuppliers(sups);
      if (types.length > 0 && !selectedTypeId) {
        setSelectedTypeId(types[0].id || types[0].code);
      }
    } catch (err: any) {
      setError(err?.message || 'حدث خطأ أثناء تحميل بيانات الكتالوج');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProductName.trim() || !newProductTypeId) return;
    try {
      await catalogService.addProduct({
        nameAr: newProductName.trim(),
        orderTypeId: newProductTypeId,
        defaultUnit: newProductUnit,
        isActive: true,
      });
      setNewProductName('');
      setIsAddingProduct(false);
      await loadData();
    } catch (err: any) {
      setError(err?.message || 'فشل إضافة الصنف');
    }
  };

  const handleCreateSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSupplierName.trim() || newSupplierTypeIds.length === 0) return;
    try {
      await catalogService.addSupplier({
        nameAr: newSupplierName.trim(),
        phone: newSupplierPhone.trim(),
        orderTypeIds: newSupplierTypeIds,
        isActive: true,
      });
      setNewSupplierName('');
      setNewSupplierPhone('');
      setNewSupplierTypeIds([]);
      setIsAddingSupplier(false);
      await loadData();
    } catch (err: any) {
      setError(err?.message || 'فشل إضافة المورد');
    }
  };

  const getTypeName = (typeIdOrCode: string) => {
    const found = orderTypes.find((t) => t.id === typeIdOrCode || t.code === typeIdOrCode);
    if (found) return found.nameAr;
    const sys = SYSTEM_ORDER_TYPES.find((s) => s.code === typeIdOrCode);
    return sys ? sys.nameAr : typeIdOrCode;
  };

  const filteredProducts = selectedTypeId
    ? products.filter((p) => p.orderTypeId === selectedTypeId)
    : products;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-stone-900 border border-stone-800 p-4 rounded-2xl">
        <div>
          <h2 className="text-lg font-bold text-stone-100 flex items-center gap-2">
            <Layers className="w-5 h-5 text-amber-500" />
            دليل الأصناف والموردين وتصنيفات الطلبات
          </h2>
          <p className="text-xs text-stone-400 mt-1">
            إدارة التصنيفات العشرة الصارمة، ربط الموردين، وإعداد قوائم التوريد
          </p>
        </div>
        <button
          onClick={loadData}
          disabled={loading}
          className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-xl transition border border-stone-700 disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          تحديث البيانات
        </button>
      </div>

      {error && (
        <div className="p-4 bg-rose-950/40 border border-rose-800/60 rounded-xl flex items-center gap-3 text-rose-300 text-sm">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-stone-800 pb-2">
        <button
          onClick={() => setActiveTab('categories')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTab === 'categories'
              ? 'bg-amber-500 text-stone-950 shadow-sm'
              : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900'
          }`}
        >
          <Layers className="w-4 h-4" />
          التصنيفات المعتمدة (10)
        </button>
        <button
          onClick={() => setActiveTab('products')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTab === 'products'
              ? 'bg-amber-500 text-stone-950 shadow-sm'
              : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900'
          }`}
        >
          <Package className="w-4 h-4" />
          الأصناف ({products.length})
        </button>
        <button
          onClick={() => setActiveTab('suppliers')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTab === 'suppliers'
              ? 'bg-amber-500 text-stone-950 shadow-sm'
              : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900'
          }`}
        >
          <Truck className="w-4 h-4" />
          الموردون ({suppliers.length})
        </button>
      </div>

      {/* Categories View */}
      {activeTab === 'categories' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {SYSTEM_ORDER_TYPES.map((sysType, idx) => {
            const prodCount = products.filter(
              (p) => p.orderTypeId === sysType.code || p.orderTypeId === `cat-${sysType.code.toLowerCase()}`
            ).length;
            const supCount = suppliers.filter(
              (s) => s.orderTypeIds?.includes(sysType.code) || s.orderTypeIds?.includes(`cat-${sysType.code.toLowerCase()}`)
            ).length;

            return (
              <div
                key={sysType.code}
                className="bg-stone-900/80 border border-stone-800 rounded-xl p-4 flex flex-col justify-between hover:border-stone-700 transition"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono font-bold text-amber-500/80 bg-amber-500/10 px-2 py-0.5 rounded">
                      #{idx + 1}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-800/40">
                      <CheckCircle className="w-3 h-3" /> معتمد
                    </span>
                  </div>
                  <h3 className="font-bold text-stone-100 text-sm mb-1">{sysType.nameAr}</h3>
                  <p className="text-xs font-mono text-stone-400">{sysType.code}</p>
                </div>

                <div className="mt-4 pt-3 border-t border-stone-800/60 flex items-center justify-between text-xs text-stone-400">
                  <span>{prodCount} أصناف</span>
                  <span>{supCount} موردين</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Products View */}
      {activeTab === 'products' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Category filter pills */}
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => setSelectedTypeId('')}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
                  selectedTypeId === ''
                    ? 'bg-amber-500 text-stone-950 font-bold'
                    : 'bg-stone-900 text-stone-400 hover:text-stone-200'
                }`}
              >
                الكل ({products.length})
              </button>
              {SYSTEM_ORDER_TYPES.map((t) => (
                <button
                  key={t.code}
                  onClick={() => setSelectedTypeId(t.code)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
                    selectedTypeId === t.code
                      ? 'bg-amber-500 text-stone-950 font-bold'
                      : 'bg-stone-900 text-stone-400 hover:text-stone-200'
                  }`}
                >
                  {t.nameAr}
                </button>
              ))}
            </div>

            <button
              onClick={() => setIsAddingProduct(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold rounded-xl transition"
            >
              <Plus className="w-4 h-4" />
              إضافة صنف جديد
            </button>
          </div>

          {isAddingProduct && (
            <form onSubmit={handleCreateProduct} className="p-4 bg-stone-900 border border-stone-800 rounded-xl space-y-3">
              <h4 className="text-xs font-bold text-stone-200">إضافة صنف جديد إلى الكتالوج</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder="اسم الصنف بالعربية..."
                  value={newProductName}
                  onChange={(e) => setNewProductName(e.target.value)}
                  className="bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
                  required
                />
                <select
                  value={newProductTypeId}
                  onChange={(e) => setNewProductTypeId(e.target.value)}
                  className="bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-xs text-stone-100 focus:outline-none focus:border-amber-500"
                  required
                >
                  <option value="">اختر التصنيف...</option>
                  {SYSTEM_ORDER_TYPES.map((t) => (
                    <option key={t.code} value={t.code}>
                      {t.nameAr}
                    </option>
                  ))}
                </select>
                <select
                  value={newProductUnit}
                  onChange={(e) => setNewProductUnit(e.target.value)}
                  className="bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-xs text-stone-100 focus:outline-none focus:border-amber-500"
                >
                  <option value="كجم">كجم</option>
                  <option value="لتر">لتر</option>
                  <option value="كرتونة">كرتونة</option>
                  <option value="باليتة">باليتة</option>
                  <option value="حبة">حبة</option>
                  <option value="رغيف">رغيف</option>
                  <option value="كيس">كيس</option>
                </select>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddingProduct(false)}
                  className="px-3 py-1.5 text-xs text-stone-400 hover:text-stone-200"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold rounded-lg transition"
                >
                  حفظ الصنف
                </button>
              </div>
            </form>
          )}

          {filteredProducts.length === 0 ? (
            <div className="text-center py-10 bg-stone-900/40 border border-dashed border-stone-800 rounded-xl">
              <Package className="w-8 h-8 text-stone-600 mx-auto mb-2" />
              <p className="text-xs text-stone-400">لا توجد أصناف في هذا التصنيف حالياً</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className="bg-stone-900/60 border border-stone-800/80 p-3 rounded-xl flex items-center justify-between"
                >
                  <div>
                    <h5 className="font-semibold text-stone-200 text-xs">{product.nameAr}</h5>
                    <span className="text-[10px] text-amber-500/80">{getTypeName(product.orderTypeId)}</span>
                  </div>
                  <span className="text-[11px] bg-stone-800 text-stone-300 px-2 py-0.5 rounded border border-stone-700">
                    {product.defaultUnit || 'كجم'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Suppliers View */}
      {activeTab === 'suppliers' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button
              onClick={() => setIsAddingSupplier(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold rounded-xl transition"
            >
              <Plus className="w-4 h-4" />
              إضافة مورد جديد
            </button>
          </div>

          {isAddingSupplier && (
            <form onSubmit={handleCreateSupplier} className="p-4 bg-stone-900 border border-stone-800 rounded-xl space-y-3">
              <h4 className="text-xs font-bold text-stone-200">إضافة مورد جديد وتحديد تخصصاته</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="اسم المورد أو الشركة..."
                  value={newSupplierName}
                  onChange={(e) => setNewSupplierName(e.target.value)}
                  className="bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
                  required
                />
                <input
                  type="tel"
                  placeholder="رقم الهاتف أو الواتساب..."
                  value={newSupplierPhone}
                  onChange={(e) => setNewSupplierPhone(e.target.value)}
                  className="bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] text-stone-400 mb-1.5">
                  حدد أنواع الطلبيات الموردة (يمكن اختيار أكثر من نوع):
                </label>
                <div className="flex flex-wrap gap-2">
                  {SYSTEM_ORDER_TYPES.map((t) => {
                    const isSelected = newSupplierTypeIds.includes(t.code);
                    return (
                      <button
                        type="button"
                        key={t.code}
                        onClick={() => {
                          setNewSupplierTypeIds((prev) =>
                            isSelected ? prev.filter((id) => id !== t.code) : [...prev, t.code]
                          );
                        }}
                        className={`text-xs px-2.5 py-1 rounded-lg border transition ${
                          isSelected
                            ? 'bg-amber-500 text-stone-950 border-amber-500 font-bold'
                            : 'bg-stone-950 text-stone-400 border-stone-800 hover:border-stone-700'
                        }`}
                      >
                        {t.nameAr}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingSupplier(false)}
                  className="px-3 py-1.5 text-xs text-stone-400 hover:text-stone-200"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={newSupplierTypeIds.length === 0}
                  className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold rounded-lg transition disabled:opacity-50"
                >
                  حفظ المورد
                </button>
              </div>
            </form>
          )}

          {suppliers.length === 0 ? (
            <div className="text-center py-10 bg-stone-900/40 border border-dashed border-stone-800 rounded-xl">
              <Truck className="w-8 h-8 text-stone-600 mx-auto mb-2" />
              <p className="text-xs text-stone-400">لم يتم إدراج موردين بعد</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {suppliers.map((supplier) => (
                <div
                  key={supplier.id}
                  className="bg-stone-900/70 border border-stone-800 rounded-xl p-4 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <h5 className="font-bold text-stone-100 text-sm">{supplier.nameAr}</h5>
                    <span className="text-[11px] font-mono text-stone-400 bg-stone-800/80 px-2 py-0.5 rounded">
                      {supplier.phone || '—'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-stone-500 block mb-1">التصنيفات الموردة:</span>
                    <div className="flex flex-wrap gap-1">
                      {supplier.orderTypeIds?.map((typeId) => (
                        <span
                          key={typeId}
                          className="text-[10px] bg-stone-800 text-amber-400 px-2 py-0.5 rounded border border-stone-700/60"
                        >
                          {getTypeName(typeId)}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CatalogManager;
