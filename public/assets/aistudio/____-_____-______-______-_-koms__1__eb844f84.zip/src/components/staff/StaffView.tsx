import React, { useState } from 'react';
import { 
  Check, 
  Edit2, 
  Plus, 
  ShieldCheck, 
  UserCheck, 
  Users, 
  X, 
  KeyRound, 
  Tag, 
  UserX, 
  CheckCircle2, 
  Phone, 
  Mail, 
  AlertTriangle,
  Trash2,
  Fingerprint,
  CreditCard,
  Hash
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { User, UserRole, ROLE_PERMISSIONS_PRESETS, PermissionKey } from '../../types';

export const StaffView: React.FC = () => {
  const { 
    users, 
    currentUser, 
    isManager, 
    updateUserRole, 
    toggleUserActive, 
    updateUserDomains, 
    updateUser,
    deleteUser,
    addUser 
  } = useAuth();
  const { orders, orderTypes } = useData();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingDomainsUser, setEditingDomainsUser] = useState<User | null>(null);
  const [selectedDomainIds, setSelectedDomainIds] = useState<string[]>([]);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  const [newUserData, setNewUserData] = useState({
    name: '',
    email: '',
    role: 'assistant' as UserRole,
    phone: '',
    employeeNumber: '',
    iban: '',
    fingerprintRegistered: true,
    assignedOrderTypeIds: [] as string[],
    isActive: true,
  });

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    await addUser({
      ...newUserData,
      fingerprintToken: newUserData.fingerprintRegistered ? `fp_token_${Date.now()}` : undefined,
    });
    setIsAddModalOpen(false);
    setNewUserData({
      name: '',
      email: '',
      role: 'assistant',
      phone: '',
      employeeNumber: '',
      iban: '',
      fingerprintRegistered: true,
      assignedOrderTypeIds: [],
      isActive: true,
    });
  };

  const handleOpenDomainModal = (u: User) => {
    setEditingDomainsUser(u);
    setSelectedDomainIds(u.assignedOrderTypeIds || []);
  };

  const handleSaveDomains = async () => {
    if (!editingDomainsUser) return;
    await updateUserDomains(editingDomainsUser.id, selectedDomainIds);
    setEditingDomainsUser(null);
  };

  const toggleDomainSelection = (catId: string) => {
    setSelectedDomainIds((prev) =>
      prev.includes(catId) ? prev.filter((id) => id !== catId) : [...prev, catId]
    );
  };

  const toggleNewUserDomainSelection = (catId: string) => {
    setNewUserData((prev) => ({
      ...prev,
      assignedOrderTypeIds: prev.assignedOrderTypeIds.includes(catId)
        ? prev.assignedOrderTypeIds.filter((id) => id !== catId)
        : [...prev.assignedOrderTypeIds, catId],
    }));
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    await updateUser({
      ...editingUser,
      displayName: editingUser.name,
    });
    setEditingUser(null);
  };

  const handleConfirmDelete = async (softOnly: boolean) => {
    if (!userToDelete) return;
    if (softOnly) {
      await updateUser({
        ...userToDelete,
        isActive: false,
      });
    } else {
      await deleteUser(userToDelete.id);
    }
    setUserToDelete(null);
  };

  const toggleEditUserDomainSelection = (catId: string) => {
    if (!editingUser) return;
    const current = editingUser.assignedOrderTypeIds || [];
    const updated = current.includes(catId)
      ? current.filter((id) => id !== catId)
      : [...current, catId];
    setEditingUser({
      ...editingUser,
      assignedOrderTypeIds: updated,
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-stone-100 flex items-center gap-2">
              <Users className="w-5 h-5 text-amber-400" />
              <span>إدارة فريق العمل والصلاحيات الإدارية (Team Management)</span>
            </h1>
            <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
              Manager Privileges
            </span>
          </div>
          <p className="text-xs text-stone-400 mt-1">
            صلاحيات حصرية للمدير: إضافة المساعدين الجدد، إسناد مجالات التوريد، والتعطيل المنطقي للحسابات (Soft-Delete via isActive)
          </p>
        </div>

        {isManager && (
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>إضافة مساعد أو عضو جديد</span>
          </button>
        )}
      </div>

      {/* Staff Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {users.map((u) => {
          const userOrders = orders.filter(
            (o) => !o.isArchived && (o.primaryAssigneeId === u.id || o.backupAssigneeId === u.id)
          );
          const completedOrders = userOrders.filter((o) => o.status === 'COMPLETED').length;

          // Resolve assigned domain names
          const assignedCategories = orderTypes.filter((cat) =>
            u.assignedOrderTypeIds?.includes(cat.id)
          );

          return (
            <div
              key={u.id}
              className={`bg-stone-900 border rounded-2xl p-4 flex flex-col justify-between transition ${
                u.isActive ? 'border-stone-800' : 'border-stone-850 opacity-60 bg-stone-950/40'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span
                    className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${
                      u.role === 'manager'
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-stone-800 text-stone-300'
                    }`}
                  >
                    {u.role === 'manager'
                      ? 'مدير المطبخ (Admin)'
                      : u.role === 'receiver'
                      ? 'مسؤول فحص واستلام'
                      : u.role === 'approver'
                      ? 'معتمد مشتريات'
                      : 'مساعد تشغيل ومتابعة'}
                  </span>

                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ${
                      u.isActive
                        ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800'
                        : 'bg-rose-950/80 text-rose-300 border border-rose-900'
                    }`}
                  >
                    {u.isActive ? (
                      <>
                        <CheckCircle2 className="w-3 h-3" />
                        <span>نشط</span>
                      </>
                    ) : (
                      <>
                        <UserX className="w-3 h-3" />
                        <span>معطل (Soft-Deleted)</span>
                      </>
                    )}
                  </span>
                </div>

                <div className="flex items-center gap-3 mt-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center text-sm border border-amber-500/30">
                    {u.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-stone-100">{u.name}</h3>
                    <p className="text-[11px] text-stone-400 font-mono mt-0.5 flex items-center gap-1">
                      <Mail className="w-3 h-3 text-stone-500 shrink-0" />
                      <span>{u.email}</span>
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-stone-800/80 space-y-2 text-xs text-stone-300">
                  <div className="flex justify-between items-center">
                    <span className="text-stone-400 flex items-center gap-1">
                      <Hash className="w-3.5 h-3.5 text-amber-400" />
                      <span>رقم الموظف:</span>
                    </span>
                    <span className="font-mono font-bold text-amber-300 bg-stone-950 px-2 py-0.5 rounded border border-stone-800">
                      {u.employeeNumber || (u.role === 'manager' ? 'MGR-01' : 'AST-01')}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-stone-400 flex items-center gap-1">
                      <CreditCard className="w-3.5 h-3.5 text-stone-400" />
                      <span>الآيبان البنكي (IBAN):</span>
                    </span>
                    <span className="font-mono text-[11px] text-stone-200 truncate max-w-[170px]" title={u.iban || 'غير محدد'}>
                      {u.iban ? `${u.iban.substring(0, 9)}...${u.iban.slice(-4)}` : '—'}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-stone-400 flex items-center gap-1">
                      <Fingerprint className="w-3.5 h-3.5 text-emerald-400" />
                      <span>بصمة الدخول:</span>
                    </span>
                    {u.fingerprintRegistered ? (
                      <span className="text-emerald-400 bg-emerald-950/80 border border-emerald-800/80 px-2 py-0.5 rounded-full text-[10px] font-sans font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>مسجلة وموثقة 👆</span>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          updateUser({
                            ...u,
                            fingerprintRegistered: true,
                            fingerprintToken: `fp_token_${u.id}_${Date.now()}`
                          });
                        }}
                        className="text-amber-400 bg-amber-950/40 border border-amber-800/60 px-2 py-0.5 rounded-full text-[10px] font-sans font-bold hover:bg-amber-900/60 transition"
                      >
                        تسجيل البصمة الآن 👆
                      </button>
                    )}
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-stone-400 flex items-center gap-1">
                      <Phone className="w-3 h-3 text-stone-500" />
                      <span>الهاتف:</span>
                    </span>
                    <span className="font-mono text-stone-200">{u.phone || '—'}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-stone-400">الطلبيات المسندة:</span>
                    <span className="font-mono font-bold text-amber-400">
                      {userOrders.length} طلبية
                    </span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-stone-400">الطلبيات المكتملة:</span>
                    <span className="font-mono font-bold text-emerald-400">
                      {completedOrders} مكتملة
                    </span>
                  </div>

                  {/* Procurement Domains (مجالات التوريد المسندة) */}
                  <div className="pt-2 border-t border-stone-800/60">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[11px] font-semibold text-amber-400 flex items-center gap-1">
                        <Tag className="w-3 h-3" />
                        <span>مجالات التوريد المسندة:</span>
                      </span>
                      {isManager && (
                        <button
                          onClick={() => handleOpenDomainModal(u)}
                          className="text-[10px] text-stone-400 hover:text-amber-400 underline font-medium"
                        >
                          تعديل المجالات
                        </button>
                      )}
                    </div>
                    {assignedCategories.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {assignedCategories.map((cat) => (
                          <span
                            key={cat.id}
                            className="text-[10px] bg-amber-500/10 text-amber-300 px-2 py-0.5 rounded-md border border-amber-500/20"
                          >
                            {cat.nameAr}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-[10px] text-stone-500 block italic">
                        {u.role === 'manager' ? 'كافة مجالات التوريد (إدارة عامة)' : 'لم يتم إسناد مجالات توريد محددة بعد'}
                      </span>
                    )}
                  </div>

                  {/* Permissions breakdown */}
                  <div className="pt-2 border-t border-stone-800/60">
                    <div className="flex items-center gap-1 text-[11px] text-stone-400 mb-1.5">
                      <KeyRound className="w-3 h-3 text-stone-500" />
                      <span>الصلاحيات الممنوحة ({ROLE_PERMISSIONS_PRESETS[u.role]?.length || 0}):</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {ROLE_PERMISSIONS_PRESETS[u.role]?.map((perm) => (
                        <span
                          key={perm}
                          className="text-[9px] font-mono bg-stone-800 text-stone-300 px-1.5 py-0.5 rounded border border-stone-750"
                        >
                          {perm}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Role, Edit, Delete and Active controls (Exclusive to Manager) */}
              {isManager && (
                <div className="mt-4 pt-3 border-t border-stone-800 space-y-2">
                  {u.email !== 'a2m.algazar@gmail.com' && (
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => setEditingUser({ ...u })}
                        className="flex-1 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 rounded-xl py-1.5 px-2.5 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                        title="تعديل الاسم والبيانات وإعادة التسمية"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>تعديل وإعادة تسمية</span>
                      </button>

                      <button
                        onClick={() => setUserToDelete(u)}
                        className="p-1.5 rounded-xl bg-stone-850 hover:bg-rose-950/60 text-stone-400 hover:text-rose-300 border border-stone-800 hover:border-rose-900/50 transition"
                        title="حذف أو تعطيل الحساب"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  <div className="flex items-center justify-between gap-2">
                    <select
                      value={u.role}
                      onChange={(e) => updateUserRole(u.id, e.target.value as UserRole)}
                      className="bg-stone-850 border border-stone-800 rounded-xl px-2 py-1.5 text-xs text-stone-200 focus:outline-none focus:border-amber-500 flex-1"
                      disabled={u.email === 'a2m.algazar@gmail.com'}
                    >
                      <option value="manager">مدير المطبخ (Admin)</option>
                      <option value="assistant">مساعد مشتريات (Assistant)</option>
                      <option value="receiver">مستلم شحنات (Receiver)</option>
                      <option value="approver">معتمد طلبات (Approver)</option>
                    </select>

                    {u.email !== 'a2m.algazar@gmail.com' && (
                      <button
                        onClick={() => toggleUserActive(u.id)}
                        title={u.isActive ? 'تعطيل الحساب منطقياً لحفظ السجلات التاريخية' : 'إعادة تفعيل الحساب للتشغيل'}
                        className={`text-xs px-2.5 py-1.5 rounded-xl font-semibold transition flex items-center gap-1 shrink-0 ${
                          u.isActive
                            ? 'bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-900/50'
                            : 'bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-900/50'
                        }`}
                      >
                        {u.isActive ? (
                          <>
                            <UserX className="w-3.5 h-3.5" />
                            <span>تعطيل (Soft Delete)</span>
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>تفعيل</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* ASSIGN PROCUREMENT DOMAINS MODAL */}
      {editingDomainsUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-lg p-5 text-stone-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <div>
                <h3 className="font-bold text-sm text-stone-100">
                  إسناد مجالات التوريد للمساعد: <span className="text-amber-400">{editingDomainsUser.name}</span>
                </h3>
                <p className="text-xs text-stone-400 mt-0.5">
                  حدد فئات التوريد المسؤولة عنها هذه الكوادر التشغيلية
                </p>
              </div>
              <button
                onClick={() => setEditingDomainsUser(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-white bg-stone-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              <label className="block text-xs font-semibold text-stone-300">
                اختر فئات التوريد المعنية:
              </label>
              <div className="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto p-1">
                {orderTypes.map((cat) => {
                  const isChecked = selectedDomainIds.includes(cat.id);
                  return (
                    <button
                      type="button"
                      key={cat.id}
                      onClick={() => toggleDomainSelection(cat.id)}
                      className={`p-2.5 rounded-xl border text-right transition flex items-center justify-between text-xs ${
                        isChecked
                          ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 font-bold'
                          : 'bg-stone-850 border-stone-800 text-stone-300 hover:bg-stone-800'
                      }`}
                    >
                      <span>{cat.nameAr}</span>
                      {isChecked && <Check className="w-4 h-4 text-amber-400" />}
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={handleSaveDomains}
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold py-2.5 rounded-xl text-xs transition"
                >
                  حفظ مجالات التوريد
                </button>
                <button
                  type="button"
                  onClick={() => setEditingDomainsUser(null)}
                  className="bg-stone-800 text-stone-300 py-2.5 px-4 rounded-xl text-xs"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ADD USER MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-lg p-5 text-stone-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <h3 className="font-bold text-sm text-stone-100">إضافة عضو جديد لفريق المطبخ</h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-white bg-stone-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-stone-300 mb-1">الاسم بالكامل:</label>
                <input
                  type="text"
                  value={newUserData.name}
                  onChange={(e) => setNewUserData({ ...newUserData, name: e.target.value })}
                  placeholder="مثال: شيف مصطفى، مسؤول الاستلام محمود..."
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-300 mb-1">البريد الإلكتروني:</label>
                <input
                  type="email"
                  value={newUserData.email}
                  onChange={(e) => setNewUserData({ ...newUserData, email: e.target.value })}
                  placeholder="username@kitchen.internal"
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">الدور والصلاحية:</label>
                  <select
                    value={newUserData.role}
                    onChange={(e) =>
                      setNewUserData({ ...newUserData, role: e.target.value as UserRole })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 focus:outline-none focus:border-amber-500"
                  >
                    <option value="assistant">مساعد مشتريات (Assistant)</option>
                    <option value="manager">مدير المطبخ (Manager)</option>
                    <option value="receiver">مستلم وفاحص (Receiver)</option>
                    <option value="approver">معتمد طلبات (Approver)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">رقم الهاتف:</label>
                  <input
                    type="text"
                    value={newUserData.phone}
                    onChange={(e) => setNewUserData({ ...newUserData, phone: e.target.value })}
                    placeholder="+201..."
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Employee ID and IBAN for Assistants */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1 flex items-center gap-1">
                    <Hash className="w-3.5 h-3.5 text-amber-400" />
                    <span>رقم المساعد / كود الوظيفة:</span>
                  </label>
                  <input
                    type="text"
                    value={newUserData.employeeNumber}
                    onChange={(e) => setNewUserData({ ...newUserData, employeeNumber: e.target.value })}
                    placeholder="مثال: AST-06"
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1 flex items-center gap-1">
                    <CreditCard className="w-3.5 h-3.5 text-stone-400" />
                    <span>الآيبان البنكي (IBAN):</span>
                  </label>
                  <input
                    type="text"
                    value={newUserData.iban}
                    onChange={(e) => setNewUserData({ ...newUserData, iban: e.target.value })}
                    placeholder="EG3800020001..."
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Fingerprint registration checkbox in Add modal */}
              <div className="bg-stone-950/60 p-2.5 rounded-xl border border-stone-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Fingerprint className="w-4 h-4 text-emerald-400" />
                  <div>
                    <span className="font-semibold text-stone-200 block text-xs">
                      تسجيل بصمة الدخول البيومترية للمساعد
                    </span>
                    <span className="text-[10px] text-stone-400">
                      تمكّن المساعد من تسجيل الدخول السريع عبر البصمة الإلكترونية
                    </span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={newUserData.fingerprintRegistered}
                  onChange={(e) => setNewUserData({ ...newUserData, fingerprintRegistered: e.target.checked })}
                  className="w-4 h-4 rounded text-emerald-500 accent-emerald-500 cursor-pointer"
                />
              </div>

              {/* Assign Domains in Add Modal */}
              <div>
                <label className="block font-semibold text-stone-300 mb-1.5 flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5 text-amber-400" />
                  <span>إسناد مجالات التوريد للمساعد الجديد (Procurement Domains):</span>
                </label>
                <div className="grid grid-cols-2 gap-1.5 max-h-36 overflow-y-auto p-1 bg-stone-950/60 border border-stone-800 rounded-xl">
                  {orderTypes.map((cat) => {
                    const isChecked = newUserData.assignedOrderTypeIds.includes(cat.id);
                    return (
                      <button
                        type="button"
                        key={cat.id}
                        onClick={() => toggleNewUserDomainSelection(cat.id)}
                        className={`p-2 rounded-lg border text-right transition flex items-center justify-between text-[11px] ${
                          isChecked
                            ? 'bg-amber-500/20 border-amber-500/40 text-amber-300 font-bold'
                            : 'bg-stone-900 border-stone-800 text-stone-300 hover:bg-stone-850'
                        }`}
                      >
                        <span>{cat.nameAr}</span>
                        {isChecked && <Check className="w-3.5 h-3.5 text-amber-400" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-stone-800">
                <button
                  type="submit"
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold py-2.5 rounded-xl transition"
                >
                  حفظ وإضافة المستخدم
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="bg-stone-800 text-stone-300 py-2.5 px-4 rounded-xl"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT USER & RENAME MODAL (صلاحية المدير في تعديل وإعادة تسمية المساعدين) */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-lg p-5 text-stone-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <div className="flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-amber-400" />
                <h3 className="font-bold text-sm text-stone-100">
                  تعديل بيانات وإعادة تسمية: <span className="text-amber-400">{editingUser.name}</span>
                </h3>
              </div>
              <button
                onClick={() => setEditingUser(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-white bg-stone-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpdateUser} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-stone-300 mb-1">الاسم بالكامل (إعادة التسمية):</label>
                <input
                  type="text"
                  value={editingUser.name}
                  onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                  placeholder="اسم المساعد أو الموظف"
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 focus:outline-none focus:border-amber-500 font-medium"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-300 mb-1">البريد الإلكتروني:</label>
                <input
                  type="email"
                  value={editingUser.email}
                  onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">الدور والصلاحية:</label>
                  <select
                    value={editingUser.role}
                    onChange={(e) =>
                      setEditingUser({ ...editingUser, role: e.target.value as UserRole })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 focus:outline-none focus:border-amber-500"
                  >
                    <option value="assistant">مساعد مشتريات (Assistant)</option>
                    <option value="manager">مدير المطبخ (Manager)</option>
                    <option value="receiver">مستلم وفاحص (Receiver)</option>
                    <option value="approver">معتمد طلبات (Approver)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">رقم الهاتف للتواصل واتساب:</label>
                  <input
                    type="text"
                    value={editingUser.phone || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, phone: e.target.value })}
                    placeholder="+201..."
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Employee ID and IBAN in Edit Modal */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1 flex items-center gap-1">
                    <Hash className="w-3.5 h-3.5 text-amber-400" />
                    <span>رقم المساعد / كود الوظيفة:</span>
                  </label>
                  <input
                    type="text"
                    value={editingUser.employeeNumber || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, employeeNumber: e.target.value })}
                    placeholder="AST-01"
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono focus:outline-none focus:border-amber-500 font-bold"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1 flex items-center gap-1">
                    <CreditCard className="w-3.5 h-3.5 text-stone-400" />
                    <span>الآيبان البنكي (IBAN):</span>
                  </label>
                  <input
                    type="text"
                    value={editingUser.iban || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, iban: e.target.value })}
                    placeholder="EG380002..."
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Biometric Fingerprint Status & Toggle in Edit Modal */}
              <div className="bg-stone-950/70 p-3 rounded-xl border border-stone-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Fingerprint className="w-5 h-5 text-emerald-400" />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-stone-200 text-xs">البصمة البيومترية للدخول:</span>
                      <span className={`text-[10px] px-2 py-0.2 rounded font-bold ${
                        editingUser.fingerprintRegistered ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-300'
                      }`}>
                        {editingUser.fingerprintRegistered ? 'مسجلة ومفعلة ✓' : 'غير مسجلة ✕'}
                      </span>
                    </div>
                    <span className="text-[10px] text-stone-400 font-mono mt-0.5 block">
                      {editingUser.fingerprintToken || 'رمز البصمة الافتراضي'}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const nextStatus = !editingUser.fingerprintRegistered;
                    setEditingUser({
                      ...editingUser,
                      fingerprintRegistered: nextStatus,
                      fingerprintToken: nextStatus ? `fp_token_${editingUser.id}_${Date.now()}` : undefined
                    });
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                    editingUser.fingerprintRegistered
                      ? 'bg-rose-950/60 text-rose-300 hover:bg-rose-900 border border-rose-800'
                      : 'bg-emerald-600 text-white hover:bg-emerald-500'
                  }`}
                >
                  {editingUser.fingerprintRegistered ? 'إلغاء البصمة' : 'تسجيل البصمة الآن 👆'}
                </button>
              </div>

              {/* Assign Domains in Edit Modal */}
              <div>
                <label className="block font-semibold text-stone-300 mb-1.5 flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5 text-amber-400" />
                  <span>تعديل مجالات التوريد المسندة (Procurement Domains):</span>
                </label>
                <div className="grid grid-cols-2 gap-1.5 max-h-36 overflow-y-auto p-1.5 bg-stone-950/60 border border-stone-800 rounded-xl">
                  {orderTypes.map((cat) => {
                    const isChecked = editingUser.assignedOrderTypeIds?.includes(cat.id);
                    return (
                      <button
                        type="button"
                        key={cat.id}
                        onClick={() => toggleEditUserDomainSelection(cat.id)}
                        className={`p-2 rounded-lg border text-right transition flex items-center justify-between text-[11px] ${
                          isChecked
                            ? 'bg-amber-500/20 border-amber-500/40 text-amber-300 font-bold'
                            : 'bg-stone-900 border-stone-800 text-stone-300 hover:bg-stone-850'
                        }`}
                      >
                        <span>{cat.nameAr}</span>
                        {isChecked && <Check className="w-3.5 h-3.5 text-amber-400" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Active Toggle in Edit Modal */}
              <div className="pt-2 border-t border-stone-800">
                <label className="flex items-center gap-2 cursor-pointer text-xs">
                  <input
                    type="checkbox"
                    checked={editingUser.isActive}
                    onChange={(e) =>
                      setEditingUser({ ...editingUser, isActive: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-amber-500 accent-amber-500"
                  />
                  <span className="font-semibold text-stone-200">
                    الحساب نشط (إلغاء التحديد لتعطيل الحساب منطقياً Soft-Delete)
                  </span>
                </label>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-stone-800">
                <button
                  type="submit"
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold py-2.5 rounded-xl transition"
                >
                  حفظ التعديلات
                </button>
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="bg-stone-800 text-stone-300 py-2.5 px-4 rounded-xl"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE / DEACTIVATE CONFIRMATION MODAL */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm">
          <div className="bg-stone-900 border border-stone-850 rounded-2xl w-full max-w-md p-5 text-stone-100 shadow-2xl">
            <div className="flex items-center gap-3 pb-3 border-b border-stone-800 text-rose-400">
              <div className="w-10 h-10 rounded-xl bg-rose-950/80 border border-rose-900 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-rose-400" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-stone-100">
                  إجراء حذف أو تعطيل حساب مساعد
                </h3>
                <p className="text-xs text-stone-400 font-mono mt-0.5">
                  {userToDelete.name} ({userToDelete.email})
                </p>
              </div>
            </div>

            <div className="mt-4 space-y-3 text-xs text-stone-300 leading-relaxed">
              <p className="bg-amber-500/10 border border-amber-500/20 text-amber-300 p-3 rounded-xl">
                💡 <strong>توصية أمنية وتشغيلية:</strong> يُفضل دائماً استخدام <strong>التعطيل المنطقي (Soft-Delete)</strong> حتى لا تفقد تقارير تدقيق استلام الشحنات والطلبيات السابقة المنسوبة لهذا الحساب.
              </p>
              <p className="text-stone-400">
                اختر نوع الإجراء المطلوب تطبيقه على هذا الحساب:
              </p>
            </div>

            <div className="mt-5 space-y-2">
              <button
                type="button"
                onClick={() => handleConfirmDelete(true)}
                className="w-full bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition"
              >
                <UserX className="w-4 h-4" />
                <span>تعطيل الحساب منطقياً (Soft-Delete - الموصى به)</span>
              </button>

              <button
                type="button"
                onClick={() => handleConfirmDelete(false)}
                className="w-full bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-900/60 font-semibold py-2 rounded-xl text-xs flex items-center justify-center gap-2 transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>حذف نهائي من قاعدة البيانات (Hard-Delete)</span>
              </button>

              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="w-full bg-stone-850 hover:bg-stone-800 text-stone-300 py-2 rounded-xl text-xs transition"
              >
                إلغاء التراجع
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
