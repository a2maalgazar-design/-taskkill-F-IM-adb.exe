import React, { useState, useMemo } from 'react';
import {
  AlertTriangle,
  Calendar,
  Check,
  CheckCircle2,
  Clock,
  Edit2,
  Layers,
  Phone,
  Plus,
  RotateCcw,
  Save,
  Search,
  Shield,
  Sparkles,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { OrderType, Product, SystemPhoneSettings, User } from '../../types';

export const HeadChefAdminPanel: React.FC = () => {
  const { currentUser, users, isManager, updateUserDomains, addUser, deleteUser } = useAuth();
  const {
    orderTypes,
    products,
    saveCategory,
    deleteCategory,
    resetCatalogToDefault,
    saveProduct,
    deleteProduct,
    phoneSettings,
    savePhoneSettings,
  } = useData();

  // Active sub-tab in Admin panel: recurrence first
  const [adminTab, setAdminTab] = useState<'recurrence' | 'items' | 'staff' | 'phones'>('recurrence');

  // Recurrence tab filter: ALL, daily, weekly, monthly
  const [recurrenceTabFilter, setRecurrenceTabFilter] = useState<'ALL' | 'daily' | 'weekly' | 'monthly'>('ALL');

  // Local state for timing inputs per category
  const [timingInputs, setTimingInputs] = useState<Record<string, string>>({});

  // Notification / message banner
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 3500);
  };

  // Recurrence counts
  const recurrenceCounts = useMemo(() => {
    let daily = 0;
    let weekly = 0;
    let monthly = 0;
    for (const c of orderTypes) {
      if (c.recurrence === 'daily') daily++;
      else if (c.recurrence === 'monthly') monthly++;
      else weekly++;
    }
    return { daily, weekly, monthly, total: orderTypes.length };
  }, [orderTypes]);

  // Filtered order types for recurrence tab
  const filteredOrderTypesByRecurrence = useMemo(() => {
    if (recurrenceTabFilter === 'ALL') return orderTypes;
    return orderTypes.filter((c) => (c.recurrence || 'weekly') === recurrenceTabFilter);
  }, [orderTypes, recurrenceTabFilter]);

  // Quick recurrence updater
  const handleQuickUpdateRecurrence = async (
    cat: OrderType,
    recurrence: 'daily' | 'weekly' | 'monthly'
  ) => {
    const updated: OrderType = {
      ...cat,
      recurrence,
      updatedAt: new Date().toISOString(),
    };
    await saveCategory(updated);
    const label = recurrence === 'daily' ? 'يومية ☀️' : recurrence === 'weekly' ? 'أسبوعية 📅' : 'شهرية 🗓️';
    showNotification(`تم تغيير دورية "${cat.nameAr}" إلى (${label}) بنجاح.`);
  };

  // Quick timing updater
  const handleQuickUpdateTiming = async (cat: OrderType, timing: string) => {
    const updated: OrderType = {
      ...cat,
      scheduleTiming: timing.trim(),
      updatedAt: new Date().toISOString(),
    };
    await saveCategory(updated);
    showNotification(`تم حفظ موعد استلام "${cat.nameAr}" إلى "${timing}" بنجاح.`);
  };

  // Quick assignee updater (Delegation)
  const handleQuickUpdateAssignee = async (cat: OrderType, assigneeId: string) => {
    const updated: OrderType = {
      ...cat,
      defaultAssigneeId: assigneeId,
      updatedAt: new Date().toISOString(),
    };
    await saveCategory(updated);
    const assigneeUser = users.find((u) => u.id === assigneeId);
    const name = assigneeUser ? assigneeUser.name.split('(')[0].trim() : 'المسؤول';
    showNotification(`تم تحويل وتفويض مسؤولية "${cat.nameAr}" إلى: ${name}`);
  };

  // -------------------------------------------------------------
  // TAB 1: ITEMS & CATEGORIES MANAGEMENT
  // -------------------------------------------------------------
  const [selectedCatFilter, setSelectedCatFilter] = useState<string>('ALL');
  const [itemSearchQuery, setItemSearchQuery] = useState('');

  // Modals for Items & Categories
  const [isAddItemModalOpen, setIsAddItemModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [newItemName, setNewItemName] = useState('');
  const [newItemUnit, setNewItemUnit] = useState('كجم');
  const [newItemCategory, setNewItemCategory] = useState(orderTypes[0]?.id || 'cat-veg');
  const [newItemDemand, setNewItemDemand] = useState<number>(10);

  const [isAddCatModalOpen, setIsAddCatModalOpen] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatCode, setNewCatCode] = useState('');
  const [newCatRecurrence, setNewCatRecurrence] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
  const [newCatScheduleTiming, setNewCatScheduleTiming] = useState('');
  const [newCatAssigneeId, setNewCatAssigneeId] = useState('user-assistant-01');
  const [newCatDesc, setNewCatDesc] = useState('');

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (selectedCatFilter !== 'ALL' && p.orderTypeId !== selectedCatFilter) return false;
      if (itemSearchQuery.trim()) {
        const q = itemSearchQuery.toLowerCase();
        return p.nameAr.toLowerCase().includes(q);
      }
      return true;
    });
  }, [products, selectedCatFilter, itemSearchQuery]);

  const handleOpenAddProduct = () => {
    setEditingProduct(null);
    setNewItemName('');
    setNewItemUnit('كجم');
    setNewItemCategory(selectedCatFilter !== 'ALL' ? selectedCatFilter : orderTypes[0]?.id || 'cat-veg');
    setNewItemDemand(10);
    setIsAddItemModalOpen(true);
  };

  const handleOpenEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setNewItemName(prod.nameAr);
    setNewItemUnit(prod.defaultUnit || 'كجم');
    setNewItemCategory(prod.orderTypeId);
    setNewItemDemand(prod.averageDailyDemand || 0);
    setIsAddItemModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    if (editingProduct) {
      const updated: Product = {
        ...editingProduct,
        nameAr: newItemName.trim(),
        name: newItemName.trim(),
        defaultUnit: newItemUnit,
        unit: newItemUnit,
        orderTypeId: newItemCategory,
        averageDailyDemand: Number(newItemDemand),
        updatedAt: new Date().toISOString(),
      };
      await saveProduct(updated);
      showNotification(`تم تحديث الصنف "${newItemName}" بنجاح.`);
    } else {
      const newProd: Product = {
        id: `prod-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        nameAr: newItemName.trim(),
        name: newItemName.trim(),
        defaultUnit: newItemUnit,
        unit: newItemUnit,
        orderTypeId: newItemCategory,
        averageDailyDemand: Number(newItemDemand),
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      await saveProduct(newProd);
      showNotification(`تمت إضافة الصنف "${newItemName}" بنجاح.`);
    }
    setIsAddItemModalOpen(false);
  };

  const handleDeleteProduct = async (prod: Product) => {
    if (confirm(`هل أنت متأكد من حذف الصنف "${prod.nameAr}" نهائياً من المطبخ؟`)) {
      await deleteProduct(prod.id);
      showNotification(`تم حذف الصنف "${prod.nameAr}".`);
    }
  };

  const [editingCategory, setEditingCategory] = useState<OrderType | null>(null);

  const handleOpenAddCategory = () => {
    setEditingCategory(null);
    setNewCatName('');
    setNewCatCode('');
    setNewCatRecurrence('weekly');
    setNewCatScheduleTiming('');
    setNewCatAssigneeId('user-assistant-01');
    setNewCatDesc('');
    setIsAddCatModalOpen(true);
  };

  const handleOpenEditCategory = (cat: OrderType) => {
    setEditingCategory(cat);
    setNewCatName(cat.nameAr);
    setNewCatCode(cat.code);
    setNewCatRecurrence(cat.recurrence || 'weekly');
    setNewCatScheduleTiming(cat.scheduleTiming || '');
    setNewCatAssigneeId(cat.defaultAssigneeId || 'user-assistant-01');
    setNewCatDesc(cat.description || '');
    setIsAddCatModalOpen(true);
  };

  const handleDeleteCategory = async (cat: OrderType) => {
    const count = products.filter((p) => p.orderTypeId === cat.id).length;
    if (
      confirm(
        `هل أنت متأكد من حذف فئة/عمود الطلبية "${cat.nameAr}" بالكامل؟${
          count > 0 ? ` (تحتوي على ${count} أصناف)` : ''
        }`
      )
    ) {
      await deleteCategory(cat.id);
      if (selectedCatFilter === cat.id) setSelectedCatFilter('ALL');
      showNotification(`تم حذف فئة "${cat.nameAr}" بنجاح.`);
    }
  };

  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    if (editingCategory) {
      const updated: OrderType = {
        ...editingCategory,
        nameAr: newCatName.trim(),
        code: (newCatCode || editingCategory.code).toUpperCase(),
        recurrence: newCatRecurrence,
        scheduleTiming: newCatScheduleTiming.trim(),
        defaultAssigneeId: newCatAssigneeId,
        description: newCatDesc.trim(),
      };
      await saveCategory(updated);
      showNotification(`تم تحديث فئة الطلبية "${newCatName}" وموعدها بنجاح.`);
    } else {
      const newCat: OrderType = {
        id: `cat-${Date.now()}`,
        code: (newCatCode || newCatName.substring(0, 4)).toUpperCase(),
        nameAr: newCatName.trim(),
        description: newCatDesc.trim(),
        recurrence: newCatRecurrence,
        scheduleTiming: newCatScheduleTiming.trim(),
        defaultAssigneeId: newCatAssigneeId,
        isActive: true,
        createdAt: new Date().toISOString(),
      };
      await saveCategory(newCat);
      showNotification(`تمت إضافة فئة الطلبية "${newCatName}" بنجاح.`);
    }

    setIsAddCatModalOpen(false);
    setEditingCategory(null);
    setNewCatName('');
    setNewCatCode('');
    setNewCatScheduleTiming('');
    setNewCatDesc('');
  };

  // -------------------------------------------------------------
  // TAB 2: STAFF & TASK ALLOCATION MANAGEMENT
  // -------------------------------------------------------------
  const [isAddStaffModalOpen, setIsAddStaffModalOpen] = useState(false);
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffPhone, setNewStaffPhone] = useState('+201');

  const assistantsList = useMemo(() => {
    return users.filter((u) => u.role === 'assistant');
  }, [users]);

  const handleToggleCategoryForAssistant = async (
    assistantId: string,
    catId: string,
    currentAssigned: string[]
  ) => {
    const isAssigned = currentAssigned.includes(catId);
    let updated: string[];
    if (isAssigned) {
      updated = currentAssigned.filter((id) => id !== catId);
    } else {
      updated = [...currentAssigned, catId];
    }
    await updateUserDomains(assistantId, updated);
    showNotification('تم تحديث إسناد المهام للمساعد بنجاح.');
  };

  const handleAddAssistant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStaffName.trim()) return;

    await addUser({
      name: newStaffName.trim(),
      email: `assistant${assistantsList.length + 1}@kitchen.internal`,
      role: 'assistant',
      phone: newStaffPhone.trim(),
      assignedOrderTypeIds: [],
      isActive: true,
    });
    showNotification(`تمت إضافة المساعد "${newStaffName}" بنجاح.`);
    setIsAddStaffModalOpen(false);
    setNewStaffName('');
    setNewStaffPhone('+201');
  };

  const handleDeleteAssistant = async (asst: User) => {
    if (confirm(`هل أنت متأكد من حذف ${asst.name} من طاقم المطبخ؟`)) {
      await deleteUser(asst.id);
      showNotification(`تم حذف ${asst.name}.`);
    }
  };

  // -------------------------------------------------------------
  // TAB 3: PHONE NUMBERS MANAGEMENT
  // -------------------------------------------------------------
  const [localPhones, setLocalPhones] = useState<SystemPhoneSettings>(phoneSettings);

  const handlePhoneChange = (
    field: 'purchasingPhone' | 'headChefPhone',
    value: string
  ) => {
    setLocalPhones((prev) => ({ ...prev, [field]: value }));
  };

  const handleSupplierPhoneChange = (catId: string, value: string) => {
    setLocalPhones((prev) => ({
      ...prev,
      supplierPhones: {
        ...prev.supplierPhones,
        [catId]: value,
      },
    }));
  };

  const handleSaveAllPhones = async () => {
    await savePhoneSettings(localPhones);
    showNotification('تم حفظ وتحديث أرقام الهواتف بنجاح.');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="text-2xl">👨‍🍳</span>
            <h1 className="text-xl lg:text-2xl font-black text-stone-100">
              لوحة إدارة المطبخ للشيف العمومي (Admin Panel)
            </h1>
            <span className="bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold">
              صلاحيات كاملة
            </span>
          </div>
          <p className="text-xs text-stone-400 mt-1">
            إدارة الأصناف والطلبيات، توزيع مهام المساعدين الخمسة، وضبط أرقام الهواتف والواتساب
          </p>
        </div>

        {/* Success toast */}
        {successMsg && (
          <div className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs px-3.5 py-2 rounded-xl font-bold flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-stone-800 pb-2 overflow-x-auto scrollbar-thin">
        <button
          type="button"
          onClick={() => setAdminTab('recurrence')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition shrink-0 ${
            adminTab === 'recurrence'
              ? 'bg-amber-500 text-stone-950 shadow-md ring-2 ring-amber-400'
              : 'bg-stone-900 text-stone-300 hover:bg-stone-800'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>دورية ومواعيد الطلبيات ({orderTypes.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setAdminTab('items')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition shrink-0 ${
            adminTab === 'items'
              ? 'bg-amber-500 text-stone-950 shadow-md'
              : 'bg-stone-900 text-stone-300 hover:bg-stone-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>الأصناف والكتالوج ({products.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setAdminTab('staff')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition shrink-0 ${
            adminTab === 'staff'
              ? 'bg-amber-500 text-stone-950 shadow-md'
              : 'bg-stone-900 text-stone-300 hover:bg-stone-800'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>طاقم المطبخ وتوزيع المهام ({assistantsList.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setAdminTab('phones')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition shrink-0 ${
            adminTab === 'phones'
              ? 'bg-amber-500 text-stone-950 shadow-md'
              : 'bg-stone-900 text-stone-300 hover:bg-stone-800'
          }`}
        >
          <Phone className="w-4 h-4" />
          <span>أرقام الهواتف والواتساب</span>
        </button>
      </div>

      {/* ========================================================= */}
      {/* SUB-TAB 0: RECURRENCE & TIMING MANAGEMENT (دورية الطلبيات) */}
      {/* ========================================================= */}
      {adminTab === 'recurrence' && (
        <div className="space-y-5 animate-fadeIn">
          {/* Header Summary & Filters */}
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 shadow-lg">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xl">⏱️</span>
                  <h2 className="text-base lg:text-lg font-black text-stone-100">
                    ضبط وتعديل دورية كل طلبية (يومي • أسبوعي • شهري)
                  </h2>
                </div>
                <p className="text-xs text-stone-400 mt-1 max-w-2xl">
                  حدد دورية كل مجموعة طلبيات وموعد تسليمها اليومي أو الأسبوعي أو الشهري، وقم بتحويل وتفويض المسؤولية بين الشيف العمومي والمساعدين. يتم تحديث منطق العرض في واجهة الأعمدة فوراً.
                </p>
              </div>

              {/* Recurrence Filter Tabs */}
              <div className="flex items-center gap-1.5 bg-stone-950 p-1 rounded-2xl border border-stone-800 self-start lg:self-auto overflow-x-auto">
                <button
                  type="button"
                  onClick={() => setRecurrenceTabFilter('ALL')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                    recurrenceTabFilter === 'ALL'
                      ? 'bg-stone-800 text-stone-100 shadow'
                      : 'text-stone-400 hover:text-stone-200'
                  }`}
                >
                  <span>كافة الطلبيات</span>
                  <span className="bg-stone-900 px-1.5 py-0.2 rounded text-[11px] font-mono">
                    {recurrenceCounts.total}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setRecurrenceTabFilter('daily')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                    recurrenceTabFilter === 'daily'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow'
                      : 'text-stone-400 hover:text-stone-200'
                  }`}
                >
                  <span>☀️ يومي</span>
                  <span className="bg-emerald-950 text-emerald-300 px-1.5 py-0.2 rounded text-[11px] font-mono">
                    {recurrenceCounts.daily}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setRecurrenceTabFilter('weekly')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                    recurrenceTabFilter === 'weekly'
                      ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow'
                      : 'text-stone-400 hover:text-stone-200'
                  }`}
                >
                  <span>📅 أسبوعي</span>
                  <span className="bg-blue-950 text-blue-300 px-1.5 py-0.2 rounded text-[11px] font-mono">
                    {recurrenceCounts.weekly}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setRecurrenceTabFilter('monthly')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                    recurrenceTabFilter === 'monthly'
                      ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow'
                      : 'text-stone-400 hover:text-stone-200'
                  }`}
                >
                  <span>🗓️ شهري</span>
                  <span className="bg-purple-950 text-purple-300 px-1.5 py-0.2 rounded text-[11px] font-mono">
                    {recurrenceCounts.monthly}
                  </span>
                </button>
              </div>
            </div>
          </div>

          {/* Cards Grid for Each Order Type */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredOrderTypesByRecurrence.map((cat) => {
              const currentRecurrence = cat.recurrence || 'weekly';
              const catProds = products.filter((p) => p.orderTypeId === cat.id);
              const assignedUser = users.find((u) => u.id === (cat.defaultAssigneeId || 'user-manager-01'));
              const currentTimingInput = timingInputs[cat.id] !== undefined ? timingInputs[cat.id] : (cat.scheduleTiming || '');

              const icon =
                cat.id === 'cat-veg'
                  ? '🥬'
                  : cat.id === 'cat-meat'
                  ? '🥩'
                  : cat.id === 'cat-poultry'
                  ? '🍗'
                  : cat.id === 'cat-sauces'
                  ? '🫙'
                  : cat.id === 'cat-frozen-oils'
                  ? '❄️'
                  : cat.id === 'cat-falahi-bread'
                  ? '🥖'
                  : cat.id === 'cat-brioche'
                  ? '🥐'
                  : cat.id === 'cat-packaging'
                  ? '📦'
                  : cat.id === 'cat-cleaning'
                  ? '🧼'
                  : cat.id === 'cat-cashier'
                  ? '🧾'
                  : '📋';

              return (
                <div
                  key={cat.id}
                  className={`bg-stone-900 border rounded-2xl p-5 flex flex-col justify-between shadow-lg transition hover:border-stone-650 ${
                    currentRecurrence === 'daily'
                      ? 'border-emerald-900/60 ring-1 ring-emerald-500/20'
                      : currentRecurrence === 'monthly'
                      ? 'border-purple-900/60 ring-1 ring-purple-500/20'
                      : 'border-blue-900/60 ring-1 ring-blue-500/20'
                  }`}
                >
                  <div>
                    {/* Card Header */}
                    <div className="flex items-start justify-between gap-2 pb-3 border-b border-stone-800">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{icon}</span>
                          <div>
                            <h3 className="font-extrabold text-sm lg:text-base text-stone-100">{cat.nameAr}</h3>
                            <span className="text-[11px] font-mono text-stone-400">كود: {cat.code}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-1">
                        <span className="bg-stone-950 text-amber-400 text-[11px] font-mono px-2 py-0.5 rounded border border-stone-800">
                          {catProds.length} أصناف
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                            currentRecurrence === 'daily'
                              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                              : currentRecurrence === 'monthly'
                              ? 'bg-purple-500/20 text-purple-400 border-purple-500/30'
                              : 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                          }`}
                        >
                          {currentRecurrence === 'daily'
                            ? '☀️ يومية'
                            : currentRecurrence === 'monthly'
                            ? '🗓️ شهرية'
                            : '📅 أسبوعية'}
                        </span>
                      </div>
                    </div>

                    {/* SECTION 1: Recurrence 3-Way Segmented Buttons */}
                    <div className="mt-4">
                      <label className="block text-[11px] font-bold text-stone-300 mb-1.5 flex items-center justify-between">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-amber-400" />
                          <span>دورية الطلبية (تغيير فوري للمدير):</span>
                        </span>
                        <span className="text-[10px] text-stone-500">حفظ تلقائي</span>
                      </label>

                      <div className="grid grid-cols-3 gap-1.5 bg-stone-950 p-1 rounded-xl border border-stone-800">
                        {/* Daily */}
                        <button
                          type="button"
                          onClick={() => handleQuickUpdateRecurrence(cat, 'daily')}
                          className={`py-2 px-1 rounded-lg text-xs font-bold transition flex flex-col items-center justify-center gap-0.5 ${
                            currentRecurrence === 'daily'
                              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950 ring-1 ring-emerald-400/50'
                              : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900'
                          }`}
                        >
                          <span className="text-xs">☀️</span>
                          <span>يومي</span>
                        </button>

                        {/* Weekly */}
                        <button
                          type="button"
                          onClick={() => handleQuickUpdateRecurrence(cat, 'weekly')}
                          className={`py-2 px-1 rounded-lg text-xs font-bold transition flex flex-col items-center justify-center gap-0.5 ${
                            currentRecurrence === 'weekly'
                              ? 'bg-blue-600 text-white shadow-md shadow-blue-950 ring-1 ring-blue-400/50'
                              : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900'
                          }`}
                        >
                          <span className="text-xs">📅</span>
                          <span>أسبوعي</span>
                        </button>

                        {/* Monthly */}
                        <button
                          type="button"
                          onClick={() => handleQuickUpdateRecurrence(cat, 'monthly')}
                          className={`py-2 px-1 rounded-lg text-xs font-bold transition flex flex-col items-center justify-center gap-0.5 ${
                            currentRecurrence === 'monthly'
                              ? 'bg-purple-600 text-white shadow-md shadow-purple-950 ring-1 ring-purple-400/50'
                              : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900'
                          }`}
                        >
                          <span className="text-xs">🗓️</span>
                          <span>شهري</span>
                        </button>
                      </div>
                    </div>

                    {/* SECTION 2: Schedule Timing Input */}
                    <div className="mt-3.5">
                      <label className="block text-[11px] font-bold text-stone-300 mb-1 flex items-center justify-between">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-amber-400" />
                          <span>موعد وتوقيت الاستلام المقرر:</span>
                        </span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          value={currentTimingInput}
                          onChange={(e) =>
                            setTimingInputs((prev) => ({ ...prev, [cat.id]: e.target.value }))
                          }
                          placeholder="مثال: الساعة 07:00 ص كحد أقصى"
                          className="flex-1 bg-stone-950 border border-stone-800 rounded-xl px-3 py-1.5 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-400"
                        />
                        <button
                          type="button"
                          onClick={() => handleQuickUpdateTiming(cat, currentTimingInput)}
                          className="bg-stone-800 hover:bg-stone-700 text-amber-300 border border-stone-700 px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0"
                          title="حفظ موعد الاستلام"
                        >
                          <Save className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* SECTION 3: Assignee Transfer & Delegation */}
                    <div className="mt-3.5">
                      <label className="block text-[11px] font-bold text-stone-300 mb-1 flex items-center gap-1">
                        <UserCheck className="w-3.5 h-3.5 text-amber-400" />
                        <span>خيار التحويل من المدير إلى المساعد:</span>
                      </label>
                      <select
                        value={cat.defaultAssigneeId || 'user-manager-01'}
                        onChange={(e) => handleQuickUpdateAssignee(cat, e.target.value)}
                        className="w-full bg-stone-950 border border-stone-800 text-amber-300 text-xs font-bold rounded-xl px-3 py-2 focus:outline-none focus:border-amber-400 cursor-pointer"
                      >
                        <option value="user-manager-01">👨‍🍳 الشيف العمومي (المدير)</option>
                        <optgroup label="المساعدون الخمسة">
                          {assistantsList.map((asst) => (
                            <option key={asst.id} value={asst.id}>
                              🧑‍🍳 {asst.name.split('(')[0].trim()}
                            </option>
                          ))}
                        </optgroup>
                      </select>
                    </div>
                  </div>

                  {/* Card Footer Actions */}
                  <div className="mt-4 pt-3 border-t border-stone-800/60 flex items-center justify-between text-xs">
                    <button
                      type="button"
                      onClick={() => handleOpenEditCategory(cat)}
                      className="flex items-center gap-1.5 bg-stone-800 hover:bg-stone-750 text-stone-200 px-3 py-1.5 rounded-xl font-bold transition"
                    >
                      <Edit2 className="w-3 h-3 text-amber-400" />
                      <span>تعديل كامل</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDeleteCategory(cat)}
                      className="flex items-center gap-1 text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/25 px-2.5 py-1.5 rounded-xl font-bold transition"
                      title="حذف هذه الطلبية"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>حذف</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-TAB 1: ITEMS & CATEGORIES */}
      {/* ========================================================= */}
      {adminTab === 'items' && (
        <div className="space-y-4">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={selectedCatFilter}
                onChange={(e) => setSelectedCatFilter(e.target.value)}
                className="bg-stone-950 border border-stone-800 text-stone-200 text-xs rounded-xl px-3 py-2"
              >
                <option value="ALL">كافة الفئات والطلبيات ({products.length})</option>
                {orderTypes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.nameAr} ({c.recurrence === 'daily' ? 'يومية' : 'أسبوعية'})
                  </option>
                ))}
              </select>

              <div className="relative">
                <Search className="w-3.5 h-3.5 text-stone-500 absolute right-3 top-2.5" />
                <input
                  type="text"
                  placeholder="بحث عن صنف..."
                  value={itemSearchQuery}
                  onChange={(e) => setItemSearchQuery(e.target.value)}
                  className="bg-stone-950 border border-stone-800 text-stone-200 text-xs rounded-xl pr-8 pl-3 py-2 w-48"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {selectedCatFilter !== 'ALL' && (() => {
                const currentCat = orderTypes.find((c) => c.id === selectedCatFilter);
                if (!currentCat) return null;
                return (
                  <div className="flex items-center gap-1.5 bg-stone-950 p-1 rounded-xl border border-stone-800">
                    <button
                      type="button"
                      onClick={() => handleOpenEditCategory(currentCat)}
                      className="flex items-center gap-1 text-[11px] bg-stone-800 hover:bg-stone-750 text-amber-300 px-2 py-1 rounded-lg font-bold transition"
                      title="تعديل اسم وبيانات الطلبية"
                    >
                      <Edit2 className="w-3 h-3" />
                      <span>تعديل الطلبية</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteCategory(currentCat)}
                      className="flex items-center gap-1 text-[11px] bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 px-2 py-1 rounded-lg font-bold transition border border-rose-500/30"
                      title="حذف هذه الطلبية/العمود"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>حذف الطلبية</span>
                    </button>
                  </div>
                );
              })()}

              <button
                type="button"
                onClick={handleOpenAddCategory}
                className="flex items-center gap-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 px-3 py-2 rounded-xl text-xs font-bold transition border border-stone-700"
              >
                <Plus className="w-3.5 h-3.5 text-amber-400" />
                <span>إضافة طلبية جديدة</span>
              </button>

              <button
                type="button"
                onClick={handleOpenAddProduct}
                className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة صنف جديد</span>
              </button>
            </div>
          </div>

          {/* Table of Products */}
          <div className="bg-stone-900 border border-stone-800 rounded-2xl overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="border-b border-stone-800 bg-stone-950/60 text-stone-400">
                    <th className="py-3 px-4">#</th>
                    <th className="py-3 px-4">اسم الصنف</th>
                    <th className="py-3 px-4">الطلبية التابع لها</th>
                    <th className="py-3 px-4">وحدة القياس</th>
                    <th className="py-3 px-4">رصيد الأمان (المتوقع)</th>
                    <th className="py-3 px-4 text-center">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-800/40">
                  {filteredProducts.map((prod, idx) => {
                    const cat = orderTypes.find((c) => c.id === prod.orderTypeId);
                    return (
                      <tr key={prod.id} className="hover:bg-stone-850 transition">
                        <td className="py-3 px-4 font-mono text-stone-500">{idx + 1}</td>
                        <td className="py-3 px-4 font-bold text-stone-100">{prod.nameAr}</td>
                        <td className="py-3 px-4">
                          <span className="bg-stone-950 text-amber-400 px-2 py-0.5 rounded border border-stone-800 text-[11px] font-medium">
                            {cat ? cat.nameAr : prod.orderTypeId}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-stone-300 font-mono font-medium">
                          {prod.defaultUnit || 'كجم'}
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-stone-300">
                          {prod.averageDailyDemand || 0}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleOpenEditProduct(prod)}
                              className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white transition"
                              title="تعديل"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteProduct(prod)}
                              className="p-1.5 rounded-lg bg-stone-800 hover:bg-rose-950/40 text-stone-400 hover:text-rose-400 transition"
                              title="حذف الصنف"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-TAB 2: STAFF & TASK ALLOCATION */}
      {/* ========================================================= */}
      {adminTab === 'staff' && (
        <div className="space-y-4">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-stone-100">إدارة طاقم العمل وتوزيع مهام الطلبيات</h3>
              <p className="text-xs text-stone-400 mt-0.5">
                حدد بمربعات الاختيار (Checkboxes) الفئات الموكلة لكل مساعد، وستظهر لديه حصراً في واجهة الأعمدة
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsAddStaffModalOpen(true)}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition shadow-sm"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>إضافة مساعد جديد</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {assistantsList.map((asst, idx) => {
              const assigned = asst.assignedOrderTypeIds || [];
              return (
                <div
                  key={asst.id}
                  className="bg-stone-900 border border-stone-800 rounded-2xl p-4 flex flex-col justify-between shadow-lg"
                >
                  <div>
                    {/* Assistant Card Header */}
                    <div className="flex items-center justify-between border-b border-stone-800 pb-3 mb-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-sm">
                          {idx + 1}
                        </div>
                        <div>
                          <h4 className="font-extrabold text-sm text-stone-100">{asst.name}</h4>
                          <span className="text-[11px] text-stone-400 font-mono">{asst.phone || 'بدون هاتف'}</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleDeleteAssistant(asst)}
                        className="text-stone-500 hover:text-rose-400 p-1.5 transition"
                        title="حذف المساعد"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Category Checkboxes for this assistant */}
                    <div className="space-y-1.5">
                      <span className="text-[11px] font-bold text-stone-400 block mb-2">
                        الطلبيات الموكلة إليه ({assigned.length}):
                      </span>

                      <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                        {orderTypes.map((cat) => {
                          const isAssigned = assigned.includes(cat.id);
                          return (
                            <label
                              key={cat.id}
                              className={`flex items-center justify-between p-2 rounded-xl border text-xs cursor-pointer transition select-none ${
                                isAssigned
                                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                                  : 'bg-stone-950 border-stone-800/80 text-stone-400 hover:border-stone-700'
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <input
                                  type="checkbox"
                                  checked={isAssigned}
                                  onChange={() =>
                                    handleToggleCategoryForAssistant(asst.id, cat.id, assigned)
                                  }
                                  className="w-4 h-4 rounded text-amber-500 focus:ring-0 bg-stone-900 border-stone-700"
                                />
                                <span className="font-medium">{cat.nameAr}</span>
                              </div>
                              <span className="text-[10px] text-stone-500 font-mono">
                                {cat.recurrence === 'daily' ? 'يومية' : 'أسبوعية'}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-TAB 3: PHONE NUMBERS MANAGEMENT */}
      {/* ========================================================= */}
      {adminTab === 'phones' && (
        <div className="space-y-5">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-sm text-stone-100">
                إدارة أرقام الهواتف والتحويل المباشر للواتساب
              </h3>
              <p className="text-xs text-stone-400 mt-0.5">
                تعديل رقم هاتف مدير المشتريات، رقم الشيف العمومي للنسخة المطابقة، وأرقام هواتف الموردين
              </p>
            </div>
            <button
              type="button"
              onClick={handleSaveAllPhones}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-xl text-xs font-black transition shadow-lg shadow-emerald-950/40"
            >
              <Save className="w-4 h-4" />
              <span>حفظ كافة الأرقام الآن</span>
            </button>
          </div>

          {/* Master Phones (Purchasing & Chef CC) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Purchasing Phone */}
            <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 space-y-2">
              <label className="text-xs font-bold text-stone-300 flex items-center gap-2">
                <span>👔</span>
                <span>رقم هاتف مدير المشتريات (WhatsApp):</span>
              </label>
              <input
                type="text"
                value={localPhones.purchasingPhone}
                onChange={(e) => handlePhoneChange('purchasingPhone', e.target.value)}
                placeholder="+201099887766"
                className="w-full bg-stone-950 border border-stone-700 text-stone-100 font-mono text-sm rounded-xl px-3.5 py-2.5 focus:ring-1 focus:ring-amber-500"
              />
              <p className="text-[11px] text-stone-500">
                يُحوّل إليه الطلب عند اختيار المساعد لجهة الإرسال: [ مدير المشتريات ]
              </p>
            </div>

            {/* Chef CC Phone */}
            <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 space-y-2">
              <label className="text-xs font-bold text-amber-300 flex items-center gap-2">
                <span>👨‍🍳</span>
                <span>رقم هاتف الشيف العمومي للنسخة المطابقة (Chef CC):</span>
              </label>
              <input
                type="text"
                value={localPhones.headChefPhone}
                onChange={(e) => handlePhoneChange('headChefPhone', e.target.value)}
                placeholder="+201000000000"
                className="w-full bg-stone-950 border border-amber-500/40 text-amber-300 font-mono text-sm rounded-xl px-3.5 py-2.5 focus:ring-1 focus:ring-amber-500"
              />
              <p className="text-[11px] text-stone-500">
                يُحوّل إليه الرابط الفوري لإرسال نسخة مطابقة تامة من أي طلبية للعلم والإشراف
              </p>
            </div>
          </div>

          {/* Category Suppliers Phones */}
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 space-y-3">
            <h4 className="font-bold text-xs text-stone-300 flex items-center gap-2">
              <span>🏢</span>
              <span>أرقام هواتف الموردين المباشرين بحسب فئة الطلبية:</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {orderTypes.map((cat) => {
                const currentPhone = localPhones.supplierPhones[cat.id] || '+201011122233';
                return (
                  <div
                    key={cat.id}
                    className="bg-stone-950 p-3 rounded-xl border border-stone-800 space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-stone-200">{cat.nameAr}</span>
                      <span className="text-[10px] text-stone-500 font-mono">
                        {cat.recurrence === 'daily' ? 'يومية' : 'أسبوعية'}
                      </span>
                    </div>
                    <input
                      type="text"
                      value={currentPhone}
                      onChange={(e) => handleSupplierPhoneChange(cat.id, e.target.value)}
                      placeholder="+201011122233"
                      className="w-full bg-stone-900 border border-stone-700 text-stone-200 font-mono text-xs rounded-lg px-2.5 py-2"
                    />
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD / EDIT PRODUCT */}
      {/* ========================================================= */}
      {isAddItemModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-fadeIn">
          <form
            onSubmit={handleSaveProduct}
            className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-md shadow-2xl p-5 space-y-4 text-stone-100"
          >
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <h3 className="font-black text-base text-stone-100">
                {editingProduct ? 'تعديل صنف في المطبخ' : 'إضافة صنف جديد للمطبخ'}
              </h3>
              <button
                type="button"
                onClick={() => setIsAddItemModalOpen(false)}
                className="w-8 h-8 rounded-full bg-stone-800 text-stone-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-stone-400 mb-1">اسم الصنف:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: لحم مفروم دسم"
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100 font-bold"
                />
              </div>

              <div>
                <label className="block text-stone-400 mb-1">الطلبية التابع لها:</label>
                <select
                  value={newItemCategory}
                  onChange={(e) => setNewItemCategory(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100"
                >
                  {orderTypes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.nameAr}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-400 mb-1">وحدة القياس:</label>
                  <select
                    value={newItemUnit}
                    onChange={(e) => setNewItemUnit(e.target.value)}
                    className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100"
                  >
                    <option value="كجم">كجم</option>
                    <option value="لتر">لتر</option>
                    <option value="كرتونة">كرتونة</option>
                    <option value="شوال">شوال</option>
                    <option value="باكت">باكت</option>
                    <option value="بالعدد / حبة">بالعدد / حبة</option>
                    <option value="ربطة">ربطة</option>
                    <option value="جركن">جركن</option>
                  </select>
                </div>

                <div>
                  <label className="block text-stone-400 mb-1">رصيد الأمان (المتوقع):</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={newItemDemand}
                    onChange={(e) => setNewItemDemand(parseFloat(e.target.value) || 0)}
                    className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100 font-mono font-bold"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-800">
              <button
                type="button"
                onClick={() => setIsAddItemModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-stone-800 hover:bg-stone-700 text-stone-300"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-stone-950"
              >
                حفظ الصنف
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD ORDER CATEGORY */}
      {/* ========================================================= */}
      {isAddCatModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-fadeIn">
          <form
            onSubmit={handleSaveCategory}
            className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-md shadow-2xl p-5 space-y-4 text-stone-100"
          >
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <h3 className="font-black text-base text-stone-100">
                {editingCategory ? 'تعديل فئة / عمود الطلبية' : 'إضافة فئة طلبية جديدة للمطبخ'}
              </h3>
              <button
                type="button"
                onClick={() => {
                  setIsAddCatModalOpen(false);
                  setEditingCategory(null);
                }}
                className="w-8 h-8 rounded-full bg-stone-800 text-stone-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-stone-400 mb-1">اسم الطلبية (مثال: طلبية الأسماك):</label>
                <input
                  type="text"
                  required
                  placeholder="طلبية..."
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100 font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-400 mb-1">كود الطلبية:</label>
                  <input
                    type="text"
                    placeholder="FISH"
                    value={newCatCode}
                    onChange={(e) => setNewCatCode(e.target.value)}
                    className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100 font-mono uppercase"
                  />
                </div>

                <div>
                  <label className="block text-stone-400 mb-1">دورية الطلبية:</label>
                  <select
                    value={newCatRecurrence}
                    onChange={(e) => setNewCatRecurrence(e.target.value as any)}
                    className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100 font-bold"
                  >
                    <option value="daily">☀️ دورية يومية</option>
                    <option value="weekly">📅 دورية أسبوعية</option>
                    <option value="monthly">🗓️ دورية شهرية</option>
                  </select>
                </div>
              </div>

              {/* Schedule timing input */}
              <div>
                <label className="block text-stone-400 mb-1">
                  موعد / توقيت الطلبية المحدد (من المدير):
                </label>
                <input
                  type="text"
                  placeholder="مثال: الساعة 07:00 صباحاً كحد أقصى، كل يوم سبت، أو أول كل شهر..."
                  value={newCatScheduleTiming}
                  onChange={(e) => setNewCatScheduleTiming(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100 font-mono"
                />
              </div>

              {/* Transfer/Assignee selector from manager to assistant */}
              <div>
                <label className="block text-stone-400 mb-1">
                  المسؤول عن الطلبية (التحويل من المدير إلى المساعد):
                </label>
                <select
                  value={newCatAssigneeId}
                  onChange={(e) => setNewCatAssigneeId(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100 font-bold"
                >
                  <option value="user-manager-01">👨‍🍳 الشيف العمومي (مدير المطبخ)</option>
                  <optgroup label="المساعدون الخمسة">
                    {assistantsList.map((asst) => (
                      <option key={asst.id} value={asst.id}>
                        🧑‍🍳 {asst.name}
                      </option>
                    ))}
                  </optgroup>
                </select>
              </div>

              <div>
                <label className="block text-stone-400 mb-1">الوصف والملاحظات:</label>
                <textarea
                  rows={2}
                  value={newCatDesc}
                  onChange={(e) => setNewCatDesc(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100"
                  placeholder="وصف محتويات الطلبية..."
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-800">
              <button
                type="button"
                onClick={() => {
                  setIsAddCatModalOpen(false);
                  setEditingCategory(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-stone-800 hover:bg-stone-700 text-stone-300"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-stone-950"
              >
                {editingCategory ? 'حفظ التعديلات' : 'إضافة الفئة'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD ASSISTANT */}
      {/* ========================================================= */}
      {isAddStaffModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-fadeIn">
          <form
            onSubmit={handleAddAssistant}
            className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-md shadow-2xl p-5 space-y-4 text-stone-100"
          >
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <h3 className="font-black text-base text-stone-100">إضافة مساعد جديد لطاقم المطبخ</h3>
              <button
                type="button"
                onClick={() => setIsAddStaffModalOpen(false)}
                className="w-8 h-8 rounded-full bg-stone-800 text-stone-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-stone-400 mb-1">اسم المساعد:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: المساعد 6 (مسؤول الحلويات)"
                  value={newStaffName}
                  onChange={(e) => setNewStaffName(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100 font-bold"
                />
              </div>

              <div>
                <label className="block text-stone-400 mb-1">رقم هاتف المساعد:</label>
                <input
                  type="text"
                  required
                  placeholder="+201666666666"
                  value={newStaffPhone}
                  onChange={(e) => setNewStaffPhone(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-700 rounded-xl px-3 py-2 text-stone-100 font-mono"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-800">
              <button
                type="button"
                onClick={() => setIsAddStaffModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-stone-800 hover:bg-stone-700 text-stone-300"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-stone-950"
              >
                إضافة المساعد
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
