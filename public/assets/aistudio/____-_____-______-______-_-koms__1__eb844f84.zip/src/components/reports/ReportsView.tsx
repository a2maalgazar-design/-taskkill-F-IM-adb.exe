import React, { useState } from 'react';
import {
  BarChart3,
  Calendar,
  CheckCircle2,
  Clock,
  Download,
  FileSpreadsheet,
  FileText,
  Filter,
  PieChart,
  TrendingUp,
  Truck,
  Users,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { WORKFLOW_STATUS_CONFIG, formatDateOnly } from '../../utils/statusLabels';

export const ReportsView: React.FC = () => {
  const { isManager, users } = useAuth();
  const { orders, orderTypes, suppliers, receivingRecords, invoices } = useData();

  const [period, setPeriod] = useState<'today' | 'week' | 'month' | 'all'>('month');

  // Filter orders by period
  const now = new Date();
  const filteredOrders = orders.filter((o) => {
    if (period === 'all') return true;
    const ordDate = new Date(o.orderDate);
    if (period === 'today') {
      return o.orderDate === now.toISOString().split('T')[0];
    }
    if (period === 'week') {
      const diffDays = (now.getTime() - ordDate.getTime()) / (1000 * 3600 * 24);
      return diffDays <= 7;
    }
    if (period === 'month') {
      const diffDays = (now.getTime() - ordDate.getTime()) / (1000 * 3600 * 24);
      return diffDays <= 30;
    }
    return true;
  });

  // Calculate Metrics for selected period
  const total = filteredOrders.length;
  const completed = filteredOrders.filter((o) => o.status === 'COMPLETED').length;
  const overdue = filteredOrders.filter((o) => {
    if (['COMPLETED', 'VERIFIED', 'CANCELLED'].includes(o.status)) return false;
    return new Date(o.orderingDeadline).getTime() < now.getTime();
  }).length;
  const withRejections = filteredOrders.filter((o) =>
    o.items.some((i) => i.rejectedQty > 0)
  ).length;

  const onTimePercentage = total > 0 ? Math.round(((total - overdue) / total) * 100) : 100;

  // Workload by Assistant
  const workloadByUser = users.map((u) => {
    const assigned = filteredOrders.filter(
      (o) => o.primaryAssigneeId === u.id || o.backupAssigneeId === u.id
    );
    const userCompleted = assigned.filter((o) => o.status === 'COMPLETED').length;
    return {
      user: u,
      count: assigned.length,
      completed: userCompleted,
    };
  });

  // Orders by Category
  const categoryStats = orderTypes.map((cat) => {
    const count = filteredOrders.filter((o) => o.orderTypeId === cat.id).length;
    return {
      category: cat,
      count,
    };
  });

  // Export CSV function
  const handleExportCSV = () => {
    const headers = [
      'رقم الطلبية',
      'تاريخ الطلب',
      'فئة التوريد',
      'المسؤول',
      'المورد',
      'الحالة',
      'عدد البنود',
      'مهلة الطلب',
      'توقع التسليم',
      'ملاحظات',
    ];

    const rows = filteredOrders.map((o) => {
      const cat = orderTypes.find((c) => c.id === o.orderTypeId)?.nameAr || o.orderTypeId;
      const usr = users.find((u) => u.id === o.primaryAssigneeId)?.name || o.primaryAssigneeId;
      const sup = suppliers.find((s) => s.id === o.supplierId)?.name || 'TBD';
      const statusLabel = WORKFLOW_STATUS_CONFIG[o.status]?.labelAr || o.status;

      return [
        `"${o.id}"`,
        `"${o.orderDate}"`,
        `"${cat}"`,
        `"${usr}"`,
        `"${sup}"`,
        `"${statusLabel}"`,
        o.items.length,
        `"${o.orderingDeadline}"`,
        `"${o.expectedDeliveryTime || ''}"`,
        `"${(o.notes || '').replace(/"/g, '""')}"`,
      ];
    });

    const csvContent =
      '\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `KOMS_Kitchen_Report_${period}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Export Action */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-stone-100 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-amber-400" />
            <span>التقارير التحليلية والإحصاءات التشغيلية</span>
          </h1>
          <p className="text-xs text-stone-400">
            بيانات فعلية محسوبة من قاعدة البيانات مباشرة لمراقبة الأداء، معدل الانضباط، وتصدير التقارير
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Period Selector */}
          <div className="bg-stone-850 p-1 rounded-xl border border-stone-800 flex items-center text-xs">
            <button
              onClick={() => setPeriod('today')}
              className={`px-2.5 py-1 rounded-lg transition ${
                period === 'today' ? 'bg-amber-500 text-stone-950 font-bold' : 'text-stone-400'
              }`}
            >
              اليوم
            </button>
            <button
              onClick={() => setPeriod('week')}
              className={`px-2.5 py-1 rounded-lg transition ${
                period === 'week' ? 'bg-amber-500 text-stone-950 font-bold' : 'text-stone-400'
              }`}
            >
              أسبوع
            </button>
            <button
              onClick={() => setPeriod('month')}
              className={`px-2.5 py-1 rounded-lg transition ${
                period === 'month' ? 'bg-amber-500 text-stone-950 font-bold' : 'text-stone-400'
              }`}
            >
              شهر
            </button>
            <button
              onClick={() => setPeriod('all')}
              className={`px-2.5 py-1 rounded-lg transition ${
                period === 'all' ? 'bg-amber-500 text-stone-950 font-bold' : 'text-stone-400'
              }`}
            >
              الكل
            </button>
          </div>

          <button
            onClick={handleExportCSV}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>تصدير CSV / إكسل</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Metrics for Period */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4">
          <span className="text-xs text-stone-400">إجمالي الطلبيات في الفترة</span>
          <div className="text-2xl font-black font-mono text-stone-100 mt-2">{total}</div>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4">
          <span className="text-xs text-stone-400">نسبة الانضباط بمواعيد الطلب</span>
          <div className="text-2xl font-black font-mono text-emerald-400 mt-2">
            %{onTimePercentage}
          </div>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4">
          <span className="text-xs text-stone-400">طلبيات متأخرة</span>
          <div className="text-2xl font-black font-mono text-rose-400 mt-2">{overdue}</div>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4">
          <span className="text-xs text-stone-400">طلبيات بها بنود مرفوضة أو تالفة</span>
          <div className="text-2xl font-black font-mono text-amber-400 mt-2">
            {withRejections}
          </div>
        </div>
      </div>

      {/* Grid: Staff Workload vs Categories Distribution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Staff Workload */}
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4">
          <h2 className="font-bold text-sm text-stone-200 mb-3 flex items-center gap-2">
            <Users className="w-4 h-4 text-amber-400" />
            <span>توزيع أعباء العمل والمسؤوليات على فريق المطبخ</span>
          </h2>

          <div className="space-y-3">
            {workloadByUser.map((w) => {
              const pct = total > 0 ? Math.round((w.count / total) * 100) : 0;
              return (
                <div key={w.user.id} className="bg-stone-850 p-3 rounded-xl border border-stone-800">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-stone-200">{w.user.name}</span>
                    <span className="font-mono text-amber-400 font-bold">
                      {w.count} طلبيات ({pct}%)
                    </span>
                  </div>

                  <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden mt-2">
                    <div
                      className="bg-amber-500 h-full rounded-full transition-all"
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  <div className="flex justify-between text-[11px] text-stone-400 mt-2">
                    <span>مكتملة: {w.completed}</span>
                    <span>قيد المتابعة: {w.count - w.completed}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Categories Distribution */}
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4">
          <h2 className="font-bold text-sm text-stone-200 mb-3 flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>حجم التوريدات بحسب فئات المشتريات الـ 10</span>
          </h2>

          <div className="space-y-2 max-h-80 overflow-y-auto">
            {categoryStats.map((c) => {
              const pct = total > 0 ? Math.round((c.count / total) * 100) : 0;
              return (
                <div
                  key={c.category.id}
                  className="flex items-center justify-between p-2.5 bg-stone-850 border border-stone-800 rounded-xl text-xs"
                >
                  <div>
                    <span className="font-semibold text-stone-200">{c.category.nameAr}</span>
                    <span className="text-[10px] text-stone-400 mr-1.5">
                      ({c.category.nameEn})
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-amber-400">{c.count}</span>
                    <span className="text-[10px] text-stone-400">({pct}%)</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
