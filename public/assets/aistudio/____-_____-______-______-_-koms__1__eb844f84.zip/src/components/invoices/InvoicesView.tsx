import React, { useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  Camera,
  CheckCircle2,
  FileSpreadsheet,
  FileText,
  Plus,
  Search,
  Sparkles,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { InvoiceRecord, WorkflowStatus } from '../../types';
import { formatDateTime } from '../../utils/statusLabels';
import { InvoiceCameraScannerModal } from '../../features/ai/components/InvoiceCameraScannerModal';
import { toReconciliationOrder, Order } from '../../features/orders/types';

export const InvoicesView: React.FC = () => {
  const { isManager, currentUser } = useAuth();
  const { invoices, orders, suppliers, saveInvoice, updateOrderStatus } = useData();

  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<InvoiceRecord | null>(null);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [selectedOrderForScan, setSelectedOrderForScan] = useState<Order | null>(null);

  // Eligible orders that received goods and need invoice verification
  const eligibleOrders = orders.filter((o) => !o.isArchived);

  const handleApplyVerifiedData = (data: { invoiceNumber: string; totalAmountEGP: number; notes: string }) => {
    if (editingInvoice) {
      setEditingInvoice({
        ...editingInvoice,
        invoiceNumber: data.invoiceNumber || editingInvoice.invoiceNumber,
        invoiceTotal: data.totalAmountEGP || editingInvoice.invoiceTotal,
        notes: editingInvoice.notes ? `${editingInvoice.notes}\n${data.notes}` : data.notes,
        verificationStatus: data.notes.includes('فوارق') ? 'DISCREPANCY' : 'VERIFIED',
        discrepancyNotes: data.notes.includes('فوارق') ? data.notes : editingInvoice.discrepancyNotes,
      });
      setIsModalOpen(true);
    } else {
      const ord = selectedOrderForScan ? orders.find((o) => o.id === selectedOrderForScan.id) : eligibleOrders[0];
      const sup = suppliers.find((s) => s.id === ord?.supplierId);
      setEditingInvoice({
        id: `inv-${Date.now()}`,
        invoiceNumber: data.invoiceNumber || '',
        orderId: ord?.id || '',
        supplierId: ord?.supplierId || suppliers[0]?.id || '',
        supplierName: sup?.name || suppliers[0]?.name || 'غير محدد',
        invoiceDate: new Date().toISOString().split('T')[0],
        invoiceTotal: data.totalAmountEGP || 0,
        verificationStatus: data.notes.includes('فوارق') ? 'DISCREPANCY' : 'VERIFIED',
        notes: data.notes,
        discrepancyNotes: data.notes.includes('فوارق') ? data.notes : undefined,
      });
      setIsModalOpen(true);
    }
  };

  const filteredInvoices = invoices.filter((inv) => {
    if (!searchTerm.trim()) return true;
    const q = searchTerm.toLowerCase();
    return (
      inv.invoiceNumber.toLowerCase().includes(q) ||
      inv.supplierName.toLowerCase().includes(q) ||
      inv.orderId.toLowerCase().includes(q)
    );
  });

  const handleOpenNewInvoice = () => {
    const firstOrder = eligibleOrders[0];
    const sup = suppliers.find((s) => s.id === firstOrder?.supplierId);

    setEditingInvoice({
      id: `inv-${Date.now()}`,
      invoiceNumber: '',
      orderId: firstOrder?.id || '',
      supplierId: firstOrder?.supplierId || suppliers[0]?.id || '',
      supplierName: sup?.name || suppliers[0]?.name || 'غير محدد',
      invoiceDate: new Date().toISOString().split('T')[0],
      invoiceTotal: 0,
      verificationStatus: 'PENDING',
      notes: '',
    });
    setIsModalOpen(true);
  };

  const handleSaveInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingInvoice) return;

    const isVerifiedNow = editingInvoice.verificationStatus === 'VERIFIED';
    const updatedInvoice: InvoiceRecord = {
      ...editingInvoice,
      verifiedBy: isVerifiedNow ? currentUser.id : editingInvoice.verifiedBy,
      verifiedByName: isVerifiedNow ? currentUser.name : editingInvoice.verifiedByName,
      verifiedAt: isVerifiedNow ? new Date().toISOString() : editingInvoice.verifiedAt,
    };

    await saveInvoice(updatedInvoice);

    // If verified, transition order status to VERIFIED or COMPLETED
    if (isVerifiedNow && editingInvoice.orderId) {
      await updateOrderStatus(
        editingInvoice.orderId,
        'VERIFIED',
        `تمت مطابقة الفاتورة رقم ${editingInvoice.invoiceNumber} بقيمة ${editingInvoice.invoiceTotal} ج.م`
      );
    }

    setIsModalOpen(false);
    setEditingInvoice(null);
  };

  const getStatusBadge = (status: InvoiceRecord['verificationStatus']) => {
    switch (status) {
      case 'VERIFIED':
        return {
          label: 'تمت المطابقة والاعتماد',
          cls: 'bg-emerald-950/80 text-emerald-400 border border-emerald-800',
        };
      case 'DISCREPANCY':
        return {
          label: 'يوجد اختلاف / فروقات',
          cls: 'bg-rose-950/80 text-rose-300 border border-rose-800',
        };
      case 'UNDER_REVIEW':
        return {
          label: 'قيد التدقيق والمراجعة',
          cls: 'bg-amber-950/80 text-amber-300 border border-amber-800',
        };
      default:
        return {
          label: 'بانتظار الفاتورة والمطابقة',
          cls: 'bg-stone-800 text-stone-300 border border-stone-700',
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-stone-100 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-yellow-400" />
            <span>تدقيق ومطابقة فواتير المشتريات (Invoice Reconciliation)</span>
          </h1>
          <p className="text-xs text-stone-400">
            مقارنة فواتير الموردين مع الكميات المستلمة فعلياً ورصد فروقات الأسعار والأوزان
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const defaultOrder = eligibleOrders[0] || orders[0];
              if (defaultOrder) {
                setSelectedOrderForScan(toReconciliationOrder(defaultOrder));
                setIsScannerOpen(true);
              }
            }}
            className="bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition"
          >
            <Camera className="w-4 h-4 text-amber-400" />
            <span>المسح الذكي بالكاميرا (Gemini AI)</span>
          </button>

          <button
            onClick={handleOpenNewInvoice}
            className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>تسجيل فاتورة جديدة</span>
          </button>
        </div>
      </div>

      {/* Invoices List */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 shadow-sm space-y-4">
        {/* Search */}
        <div className="flex items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-stone-400 absolute right-3 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="بحث برقم الفاتورة، المورد، رقم الطلبية..."
              className="w-full bg-stone-850 border border-stone-800 rounded-xl pr-9 pl-3 py-2 text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500"
            />
          </div>
          <span className="text-xs text-stone-400 font-mono">
            {filteredInvoices.length} فواتير مسجلة
          </span>
        </div>

        {/* Table */}
        <div className="border border-stone-800 rounded-xl overflow-hidden">
          <table className="w-full text-right text-xs text-stone-300">
            <thead className="bg-stone-850 text-stone-400 text-[11px] uppercase">
              <tr>
                <th className="p-3">رقم الفاتورة</th>
                <th className="p-3">الطلبية المرتبطة</th>
                <th className="p-3">المورد</th>
                <th className="p-3">تاريخ الفاتورة</th>
                <th className="p-3">القيمة الإجمالية</th>
                <th className="p-3">حالة المطابقة</th>
                <th className="p-3">المراجع والملاحظات</th>
                <th className="p-3 text-center">إجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-800/80">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-10 text-center text-stone-500">
                    لا توجد فواتير مسجلة حالياً. اضغط على "تسجيل فاتورة جديدة" لإدخال فاتورة مورد.
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => {
                  const badge = getStatusBadge(inv.verificationStatus);
                  return (
                    <tr key={inv.id} className="hover:bg-stone-850/60 transition">
                      <td className="p-3 font-bold font-mono text-stone-100">
                        #{inv.invoiceNumber}
                      </td>
                      <td className="p-3 font-mono text-amber-400 font-bold">{inv.orderId}</td>
                      <td className="p-3 font-semibold text-stone-200">{inv.supplierName}</td>
                      <td className="p-3 font-mono text-stone-400">{inv.invoiceDate}</td>
                      <td className="p-3 font-mono font-bold text-stone-100">
                        {inv.invoiceTotal.toLocaleString('ar-EG')} ج.م
                      </td>
                      <td className="p-3">
                        <span
                          className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${badge.cls}`}
                        >
                          {badge.label}
                        </span>
                      </td>
                      <td className="p-3">
                        {inv.verifiedByName ? (
                          <div className="text-[11px] text-stone-300">
                            مراجع: {inv.verifiedByName}
                          </div>
                        ) : (
                          <div className="text-[11px] text-stone-500">لم تدقق بعد</div>
                        )}
                        {inv.discrepancyNotes && (
                          <div className="text-[10px] text-rose-400 mt-0.5 font-medium">
                            فرق: {inv.discrepancyNotes}
                          </div>
                        )}
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => {
                            setEditingInvoice(inv);
                            setIsModalOpen(true);
                          }}
                          className="px-2.5 py-1 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 rounded-lg text-xs font-semibold transition"
                        >
                          مطابقة / تعديل
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE / EDIT INVOICE MODAL */}
      {isModalOpen && editingInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl w-full max-w-lg p-5 text-stone-100 shadow-2xl my-6">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <h3 className="font-bold text-sm text-stone-100">
                تسجيل وتدقيق فاتورة مورد
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-white bg-stone-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveInvoice} className="mt-4 space-y-3.5 text-xs">
              {/* زر المسح البصري الذكي */}
              <button
                type="button"
                onClick={() => {
                  const currentOrder = orders.find((o) => o.id === editingInvoice.orderId) || eligibleOrders[0];
                  if (currentOrder) {
                    setSelectedOrderForScan(toReconciliationOrder(currentOrder));
                    setIsScannerOpen(true);
                  }
                }}
                className="w-full py-2.5 px-3 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 rounded-xl font-bold flex items-center justify-center gap-2 transition shadow-sm"
              >
                <Camera className="w-4 h-4 text-amber-400" />
                <span>مسح وتدقيق الفاتورة الورقية بالكاميرا (Gemini AI OCR)</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              </button>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">
                    رقم الفاتورة الورقية / الضريبية:
                  </label>
                  <input
                    type="text"
                    value={editingInvoice.invoiceNumber}
                    onChange={(e) =>
                      setEditingInvoice({ ...editingInvoice, invoiceNumber: e.target.value })
                    }
                    placeholder="مثال: INV-9842"
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">
                    الطلبية المرتبطة:
                  </label>
                  <select
                    value={editingInvoice.orderId}
                    onChange={(e) => {
                      const selOrd = orders.find((o) => o.id === e.target.value);
                      const sup = suppliers.find((s) => s.id === selOrd?.supplierId);
                      setEditingInvoice({
                        ...editingInvoice,
                        orderId: e.target.value,
                        supplierId: selOrd?.supplierId || editingInvoice.supplierId,
                        supplierName: sup?.name || editingInvoice.supplierName,
                      });
                    }}
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono"
                    required
                  >
                    {eligibleOrders.map((o) => (
                      <option key={o.id} value={o.id}>
                        {o.id} ({o.items.length} أصناف)
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">المورد:</label>
                  <input
                    type="text"
                    value={editingInvoice.supplierName}
                    onChange={(e) =>
                      setEditingInvoice({ ...editingInvoice, supplierName: e.target.value })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">تاريخ الفاتورة:</label>
                  <input
                    type="date"
                    value={editingInvoice.invoiceDate}
                    onChange={(e) =>
                      setEditingInvoice({ ...editingInvoice, invoiceDate: e.target.value })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-300 mb-1">
                    إجمالي المبلغ (ج.م):
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={editingInvoice.invoiceTotal}
                    onChange={(e) =>
                      setEditingInvoice({
                        ...editingInvoice,
                        invoiceTotal: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-300 mb-1">
                    قرار المطابقة والتدقيق:
                  </label>
                  <select
                    value={editingInvoice.verificationStatus}
                    onChange={(e: any) =>
                      setEditingInvoice({
                        ...editingInvoice,
                        verificationStatus: e.target.value,
                      })
                    }
                    className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 font-bold"
                  >
                    <option value="PENDING">بانتظار المراجعة (PENDING)</option>
                    <option value="UNDER_REVIEW">قيد المراجعة (UNDER REVIEW)</option>
                    <option value="VERIFIED">مطابقة تامة ومعتمدة (VERIFIED)</option>
                    <option value="DISCREPANCY">يوجد خلاف أو فروقات (DISCREPANCY)</option>
                  </select>
                </div>
              </div>

              {editingInvoice.verificationStatus === 'DISCREPANCY' && (
                <div>
                  <label className="block font-semibold text-rose-300 mb-1">
                    تفاصيل الفروقات (وزن ناقص، سعر زائد، بنود مرفوضة):
                  </label>
                  <textarea
                    value={editingInvoice.discrepancyNotes || ''}
                    onChange={(e) =>
                      setEditingInvoice({
                        ...editingInvoice,
                        discrepancyNotes: e.target.value,
                      })
                    }
                    placeholder="مثال: تم إثبات 5 كجم طماطم تالفة في الاستلام ولكنها محسوبة في الفاتورة..."
                    className="w-full bg-stone-850 border border-rose-900/60 rounded-xl p-2.5 text-rose-200 h-16 resize-none"
                    required
                  />
                </div>
              )}

              <div>
                <label className="block font-semibold text-stone-300 mb-1">ملاحظات عامة:</label>
                <textarea
                  value={editingInvoice.notes || ''}
                  onChange={(e) =>
                    setEditingInvoice({ ...editingInvoice, notes: e.target.value })
                  }
                  className="w-full bg-stone-850 border border-stone-800 rounded-xl p-2.5 text-stone-100 h-16 resize-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-stone-800">
                <button
                  type="submit"
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold py-2.5 rounded-xl transition"
                >
                  حفظ الفاتورة وتوثيق المطابقة
                </button>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="bg-stone-800 text-stone-300 py-2.5 px-4 rounded-xl"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* AI Invoice Camera Scanner & Reconciliation Modal */}
      {isScannerOpen && selectedOrderForScan && (
        <InvoiceCameraScannerModal
          order={selectedOrderForScan}
          onClose={() => {
            setIsScannerOpen(false);
            setSelectedOrderForScan(null);
          }}
          onApplyVerifiedData={(data) => {
            handleApplyVerifiedData(data);
            setIsScannerOpen(false);
            setSelectedOrderForScan(null);
          }}
        />
      )}
    </div>
  );
};
