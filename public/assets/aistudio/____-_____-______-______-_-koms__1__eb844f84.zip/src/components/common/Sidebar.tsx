import React from 'react';
import {
  Archive,
  BarChart3,
  BookOpen,
  CalendarDays,
  CheckSquare,
  ClipboardList,
  FileSpreadsheet,
  FileText,
  History,
  LayoutDashboard,
  Layers,
  Settings,
  ShieldCheck,
  Truck,
  Users,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';

export type ActiveTab =
  | 'columnar-orders'
  | 'weekly-archive'
  | 'chef-admin'
  | 'dashboard'
  | 'veg-order'
  | 'orders'
  | 'my-orders'
  | 'schedules'
  | 'categories'
  | 'suppliers'
  | 'receiving'
  | 'invoices'
  | 'staff'
  | 'reports'
  | 'archive'
  | 'audit'
  | 'guide';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isOpenMobile,
  onCloseMobile,
}) => {
  const { isManager, currentUser } = useAuth();
  const { orders, invoices, receivingRecords } = useData();

  // Active counts
  const myOrdersCount = orders.filter(
    (o) => !o.isArchived && o.primaryAssigneeId === currentUser.id && o.status !== 'COMPLETED'
  ).length;

  const awaitingReceivingCount = orders.filter(
    (o) => !o.isArchived && ['AWAITING_DELIVERY', 'RECEIVING'].includes(o.status)
  ).length;

  const invoicePendingCount = orders.filter(
    (o) => !o.isArchived && o.status === 'INVOICE_PENDING'
  ).length;

  const navItems = [
    {
      id: 'columnar-orders' as ActiveTab,
      label: 'حصر وطلبيات المطبخ',
      sublabel: 'طلبيات مطبخ نانا الشيخ زايد',
      icon: LayoutDashboard,
      badge: null,
      badgeText: 'الرئيسية ⭐',
      managerOnly: false,
    },
    {
      id: 'weekly-archive' as ActiveTab,
      label: 'الملف الأسبوعي للطلبيات',
      sublabel: 'أرشيف تراكمي والطباعة للشيف',
      icon: FileSpreadsheet,
      badge: null,
      badgeText: 'أسبوعي 📂',
      managerOnly: false,
    },
    {
      id: 'chef-admin' as ActiveTab,
      label: 'لوحة إدارة الشيف العمومي',
      sublabel: 'إدارة الأصناف والمهام والهواتف',
      icon: ShieldCheck,
      badge: null,
      badgeText: 'Admin 👨‍🍳',
      managerOnly: true,
    },
    {
      id: 'dashboard' as ActiveTab,
      label: 'لوحة العمليات اليومية',
      sublabel: 'المؤشرات والعمليات الحية',
      icon: Layers,
      badge: null,
      badgeText: null,
      managerOnly: false,
    },
    {
      id: 'orders' as ActiveTab,
      label: 'إدارة الطلبيات',
      sublabel: 'جدول و كانبان والتقويم',
      icon: ClipboardList,
      badge: orders.filter((o) => !o.isArchived && o.status !== 'COMPLETED').length,
      badgeText: null,
      managerOnly: false,
    },
    {
      id: 'my-orders' as ActiveTab,
      label: 'مهامي الشخصية',
      sublabel: 'الطلبيات المسندة إليّ',
      icon: CheckSquare,
      badge: myOrdersCount,
      managerOnly: false,
    },
    {
      id: 'schedules' as ActiveTab,
      label: 'جدول التوريد الدوري',
      sublabel: 'الجداول التكرارية المؤتمتة',
      icon: CalendarDays,
      badge: null,
      managerOnly: true,
    },
    {
      id: 'categories' as ActiveTab,
      label: 'فئات الطلبيات والأصناف',
      sublabel: 'الـ 10 فئات وأصناف الخضار',
      icon: Layers,
      badge: null,
      managerOnly: false,
    },
    {
      id: 'suppliers' as ActiveTab,
      label: 'دليل الموردين',
      sublabel: 'جهات التوريد ومواعيد التسليم',
      icon: Truck,
      badge: null,
      managerOnly: false,
    },
    {
      id: 'receiving' as ActiveTab,
      label: 'الاستلام وفحص الجودة',
      sublabel: 'تسجيل الحرارة والأوزان والتوالف',
      icon: ShieldCheck,
      badge: awaitingReceivingCount > 0 ? awaitingReceivingCount : null,
      managerOnly: false,
    },

    {
      id: 'invoices' as ActiveTab,
      label: 'الفواتير والمطابقة',
      sublabel: 'مراجعة المبالغ ورصد الفروقات',
      icon: FileSpreadsheet,
      badge: invoicePendingCount > 0 ? invoicePendingCount : null,
      managerOnly: false,
    },
    {
      id: 'staff' as ActiveTab,
      label: 'فريق العمل والصلاحيات',
      sublabel: 'المدير التنفيذي ومساعدو المطبخ',
      icon: Users,
      badge: null,
      managerOnly: true,
    },
    {
      id: 'reports' as ActiveTab,
      label: 'التقارير والإحصائيات',
      sublabel: 'تصدير إكسل ومؤشرات الإنجاز',
      icon: BarChart3,
      badge: null,
      managerOnly: true,
    },
    {
      id: 'archive' as ActiveTab,
      label: 'الأرشيف التاريخي',
      sublabel: 'الطلبيات المكتملة والمغلقة',
      icon: Archive,
      badge: null,
      managerOnly: false,
    },
    {
      id: 'audit' as ActiveTab,
      label: 'سجل العمليات والتدقيق',
      sublabel: 'تتبع كافة الحركات والقرارات',
      icon: History,
      badge: null,
      managerOnly: true,
    },
    {
      id: 'guide' as ActiveTab,
      label: 'دليل استخدام النظام',
      sublabel: 'شرح مبسط للأدوار والخطوات',
      icon: BookOpen,
      badge: null,
      managerOnly: false,
    },
  ];

  const handleSelect = (tab: ActiveTab) => {
    setActiveTab(tab);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-stone-950/80 backdrop-blur-sm z-40 lg:hidden"
        />
      )}

      {/* Aside container */}
      <aside
        className={`fixed lg:sticky top-0 lg:top-[57px] right-0 z-40 w-72 lg:w-64 h-full lg:h-[calc(100vh-57px)] bg-stone-900 border-l border-stone-800 flex flex-col transition-transform duration-200 ease-in-out ${
          isOpenMobile ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Mobile Header */}
        <div className="lg:hidden p-4 border-b border-stone-800 flex items-center justify-between">
          <span className="font-bold text-stone-100">أقسام نظام المطبخ</span>
          <button
            onClick={onCloseMobile}
            className="p-1 rounded bg-stone-800 text-stone-400 hover:text-white"
          >
            ✕
          </button>
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            const isRestricted = item.managerOnly && !isManager;

            return (
              <button
                key={item.id}
                onClick={() => !isRestricted && handleSelect(item.id)}
                disabled={isRestricted}
                className={`w-full text-right flex items-center justify-between px-3 py-2.5 rounded-xl transition text-xs group ${
                  isActive
                    ? 'bg-amber-500/15 text-amber-400 font-bold border border-amber-500/25 shadow-sm'
                    : isRestricted
                    ? 'opacity-40 cursor-not-allowed text-stone-500'
                    : 'text-stone-300 hover:bg-stone-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isActive ? 'text-amber-400' : 'text-stone-400 group-hover:text-amber-400'
                    }`}
                  />
                  <div>
                    <div className="leading-tight">{item.label}</div>
                    <div className="text-[10px] text-stone-500 mt-0.5 font-normal">
                      {item.sublabel}
                    </div>
                  </div>
                </div>

                {item.badgeText ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    {item.badgeText}
                  </span>
                ) : item.badge !== null && item.badge > 0 ? (
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                      isActive
                        ? 'bg-amber-500 text-stone-950 font-bold'
                        : 'bg-stone-800 text-stone-300 group-hover:bg-amber-500/20 group-hover:text-amber-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-stone-800 bg-stone-950/40 text-[11px] text-stone-400">
          <div className="flex items-center justify-between mb-1">
            <span className="text-stone-400">وضع التشغيل:</span>
            <span className="font-semibold text-emerald-400">مباشر ومحمي</span>
          </div>
          <div className="text-[10px] text-stone-500 leading-tight">
            نظام متوافق مع PWA ومعايير سلامة الغذاء HACCP
          </div>
        </div>
      </aside>
    </>
  );
};
