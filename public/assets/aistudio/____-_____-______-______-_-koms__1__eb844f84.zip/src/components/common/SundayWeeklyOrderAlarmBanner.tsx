import React, { useState, useEffect, useMemo } from 'react';
import {
  Bell,
  BellRing,
  AlertTriangle,
  Calendar,
  CheckCircle2,
  Clock,
  ShieldAlert,
  Sparkles,
  Volume2,
  VolumeX,
  ChevronDown,
  ChevronUp,
  UserCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface SundayWeeklyOrderAlarmBannerProps {
  onFilterWeeklyOnly?: () => void;
  isWeeklyFilterActive?: boolean;
}

interface SupervisorReviewRecord {
  completed: boolean;
  by: string;
  timestamp: string;
}

export const SundayWeeklyOrderAlarmBanner: React.FC<SundayWeeklyOrderAlarmBannerProps> = ({
  onFilterWeeklyOnly,
  isWeeklyFilterActive,
}) => {
  const { currentUser, isManager } = useAuth();

  // Day simulation for testing & operational demonstration (real by default)
  const [simulatedDay, setSimulatedDay] = useState<'real' | 'sunday' | 'saturday' | 'midweek'>('real');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isExpanded, setIsExpanded] = useState<boolean>(true);

  // Supervisor reviews stored locally per week
  const currentWeekNumber = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + 3 - ((d.getDay() + 6) % 7));
    const week1 = new Date(d.getFullYear(), 0, 4);
    return 1 + Math.round(((d.getTime() - week1.getTime()) / 86400000 - 3 + ((week1.getDay() + 6) % 7)) / 7);
  }, []);

  const storageKey = `koms_weekly_reviews_w${currentWeekNumber}_${new Date().getFullYear()}`;

  const [reviews, setReviews] = useState<{
    review1: SupervisorReviewRecord; // Mid-week review (e.g. Wednesday)
    review2: SupervisorReviewRecord; // Weekend review (Saturday)
  }>(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      review1: { completed: false, by: '', timestamp: '' },
      review2: { completed: false, by: '', timestamp: '' },
    };
  });

  const saveReviews = (updated: typeof reviews) => {
    setReviews(updated);
    try {
      localStorage.setItem(storageKey, JSON.stringify(updated));
    } catch {}
  };

  // Determine current effective day (0 = Sunday, 6 = Saturday, 1..5 = Midweek)
  const effectiveDay = useMemo(() => {
    if (simulatedDay === 'sunday') return 0;
    if (simulatedDay === 'saturday') return 6;
    if (simulatedDay === 'midweek') return 3; // Wednesday
    return new Date().getDay();
  }, [simulatedDay]);

  const isSunday = effectiveDay === 0;
  const isSaturday = effectiveDay === 6;

  // Beep sound effect on Sunday active alarm (synthesized via Web Audio API, safe and dependency-free)
  const playAlarmSound = () => {
    if (!soundEnabled) return;
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime); // A5
      osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } catch {}
  };

  useEffect(() => {
    if (isSunday && soundEnabled) {
      playAlarmSound();
    }
  }, [isSunday, simulatedDay]);

  const handleToggleReview = (reviewKey: 'review1' | 'review2') => {
    const current = reviews[reviewKey];
    const updated = {
      ...reviews,
      [reviewKey]: {
        completed: !current.completed,
        by: !current.completed ? currentUser.name : '',
        timestamp: !current.completed ? new Date().toLocaleDateString('ar-EG', { weekday: 'long', hour: '2-digit', minute: '2-digit' }) : '',
      },
    };
    saveReviews(updated);
  };

  return (
    <div
      className={`rounded-2xl border transition-all duration-300 shadow-xl overflow-hidden mb-4 ${
        isSunday
          ? 'bg-gradient-to-r from-rose-950/80 via-stone-900 to-amber-950/80 border-rose-500/50 ring-2 ring-rose-500/20'
          : isSaturday
          ? 'bg-gradient-to-r from-amber-950/80 via-stone-900 to-amber-950/60 border-amber-500/50 ring-1 ring-amber-500/30'
          : 'bg-stone-900/90 border-stone-800'
      }`}
    >
      {/* Banner Top Header */}
      <div className="p-3 sm:p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex items-start sm:items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-lg ${
              isSunday
                ? 'bg-rose-500 text-white animate-bounce'
                : isSaturday
                ? 'bg-amber-500 text-stone-950 animate-pulse'
                : 'bg-stone-800 text-amber-400'
            }`}
          >
            {isSunday ? <BellRing className="w-5 h-5" /> : <Bell className="w-5 h-5" />}
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={`text-[10px] sm:text-xs font-black uppercase px-2 py-0.5 rounded-full font-mono ${
                  isSunday
                    ? 'bg-rose-500 text-white animate-pulse'
                    : isSaturday
                    ? 'bg-amber-500 text-stone-950'
                    : 'bg-stone-800 text-stone-300'
                }`}
              >
                {isSunday
                  ? '🚨 منبه يوم الأحد الحصري (يوم الطلب)'
                  : isSaturday
                  ? '⚠️ تنبيه اليوم السابق (مراجعة وتحضير)'
                  : '📅 متابعة الطلبيات الأسبوعية'}
              </span>

              <span className="text-xs text-stone-400 font-mono">
                أسبوع العمل #{currentWeekNumber}
              </span>
            </div>

            <h3 className="font-black text-sm sm:text-base text-stone-100 mt-1">
              {isSunday
                ? 'اليوم الأحد: موعد إرسال كافة الطلبيات الأسبوعية لمطبخ نانا الشيخ زايد'
                : isSaturday
                ? 'غداً الأحد موعد طلب الطلبيات الأسبوعية — يرجى إتمام مراجعة المشرفين النهائية'
                : 'الطلبيات الأسبوعية: مراجعة المشرفين مرتين أسبوعياً • الإرسال يوم الأحد فقط'}
            </h3>
          </div>
        </div>

        {/* Action Controls & Simulation Pill */}
        <div className="flex flex-wrap items-center gap-2 self-end md:self-center">
          {/* Audio Chime Button (on Sunday) */}
          {isSunday && (
            <button
              type="button"
              onClick={() => {
                setSoundEnabled(!soundEnabled);
                if (!soundEnabled) playAlarmSound();
              }}
              className={`p-2 rounded-xl border text-xs font-bold transition flex items-center gap-1 ${
                soundEnabled
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30'
                  : 'bg-stone-800 text-stone-400 border-stone-700'
              }`}
              title={soundEnabled ? 'كتم رنين المنبه' : 'تشغيل رنين المنبه'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-rose-400" /> : <VolumeX className="w-4 h-4" />}
            </button>
          )}

          {/* Quick Filter for Weekly Orders */}
          {onFilterWeeklyOnly && (
            <button
              type="button"
              onClick={onFilterWeeklyOnly}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border shadow-sm ${
                isWeeklyFilterActive
                  ? 'bg-amber-500 text-stone-950 border-amber-400'
                  : isSunday
                  ? 'bg-rose-600 hover:bg-rose-500 text-white border-rose-400'
                  : 'bg-stone-800 hover:bg-stone-750 text-stone-200 border-stone-700'
              }`}
            >
              <span>📅</span>
              <span>
                {isWeeklyFilterActive ? 'إلغاء تصفية الأسبوعية' : 'إظهار الطلبيات الأسبوعية (الأحد)'}
              </span>
            </button>
          )}

          {/* Expand/Collapse Toggle */}
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-lg bg-stone-800/80 hover:bg-stone-800 text-stone-400 hover:text-stone-200 border border-stone-700/60"
            title={isExpanded ? 'طي التفاصيل' : 'عرض التفاصيل'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Expanded Details: Two-Times Supervisor Review SOP & Day Simulator */}
      {isExpanded && (
        <div className="px-4 pb-4 pt-1 border-t border-stone-800/70 bg-stone-950/40 space-y-3">
          {/* Core Rule Callout */}
          <div className="bg-stone-900/80 border border-stone-800 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
            <div className="flex items-start sm:items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5 sm:mt-0" />
              <p className="text-stone-300 leading-relaxed">
                <span className="font-bold text-amber-300">النظام التشغيلي الملزم:</span> يجب على جميع المشرفين مراجعة الطلبيات الأسبوعية <span className="underline decoration-amber-400 font-bold">مرتين في الأسبوع</span>، ولكن يتم إرسال وطلب الطلبيات <span className="underline decoration-rose-400 font-bold text-rose-300">مرة واحدة فقط وهو يوم الأحد</span>.
              </p>
            </div>

            {/* Test Simulation Buttons (for instant demonstration & testing on mobile/laptop) */}
            <div className="flex items-center gap-1 bg-stone-950 p-1 rounded-xl border border-stone-800 shrink-0 self-start sm:self-auto">
              <span className="text-[10px] text-stone-500 font-mono px-1">تجربة:</span>
              <button
                type="button"
                onClick={() => setSimulatedDay('real')}
                className={`text-[10px] px-2 py-0.5 rounded-lg font-bold transition ${
                  simulatedDay === 'real' ? 'bg-amber-500 text-stone-950' : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                الفعلي
              </button>
              <button
                type="button"
                onClick={() => setSimulatedDay('sunday')}
                className={`text-[10px] px-2 py-0.5 rounded-lg font-bold transition ${
                  simulatedDay === 'sunday' ? 'bg-rose-500 text-white' : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                الأحد 🚨
              </button>
              <button
                type="button"
                onClick={() => setSimulatedDay('saturday')}
                className={`text-[10px] px-2 py-0.5 rounded-lg font-bold transition ${
                  simulatedDay === 'saturday' ? 'bg-amber-500 text-stone-950' : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                السبت ⚠️
              </button>
              <button
                type="button"
                onClick={() => setSimulatedDay('midweek')}
                className={`text-[10px] px-2 py-0.5 rounded-lg font-bold transition ${
                  simulatedDay === 'midweek' ? 'bg-blue-600 text-white' : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                وسط الأسبوع
              </button>
            </div>
          </div>

          {/* Supervisors Review Checklist Cards (2 Times a Week) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            {/* Review 1: Mid-week */}
            <div
              className={`p-3 rounded-xl border transition flex items-center justify-between ${
                reviews.review1.completed
                  ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-stone-900 border-stone-800 text-stone-300'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                    reviews.review1.completed ? 'bg-emerald-500 text-stone-950' : 'bg-stone-800 text-stone-400'
                  }`}
                >
                  {reviews.review1.completed ? <CheckCircle2 className="w-4 h-4" /> : '1'}
                </div>
                <div>
                  <div className="font-bold">المراجعة الأولى للمشرفين (منتصف الأسبوع - الأربعاء)</div>
                  <div className="text-[10px] text-stone-400 mt-0.5">
                    {reviews.review1.completed
                      ? `تمت المراجعة بواسطة: ${reviews.review1.by} (${reviews.review1.timestamp})`
                      : 'فحص معدل الاستهلاك الأسبوعي ورصد النواقص'}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleToggleReview('review1')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border transition ${
                  reviews.review1.completed
                    ? 'bg-emerald-900/40 text-emerald-300 border-emerald-700/60 hover:bg-emerald-900/60'
                    : 'bg-stone-800 text-amber-300 border-amber-500/30 hover:bg-stone-750'
                }`}
              >
                {reviews.review1.completed ? 'تم الاعتماد ✓' : 'تسجيل المراجعة 1'}
              </button>
            </div>

            {/* Review 2: Saturday / Weekend */}
            <div
              className={`p-3 rounded-xl border transition flex items-center justify-between ${
                reviews.review2.completed
                  ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                  : isSaturday
                  ? 'bg-amber-950/30 border-amber-500/50 text-amber-200'
                  : 'bg-stone-900 border-stone-800 text-stone-300'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                    reviews.review2.completed
                      ? 'bg-emerald-500 text-stone-950'
                      : isSaturday
                      ? 'bg-amber-500 text-stone-950 animate-pulse'
                      : 'bg-stone-800 text-stone-400'
                  }`}
                >
                  {reviews.review2.completed ? <CheckCircle2 className="w-4 h-4" /> : '2'}
                </div>
                <div>
                  <div className="font-bold">المراجعة الثانية للمشرفين (نهاية الأسبوع - السبت)</div>
                  <div className="text-[10px] text-stone-400 mt-0.5">
                    {reviews.review2.completed
                      ? `تمت المراجعة بواسطة: ${reviews.review2.by} (${reviews.review2.timestamp})`
                      : 'التحضير النهائي وإقرار الكميات للإرسال غداً الأحد'}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleToggleReview('review2')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border transition ${
                  reviews.review2.completed
                    ? 'bg-emerald-900/40 text-emerald-300 border-emerald-700/60 hover:bg-emerald-900/60'
                    : 'bg-amber-500 hover:bg-amber-400 text-stone-950 font-black'
                }`}
              >
                {reviews.review2.completed ? 'تم الاعتماد ✓' : 'تسجيل المراجعة 2'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
