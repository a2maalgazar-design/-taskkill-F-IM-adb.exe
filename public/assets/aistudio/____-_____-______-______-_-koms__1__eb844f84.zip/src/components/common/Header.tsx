import React, { useState } from 'react';
import {
  AlertTriangle,
  Bell,
  CheckCircle2,
  ChevronDown,
  Database,
  Plus,
  ShieldCheck,
  UserCheck,
  Users,
  X,
  Fingerprint,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { useNotifications } from '../../features/notifications/context/NotificationProvider';
import { hasLiveFirebaseConfig } from '../../firebase';

interface HeaderProps {
  onOpenNewOrder: () => void;
  onOpenVegOrder?: () => void;
  onOpenColumnarOrders?: () => void;
  onOpenWeeklyArchive?: () => void;
  onOpenChefAdmin?: () => void;
  onOpenMobileMenu: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenNewOrder,
  onOpenVegOrder,
  onOpenColumnarOrders,
  onOpenWeeklyArchive,
  onOpenChefAdmin,
  onOpenMobileMenu,
}) => {
  const { currentUser, users, switchUser, isManager, signInWithGoogle } = useAuth();
  const { notifications, unreadCount, markAsRead, markAllAsRead, lateOrdersCount, lowStockCount } = useNotifications();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <header className="sticky top-0 z-30 bg-stone-900/95 backdrop-blur border-b border-stone-800 px-4 py-3 text-stone-100 flex items-center justify-between">
      {/* Left: Mobile hamburger & Brand */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileMenu}
          className="lg:hidden p-2 rounded-lg bg-stone-800 text-stone-300 hover:text-white"
          aria-label="القائمة"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-600 to-amber-500 flex items-center justify-center shadow-lg shadow-amber-950/40 text-stone-950 font-black text-lg">
            K
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base tracking-tight text-stone-100">نظام طلبيات المطبخ</span>
              <span className="text-[11px] font-mono uppercase bg-amber-500/10 text-amber-400 px-1.5 py-0.5 rounded border border-amber-500/20">
                KOMS PRO
              </span>
            </div>
            <p className="text-[11px] text-stone-400 hidden sm:block">
              إدارة التوريد والمشتريات والفحص المطبخي
            </p>
          </div>
        </div>
      </div>

      {/* Center: Persistent Storage & Security Status */}
      <div className="hidden md:flex items-center gap-2 bg-stone-950/80 px-3 py-1.5 rounded-full border border-stone-800 text-xs">
        <span className="flex h-2 w-2 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
        </span>
        <Database className="w-3.5 h-3.5 text-emerald-400" />
        <span className="text-stone-300 font-medium">
          {hasLiveFirebaseConfig ? 'Cloud Firestore: متصل وحي' : 'قاعدة البيانات: نشطة ومحفوظة'}
        </span>
        <span className="text-stone-500">|</span>
        <span className="text-amber-400 font-mono text-[11px]">
          {hasLiveFirebaseConfig ? 'Live Firebase Sync' : 'Firestore Schema Ready'}
        </span>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-2">
        {/* Quick Weekly Archive Button */}
        {onOpenWeeklyArchive && (
          <button
            onClick={onOpenWeeklyArchive}
            className="hidden sm:flex items-center gap-1.5 bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 px-3 py-2 rounded-xl text-xs font-bold transition"
            title="الملف الأسبوعي للطلبيات والأرشيف التراكمي والطباعة"
          >
            <span>📂</span>
            <span className="hidden lg:inline">الملف الأسبوعي</span>
          </button>
        )}

        {/* Quick Chef Admin Button */}
        {onOpenChefAdmin && isManager && (
          <button
            onClick={onOpenChefAdmin}
            className="hidden xl:flex items-center gap-1.5 bg-stone-800 hover:bg-stone-750 text-amber-400 border border-amber-500/30 px-3 py-2 rounded-xl text-xs font-bold transition"
            title="لوحة إدارة المطبخ للشيف العمومي"
          >
            <span>👨‍🍳</span>
            <span>لوحة الشيف</span>
          </button>
        )}

        {/* Create Order Button */}
        <button
          onClick={onOpenNewOrder}
          className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-450 active:bg-amber-600 text-stone-950 px-3.5 py-2 rounded-xl text-xs font-bold transition shadow-sm hover:shadow"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>طلبية جديدة</span>
        </button>

        {/* Notifications Popover */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 rounded-xl bg-stone-800/80 hover:bg-stone-800 border border-stone-700/60 text-stone-300 hover:text-white transition"
            aria-label="التنبيهات"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-amber-500 text-stone-950 font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute left-0 mt-2 w-80 sm:w-96 bg-stone-900 border border-stone-750 rounded-2xl shadow-2xl p-3 z-50 text-right animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-stone-200">التنبيهات التشغيلية الحية</span>
                  <span className="text-xs text-stone-400 font-mono">
                    ({unreadCount} غير مقروء)
                  </span>
                </div>
                {unreadCount > 0 && (
                  <button
                    onClick={() => markAllAsRead()}
                    className="text-[11px] text-amber-400 hover:text-amber-300 font-medium"
                  >
                    تمييز الكل كمقروء
                  </button>
                )}
              </div>

              {/* Quick Status Chips */}
              {(lateOrdersCount > 0 || lowStockCount > 0) && (
                <div className="flex items-center gap-2 py-2 border-b border-stone-800/80 text-[10px] font-bold">
                  {lateOrdersCount > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                      {lateOrdersCount} طلبيات متأخرة
                    </span>
                  )}
                  {lowStockCount > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {lowStockCount} تنبيهات مخزون حرج
                    </span>
                  )}
                </div>
              )}

              <div className="max-h-80 overflow-y-auto divide-y divide-stone-800/70 mt-1">
                {notifications.length === 0 ? (
                  <p className="text-xs text-stone-400 text-center py-6">لا توجد إشعارات حالياً</p>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => markAsRead(n.id)}
                      className={`p-2.5 rounded-lg transition cursor-pointer text-xs ${
                        n.isRead ? 'opacity-65 hover:bg-stone-800/40' : 'bg-stone-800/60 hover:bg-stone-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          {n.severity === 'critical' ? (
                            <span className="p-1 rounded bg-rose-500/20 text-rose-300">
                              <AlertTriangle className="w-3 h-3" />
                            </span>
                          ) : n.severity === 'warning' ? (
                            <span className="p-1 rounded bg-amber-500/20 text-amber-300">
                              <AlertTriangle className="w-3 h-3" />
                            </span>
                          ) : (
                            <span className="p-1 rounded bg-sky-500/20 text-sky-300">
                              <Bell className="w-3 h-3" />
                            </span>
                          )}
                          <span
                            className={`font-semibold ${
                              n.severity === 'critical'
                                ? 'text-rose-300'
                                : n.severity === 'warning'
                                ? 'text-amber-300'
                                : 'text-stone-200'
                            }`}
                          >
                            {n.title}
                          </span>
                        </div>
                        {!n.isRead && (
                          <span className="w-2 h-2 rounded-full bg-amber-500 inline-block"></span>
                        )}
                      </div>
                      <p className="text-stone-300 mt-1 text-[11px] leading-relaxed">{n.message}</p>
                      <span className="text-[10px] text-stone-500 mt-1 block font-mono">
                        {new Date(n.createdAt).toLocaleTimeString('ar-EG', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Role Switcher Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 bg-stone-800/90 hover:bg-stone-750 border border-stone-700/70 rounded-xl px-2.5 py-1.5 transition text-xs"
          >
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center text-xs border border-amber-500/30">
              {currentUser.name.charAt(0)}
            </div>
            <div className="text-right hidden sm:block">
              <div className="font-semibold text-stone-200 text-xs truncate max-w-[130px]">
                {currentUser.name}
              </div>
              <div className="text-[10px] text-amber-400 font-medium">
                {isManager ? 'مدير المطبخ (Admin)' : 'مساعد مشتريات'}
              </div>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-stone-400" />
          </button>

          {showUserMenu && (
            <div className="absolute left-0 mt-2 w-72 bg-stone-900 border border-stone-750 rounded-2xl shadow-2xl p-2.5 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="px-2 py-1.5 border-b border-stone-800 mb-1.5">
                <p className="text-[11px] text-stone-400">تسجيل الدخول والتبديل (بصمة ورقم المساعد):</p>
                <div className="flex items-center justify-between mt-0.5">
                  <span className="text-xs font-bold text-amber-400">{currentUser.name}</span>
                  {currentUser.role === 'assistant' && (
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.2 rounded font-mono font-bold flex items-center gap-1">
                      <Fingerprint className="w-2.5 h-2.5" />
                      <span>{currentUser.employeeNumber || 'AST-01'}</span>
                    </span>
                  )}
                </div>
              </div>

              <div className="space-y-1">
                {users.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => {
                      switchUser(u.id);
                      setShowUserMenu(false);
                    }}
                    className={`w-full text-right flex items-center justify-between px-2.5 py-2 rounded-xl text-xs transition ${
                      u.id === currentUser.id
                        ? 'bg-amber-500/15 text-amber-300 font-bold border border-amber-500/30'
                        : 'text-stone-300 hover:bg-stone-800'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold">{u.name}</span>
                        {u.employeeNumber && (
                          <span className="text-[9px] font-mono text-stone-400 bg-stone-950 px-1.5 rounded border border-stone-800">
                            {u.employeeNumber}
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-stone-400 flex items-center gap-1 mt-0.5">
                        {u.role === 'manager' ? (
                          'مدير المطبخ (صلاحيات كاملة)'
                        ) : (
                          <>
                            <Fingerprint className="w-3 h-3 text-emerald-400 inline" />
                            <span className="text-emerald-400/90 font-medium">دخول بالبصمة البيومترية 👆</span>
                          </>
                        )}
                      </div>
                    </div>
                    {u.id === currentUser.id && (
                      <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    )}
                  </button>
                ))}
              </div>

              <div className="mt-2 pt-2 border-t border-stone-800 space-y-1.5">
                <button
                  onClick={async () => {
                    try {
                      await signInWithGoogle();
                      setShowUserMenu(false);
                    } catch (e: any) {
                      console.error('Sign-in failed:', e);
                    }
                  }}
                  className="w-full flex items-center justify-center gap-2 bg-stone-800 hover:bg-stone-750 border border-stone-700 text-stone-200 py-1.5 px-3 rounded-xl text-xs font-semibold transition"
                >
                  <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                  <span>تسجيل الدخول عبر Google</span>
                </button>

                <div className="text-[11px] text-stone-400 px-2 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>حساب المدير متصل بـ: a2m.algazar@gmail.com</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
