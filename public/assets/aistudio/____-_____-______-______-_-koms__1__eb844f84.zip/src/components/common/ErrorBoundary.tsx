import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    errorMessage: '',
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, errorMessage: error.message };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('KOMS Runtime Error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white border border-rose-200 rounded-2xl p-6 max-w-md w-full shadow-lg text-center space-y-3">
            <span className="text-3xl">⚠️</span>
            <h2 className="text-base font-bold text-slate-800">حدث خطأ تقني غير متوقع</h2>
            <p className="text-xs text-rose-600 bg-rose-50 p-3 rounded-lg font-mono text-left dir-ltr break-all">
              {this.state.errorMessage || 'Unknown Error'}
            </p>
            <button
              onClick={() => window.location.reload()}
              className="w-full py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition"
            >
              إعادة تحميل التطبيق
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
