import React from 'react';
import { useAuth } from '@/features/auth/components/AuthGuard';

interface AppShellProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const AppShell: React.FC<AppShellProps> = ({ children, activeTab, onTabChange }) => {
  const { user, signOut } = useAuth();

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 text-slate-900">
      {/* شريط الرأس المكتبي والمحماري */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="font-bold text-lg text-slate-900 tracking-tight">KOMS</span>
          <span className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200">
            {user?.role === 'manager' ? 'مدير المطبخ' : 'مساعد تشغيل'}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm font-medium text-slate-700 hidden sm:inline-block">
            {user?.displayName}
          </span>
          <button
            onClick={() => signOut()}
            className="text-xs text-rose-600 hover:text-rose-700 font-semibold ps-2 cursor-pointer"
          >
            خروج
          </button>
        </div>
      </header>

      {/* منطقة المحتوى التفاعلي */}
      <main className="flex-1 pb-20 md:pb-6 p-4 max-w-7xl w-full mx-auto">
        {children}
      </main>

      {/* شريط الملاحة السفلي المخصص للأجهزة المحمولة */}
      <nav className="fixed bottom-0 inset-x-0 bg-white border-t border-slate-200 md:hidden z-30 flex justify-around py-2">
        <button
          onClick={() => onTabChange('orders')}
          className={`flex flex-col items-center text-xs py-1 px-3 rounded-lg ${
            activeTab === 'orders' ? 'text-slate-900 font-bold' : 'text-slate-400'
          }`}
        >
          <span>الطلبات</span>
        </button>
        <button
          onClick={() => onTabChange('catalog')}
          className={`flex flex-col items-center text-xs py-1 px-3 rounded-lg ${
            activeTab === 'catalog' ? 'text-slate-900 font-bold' : 'text-slate-400'
          }`}
        >
          <span>الأصناف</span>
        </button>
        <button
          onClick={() => onTabChange('receiving')}
          className={`flex flex-col items-center text-xs py-1 px-3 rounded-lg ${
            activeTab === 'receiving' ? 'text-slate-900 font-bold' : 'text-slate-400'
          }`}
        >
          <span>الاستلام</span>
        </button>
      </nav>
    </div>
  );
};

export default AppShell;
