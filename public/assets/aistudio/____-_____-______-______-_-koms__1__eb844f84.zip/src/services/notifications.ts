import { NotificationService } from '../features/notifications/services/NotificationService';
import { AppNotification, NotificationSeverity, NotificationType } from '../features/notifications/types';

export const subscribeToAlerts = NotificationService.subscribeToAlerts.bind(NotificationService);
export const notificationService = NotificationService;
export { NotificationService };
export type { AppNotification, NotificationSeverity, NotificationType };
