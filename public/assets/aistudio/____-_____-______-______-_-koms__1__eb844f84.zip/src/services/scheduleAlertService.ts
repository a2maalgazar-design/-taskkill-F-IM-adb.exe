import {
  ActualOrder,
  AppNotification,
  ManagerAlertSettings,
  MasterOrderSchedule,
  OrderType,
  ScheduleAlertLog,
  Supplier,
  User,
} from '../types';
import { dbService } from './databaseService';

const SETTINGS_KEY = 'koms_manager_alert_settings';
const LOGS_KEY = 'koms_schedule_alert_logs';

export const DEFAULT_MANAGER_ALERT_SETTINGS: ManagerAlertSettings = {
  enabled: true,
  managerEmail: 'a2m.algazar@gmail.com',
  managerName: 'أحمد الجزار (مدير المطبخ والمشتريات)',
  sendInApp: true,
  sendEmail: true,
  autoCheckOnWorkday: true,
  checkCutoffTime: '10:00',
  lastAuditTimestamp: undefined,
};

export interface MissedScheduleItem {
  schedule: MasterOrderSchedule;
  categoryName: string;
  supplierName: string;
  assigneeName: string;
  scheduledTime: string;
  isPastCutoff: boolean;
  delayText: string;
}

export const scheduleAlertService = {
  getSettings(): ManagerAlertSettings {
    try {
      const stored = localStorage.getItem(SETTINGS_KEY);
      if (stored) {
        return { ...DEFAULT_MANAGER_ALERT_SETTINGS, ...JSON.parse(stored) };
      }
    } catch (e) {
      console.warn('Failed to read manager alert settings from storage:', e);
    }
    return { ...DEFAULT_MANAGER_ALERT_SETTINGS };
  },

  saveSettings(settings: ManagerAlertSettings): void {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save manager alert settings:', e);
    }
  },

  getAlertLogs(): ScheduleAlertLog[] {
    try {
      const stored = localStorage.getItem(LOGS_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Failed to read schedule alert logs:', e);
    }
    return [];
  },

  saveAlertLog(log: ScheduleAlertLog): void {
    try {
      const existing = this.getAlertLogs();
      const updated = [log, ...existing].slice(0, 50); // Keep last 50 logs
      localStorage.setItem(LOGS_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save alert log:', e);
    }
  },

  clearAlertLogs(): void {
    try {
      localStorage.removeItem(LOGS_KEY);
    } catch (e) {
      console.error('Failed to clear alert logs:', e);
    }
  },

  isScheduleDueToday(schedule: MasterOrderSchedule, targetDate?: string): boolean {
    if (!schedule.isActive) return false;

    const date = targetDate ? new Date(targetDate) : new Date();
    const dayOfWeek = date.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday

    if (schedule.daysOfWeek && schedule.daysOfWeek.length > 0) {
      return schedule.daysOfWeek.includes(dayOfWeek);
    }

    if (schedule.recurrenceRule === 'daily') {
      return true;
    }

    // Match Arabic days
    const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const currentDayName = dayNames[dayOfWeek];

    if (schedule.orderingDay) {
      if (schedule.orderingDay.includes('يومي') || schedule.orderingDay.includes('يوميا')) {
        return true;
      }
      if (schedule.orderingDay.includes(currentDayName)) {
        return true;
      }
    }

    // Default to true if not specified
    return true;
  },

  getMissedSchedules(
    schedules: MasterOrderSchedule[],
    orders: ActualOrder[],
    orderTypes: OrderType[] = [],
    suppliers: Supplier[] = [],
    users: User[] = [],
    targetDate?: string
  ): MissedScheduleItem[] {
    const today = targetDate ? new Date(targetDate) : new Date();
    const dateStr = today.toISOString().split('T')[0];
    const currentHours = today.getHours();
    const currentMinutes = today.getMinutes();
    const currentTimeVal = currentHours * 60 + currentMinutes;

    const missedList: MissedScheduleItem[] = [];

    for (const schedule of schedules) {
      // Must be active and not explicitly opted out of alerts
      if (!schedule.isActive) continue;
      if (schedule.alertIfMissed === false) continue;

      // Check if due today
      if (!this.isScheduleDueToday(schedule, dateStr)) continue;

      // Check if order was generated today
      const alreadyGenerated = orders.some(
        (o) =>
          (o.masterScheduleId === schedule.id || (o as any).scheduleId === schedule.id) &&
          o.orderDate === dateStr &&
          !o.isArchived
      );

      if (alreadyGenerated || schedule.lastGeneratedDate === dateStr) {
        continue;
      }

      // Check scheduled time and delay
      const schedTimeStr = schedule.orderingTime || '08:00';
      const [sh, sm] = schedTimeStr.split(':').map(Number);
      const schedTimeVal = (isNaN(sh) ? 8 : sh) * 60 + (isNaN(sm) ? 0 : sm);

      const cutoffStr = schedule.alertCutoffTime || '10:00';
      const [ch, cm] = cutoffStr.split(':').map(Number);
      const cutoffTimeVal = (isNaN(ch) ? 10 : ch) * 60 + (isNaN(cm) ? 0 : cm);

      const isPastCutoff = currentTimeVal >= schedTimeVal || currentTimeVal >= cutoffTimeVal;
      const delayMinutes = Math.max(0, currentTimeVal - schedTimeVal);
      const delayHours = Math.floor(delayMinutes / 60);
      const remainingMinutes = delayMinutes % 60;

      let delayText = 'مستحق اليوم';
      if (isPastCutoff && delayMinutes > 0) {
        if (delayHours > 0) {
          delayText = `متأخر بمقدار ${delayHours} س ${remainingMinutes > 0 ? `و ${remainingMinutes} د` : ''}`;
        } else {
          delayText = `متأخر بمقدار ${remainingMinutes} دقيقة`;
        }
      }

      const category = orderTypes.find((c) => c.id === schedule.orderTypeId);
      const supplier = suppliers.find((s) => s.id === schedule.supplierId);
      const assignee = users.find((u) => u.id === schedule.primaryAssigneeId);

      missedList.push({
        schedule,
        categoryName: category?.nameAr || schedule.orderTypeId,
        supplierName: supplier?.name || supplier?.nameAr || 'غير محدد (TBD)',
        assigneeName: assignee?.name || 'مساعد تشغيل',
        scheduledTime: schedTimeStr,
        isPastCutoff,
        delayText,
      });
    }

    return missedList;
  },

  generateEmailContent(
    missedItems: MissedScheduleItem[],
    settings: ManagerAlertSettings,
    dateStr: string
  ): { subject: string; html: string; text: string; mailtoUrl: string } {
    const count = missedItems.length;
    const subject = `⚠️ [تنبيه عاجل - KOMS] عدم توليد طلبات تلقائية لـ (${count}) جداول توريد اليوم (${dateStr})`;

    const itemsRowsHtml = missedItems
      .map(
        (item, index) => `
      <tr style="border-bottom: 1px solid #e2e8f0; ${index % 2 === 0 ? 'background-color: #f8fafc;' : ''}">
        <td style="padding: 10px 12px; font-weight: bold; color: #0f172a;">${item.schedule.name}</td>
        <td style="padding: 10px 12px; color: #d97706; font-weight: 600;">${item.categoryName}</td>
        <td style="padding: 10px 12px; color: #334155;">${item.supplierName}</td>
        <td style="padding: 10px 12px; font-family: monospace; color: #dc2626; font-weight: bold;">${item.scheduledTime}</td>
        <td style="padding: 10px 12px; color: #475569;">${item.assigneeName}</td>
        <td style="padding: 10px 12px; color: #b91c1c; font-size: 12px;">${item.delayText}</td>
      </tr>`
      )
      .join('');

    const html = `
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="utf-8">
      <title>${subject}</title>
    </head>
    <body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f1f5f9; margin: 0; padding: 24px; direction: rtl; text-align: right; color: #1e293b;">
      <div style="max-width: 680px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 16px rgba(0,0,0,0.08); border: 1px solid #e2e8f0;">
        
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #0c0a09 0%, #1c1917 100%); color: #ffffff; padding: 24px 28px; border-bottom: 3px solid #f59e0b;">
          <div style="display: flex; align-items: center; justify-content: space-between;">
            <div>
              <span style="background: #f59e0b; color: #000; font-size: 11px; font-weight: 900; padding: 3px 8px; border-radius: 6px; letter-spacing: 1px;">KOMS PRO</span>
              <h1 style="margin: 8px 0 4px; font-size: 20px; font-weight: 800; color: #f8fafc;">تنبيه تشغيلي: جداول توريد لم تولد طلباتها</h1>
              <p style="margin: 0; font-size: 12px; color: #cbd5e1;">نظام إدارة وتنسيق طلبيات المطبخ والمشتريات المركزية</p>
            </div>
            <div style="font-size: 28px;">⚠️</div>
          </div>
        </div>

        <!-- Body -->
        <div style="padding: 24px 28px;">
          <p style="font-size: 14px; margin-top: 0; color: #334155;">
            عزيزي <strong>${settings.managerName}</strong>،
          </p>
          <div style="background: #fffbeb; border: 1px solid #fde68a; border-right: 4px solid #f59e0b; padding: 14px 16px; border-radius: 8px; margin-bottom: 20px;">
            <p style="margin: 0; font-size: 13px; line-height: 1.6; color: #92400e;">
              يرجى الإحاطة بأنه حتى توقيت هذا الإشعار خلال يوم العمل بتاريخ <strong>${dateStr}</strong>، <strong>لم يتم توليد أو إصدار طلبيات الشراء الفعلية</strong> لـ <strong>(${count})</strong> من جداول التوريد الدورية المعتمدة في المطبخ.
            </p>
          </div>

          <h3 style="font-size: 14px; font-weight: 700; color: #0f172a; margin: 18px 0 10px;">
            📋 بيان الجداول المتأخرة عن التوليد:
          </h3>

          <table style="width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 24px; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden;">
            <thead>
              <tr style="background: #f1f5f9; color: #475569; text-align: right;">
                <th style="padding: 10px 12px; font-size: 12px;">اسم الجدول</th>
                <th style="padding: 10px 12px; font-size: 12px;">الفئة</th>
                <th style="padding: 10px 12px; font-size: 12px;">المورد المقترح</th>
                <th style="padding: 10px 12px; font-size: 12px;">موعد الطلب</th>
                <th style="padding: 10px 12px; font-size: 12px;">المسؤول</th>
                <th style="padding: 10px 12px; font-size: 12px;">الحالة</th>
              </tr>
            </thead>
            <tbody>
              ${itemsRowsHtml}
            </tbody>
          </table>

          <div style="background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 10px; padding: 14px 18px; margin-bottom: 24px;">
            <h4 style="margin: 0 0 6px; font-size: 12px; color: #475569; font-weight: 700;">الأثر التشغيلي المحتمل:</h4>
            <ul style="margin: 0; padding-right: 20px; font-size: 12px; color: #64748b; line-height: 1.7;">
              <li>تأخر توريد الخضروات والمخبوزات واللحوم الطازجة قبل بدء تجهيزات ورديات الطهي.</li>
              <li>تفويت نوافذ الاستلام والفحص لدرجات الحرارة وضمان الجودة.</li>
              <li>احتمالية تعطل خدمة المطعم أو اللجوء للشراء الطارئ بتكلفة أعلى.</li>
            </ul>
          </div>

          <div style="text-align: center; margin: 28px 0 12px;">
            <a href="#" style="background: #f59e0b; color: #0c0a09; text-decoration: none; font-weight: 800; font-size: 13px; padding: 12px 28px; border-radius: 10px; display: inline-block; box-shadow: 0 2px 8px rgba(245,158,11,0.3);">
              الدخول لنظام KOMS وتوليد الطلبيات فوراً
            </a>
          </div>
        </div>

        <!-- Footer -->
        <div style="background: #f8fafc; border-top: 1px solid #e2e8f0; padding: 14px 28px; font-size: 11px; color: #94a3b8; text-align: center;">
          تم إرسال هذا التنبيه التلقائي المبرمج إلى المدير المسؤول (${settings.managerEmail}) عبر نظام KOMS.<br>
          Kitchen Order Management System &copy; 2026
        </div>
      </div>
    </body>
    </html>
    `;

    const text = `
تنبيه تشغيلي عاجل - نظام KOMS
تاريخ يوم العمل: ${dateStr}
إلى: ${settings.managerName} (${settings.managerEmail})

الموضوع: عدم توليد طلبات تلقائية لـ (${count}) جداول توريد دورية خلال يوم العمل

بيان الجداول التي لم تُولّد طلباتها حتى الآن:
${missedItems
  .map(
    (item, idx) =>
      `${idx + 1}. [${item.categoryName}] ${item.schedule.name}
   - المورد: ${item.supplierName}
   - موعد الطلب المعتاد: ${item.scheduledTime}
   - المسؤول المكلف: ${item.assigneeName}
   - التأخير: ${item.delayText}`
  )
  .join('\n\n')}

توصية النظام:
يرجى فتح نظام طلبيات المطبخ ومراجعة شاشة الجداول الدورية وتوليد الطلبيات يدوياً أو التنسيق مع المساعدين المسؤولين فوراً لتجنب نقص الإمدادات الطازجة في المطبخ.
    `.trim();

    const mailtoSubject = encodeURIComponent(subject);
    const mailtoBody = encodeURIComponent(text);
    const mailtoUrl = `mailto:${encodeURIComponent(settings.managerEmail)}?subject=${mailtoSubject}&body=${mailtoBody}`;

    return { subject, html, text, mailtoUrl };
  },

  async triggerMissedScheduleAlerts(
    missedItems: MissedScheduleItem[],
    options: {
      currentUser: User;
      createNotification: (notif: Omit<AppNotification, 'id' | 'createdAt' | 'isRead'>) => Promise<void>;
      targetDate?: string;
      customEmail?: string;
    }
  ): Promise<{
    success: boolean;
    count: number;
    log: ScheduleAlertLog;
    mailtoUrl: string;
  }> {
    const settings = this.getSettings();
    const todayStr = options.targetDate || new Date().toISOString().split('T')[0];
    const targetEmail = options.customEmail || settings.managerEmail || options.currentUser.email || 'a2m.algazar@gmail.com';
    const managerName = settings.managerName || options.currentUser.name || 'مدير المطبخ والمشتريات';

    const { subject, html, text, mailtoUrl } = this.generateEmailContent(
      missedItems,
      { ...settings, managerEmail: targetEmail, managerName },
      todayStr
    );

    const channels: ('in_app' | 'email')[] = [];

    // 1. In-App Notification
    if (settings.sendInApp) {
      channels.push('in_app');
      const missedNames = missedItems.map((i) => i.schedule.name).join('، ');
      await options.createNotification({
        recipientId: options.currentUser.role === 'manager' ? options.currentUser.id : 'user-manager-01',
        type: 'SCHEDULE_MISSED',
        scheduleId: missedItems[0]?.schedule?.id,
        title: `⚠️ تنبيه عدم توليد طلبات تلقائية (${missedItems.length} جداول اليوم)`,
        message: `لم يتم توليد طلبيات المطبخ لـ (${missedItems.length}) جداول توريد مستحقة اليوم: [${missedNames}]. تم إرسال تنبيه بريدي إلى ${targetEmail}.`,
      });
    }

    // 2. Email Channel
    if (settings.sendEmail) {
      channels.push('email');
    }

    // 3. Web Notification API (Browser push simulation)
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(`⚠️ تنبيه المطبخ: ${missedItems.length} جداول لم تولد طلباتها اليوم`, {
          body: `تنبيه مرسل إلى ${targetEmail}: يرجى فتح KOMS والموافقة على التوريد.`,
          icon: '/favicon.ico',
        });
      } catch (err) {
        console.warn('Browser desktop notification skipped:', err);
      }
    }

    // 4. Audit Log
    await dbService.logAudit({
      userId: options.currentUser.id,
      userName: options.currentUser.name,
      action: 'ALERT_SENT',
      entityType: 'ALERT',
      entityId: `alert-${Date.now()}`,
      details: `إرسال تنبيه إداري بريدي ونظامي للمدير (${targetEmail}) بشأن ${missedItems.length} جداول لم تولد اليوم`,
    });

    // 5. Save Alert Log Record
    const log: ScheduleAlertLog = {
      id: `alert-log-${Date.now()}`,
      date: todayStr,
      timestamp: new Date().toISOString(),
      managerEmail: targetEmail,
      managerName,
      channels,
      missedSchedules: missedItems.map((item) => ({
        id: item.schedule.id,
        name: item.schedule.name || item.categoryName || 'طلبية مجدولة',
        orderTypeId: item.schedule.orderTypeId,
        orderTypeName: item.categoryName,
        orderingTime: item.scheduledTime,
        supplierName: item.supplierName,
        assigneeName: item.assigneeName,
      })),
      subject,
      emailContentHtml: html,
      emailContentText: text,
      status: 'sent',
    };

    this.saveAlertLog(log);

    // Update settings last audit
    this.saveSettings({
      ...settings,
      lastAuditTimestamp: new Date().toISOString(),
    });

    return {
      success: true,
      count: missedItems.length,
      log,
      mailtoUrl,
    };
  },

  async sendTestAlert(
    options: {
      currentUser: User;
      targetEmail: string;
      createNotification: (notif: Omit<AppNotification, 'id' | 'createdAt' | 'isRead'>) => Promise<void>;
    }
  ): Promise<{ success: boolean; log: ScheduleAlertLog; mailtoUrl: string }> {
    const dummyMissed: MissedScheduleItem = {
      schedule: {
        id: 'test-sched-demo',
        name: 'توريد الخضروات الورقية والدرنية اليومي (تجريبي)',
        orderTypeId: 'cat-veg',
        primaryAssigneeId: options.currentUser.id,
        orderingDay: 'يومي',
        orderingTime: '07:00',
        requiredDeliveryHours: 4,
        purchasingChannel: 'واتساب',
        requiresApproval: false,
        recurrenceRule: 'daily',
        isActive: true,
        createdAt: new Date().toISOString(),
      },
      categoryName: 'الخضار',
      supplierName: 'مزارع الوادي للخضروات الطازجة',
      assigneeName: options.currentUser.name,
      scheduledTime: '07:00 ص',
      isPastCutoff: true,
      delayText: 'فحص تجريبي لآلية التنبيه',
    };

    const res = await this.triggerMissedScheduleAlerts([dummyMissed], {
      currentUser: options.currentUser,
      createNotification: options.createNotification,
      customEmail: options.targetEmail,
    });

    return {
      success: true,
      log: res.log,
      mailtoUrl: res.mailtoUrl,
    };
  },
};
