import { 
  signInWithPopup, 
  signInWithEmailAndPassword, 
  signOut as fbSignOut, 
  User 
} from 'firebase/auth';
import { 
  doc, 
  runTransaction, 
  getDoc, 
  serverTimestamp, 
  collection, 
  getDocs, 
  limit, 
  query 
} from 'firebase/firestore';
import { auth, googleProvider, db } from '../firebase';
import { UserProfile, ROLE_PERMISSIONS_PRESETS } from '../types';

export const authService = {
  async signInWithGoogle(): Promise<UserProfile> {
    const cred = await signInWithPopup(auth, googleProvider);
    return this.syncUserProfile(cred.user);
  },

  async syncUserProfile(user: User): Promise<UserProfile> {
    const userRef = doc(db, 'users', user.uid);

    return await runTransaction(db, async (transaction) => {
      const userSnapshot = await transaction.get(userRef);

      if (userSnapshot.exists()) {
        const existingData = userSnapshot.data() as UserProfile;
        transaction.update(userRef, {
          lastLoginAt: serverTimestamp(),
        });
        return existingData;
      }

      // فحص أولي لتحديد ما إذا كان هذا المستخدم هو الأول في النظام
      const usersCol = collection(db, 'users');
      const existingUsersSnap = await getDocs(query(usersCol, limit(1)));
      const isFirstUser = existingUsersSnap.empty;

      const assignedRole = isFirstUser ? 'manager' : 'assistant';
      const newProfile: UserProfile = {
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || 'مستخدم جديد',
        role: assignedRole,
        permissions: ROLE_PERMISSIONS_PRESETS[assignedRole],
        isActive: true,
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      };

      transaction.set(userRef, {
        ...newProfile,
        createdAt: serverTimestamp(),
        lastLoginAt: serverTimestamp(),
      });

      return newProfile;
    });
  },

  async signOut(): Promise<void> {
    await fbSignOut(auth);
  },
};

export default authService;
