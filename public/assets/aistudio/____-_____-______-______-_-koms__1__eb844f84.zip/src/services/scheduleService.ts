import {
  collection,
  doc,
  getDocs,
  addDoc,
  updateDoc,
  query,
  where,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { MasterSchedule, GenerationSummary, ActualOrder } from '../types';

export const scheduleService = {
  async getSchedules(): Promise<MasterSchedule[]> {
    const colRef = collection(db, 'schedules');
    const snap = await getDocs(query(colRef, where('isActive', '==', true)));
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as MasterSchedule));
  },

  async saveSchedule(schedule: Partial<MasterSchedule> & { id?: string }): Promise<string> {
    if (schedule.id) {
      const docRef = doc(db, 'schedules', schedule.id);
      await updateDoc(docRef, {
        ...schedule,
        updatedAt: serverTimestamp(),
      });
      return schedule.id;
    } else {
      const colRef = collection(db, 'schedules');
      const docRef = await addDoc(colRef, {
        ...schedule,
        isActive: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      return docRef.id;
    }
  },

  async deleteSchedule(id: string): Promise<void> {
    const docRef = doc(db, 'schedules', id);
    await updateDoc(docRef, {
      isActive: false,
      updatedAt: serverTimestamp(),
    });
  },

  async generateDailyOrders(targetDate?: string): Promise<GenerationSummary> {
    const today = targetDate ? new Date(targetDate) : new Date();
    const dateStr = today.toISOString().split('T')[0];
    const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday

    const schedules = await this.getSchedules();
    const matchingSchedules = schedules.filter(s => 
      s.isActive && (s.daysOfWeek ? s.daysOfWeek.includes(dayOfWeek) : true)
    );

    const generatedOrderIds: string[] = [];
    let skippedCount = 0;

    for (const schedule of matchingSchedules) {
      try {
        const ordersCol = collection(db, 'orders');
        // Check if an order already exists for this schedule on this date
        const existingQuery = query(
          ordersCol,
          where('scheduleId', '==', schedule.id),
          where('orderDate', '==', dateStr)
        );
        const existingSnap = await getDocs(existingQuery);

        if (!existingSnap.empty) {
          skippedCount++;
          continue;
        }

        const items = (schedule.itemTemplates || []).map((template, idx) => ({
          id: `item-${Date.now()}-${idx}`,
          productId: template.productId,
          productName: template.productNameAr,
          requestedQty: template.defaultRequestedQty || 1,
          unit: template.unit || 'كجم',
        }));

        const newOrder: Partial<ActualOrder> = {
          orderNumber: `ORD-${Date.now().toString().slice(-6)}`,
          scheduleId: schedule.id,
          orderTypeId: schedule.orderTypeId,
          supplierId: schedule.supplierId,
          orderDate: dateStr,
          status: 'DUE',
          items: items as any,
          notes: schedule.title || 'طلب مجدول دوري',
        };

        const docRef = await addDoc(ordersCol, {
          ...newOrder,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        generatedOrderIds.push(docRef.id);
      } catch {
        skippedCount++;
      }
    }

    return {
      date: dateStr,
      generatedCount: generatedOrderIds.length,
      skippedCount,
      orderIds: generatedOrderIds,
    };
  }
};

export default scheduleService;
