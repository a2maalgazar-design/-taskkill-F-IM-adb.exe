import { 
  collection, 
  doc, 
  getDocs, 
  setDoc, 
  addDoc, 
  updateDoc, 
  query, 
  where, 
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { OrderType, Product, Supplier, SYSTEM_ORDER_TYPES } from '../types';

export const catalogService = {
  // زرع التصنيفات العشرة النظامية فقط في حال عدم وجودها
  async ensureSeedOrderTypes(): Promise<void> {
    const colRef = collection(db, 'orderTypes');
    const existingSnap = await getDocs(colRef);
    
    if (existingSnap.empty) {
      for (const item of SYSTEM_ORDER_TYPES) {
        const docRef = doc(colRef, item.code);
        await setDoc(docRef, {
          code: item.code,
          nameAr: item.nameAr,
          isActive: true,
          createdAt: serverTimestamp(),
        });
      }
    }
  },

  async getOrderTypes(): Promise<OrderType[]> {
    const snap = await getDocs(collection(db, 'orderTypes'));
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as OrderType));
  },

  async getProducts(orderTypeId?: string): Promise<Product[]> {
    const colRef = collection(db, 'products');
    const q = orderTypeId 
      ? query(colRef, where('orderTypeId', '==', orderTypeId), where('isActive', '==', true))
      : query(colRef, where('isActive', '==', true));
    
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as Product));
  },

  async addProduct(product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const colRef = collection(db, 'products');
    const docRef = await addDoc(colRef, {
      ...product,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docRef.id;
  },

  async updateProduct(id: string, updates: Partial<Product>): Promise<void> {
    const docRef = doc(db, 'products', id);
    await updateDoc(docRef, {
      ...updates,
      updatedAt: serverTimestamp(),
    });
  },

  async deleteProduct(id: string): Promise<void> {
    const docRef = doc(db, 'products', id);
    await updateDoc(docRef, {
      isActive: false,
      updatedAt: serverTimestamp(),
    });
  },

  async getSuppliers(orderTypeId?: string): Promise<Supplier[]> {
    const colRef = collection(db, 'suppliers');
    const q = orderTypeId
      ? query(colRef, where('orderTypeIds', 'array-contains', orderTypeId), where('isActive', '==', true))
      : query(colRef, where('isActive', '==', true));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as Supplier));
  },

  async addSupplier(supplier: Omit<Supplier, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const colRef = collection(db, 'suppliers');
    const docRef = await addDoc(colRef, {
      ...supplier,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docRef.id;
  },

  async updateSupplier(id: string, updates: Partial<Supplier>): Promise<void> {
    const docRef = doc(db, 'suppliers', id);
    await updateDoc(docRef, {
      ...updates,
      updatedAt: serverTimestamp(),
    });
  },

  async deleteSupplier(id: string): Promise<void> {
    const docRef = doc(db, 'suppliers', id);
    await updateDoc(docRef, {
      isActive: false,
      updatedAt: serverTimestamp(),
    });
  }
};

export default catalogService;
