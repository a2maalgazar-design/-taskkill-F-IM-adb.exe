import {
  ActualOrder,
  AppNotification,
  AuditLog,
  InvoiceRecord,
  MasterOrderSchedule,
  OrderType,
  Product,
  ReceivingRecord,
  Supplier,
  SystemPhoneSettings,
  User,
  WorkflowStatus,
} from '../types';
import { INITIAL_ORDER_TYPES, INITIAL_PRODUCTS, INITIAL_USERS, INITIAL_SUPPLIERS, INITIAL_SCHEDULES, DEFAULT_PHONE_SETTINGS } from './seedData';
import { hasLiveFirebaseConfig } from '../firebase';

const DB_NAME = 'koms_kitchen_db';
const DB_VERSION = 1;

interface KOMSStores {
  users: User;
  orderTypes: OrderType;
  products: Product;
  schedules: MasterOrderSchedule;
  orders: ActualOrder;
  suppliers: Supplier;
  receivingRecords: ReceivingRecord;
  invoices: InvoiceRecord;
  notifications: AppNotification;
  auditLogs: AuditLog;
  metadata: { key: string; value: any };
}

class KitchenDatabase {
  private dbPromise: Promise<IDBDatabase> | null = null;
  private isFirebaseConfigured: boolean = false;
  private firebaseDbInstance: any = null;

  constructor() {
    this.init();
  }

  private init(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event: any) => {
        const db = request.result;

        const createStore = (name: string, keyPath: string = 'id') => {
          if (!db.objectStoreNames.contains(name)) {
            db.createObjectStore(name, { keyPath });
          }
        };

        createStore('users');
        createStore('orderTypes');
        createStore('products');
        createStore('schedules');
        createStore('orders');
        createStore('suppliers');
        createStore('receivingRecords');
        createStore('invoices');
        createStore('notifications');
        createStore('auditLogs');
        createStore('metadata', 'key');
      };

      request.onsuccess = async () => {
        const db = request.result;
        // Verify initial seed
        await this.ensureInitialSeed(db);
        resolve(db);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });

    return this.dbPromise;
  }

  private async ensureInitialSeed(db: IDBDatabase) {
    const tx = db.transaction(['orderTypes', 'users', 'products', 'suppliers', 'metadata'], 'readwrite');
    const typesStore = tx.objectStore('orderTypes');
    const usersStore = tx.objectStore('users');
    const prodStore = tx.objectStore('products');
    const supStore = tx.objectStore('suppliers');
    const metaStore = tx.objectStore('metadata');

    const countReq = typesStore.count();
    countReq.onsuccess = () => {
      if (countReq.result === 0) {
        // Seed categories
        INITIAL_ORDER_TYPES.forEach((item) => typesStore.put(item));
        // Seed users
        INITIAL_USERS.forEach((u) => usersStore.put(u));
        // Seed 24 TBD vegetables
        INITIAL_PRODUCTS.forEach((p) => prodStore.put(p));
        // Seed initial approved suppliers
        INITIAL_SUPPLIERS.forEach((s) => supStore.put(s));
        // Seed order counter
        metaStore.put({ key: 'order_seq_counter', value: 100 });
      }
    };
  }

  // --- Generic Helpers ---
  private async getAll<T>(storeName: keyof KOMSStores): Promise<T[]> {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName as string, 'readonly');
      const store = tx.objectStore(storeName as string);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result as T[]);
      req.onerror = () => reject(req.error);
    });
  }

  private async getById<T>(storeName: keyof KOMSStores, id: string): Promise<T | null> {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName as string, 'readonly');
      const store = tx.objectStore(storeName as string);
      const req = store.get(id);
      req.onsuccess = () => resolve((req.result as T) || null);
      req.onerror = () => reject(req.error);
    });
  }

  private async putItem<T>(storeName: keyof KOMSStores, item: T): Promise<void> {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName as string, 'readwrite');
      const store = tx.objectStore(storeName as string);
      const req = store.put(item);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  private async removeItem(storeName: keyof KOMSStores, id: string): Promise<void> {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName as string, 'readwrite');
      const store = tx.objectStore(storeName as string);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // --- Orders ---
  public async getOrders(includeArchived: boolean = false): Promise<ActualOrder[]> {
    const orders = await this.getAll<ActualOrder>('orders');
    return orders
      .filter((o) => (includeArchived ? true : !o.isArchived))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public async getOrderById(id: string): Promise<ActualOrder | null> {
    return this.getById<ActualOrder>('orders', id);
  }

  public async generateNextOrderId(): Promise<string> {
    const db = await this.init();
    return new Promise((resolve) => {
      const tx = db.transaction('metadata', 'readwrite');
      const store = tx.objectStore('metadata');
      const req = store.get('order_seq_counter');
      req.onsuccess = () => {
        const current = (req.result && req.result.value) || 100;
        const next = current + 1;
        store.put({ key: 'order_seq_counter', value: next });
        const currentYear = new Date().getFullYear();
        const formatted = `KOMS-${currentYear}-${String(next).padStart(5, '0')}`;
        resolve(formatted);
      };
      req.onerror = () => {
        const random = Math.floor(10000 + Math.random() * 90000);
        resolve(`KOMS-${new Date().getFullYear()}-${random}`);
      };
    });
  }

  public async createOrder(order: ActualOrder, currentUser: User): Promise<void> {
    await this.putItem('orders', order);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'CREATE',
      entityType: 'ORDER',
      entityId: order.id,
      details: `إنشاء طلبية جديدة برقم ${order.id} للأصناف المعنية (${order.items.length} صنف)`,
    });

    // Notify assigned assistant
    if (order.primaryAssigneeId) {
      await this.createNotification({
        recipientId: order.primaryAssigneeId,
        type: 'ASSIGNMENT',
        orderId: order.id,
        title: 'تم إسناد طلبية جديدة لك',
        message: `تم تكليفك بتنفيذ ومتابعة الطلبية رقم ${order.id}`,
      });
    }
  }

  public async updateOrder(
    order: ActualOrder,
    currentUser: User,
    changeNote?: string
  ): Promise<void> {
    order.updatedAt = new Date().toISOString();
    await this.putItem('orders', order);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'ORDER',
      entityId: order.id,
      details: changeNote || `تحديث بيانات الطلبية ${order.id}`,
    });
  }

  public async updateOrderStatus(
    orderId: string,
    newStatus: WorkflowStatus,
    currentUser: User,
    note?: string
  ): Promise<void> {
    const order = await this.getOrderById(orderId);
    if (!order) throw new Error(`الطلبية ${orderId} غير موجودة`);

    const prevStatus = order.status;
    order.status = newStatus;
    order.updatedAt = new Date().toISOString();

    const historyEntry = {
      status: newStatus,
      changedBy: currentUser.id,
      changedByName: currentUser.name,
      timestamp: new Date().toISOString(),
      note: note || '',
    };
    order.statusHistory = [...(order.statusHistory || []), historyEntry];

    await this.putItem('orders', order);

    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'STATUS_CHANGE',
      entityType: 'ORDER',
      entityId: order.id,
      details: `تغيير حالة الطلبية من (${prevStatus}) إلى (${newStatus})${note ? ` - ملاحظات: ${note}` : ''}`,
    });

    // Notify Manager or Assignee
    await this.createNotification({
      recipientId: order.primaryAssigneeId,
      type: 'STATUS_CHANGE',
      orderId: order.id,
      title: `تحديث حالة الطلبية ${order.id}`,
      message: `تم تغيير حالة الطلبية إلى: ${newStatus}`,
    });
  }

  public async archiveOrder(orderId: string, currentUser: User): Promise<void> {
    const order = await this.getOrderById(orderId);
    if (!order) return;
    order.isArchived = true;
    order.updatedAt = new Date().toISOString();
    await this.putItem('orders', order);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'ARCHIVE',
      entityType: 'ORDER',
      entityId: order.id,
      details: `أرشفة الطلبية المكتملة ${order.id}`,
    });
  }

  // --- Phone Settings ---
  public async getPhoneSettings(): Promise<SystemPhoneSettings> {
    const meta = await this.getById<{ key: string; value: any }>('metadata', 'phone_settings');
    if (meta && meta.value) {
      return {
        ...DEFAULT_PHONE_SETTINGS,
        ...meta.value,
        supplierPhones: {
          ...DEFAULT_PHONE_SETTINGS.supplierPhones,
          ...(meta.value.supplierPhones || {}),
        },
      };
    }
    await this.putItem('metadata', { key: 'phone_settings', value: DEFAULT_PHONE_SETTINGS });
    return DEFAULT_PHONE_SETTINGS;
  }

  public async savePhoneSettings(settings: SystemPhoneSettings, currentUser?: User): Promise<void> {
    await this.putItem('metadata', { key: 'phone_settings', value: settings });
    if (currentUser) {
      await this.logAudit({
        userId: currentUser.id,
        userName: currentUser.name,
        action: 'UPDATE',
        entityType: 'ALERT',
        entityId: 'phone_settings',
        details: 'تحديث أرقام هواتف المشتريات والشيف العمومي والموردين',
      });
    }
  }

  // --- Order Types (Categories / Columns) ---
  public async getOrderTypes(): Promise<OrderType[]> {
    const isSeeded = await this.getById<{ key: string; value: boolean }>('metadata', 'seeded_catalog_v6');
    if (!isSeeded) {
      // Clear out old categories and seed authentic ones
      const current = await this.getAll<OrderType>('orderTypes');
      for (const t of current) {
        await this.removeItem('orderTypes', t.id);
      }
      for (const m of INITIAL_ORDER_TYPES) {
        await this.putItem('orderTypes', m);
      }
      await this.putItem('metadata', { key: 'seeded_catalog_v6', value: true });
      return this.getAll<OrderType>('orderTypes');
    }
    return this.getAll<OrderType>('orderTypes');
  }

  public async saveOrderType(category: OrderType, currentUser: User): Promise<void> {
    await this.putItem('orderTypes', category);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'CATEGORY',
      entityId: category.id,
      details: `تحديث/إضافة فئة أو عمود التوريد: ${category.nameAr} (${category.code || ''})`,
    });
  }

  public async deleteOrderType(id: string, currentUser: User): Promise<void> {
    await this.removeItem('orderTypes', id);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'CATEGORY',
      entityId: id,
      details: `حذف فئة أو عمود التوريد: ${id}`,
    });
  }

  // --- Products (Items) ---
  public async getProducts(): Promise<Product[]> {
    const isSeeded = await this.getById<{ key: string; value: boolean }>('metadata', 'seeded_products_v6');
    if (!isSeeded) {
      // Clear out old products and seed authentic items including cashier
      const current = await this.getAll<Product>('products');
      for (const p of current) {
        await this.removeItem('products', p.id);
      }
      for (const p of INITIAL_PRODUCTS) {
        await this.putItem('products', p);
      }
      await this.putItem('metadata', { key: 'seeded_products_v6', value: true });
      return this.getAll<Product>('products');
    }
    return this.getAll<Product>('products');
  }

  public async getProductsByCategory(orderTypeId: string): Promise<Product[]> {
    const all = await this.getProducts();
    return all.filter((p) => p.orderTypeId === orderTypeId);
  }

  public async saveProduct(product: Product, currentUser: User): Promise<void> {
    await this.putItem('products', product);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'PRODUCT',
      entityId: product.id,
      details: `تحديث/إضافة صنف توريد: ${product.nameAr || product.name} (وحدة: ${product.defaultUnit || product.unit})`,
    });
  }

  public async deleteProduct(id: string, currentUser: User): Promise<void> {
    await this.removeItem('products', id);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'PRODUCT',
      entityId: id,
      details: `حذف الصنف المعرف: ${id}`,
    });
  }

  public async resetCatalogToDefault(currentUser: User): Promise<void> {
    // Helper for manager to reset back to authentic 180 items & 10 categories if requested
    const currentProds = await this.getAll<Product>('products');
    for (const p of currentProds) {
      await this.removeItem('products', p.id);
    }
    for (const p of INITIAL_PRODUCTS) {
      await this.putItem('products', p);
    }

    const currentCats = await this.getAll<OrderType>('orderTypes');
    for (const c of currentCats) {
      await this.removeItem('orderTypes', c.id);
    }
    for (const c of INITIAL_ORDER_TYPES) {
      await this.putItem('orderTypes', c);
    }

    await this.putItem('metadata', { key: 'seeded_catalog_v5', value: true });
    await this.putItem('metadata', { key: 'seeded_products_v5', value: true });

    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'PRODUCT',
      entityId: 'ALL',
      details: 'إعادة ضبط كتالوج المطبخ للأصناف والقوائم الـ 10 المعتمدة شاملة طلبية الكاشير',
    });
  }

  // --- Master Schedules ---
  public async getSchedules(): Promise<MasterOrderSchedule[]> {
    const list = await this.getAll<MasterOrderSchedule>('schedules');
    if (list.length === 0) {
      for (const s of INITIAL_SCHEDULES) {
        await this.putItem('schedules', s);
      }
      return INITIAL_SCHEDULES;
    }
    return list;
  }

  public async saveSchedule(schedule: MasterOrderSchedule, currentUser: User): Promise<void> {
    await this.putItem('schedules', schedule);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'SCHEDULE',
      entityId: schedule.id,
      details: `تحديث/إنشاء جدول دوري للتوريد: ${schedule.name} (${schedule.recurrenceRule})`,
    });
  }

  public async deleteSchedule(id: string, currentUser: User): Promise<void> {
    await this.removeItem('schedules', id);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'SCHEDULE',
      entityId: id,
      details: `حذف جدول التوريد الدوري: ${id}`,
    });
  }

  // --- Suppliers ---
  public async getSuppliers(): Promise<Supplier[]> {
    return this.getAll<Supplier>('suppliers');
  }

  public async saveSupplier(supplier: Supplier, currentUser: User): Promise<void> {
    await this.putItem('suppliers', supplier);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'SUPPLIER',
      entityId: supplier.id,
      details: `تحديث/إضافة مورد: ${supplier.name} (${supplier.phone})`,
    });
  }

  // --- Receiving & Inspection ---
  public async getReceivingRecords(): Promise<ReceivingRecord[]> {
    const list = await this.getAll<ReceivingRecord>('receivingRecords');
    return list.sort((a, b) => new Date(b.receivedAt).getTime() - new Date(a.receivedAt).getTime());
  }

  public async recordReceiving(
    record: ReceivingRecord,
    updatedOrder: ActualOrder,
    currentUser: User
  ): Promise<void> {
    await this.putItem('receivingRecords', record);
    await this.putItem('orders', updatedOrder);

    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'RECEIVE',
      entityType: 'ORDER',
      entityId: record.orderId,
      details: `تسجيل استلام وفحص الجودة للطلبية ${record.orderId} - النتيجة: ${record.inspectionResult}`,
    });

    if (record.inspectionResult === 'REJECTED' || record.inspectionResult === 'PARTIALLY_ACCEPTED') {
      await this.createNotification({
        recipientId: 'user-manager-01',
        type: 'REJECTION',
        orderId: record.orderId,
        title: 'تنبيه فحص استلام: وجود بنود مرفوضة أو ناقصة',
        message: `تم تسجيل رفض/نقص أثناء استلام الطلبية ${record.orderId} - سبب: ${record.rejectionReason || 'يرجى مراجعة محضر الفحص'}`,
      });
    }
  }

  // --- Invoices ---
  public async getInvoices(): Promise<InvoiceRecord[]> {
    return this.getAll<InvoiceRecord>('invoices');
  }

  public async saveInvoice(invoice: InvoiceRecord, currentUser: User): Promise<void> {
    await this.putItem('invoices', invoice);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'VERIFY_INVOICE',
      entityType: 'INVOICE',
      entityId: invoice.id,
      details: `تسجيل/مطابقة فاتورة #${invoice.invoiceNumber} بقيمة ${invoice.invoiceTotal} ج.م - الحالة: ${invoice.verificationStatus}`,
    });

    if (invoice.verificationStatus === 'DISCREPANCY') {
      await this.createNotification({
        recipientId: 'user-manager-01',
        type: 'INVOICE_DISCREPANCY',
        orderId: invoice.orderId,
        title: `فروقات في فاتورة التوريد #${invoice.invoiceNumber}`,
        message: `تم رصد اختلاف بين كميات الاستلام وقيمة الفاتورة للطلبية ${invoice.orderId}: ${invoice.discrepancyNotes || ''}`,
      });
    }
  }

  // --- Users ---
  public async getUsers(): Promise<User[]> {
    const users = await this.getAll<User>('users');
    let hasUpdates = false;
    for (const init of INITIAL_USERS) {
      const existing = users.find((u) => u.id === init.id);
      if (!existing) {
        await this.putItem('users', init);
        hasUpdates = true;
      } else if (!existing.employeeNumber || !existing.iban || existing.fingerprintRegistered === undefined) {
        const merged: User = {
          ...existing,
          employeeNumber: existing.employeeNumber || init.employeeNumber,
          iban: existing.iban || init.iban,
          fingerprintRegistered:
            existing.fingerprintRegistered !== undefined ? existing.fingerprintRegistered : init.fingerprintRegistered,
          fingerprintToken: existing.fingerprintToken || init.fingerprintToken,
        };
        await this.putItem('users', merged);
        hasUpdates = true;
      }
    }
    if (hasUpdates) {
      return this.getAll<User>('users');
    }
    return users;
  }

  public async saveUser(user: User, currentUser: User): Promise<void> {
    await this.putItem('users', user);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'USER',
      entityId: user.id,
      details: `تحديث بيانات المستخدم: ${user.name} دور: ${user.role}`,
    });
  }

  public async deleteUser(userId: string, currentUser: User): Promise<void> {
    await this.removeItem('users', userId);
    await this.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      action: 'UPDATE',
      entityType: 'USER',
      entityId: userId,
      details: `حذف المستخدم نهائياً من قاعدة البيانات: ${userId}`,
    });
  }

  // --- Notifications ---
  public async getNotifications(recipientId?: string): Promise<AppNotification[]> {
    const all = await this.getAll<AppNotification>('notifications');
    return all
      .filter((n) => (!recipientId ? true : n.recipientId === recipientId))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public async createNotification(
    notif: Omit<AppNotification, 'id' | 'createdAt' | 'isRead'>
  ): Promise<void> {
    const item: AppNotification = {
      ...notif,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    await this.putItem('notifications', item);
  }

  public async markNotificationRead(id: string): Promise<void> {
    const item = await this.getById<AppNotification>('notifications', id);
    if (item) {
      item.isRead = true;
      await this.putItem('notifications', item);
    }
  }

  // --- Audit Logs ---
  public async getAuditLogs(): Promise<AuditLog[]> {
    const list = await this.getAll<AuditLog>('auditLogs');
    return list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  public async logAudit(entry: Omit<AuditLog, 'id' | 'timestamp'>): Promise<void> {
    const item: AuditLog = {
      ...entry,
      id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
    };
    await this.putItem('auditLogs', item);
  }

  // System status
  public getStatus() {
    return {
      storageEngine: hasLiveFirebaseConfig
        ? 'Cloud Firestore + Multi-tab Local Cache'
        : 'IndexedDB Secure Store (Persistent Local Database)',
      isFirebaseLive: hasLiveFirebaseConfig,
      firestoreRegion: 'Cloud Firestore Ready',
      version: '1.0.0-PROD',
    };
  }
}

export const dbService = new KitchenDatabase();
