import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import {
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  Firestore,
} from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

export const hasLiveFirebaseConfig = Boolean(
  firebaseConfig.apiKey &&
  firebaseConfig.projectId &&
  firebaseConfig.apiKey !== 'MY_FIREBASE_API_KEY'
);

// Fallback config to prevent runtime crash if environment variables have not been configured yet
const effectiveConfig = hasLiveFirebaseConfig
  ? firebaseConfig
  : {
      apiKey: firebaseConfig.apiKey || 'AIzaSyDemoKitchenOrderSystem00000',
      authDomain: firebaseConfig.authDomain || 'koms-kitchen.firebaseapp.com',
      projectId: firebaseConfig.projectId || 'koms-kitchen-project',
      storageBucket: firebaseConfig.storageBucket || 'koms-kitchen.appspot.com',
      messagingSenderId: firebaseConfig.messagingSenderId || '123456789012',
      appId: firebaseConfig.appId || '1:123456789012:web:demo00000000',
    };

const app = !getApps().length ? initializeApp(effectiveConfig) : getApp();

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export const db: Firestore = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager(),
  }),
});

export const storage = getStorage(app);
export default app;
