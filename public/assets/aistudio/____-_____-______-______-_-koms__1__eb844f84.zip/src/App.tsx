import React, { useState } from 'react';
import { AuthProvider, useAuth, AuthGuard } from './context/AuthContext';
import { DataProvider, useData } from './context/DataContext';
import { Header } from './components/common/Header';
import { Sidebar, ActiveTab } from './components/common/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { OrdersView } from './components/orders/OrdersView';
import { CategoriesProductsView } from './components/categories/CategoriesProductsView';
import { MasterScheduleView } from './components/schedules/MasterScheduleView';
import { ReceivingView } from './components/receiving/ReceivingView';
import { InvoicesView } from './components/invoices/InvoicesView';
import { SuppliersView } from './components/suppliers/SuppliersView';
import { StaffView } from './components/staff/StaffView';
import { ReportsView } from './components/reports/ReportsView';
import { ArchiveView } from './components/archive/ArchiveView';
import { AuditView } from './components/audit/AuditView';
import { UserGuideView } from './features/guide/components/UserGuideView';
import { OrderModal } from './components/orders/OrderModal';
import { VegetableOrderView } from './components/orders/VegetableOrderView';
import { ColumnarOrderView } from './components/orders/ColumnarOrderView';
import { WeeklyFileArchiveView } from './components/orders/WeeklyFileArchiveView';
import { HeadChefAdminPanel } from './components/admin/HeadChefAdminPanel';
import { ActualOrder } from './types';
import { useNetworkStatus } from './hooks/useNetworkStatus';
import { WifiOff } from 'lucide-react';
import { NotificationProvider } from './features/notifications/context/NotificationProvider';
import { NotificationToastBanner } from './features/notifications/components/NotificationToastBanner';

function MainKitchenApp() {
  const { currentUser, isManager } = useAuth();
  const { createOrder } = useData();

  const { isOnline } = useNetworkStatus();

  const [activeTab, setActiveTab] = useState<ActiveTab>('columnar-orders');
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [isNewOrderModalOpen, setIsNewOrderModalOpen] = useState(false);
  const [newOrderInitialCategory, setNewOrderInitialCategory] = useState<string | undefined>(undefined);
  const [selectedOrderForReceiving, setSelectedOrderForReceiving] = useState<ActualOrder | null>(null);

  const handleNavigateToReceiving = (order: ActualOrder) => {
    setSelectedOrderForReceiving(order);
    setActiveTab('receiving');
  };

  const handleOpenNewOrder = (categoryId?: string) => {
    setNewOrderInitialCategory(categoryId);
    setIsNewOrderModalOpen(true);
  };

  const handleCreateOrder = async (orderData: Partial<ActualOrder>) => {
    return await createOrder(orderData);
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col font-sans selection:bg-amber-500 selection:text-stone-950">
      {/* Top Navigation Bar */}
      <Header
        onOpenNewOrder={() => handleOpenNewOrder()}
        onOpenVegOrder={() => setActiveTab('veg-order')}
        onOpenColumnarOrders={() => setActiveTab('columnar-orders')}
        onOpenWeeklyArchive={() => setActiveTab('weekly-archive')}
        onOpenChefAdmin={() => setActiveTab('chef-admin')}
        onOpenMobileMenu={() => setIsMobileNavOpen(true)}
      />

      {/* Real-time Push Notification Toast Banner */}
      <NotificationToastBanner />

      {/* Offline Status Alert Banner */}
      {!isOnline && (
        <div className="bg-amber-550 text-stone-950 px-4 py-2 text-xs font-bold flex items-center justify-center gap-2 border-b border-amber-600 shadow-sm">
          <WifiOff className="w-4 h-4 shrink-0" />
          <span>أنت تعمل حالياً دون اتصال بالإنترنت (Offline Mode). النظام يعمل بكفاءة والبيانات محفوظة محلياً.</span>
        </div>
      )}

      <div className="flex flex-1">
        {/* Right Sidebar (RTL) */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={(tab) => {
            setActiveTab(tab);
            if (tab !== 'receiving') {
              setSelectedOrderForReceiving(null);
            }
          }}
          isOpenMobile={isMobileNavOpen}
          onCloseMobile={() => setIsMobileNavOpen(false)}
        />

        {/* Center Main View Area */}
        <main className="flex-1 p-4 lg:p-6 max-w-7xl mx-auto w-full overflow-y-auto">
          {activeTab === 'columnar-orders' && (
            <ColumnarOrderView onNavigateTab={(tab) => setActiveTab(tab)} />
          )}

          {activeTab === 'weekly-archive' && (
            <WeeklyFileArchiveView
              onSelectOrder={(ord) => {
                setActiveTab('orders');
              }}
            />
          )}

          {activeTab === 'chef-admin' && (
            <HeadChefAdminPanel />
          )}

          {activeTab === 'dashboard' && (
            <DashboardView
              onOpenNewOrder={handleOpenNewOrder}
              onSelectOrder={(order) => {
                if (['RECEIVING', 'AWAITING_DELIVERY', 'PARTIALLY_RECEIVED'].includes(order.status)) {
                  handleNavigateToReceiving(order);
                } else {
                  setActiveTab('orders');
                }
              }}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'veg-order' && (
            <VegetableOrderView onNavigateTab={(tab) => setActiveTab(tab)} />
          )}

          {activeTab === 'orders' && (
            <OrdersView
              onOpenNewOrder={handleOpenNewOrder}
              onNavigateToReceiving={handleNavigateToReceiving}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'my-orders' && (
            <OrdersView
              filterAssigneeId={currentUser.id}
              onOpenNewOrder={handleOpenNewOrder}
              onNavigateToReceiving={handleNavigateToReceiving}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'schedules' && <MasterScheduleView />}

          {activeTab === 'categories' && <CategoriesProductsView />}

          {activeTab === 'suppliers' && <SuppliersView />}

          {activeTab === 'receiving' && (
            <ReceivingView initialOrder={selectedOrderForReceiving} />
          )}

          {activeTab === 'invoices' && <InvoicesView />}

          {activeTab === 'staff' && <StaffView />}

          {activeTab === 'reports' && <ReportsView />}

          {activeTab === 'archive' && (
            <ArchiveView
              onSelectOrder={(ord) => {
                setActiveTab('orders');
              }}
            />
          )}

          {activeTab === 'audit' && <AuditView />}

          {activeTab === 'guide' && (
            <UserGuideView onNavigateTab={(tab) => setActiveTab(tab)} />
          )}
        </main>
      </div>

      {/* Global New Order Creation Modal */}
      {isNewOrderModalOpen && (
        <OrderModal
          defaultCategoryId={newOrderInitialCategory}
          onClose={() => {
            setIsNewOrderModalOpen(false);
            setNewOrderInitialCategory(undefined);
          }}
          onSave={handleCreateOrder}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AuthGuard>
        <DataProvider>
          <NotificationProvider>
            <MainKitchenApp />
          </NotificationProvider>
        </DataProvider>
      </AuthGuard>
    </AuthProvider>
  );
}

