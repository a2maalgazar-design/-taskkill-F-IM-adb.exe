import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  addDoc, 
  deleteDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { UserProfile } from '@/features/auth/types';
import { inventoryService } from '@/features/inventory/api/inventoryService';
import { Recipe, RecipeIngredient, DailyPrepExecution, SuggestedReplenishmentItem } from '../types';

const RECIPES_LOCAL_KEY = 'koms_kitchen_recipes_cache';
const PREP_LOCAL_KEY = 'koms_kitchen_daily_preps_cache';

const INITIAL_SEED_RECIPES: Recipe[] = [
  {
    id: 'rec-bamia-01',
    dishNameAr: 'طاجن بامية باللحمة البلدي (موزة)',
    category: 'MAIN_COURSE',
    portionsYield: 1,
    sellingPriceEGP: 260,
    targetFoodCostPct: 32,
    actualFoodCostPct: 30.6,
    calculatedPortionCostEGP: 79.5,
    isActive: true,
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    updatedAt: new Date().toISOString(),
    ingredients: [
      {
        productId: 'prod-meat-01',
        productNameAr: 'لحم بقري بلدي طازج (قطع موزة)',
        unit: 'كجم',
        quantityPerPortion: 0.22,
        yieldFactor: 0.90, // هدر تنظيف 10%
        unitCostEGP: 290,
      },
      {
        productId: 'prod-veg-02',
        productNameAr: 'بامية بلدي خضراء طازجة (قمع صغير)',
        unit: 'كجم',
        quantityPerPortion: 0.18,
        yieldFactor: 0.85, // تقميع وهدر 15%
        unitCostEGP: 45,
      },
      {
        productId: 'prod-veg-01',
        productNameAr: 'طماطم بلدي طازجة درجة أولى',
        unit: 'كجم',
        quantityPerPortion: 0.15,
        yieldFactor: 0.95,
        unitCostEGP: 22,
      },
      {
        productId: 'prod-veg-03',
        productNameAr: 'بصل أحمر بلدي خزين',
        unit: 'كجم',
        quantityPerPortion: 0.08,
        yieldFactor: 0.88,
        unitCostEGP: 18,
      },
    ],
  },
  {
    id: 'rec-kofta-02',
    dishNameAr: 'كفتة حاتي مشوية على الفحم',
    category: 'MAIN_COURSE',
    portionsYield: 1,
    sellingPriceEGP: 230,
    targetFoodCostPct: 30,
    actualFoodCostPct: 29.8,
    calculatedPortionCostEGP: 68.5,
    isActive: true,
    createdAt: new Date(Date.now() - 86400000 * 4).toISOString(),
    updatedAt: new Date().toISOString(),
    ingredients: [
      {
        productId: 'prod-meat-01',
        productNameAr: 'مفروم لحم بقري دسم للشوي',
        unit: 'كجم',
        quantityPerPortion: 0.25,
        yieldFactor: 0.92,
        unitCostEGP: 240,
      },
      {
        productId: 'prod-veg-03',
        productNameAr: 'بصل أحمر مفروم مصفى',
        unit: 'كجم',
        quantityPerPortion: 0.06,
        yieldFactor: 0.75,
        unitCostEGP: 18,
      },
    ],
  },
  {
    id: 'rec-molokhia-03',
    dishNameAr: 'ملوخية مصرية خضراء بالطشة',
    category: 'MAIN_COURSE',
    portionsYield: 1,
    sellingPriceEGP: 90,
    targetFoodCostPct: 28,
    actualFoodCostPct: 26.2,
    calculatedPortionCostEGP: 23.6,
    isActive: true,
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date().toISOString(),
    ingredients: [
      {
        productId: 'prod-veg-04',
        productNameAr: 'ملوخية خضراء بلدي طازجة',
        unit: 'كجم',
        quantityPerPortion: 0.25,
        yieldFactor: 0.70, // تقطيف 30% هدر
        unitCostEGP: 30,
      },
      {
        productId: 'prod-veg-05',
        productNameAr: 'ثوم بلدي مفروم للطشة',
        unit: 'كجم',
        quantityPerPortion: 0.03,
        yieldFactor: 0.90,
        unitCostEGP: 65,
      },
    ],
  },
  {
    id: 'rec-salad-04',
    dishNameAr: 'سلطة خضراء بلدية بالكمون والليمون',
    category: 'APPETIZER',
    portionsYield: 1,
    sellingPriceEGP: 40,
    targetFoodCostPct: 25,
    actualFoodCostPct: 22.5,
    calculatedPortionCostEGP: 9.0,
    isActive: true,
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date().toISOString(),
    ingredients: [
      {
        productId: 'prod-veg-01',
        productNameAr: 'طماطم بلدي طازجة درجة أولى',
        unit: 'كجم',
        quantityPerPortion: 0.12,
        yieldFactor: 0.95,
        unitCostEGP: 22,
      },
      {
        productId: 'prod-veg-06',
        productNameAr: 'خيار بلدي طازج مخلل وسلطة',
        unit: 'كجم',
        quantityPerPortion: 0.10,
        yieldFactor: 0.92,
        unitCostEGP: 20,
      },
    ],
  },
  {
    id: 'rec-subprep-sauce-05',
    dishNameAr: 'صلصة طماطم وتتبيل أساسية (تحضير وسيط)',
    category: 'SUB_PREP',
    portionsYield: 5,
    sellingPriceEGP: 0,
    targetFoodCostPct: 0,
    actualFoodCostPct: 0,
    calculatedPortionCostEGP: 18.2,
    isActive: true,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
    ingredients: [
      {
        productId: 'prod-veg-01',
        productNameAr: 'طماطم بلدي طازجة درجة أولى',
        unit: 'كجم',
        quantityPerPortion: 0.60,
        yieldFactor: 0.95,
        unitCostEGP: 22,
      },
      {
        productId: 'prod-veg-03',
        productNameAr: 'بصل أحمر بلدي خزين',
        unit: 'كجم',
        quantityPerPortion: 0.20,
        yieldFactor: 0.88,
        unitCostEGP: 18,
      },
      {
        productId: 'prod-oil-01',
        productNameAr: 'زيت قلي طهي نقي عبوة 20 لتر',
        unit: 'لتر',
        quantityPerPortion: 0.05,
        yieldFactor: 1.0,
        unitCostEGP: 65,
      },
    ],
  },
];

function getLocalRecipes(): Recipe[] {
  try {
    const raw = localStorage.getItem(RECIPES_LOCAL_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Could not read recipes local cache:', e);
  }
  localStorage.setItem(RECIPES_LOCAL_KEY, JSON.stringify(INITIAL_SEED_RECIPES));
  return INITIAL_SEED_RECIPES;
}

function saveLocalRecipes(recipes: Recipe[]): void {
  try {
    localStorage.setItem(RECIPES_LOCAL_KEY, JSON.stringify(recipes));
  } catch (e) {
    console.warn('Could not save recipes local cache:', e);
  }
}

function getLocalPreps(): DailyPrepExecution[] {
  try {
    const raw = localStorage.getItem(PREP_LOCAL_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Could not read daily preps local cache:', e);
  }
  return [];
}

function saveLocalPreps(preps: DailyPrepExecution[]): void {
  try {
    localStorage.setItem(PREP_LOCAL_KEY, JSON.stringify(preps));
  } catch (e) {
    console.warn('Could not save daily preps local cache:', e);
  }
}

export const recipeService = {
  /**
   * حساب تكلفة الحصة الواحدة بناء على كمية البند ومعامل الهدر (Gross = Net / Yield)
   */
  calculateCosting(
    ingredients: RecipeIngredient[],
    sellingPriceEGP: number,
    portionsYield: number = 1
  ): { portionCostEGP: number; totalBatchCostEGP: number; actualFoodCostPct: number } {
    let totalBatchCost = 0;

    for (const ing of ingredients) {
      const yieldFactor = ing.yieldFactor > 0 ? ing.yieldFactor : 1;
      const grossQtyPerPortion = ing.quantityPerPortion / yieldFactor;
      const unitCost = ing.unitCostEGP || 0;
      const itemCostPerPortion = grossQtyPerPortion * unitCost;
      totalBatchCost += itemCostPerPortion * (portionsYield || 1);
    }

    const portionCostEGP = (portionsYield > 0 ? totalBatchCost / portionsYield : totalBatchCost);
    const actualFoodCostPct = sellingPriceEGP > 0 
      ? Math.round((portionCostEGP / sellingPriceEGP) * 1000) / 10 
      : 0;

    return {
      portionCostEGP: Math.round(portionCostEGP * 100) / 100,
      totalBatchCostEGP: Math.round(totalBatchCost * 100) / 100,
      actualFoodCostPct,
    };
  },

  /**
   * جلب كافة الوصفات المعيارية
   */
  async getRecipes(): Promise<Recipe[]> {
    try {
      const q = query(collection(db, 'recipes'), orderBy('createdAt', 'desc'));
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs.map(d => ({ id: d.id, ...d.data() } as Recipe));
      }
    } catch (err) {
      console.warn('Firestore getRecipes fallback:', err);
    }
    return getLocalRecipes();
  },

  /**
   * حفظ أو تحديث بطاقة وصفة معيارية
   */
  async saveRecipe(recipeData: Partial<Recipe>, actor: UserProfile): Promise<Recipe> {
    const isNew = !recipeData.id;
    const recipeId = recipeData.id || `rec-${Date.now()}`;
    const portionsYield = recipeData.portionsYield || 1;
    const sellingPriceEGP = recipeData.sellingPriceEGP || 0;
    const ingredients = recipeData.ingredients || [];

    const costing = this.calculateCosting(ingredients, sellingPriceEGP, portionsYield);

    const recipe: Recipe = {
      id: recipeId,
      dishNameAr: recipeData.dishNameAr || 'وصفة جديدة',
      category: recipeData.category || 'MAIN_COURSE',
      portionsYield,
      sellingPriceEGP,
      targetFoodCostPct: recipeData.targetFoodCostPct || 30,
      actualFoodCostPct: costing.actualFoodCostPct,
      calculatedPortionCostEGP: costing.portionCostEGP,
      ingredients,
      isActive: recipeData.isActive ?? true,
      createdAt: recipeData.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      const docRef = doc(db, 'recipes', recipeId);
      await setDoc(docRef, {
        ...recipe,
        updatedAt: serverTimestamp(),
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore saveRecipe fallback:', err);
    }

    const local = getLocalRecipes();
    const idx = local.findIndex(r => r.id === recipeId);
    if (idx >= 0) {
      local[idx] = recipe;
    } else {
      local.unshift(recipe);
    }
    saveLocalRecipes(local);

    return recipe;
  },

  /**
   * حذف وصفة
   */
  async deleteRecipe(recipeId: string): Promise<void> {
    try {
      await deleteDoc(doc(db, 'recipes', recipeId));
    } catch (err) {
      console.warn('Firestore deleteRecipe fallback:', err);
    }
    const local = getLocalRecipes().filter(r => r.id !== recipeId);
    saveLocalRecipes(local);
  },

  /**
   * تنفيذ خط إنتاج تحضير يومي (Daily Prep Run) وخصم مكونات الوصفة آلياً من المخزون اللحظي
   */
  async executeDailyPrep(
    prepData: {
      recipeId: string;
      dishNameAr: string;
      portionsProduced: number;
      date: string;
    },
    actor: UserProfile
  ): Promise<DailyPrepExecution> {
    if (prepData.portionsProduced <= 0) {
      throw new Error('عدد الحصص المنفذة يجب أن يكون أكبر من الصفر');
    }

    // جلب الوصفة
    const recipes = await this.getRecipes();
    const recipe = recipes.find(r => r.id === prepData.recipeId);
    if (!recipe) {
      throw new Error('الوصفة المحددة غير موجودة');
    }

    // التحقق من توافر المخزون وخصم المكونات بناء على معامل الهدر (FEFO)
    for (const ing of recipe.ingredients) {
      const yieldFactor = ing.yieldFactor > 0 ? ing.yieldFactor : 1;
      const grossQtyRequired = (ing.quantityPerPortion / yieldFactor) * prepData.portionsProduced;
      const roundedGrossQty = Math.round(grossQtyRequired * 1000) / 1000;

      try {
        await inventoryService.consumeStock(
          ing.productId,
          roundedGrossQty,
          'USAGE',
          `تشغيل تحضير يومي: ${recipe.dishNameAr} (${prepData.portionsProduced} وجبة) - معامل هدر ${(100 - yieldFactor * 100).toFixed(0)}%`,
          actor
        );
      } catch (err: any) {
        throw new Error(
          `تعذر استيفاء الصنف [${ing.productNameAr}]: ${err.message || 'رصيد المخزون لا يكفي لتشغيل هذه الكمية'}`
        );
      }
    }

    const prepExecution: DailyPrepExecution = {
      id: `prep-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      date: prepData.date || new Date().toISOString().split('T')[0],
      recipeId: recipe.id,
      dishNameAr: recipe.dishNameAr,
      portionsProduced: prepData.portionsProduced,
      actorId: actor.uid,
      actorName: actor.displayName,
      executedAt: new Date().toISOString(),
    };

    try {
      const docRef = doc(collection(db, 'dailyPrepExecutions'));
      await setDoc(docRef, {
        ...prepExecution,
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      console.warn('Firestore executeDailyPrep fallback:', err);
    }

    const preps = getLocalPreps();
    preps.unshift(prepExecution);
    saveLocalPreps(preps);

    return prepExecution;
  },

  /**
   * جلب سجلات التحضير اليومية المنفذة
   */
  async getDailyPrepExecutions(dateFilter?: string): Promise<DailyPrepExecution[]> {
    try {
      let q = query(collection(db, 'dailyPrepExecutions'), orderBy('executedAt', 'desc'));
      if (dateFilter) {
        q = query(collection(db, 'dailyPrepExecutions'), where('date', '==', dateFilter), orderBy('executedAt', 'desc'));
      }
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs.map(d => ({ id: d.id, ...d.data() } as DailyPrepExecution));
      }
    } catch (err) {
      console.warn('Firestore getDailyPrepExecutions fallback:', err);
    }

    let preps = getLocalPreps();
    if (dateFilter) {
      preps = preps.filter(p => p.date === dateFilter);
    }
    return preps;
  },

  /**
   * استخراج مقترحات إعادة التوريد الذكية وسد النواقص (Par-Level Replenishment)
   */
  async getSuggestedReplenishment(): Promise<SuggestedReplenishmentItem[]> {
    const inv = await inventoryService.getInventory();

    // نحدد الأصناف التي نقص رصيدها عن الحد الأمثل Par Level أو بلغت حد الأمان Min
    const shortageItems = inv.filter(item => item.currentStock < item.idealParLevel);

    return shortageItems.map(item => {
      const suggestedOrderQty = Math.max(0, item.idealParLevel - item.currentStock);
      return {
        productId: item.productId,
        productNameAr: item.productNameAr,
        orderTypeId: item.orderTypeId || 'general',
        currentStock: item.currentStock,
        minThreshold: item.minThreshold,
        idealParLevel: item.idealParLevel,
        suggestedOrderQty: Math.ceil(suggestedOrderQty * 10) / 10,
        unit: item.unit,
      };
    });
  },
};
