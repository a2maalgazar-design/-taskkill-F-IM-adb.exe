import React, { useState, useEffect } from 'react';
import { X, Play, AlertTriangle, CheckCircle, Package, Flame, Clock } from 'lucide-react';
import { Recipe } from '../types';
import { recipeService } from '../api/recipeService';
import { inventoryService } from '@/features/inventory/api/inventoryService';
import { InventoryItem } from '@/features/inventory/types';
import { UserProfile } from '@/features/auth/types';

interface DailyPrepModalProps {
  recipes: Recipe[];
  onClose: () => void;
  onSuccess: () => void;
  actor: UserProfile;
  initialRecipeId?: string;
}

export const DailyPrepModal: React.FC<DailyPrepModalProps> = ({
  recipes,
  onClose,
  onSuccess,
  actor,
  initialRecipeId,
}) => {
  const [selectedRecipeId, setSelectedRecipeId] = useState<string>(
    initialRecipeId || (recipes.length > 0 ? recipes[0].id : '')
  );
  const [portionsProduced, setPortionsProduced] = useState<number>(10);
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [inventoryMap, setInventoryMap] = useState<Record<string, InventoryItem>>({});
  const [loadingInv, setLoadingInv] = useState(true);
  const [executing, setExecuting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedRecipe = recipes.find(r => r.id === selectedRecipeId);

  useEffect(() => {
    async function loadStock() {
      try {
        const inv = await inventoryService.getInventory();
        const map: Record<string, InventoryItem> = {};
        for (const item of inv) {
          map[item.productId] = item;
        }
        setInventoryMap(map);
      } catch (e) {
        console.error('Failed to load inventory for prep run:', e);
      } finally {
        setLoadingInv(false);
      }
    }
    loadStock();
  }, []);

  // Compute raw material requirements
  const ingredientsCheck = (selectedRecipe?.ingredients || []).map(ing => {
    const yieldFactor = ing.yieldFactor > 0 ? ing.yieldFactor : 1;
    const grossQtyRequired = (ing.quantityPerPortion / yieldFactor) * portionsProduced;
    const roundedGross = Math.round(grossQtyRequired * 100) / 100;
    
    // Check available stock in inventory
    const currentInvItem = inventoryMap[ing.productId];
    const availableStock = currentInvItem?.currentStock || 0;
    const hasEnoughStock = availableStock >= roundedGross;

    return {
      ...ing,
      grossQtyRequired: roundedGross,
      availableStock,
      hasEnoughStock,
      stockShortage: Math.max(0, roundedGross - availableStock),
    };
  });

  const hasAnyShortage = ingredientsCheck.some(i => !i.hasEnoughStock);

  const handleExecute = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRecipe) return;
    if (portionsProduced <= 0) {
      setError('يرجى تحديد عدد حصص أكبر من الصفر');
      return;
    }

    setExecuting(true);
    setError(null);

    try {
      await recipeService.executeDailyPrep(
        {
          recipeId: selectedRecipe.id,
          dishNameAr: selectedRecipe.dishNameAr,
          portionsProduced,
          date,
        },
        actor
      );
      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء تشغيل أمر التحضير');
    } finally {
      setExecuting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-stone-900 border border-stone-800 rounded-xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl text-stone-100">
        {/* الرأس */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-stone-800 bg-stone-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-stone-100">تشغيل تحضير وجبات (Daily Prep Run)</h3>
              <p className="text-xs text-stone-400">
                خصم كميات المواد الخام آلياً من المخزون اللحظي مع مراعاة معاملات الهدر و FEFO
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-stone-200 p-2 rounded-lg hover:bg-stone-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* نموذج التشغيل */}
        <form onSubmit={handleExecute} className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {error && (
            <div className="p-3 bg-rose-550/10 border border-rose-500/30 rounded-lg text-rose-400 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-stone-300">اختيار الوصفة المعيارية *</label>
              <select
                value={selectedRecipeId}
                onChange={(e) => setSelectedRecipeId(e.target.value)}
                className="w-full bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-sm text-stone-100 focus:outline-none focus:border-emerald-500"
              >
                {recipes.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.dishNameAr} ({r.category})
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-stone-300">تاريخ التشغيل *</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-sm text-stone-100 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="p-4 bg-stone-950/70 border border-stone-800 rounded-xl space-y-2">
            <label className="text-xs font-semibold text-stone-300 block">
              عدد الوجبات / الحصص المستهدفة للتحضير (Batch Portions) *
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                min="1"
                step="1"
                value={portionsProduced}
                onChange={(e) => setPortionsProduced(Math.max(1, Number(e.target.value)))}
                required
                className="w-32 bg-stone-900 border border-stone-800 rounded-lg px-3 py-2 text-base font-bold font-mono text-emerald-400 focus:outline-none focus:border-emerald-500 text-center"
              />
              <div className="flex flex-wrap gap-1.5">
                {[5, 10, 20, 50, 100].map((quick) => (
                  <button
                    key={quick}
                    type="button"
                    onClick={() => setPortionsProduced(quick)}
                    className={`px-2.5 py-1 text-xs rounded border transition ${
                      portionsProduced === quick
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-stone-900 text-stone-400 border-stone-800 hover:text-stone-200'
                    }`}
                  >
                    {quick} وجبة
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* فحص توافر المواد الخام بالمخزون */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-stone-300 flex items-center gap-1.5">
                <Package className="w-3.5 h-3.5 text-stone-400" />
                <span>المواد الخام المطلوبة وفحص الرصيد اللحظي</span>
              </h4>
              {hasAnyShortage && (
                <span className="text-[11px] text-rose-400 font-bold flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>تنبيه: يوجد نقص في بعض المواد الخام</span>
                </span>
              )}
            </div>

            <div className="border border-stone-800 rounded-xl overflow-hidden bg-stone-950/40">
              <table className="w-full text-right text-xs">
                <thead className="bg-stone-900/80 text-stone-400 border-b border-stone-800 font-medium">
                  <tr>
                    <th className="p-2.5">الصنف</th>
                    <th className="p-2.5">المطلوب الصافي</th>
                    <th className="p-2.5">الإجمالي بالهدر</th>
                    <th className="p-2.5">المخزون المتاح</th>
                    <th className="p-2.5 text-center">الحالة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-800/60 font-sans">
                  {ingredientsCheck.map((item, idx) => {
                    const netTotal = Math.round(item.quantityPerPortion * portionsProduced * 100) / 100;
                    return (
                      <tr key={idx} className="hover:bg-stone-900/40 transition">
                        <td className="p-2.5 font-medium text-stone-200">
                          {item.productNameAr}
                        </td>
                        <td className="p-2.5 text-stone-400 font-mono">
                          {netTotal} {item.unit}
                        </td>
                        <td className="p-2.5 text-stone-200 font-mono font-bold">
                          {item.grossQtyRequired} {item.unit}
                          <span className="text-[10px] text-stone-500 mr-1 block">
                            (معامل {item.yieldFactor})
                          </span>
                        </td>
                        <td className="p-2.5 font-mono">
                          <span className={item.hasEnoughStock ? 'text-stone-300' : 'text-rose-400 font-bold'}>
                            {item.availableStock} {item.unit}
                          </span>
                        </td>
                        <td className="p-2.5 text-center">
                          {item.hasEnoughStock ? (
                            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                              <CheckCircle className="w-3 h-3" />
                              <span>متاح</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] text-rose-400 bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded-full font-bold">
                              <AlertTriangle className="w-3 h-3" />
                              <span>عجز {item.stockShortage}</span>
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </form>

        {/* أزرار الإجراء */}
        <div className="flex items-center justify-between p-4 border-t border-stone-800 bg-stone-950/60">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg text-xs font-bold transition"
          >
            إلغاء
          </button>

          <button
            onClick={handleExecute}
            disabled={executing || !selectedRecipe}
            className="flex items-center gap-2 px-5 py-2 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-stone-950 rounded-lg text-xs font-bold transition shadow-lg shadow-emerald-500/10"
          >
            {executing ? (
              <span>جاري الخصم والتشغيل...</span>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>تأكيد وتشغيل التحضير وخصم المخزون</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
