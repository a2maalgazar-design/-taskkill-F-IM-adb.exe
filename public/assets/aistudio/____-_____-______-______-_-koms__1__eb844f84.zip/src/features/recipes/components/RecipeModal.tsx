import React, { useState } from 'react';
import { X, Plus, Trash2, Calculator, AlertCircle, ChefHat, Check, DollarSign } from 'lucide-react';
import { Recipe, RecipeIngredient } from '../types';
import { recipeService } from '../api/recipeService';
import { UserProfile } from '@/features/auth/types';

interface RecipeModalProps {
  recipe?: Recipe | null;
  onClose: () => void;
  onSaved: (savedRecipe: Recipe) => void;
  actor: UserProfile;
  availableProducts?: { id: string; nameAr: string; unit: string; currentPriceEGP?: number }[];
}

export const RecipeModal: React.FC<RecipeModalProps> = ({
  recipe,
  onClose,
  onSaved,
  actor,
  availableProducts = [],
}) => {
  const [dishNameAr, setDishNameAr] = useState(recipe?.dishNameAr || '');
  const [category, setCategory] = useState<Recipe['category']>(recipe?.category || 'MAIN_COURSE');
  const [portionsYield, setPortionsYield] = useState<number>(recipe?.portionsYield || 1);
  const [sellingPriceEGP, setSellingPriceEGP] = useState<number>(recipe?.sellingPriceEGP || 100);
  const [targetFoodCostPct, setTargetFoodCostPct] = useState<number>(recipe?.targetFoodCostPct || 30);
  const [isActive, setIsActive] = useState<boolean>(recipe?.isActive ?? true);
  
  const [ingredients, setIngredients] = useState<RecipeIngredient[]>(
    recipe?.ingredients && recipe.ingredients.length > 0
      ? recipe.ingredients
      : [
          {
            productId: 'prod-meat-01',
            productNameAr: 'لحم بقري بلدي طازج',
            unit: 'كجم',
            quantityPerPortion: 0.25,
            yieldFactor: 0.90,
            unitCostEGP: 290,
          },
        ]
  );

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Live costing calculations
  const costing = recipeService.calculateCosting(ingredients, sellingPriceEGP, portionsYield);

  const isCostExceeded = sellingPriceEGP > 0 && costing.actualFoodCostPct > targetFoodCostPct;

  const handleAddIngredient = () => {
    setIngredients([
      ...ingredients,
      {
        productId: `custom-${Date.now()}`,
        productNameAr: '',
        unit: 'كجم',
        quantityPerPortion: 0.1,
        yieldFactor: 1.0,
        unitCostEGP: 0,
      },
    ]);
  };

  const handleRemoveIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const handleIngredientChange = (index: number, fields: Partial<RecipeIngredient>) => {
    const next = [...ingredients];
    next[index] = { ...next[index], ...fields };
    setIngredients(next);
  };

  const handleProductSelect = (index: number, productId: string) => {
    const found = availableProducts.find(p => p.id === productId);
    if (found) {
      handleIngredientChange(index, {
        productId: found.id,
        productNameAr: found.nameAr,
        unit: found.unit || 'كجم',
        unitCostEGP: found.currentPriceEGP || 0,
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dishNameAr.trim()) {
      setError('يرجى إدخال اسم الوجبة أو الوصفة');
      return;
    }
    if (ingredients.length === 0) {
      setError('يجب إضافة مكون واحد على الأقل للوصفة');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const saved = await recipeService.saveRecipe(
        {
          id: recipe?.id,
          dishNameAr,
          category,
          portionsYield,
          sellingPriceEGP,
          targetFoodCostPct,
          ingredients,
          isActive,
        },
        actor
      );
      onSaved(saved);
      onClose();
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء حفظ الوصفة');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-stone-900 border border-stone-800 rounded-xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl text-stone-100">
        {/* رأس النافذة */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-stone-800 bg-stone-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-500">
              <ChefHat className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-stone-100">
                {recipe ? 'تعديل بطاقة الوصفة المعيارية' : 'إنشاء بطاقة وصفة معيارية جديدة'}
              </h3>
              <p className="text-xs text-stone-400">
                حساب دقيق لتكلفة الحصة، معامل الهدر الصافي، ونسبة تكلفة الغذاء (Food Cost %)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-stone-200 p-2 rounded-lg hover:bg-stone-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* محتوى النموذج */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1">
          {error && (
            <div className="p-3 bg-rose-550/10 border border-rose-500/30 rounded-lg text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* بيانات الصنف العامة */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2 space-y-1.5">
              <label className="text-xs font-semibold text-stone-300">اسم الوجبة / الصنف (بالعربية) *</label>
              <input
                type="text"
                value={dishNameAr}
                onChange={(e) => setDishNameAr(e.target.value)}
                placeholder="مثال: طاجن عكاري بالبصل القاورما، كفتة حاتي..."
                required
                className="w-full bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-sm text-stone-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-stone-300">التصنيف *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Recipe['category'])}
                className="w-full bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-sm text-stone-100 focus:outline-none focus:border-amber-500"
              >
                <option value="MAIN_COURSE">طبق رئيسي (Main Course)</option>
                <option value="APPETIZER">مقبلات وسلطات (Appetizer)</option>
                <option value="DESSERT">حلويات (Dessert)</option>
                <option value="BAKERY">مخبوزات وعجائن (Bakery)</option>
                <option value="BEVERAGE">مشروبات (Beverage)</option>
                <option value="SUB_PREP">تحضير وسيط / صوصات (Sub-Prep)</option>
              </select>
            </div>
          </div>

          {/* المؤشرات المالية والتسعير */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 bg-stone-950/60 border border-stone-800/80 rounded-xl">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-stone-300">سعر البيع في المنيو (ج.م)</label>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  step="0.5"
                  value={sellingPriceEGP}
                  onChange={(e) => setSellingPriceEGP(Number(e.target.value))}
                  disabled={category === 'SUB_PREP'}
                  className="w-full bg-stone-900 border border-stone-800 rounded-lg px-3 py-2 text-sm text-stone-100 focus:outline-none focus:border-amber-500 pl-8"
                />
                <span className="absolute left-2.5 top-2.5 text-xs text-stone-500 font-mono">EGP</span>
              </div>
              {category === 'SUB_PREP' && (
                <p className="text-[11px] text-stone-500">التحضير الوسيط ليس له سعر بيع مباشر</p>
              )}
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-stone-300">تكلفة الطعام المستهدفة (Target %)</label>
              <div className="relative">
                <input
                  type="number"
                  min="5"
                  max="100"
                  value={targetFoodCostPct}
                  onChange={(e) => setTargetFoodCostPct(Number(e.target.value))}
                  className="w-full bg-stone-900 border border-stone-800 rounded-lg px-3 py-2 text-sm text-stone-100 focus:outline-none focus:border-amber-500 pl-8"
                />
                <span className="absolute left-2.5 top-2.5 text-xs text-stone-500 font-mono">%</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-stone-300">حجم الوجبة المعيارية (Portions)</label>
              <input
                type="number"
                min="1"
                value={portionsYield}
                onChange={(e) => setPortionsYield(Math.max(1, Number(e.target.value)))}
                className="w-full bg-stone-900 border border-stone-800 rounded-lg px-3 py-2 text-sm text-stone-100 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* لوحة كشف الحساب والنتائج الفورية */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-stone-950 border border-stone-800 rounded-xl">
            <div>
              <span className="text-[11px] text-stone-400 block mb-0.5">تكلفة الحصة المحسوبة</span>
              <span className="text-lg font-bold text-amber-400 font-mono">
                {costing.portionCostEGP.toFixed(2)} <span className="text-xs font-normal text-stone-400">ج.م</span>
              </span>
            </div>

            <div>
              <span className="text-[11px] text-stone-400 block mb-0.5">تكلفة الطعام الفعلية (Food Cost)</span>
              <div className="flex items-center gap-1.5">
                <span
                  className={`text-lg font-bold font-mono ${
                    isCostExceeded ? 'text-rose-400' : 'text-emerald-400'
                  }`}
                >
                  {costing.actualFoodCostPct}%
                </span>
                {sellingPriceEGP > 0 && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                      isCostExceeded
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    }`}
                  >
                    {isCostExceeded ? 'تجاوز الهدف' : 'ضمن المخطط'}
                  </span>
                )}
              </div>
            </div>

            <div>
              <span className="text-[11px] text-stone-400 block mb-0.5">هامش الربح الإجمالي (Margin)</span>
              <span className="text-lg font-bold text-stone-200 font-mono">
                {sellingPriceEGP > 0
                  ? `${(100 - costing.actualFoodCostPct).toFixed(1)}%`
                  : '—'}
              </span>
            </div>

            <div>
              <span className="text-[11px] text-stone-400 block mb-0.5">إجمالي تكلفة التشغيلة (Batch)</span>
              <span className="text-lg font-bold text-stone-300 font-mono">
                {costing.totalBatchCostEGP.toFixed(2)} <span className="text-xs font-normal text-stone-500">ج.م</span>
              </span>
            </div>
          </div>

          {/* قائمة المكونات ومعاملات الهدر */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-stone-200 flex items-center gap-2">
                  <span>مكونات الوصفة ومعاملات التنظيف والهدر (Yield Factors)</span>
                  <span className="text-xs font-normal bg-stone-800 text-stone-300 px-2 py-0.5 rounded-full">
                    {ingredients.length} أصناف
                  </span>
                </h4>
                <p className="text-[11px] text-stone-400 mt-0.5">
                  معامل الهدر (Yield Factor) يحسب الفاقد في التنظيف والتقميع والطهي: الكمية الإجمالية = الكمية الصافية ÷ المعامل
                </p>
              </div>
              <button
                type="button"
                onClick={handleAddIngredient}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-lg text-xs font-bold transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة صنف</span>
              </button>
            </div>

            <div className="border border-stone-800 rounded-xl overflow-hidden bg-stone-950/40">
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-stone-900/80 text-stone-400 border-b border-stone-800 font-medium">
                    <tr>
                      <th className="p-3">الصنف الخام</th>
                      <th className="p-3 w-28">الكمية الصافية</th>
                      <th className="p-3 w-20">الوحدة</th>
                      <th className="p-3 w-36">معامل الصافي (Yield)</th>
                      <th className="p-3 w-28">سعر الوحدة (ج.م)</th>
                      <th className="p-3 w-28">إجمالي التكلفة</th>
                      <th className="p-3 w-12 text-center">إجراء</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-800/60 font-sans">
                    {ingredients.map((ing, idx) => {
                      const yieldFactor = ing.yieldFactor > 0 ? ing.yieldFactor : 1;
                      const grossQty = ing.quantityPerPortion / yieldFactor;
                      const costPerPortion = grossQty * (ing.unitCostEGP || 0);

                      return (
                        <tr key={idx} className="hover:bg-stone-900/40 transition">
                          <td className="p-2.5">
                            {availableProducts.length > 0 ? (
                              <div className="space-y-1">
                                <input
                                  type="text"
                                  value={ing.productNameAr}
                                  onChange={(e) => handleIngredientChange(idx, { productNameAr: e.target.value })}
                                  placeholder="اسم الصنف..."
                                  required
                                  className="w-full bg-stone-900 border border-stone-800 rounded px-2 py-1 text-xs text-stone-100 focus:outline-none focus:border-amber-500"
                                />
                              </div>
                            ) : (
                              <input
                                type="text"
                                value={ing.productNameAr}
                                onChange={(e) => handleIngredientChange(idx, { productNameAr: e.target.value })}
                                placeholder="اسم الصنف..."
                                required
                                className="w-full bg-stone-900 border border-stone-800 rounded px-2 py-1 text-xs text-stone-100 focus:outline-none focus:border-amber-500"
                              />
                            )}
                          </td>

                          <td className="p-2.5">
                            <input
                              type="number"
                              min="0.001"
                              step="0.01"
                              value={ing.quantityPerPortion}
                              onChange={(e) => handleIngredientChange(idx, { quantityPerPortion: Number(e.target.value) })}
                              required
                              className="w-full bg-stone-900 border border-stone-800 rounded px-2 py-1 text-xs text-stone-100 focus:outline-none focus:border-amber-500 font-mono text-center"
                            />
                          </td>

                          <td className="p-2.5">
                            <select
                              value={ing.unit}
                              onChange={(e) => handleIngredientChange(idx, { unit: e.target.value })}
                              className="w-full bg-stone-900 border border-stone-800 rounded px-1.5 py-1 text-xs text-stone-100 focus:outline-none focus:border-amber-500"
                            >
                              <option value="كجم">كجم</option>
                              <option value="لتر">لتر</option>
                              <option value="حبة">حبة</option>
                              <option value="جرام">جرام</option>
                              <option value="عبوة">عبوة</option>
                            </select>
                          </td>

                          <td className="p-2.5">
                            <div className="flex items-center gap-2">
                              <input
                                type="number"
                                min="0.1"
                                max="1.0"
                                step="0.05"
                                value={ing.yieldFactor}
                                onChange={(e) => handleIngredientChange(idx, { yieldFactor: Number(e.target.value) })}
                                className="w-16 bg-stone-900 border border-stone-800 rounded px-1.5 py-1 text-xs text-stone-100 focus:outline-none focus:border-amber-500 font-mono text-center"
                              />
                              <span className="text-[10px] text-stone-400">
                                {`(${Math.round(yieldFactor * 100)}% صافي)`}
                              </span>
                            </div>
                          </td>

                          <td className="p-2.5">
                            <input
                              type="number"
                              min="0"
                              step="0.5"
                              value={ing.unitCostEGP || 0}
                              onChange={(e) => handleIngredientChange(idx, { unitCostEGP: Number(e.target.value) })}
                              className="w-full bg-stone-900 border border-stone-800 rounded px-2 py-1 text-xs text-stone-100 focus:outline-none focus:border-amber-500 font-mono text-center"
                            />
                          </td>

                          <td className="p-2.5 font-mono text-amber-400 font-bold">
                            {costPerPortion.toFixed(2)} ج.م
                          </td>

                          <td className="p-2.5 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveIngredient(idx)}
                              className="text-stone-500 hover:text-rose-400 p-1 rounded hover:bg-stone-800 transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </form>

        {/* أزرار التحكم وحفظ البيانات */}
        <div className="flex items-center justify-between p-4 border-t border-stone-800 bg-stone-950/60">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg text-xs font-bold transition"
          >
            إلغاء
          </button>

          <button
            onClick={handleSubmit}
            disabled={saving}
            className="flex items-center gap-2 px-5 py-2 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-stone-950 rounded-lg text-xs font-bold transition shadow-lg shadow-amber-500/10"
          >
            {saving ? (
              <span>جاري الحفظ...</span>
            ) : (
              <>
                <Check className="w-4 h-4" />
                <span>حفظ بطاقة الوصفة</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
