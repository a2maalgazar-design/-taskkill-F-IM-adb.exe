import React, { useState, useEffect } from 'react';
import { 
  ChefHat, 
  Plus, 
  Flame, 
  Layers, 
  TrendingUp, 
  Search, 
  Calendar, 
  ArrowUpDown, 
  AlertTriangle, 
  CheckCircle, 
  ShoppingCart, 
  DollarSign, 
  Package, 
  Clock, 
  Filter, 
  RefreshCw, 
  Trash2, 
  Edit3 
} from 'lucide-react';
import { Recipe, DailyPrepExecution, SuggestedReplenishmentItem } from '../types';
import { recipeService } from '../api/recipeService';
import { RecipeModal } from './RecipeModal';
import { DailyPrepModal } from './DailyPrepModal';
import { useAuth } from '@/features/auth/components/AuthGuard';
import { UserProfile } from '@/features/auth/types';
import { useData } from '@/context/DataContext';

export const RecipesView: React.FC = () => {
  const { user, currentUser, isManager } = useAuth();
  const { products, orderTypes, suppliers, createOrder } = useData();

  const [activeSubTab, setActiveSubTab] = useState<'recipes' | 'prep-history' | 'replenishment'>('recipes');
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [prepHistory, setPrepHistory] = useState<DailyPrepExecution[]>([]);
  const [replenishmentItems, setReplenishmentItems] = useState<SuggestedReplenishmentItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Modals
  const [isRecipeModalOpen, setIsRecipeModalOpen] = useState(false);
  const [editingRecipe, setEditingRecipe] = useState<Recipe | null>(null);
  const [isPrepModalOpen, setIsPrepModalOpen] = useState(false);
  const [prepTargetRecipeId, setPrepTargetRecipeId] = useState<string | undefined>(undefined);

  // Replenishment selection
  const [selectedReplenishIds, setSelectedReplenishIds] = useState<Set<string>>(new Set());
  const [creatingOrder, setCreatingOrder] = useState(false);
  const [orderCreatedSuccess, setOrderCreatedSuccess] = useState<string | null>(null);

  const effectiveUser: UserProfile = user || {
    uid: currentUser?.id || 'user-manager-01',
    email: currentUser?.email || 'manager@kitchen.internal',
    displayName: currentUser?.name || 'مدير المطبخ والمشتريات',
    role: currentUser?.role || 'manager',
    permissions: [],
    isActive: true,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [recs, preps, replenish] = await Promise.all([
        recipeService.getRecipes(),
        recipeService.getDailyPrepExecutions(),
        recipeService.getSuggestedReplenishment(),
      ]);
      setRecipes(recs);
      setPrepHistory(preps);
      setReplenishmentItems(replenish);
    } catch (err) {
      console.error('Failed to load recipe data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filtered recipes
  const filteredRecipes = recipes.filter(r => {
    const matchesCat = selectedCategory === 'ALL' || r.category === selectedCategory;
    const matchesSearch = !searchQuery.trim() || r.dishNameAr.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  // KPI calculations
  const totalRecipesCount = recipes.length;
  const avgFoodCostPct = totalRecipesCount > 0
    ? Math.round(
        recipes.reduce((acc, r) => acc + (r.actualFoodCostPct || 0), 0) /
        recipes.filter(r => (r.sellingPriceEGP || 0) > 0).length || 0
      )
    : 0;
  
  const todayStr = new Date().toISOString().split('T')[0];
  const prepsToday = prepHistory.filter(p => p.date === todayStr);
  const portionsPreparedToday = prepsToday.reduce((acc, p) => acc + p.portionsProduced, 0);

  const handleDeleteRecipe = async (id: string, name: string) => {
    if (!window.confirm(`هل أنت متأكد من حذف بطاقة الوصفة المعيارية "${name}"؟`)) {
      return;
    }
    await recipeService.deleteRecipe(id);
    await loadData();
  };

  const handleToggleSelectReplenish = (prodId: string) => {
    const next = new Set(selectedReplenishIds);
    if (next.has(prodId)) {
      next.delete(prodId);
    } else {
      next.add(prodId);
    }
    setSelectedReplenishIds(next);
  };

  const handleSelectAllReplenish = () => {
    if (selectedReplenishIds.size === replenishmentItems.length) {
      setSelectedReplenishIds(new Set());
    } else {
      setSelectedReplenishIds(new Set(replenishmentItems.map(r => r.productId)));
    }
  };

  const handleCreateReplenishmentOrder = async () => {
    const selected = replenishmentItems.filter(r => selectedReplenishIds.has(r.productId));
    if (selected.length === 0) return;

    setCreatingOrder(true);
    setOrderCreatedSuccess(null);

    try {
      const orderItems = selected.map((item, idx) => ({
        id: `item-${Date.now()}-${idx}`,
        productId: item.productId,
        productName: item.productNameAr,
        requestedQty: item.suggestedOrderQty,
        orderedQty: item.suggestedOrderQty,
        receivedQty: 0,
        rejectedQty: 0,
        outstandingQty: item.suggestedOrderQty,
        unit: item.unit,
        itemStatus: 'pending' as const,
      }));

      const defaultSupplier = suppliers[0];

      const todayStr = new Date().toISOString().split('T')[0];
      const now = new Date();
      const deadline = new Date(now.getTime() + 4 * 3600000).toISOString();
      const expectedDelivery = new Date(now.getTime() + 24 * 3600000).toISOString();

      await createOrder({
        orderTypeId: selected[0]?.orderTypeId || orderTypes[0]?.id || 'cat-general',
        supplierId: defaultSupplier?.id || undefined,
        orderDate: todayStr,
        orderingDeadline: deadline,
        expectedDeliveryTime: expectedDelivery,
        primaryAssigneeId: effectiveUser.uid,
        purchasingChannel: 'واتساب',
        priority: 'urgent',
        requiresApproval: false,
        items: orderItems,
        notes: `أمر شراء تم توليده آلياً لسد نواقص المخزون والوصول للحد الأمثل (Par-Level Replenishment)`,
      });

      setOrderCreatedSuccess(`تم إنشاء أمر التوريد بنجاح لـ ${selected.length} صنف!`);
      setSelectedReplenishIds(new Set());
      await loadData();
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء إنشاء أمر التوريد');
    } finally {
      setCreatingOrder(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* الرأس والمؤشرات الأساسية */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-stone-100">
              الوصفات المعيارية والتحضير اليومي
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
              Culinary Costing & Prep Runs
            </span>
          </div>
          <p className="text-xs text-stone-400 mt-1">
            حساب تكاليف الحصص، رصد نسب تكلفة الغذاء (Food Cost %)، تشغيل الإنتاج وخصم المخزون اللحظي
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => {
              setPrepTargetRecipeId(undefined);
              setIsPrepModalOpen(true);
            }}
            className="flex items-center gap-2 px-3.5 py-2 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 rounded-lg text-xs font-bold transition shadow-sm"
          >
            <Flame className="w-4 h-4" />
            <span>تشغيل تحضير يومي</span>
          </button>

          {isManager && (
            <button
              onClick={() => {
                setEditingRecipe(null);
                setIsRecipeModalOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded-lg text-xs font-bold transition shadow-lg shadow-amber-500/10"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة بطاقة وصفة</span>
            </button>
          )}
        </div>
      </div>

      {/* لوحة المؤشرات الرقمية (KPIs) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-stone-400 text-xs mb-1">
            <span>الوصفات المعيارية</span>
            <ChefHat className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-stone-100 font-mono">
            {totalRecipesCount}
            <span className="text-xs font-normal text-stone-400 mr-1.5">طبق ووصفة</span>
          </div>
          <span className="text-[11px] text-stone-400">معاملات هدر وتكاليف مدققة</span>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-stone-400 text-xs mb-1">
            <span>متوسط تكلفة الطعام (Food Cost)</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono">
            {avgFoodCostPct}%
            <span className="text-xs font-normal text-stone-400 mr-1.5">من المنيو</span>
          </div>
          <span className="text-[11px] text-emerald-500/80">المستهدف العام: 30%</span>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-stone-400 text-xs mb-1">
            <span>تشغيل اليوم (Today's Prep)</span>
            <Flame className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-2xl font-bold text-orange-400 font-mono">
            {portionsPreparedToday}
            <span className="text-xs font-normal text-stone-400 mr-1.5">وجبة منفذة</span>
          </div>
          <span className="text-[11px] text-stone-400">{prepsToday.length} تشغيلات تم خصمها</span>
        </div>

        <div className="bg-stone-900 border border-stone-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-stone-400 text-xs mb-1">
            <span>مقترحات سد النواقص (Par-Level)</span>
            <ShoppingCart className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-blue-400 font-mono">
            {replenishmentItems.length}
            <span className="text-xs font-normal text-stone-400 mr-1.5">صنف تحت الحد الأمثل</span>
          </div>
          <span className="text-[11px] text-stone-400">جاهزة لتوليد أوامر الشراء</span>
        </div>
      </div>

      {/* التبويبات الثلاثة */}
      <div className="flex border-b border-stone-800 gap-2">
        <button
          onClick={() => setActiveSubTab('recipes')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition ${
            activeSubTab === 'recipes'
              ? 'border-amber-500 text-amber-400 bg-amber-500/5'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <ChefHat className="w-4 h-4" />
          <span>بطاقات الوصفات والتكلفة المعيارية</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-stone-800 text-stone-300">
            {recipes.length}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('prep-history')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition ${
            activeSubTab === 'prep-history'
              ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <Flame className="w-4 h-4" />
          <span>سجل التشغيل والإنتاج اليومي</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-stone-800 text-stone-300">
            {prepHistory.length}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('replenishment')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition ${
            activeSubTab === 'replenishment'
              ? 'border-blue-500 text-blue-400 bg-blue-500/5'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <ShoppingCart className="w-4 h-4" />
          <span>مقترحات التوريد الذكية (Auto-Replenishment)</span>
          {replenishmentItems.length > 0 && (
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
              {replenishmentItems.length}
            </span>
          )}
        </button>
      </div>

      {/* المحتوى بحسب التبويب */}
      {activeSubTab === 'recipes' && (
        <div className="space-y-4">
          {/* فلتر البحث والتصنيفات */}
          <div className="flex flex-col sm:flex-row gap-3 justify-between items-stretch sm:items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 absolute right-3 top-2.5 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث باسم الوجبة أو الطبق..."
                className="w-full bg-stone-900 border border-stone-800 rounded-lg pr-9 pl-3 py-1.5 text-xs text-stone-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex flex-wrap gap-1.5 text-xs">
              {[
                { id: 'ALL', label: 'الكل' },
                { id: 'MAIN_COURSE', label: 'أطباق رئيسية' },
                { id: 'APPETIZER', label: 'مقبلات وسلطات' },
                { id: 'SUB_PREP', label: 'تحضيرات وسيطة' },
              ].map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1 rounded-lg transition ${
                    selectedCategory === cat.id
                      ? 'bg-amber-500 text-stone-950 font-bold'
                      : 'bg-stone-900 border border-stone-800 text-stone-400 hover:text-stone-200'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* شبكة بطاقات الوصفات */}
          {loading ? (
            <div className="p-8 text-center text-xs text-stone-500">جاري تحميل الوصفات المعيارية...</div>
          ) : filteredRecipes.length === 0 ? (
            <div className="p-12 text-center border border-dashed border-stone-800 rounded-xl text-stone-500 text-xs">
              لا توجد وصفات مطابقة لخيارات البحث
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredRecipes.map((r) => {
                const isOverBudget = r.sellingPriceEGP > 0 && r.actualFoodCostPct > r.targetFoodCostPct;

                return (
                  <div
                    key={r.id}
                    className="bg-stone-900 border border-stone-800 hover:border-stone-700 rounded-xl p-4 flex flex-col justify-between transition shadow-sm space-y-4"
                  >
                    <div>
                      {/* رأس البطاقة */}
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold bg-stone-800 text-stone-400">
                            {r.category === 'MAIN_COURSE' && 'طبق رئيسي'}
                            {r.category === 'APPETIZER' && 'مقبلات وسلطة'}
                            {r.category === 'SUB_PREP' && 'تحضير وسيط'}
                            {r.category === 'DESSERT' && 'حلويات'}
                            {r.category === 'BAKERY' && 'مخبوزات'}
                            {r.category === 'BEVERAGE' && 'مشروبات'}
                          </span>
                          <h3 className="text-sm font-bold text-stone-100 mt-1.5">{r.dishNameAr}</h3>
                        </div>

                        {isManager && (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                setEditingRecipe(r);
                                setIsRecipeModalOpen(true);
                              }}
                              className="text-stone-400 hover:text-stone-200 p-1 rounded hover:bg-stone-800 transition"
                              title="تعديل"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteRecipe(r.id, r.dishNameAr)}
                              className="text-stone-500 hover:text-rose-400 p-1 rounded hover:bg-stone-800 transition"
                              title="حذف"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>

                      {/* مؤشرات التكلفة والمنيو */}
                      <div className="grid grid-cols-3 gap-2 mt-3 p-2.5 bg-stone-950/60 border border-stone-800/80 rounded-lg text-center font-mono">
                        <div>
                          <span className="text-[10px] text-stone-400 block">تكلفة الحصة</span>
                          <span className="text-xs font-bold text-amber-400">
                            {r.calculatedPortionCostEGP.toFixed(1)} ج.م
                          </span>
                        </div>

                        <div>
                          <span className="text-[10px] text-stone-400 block">سعر المنيو</span>
                          <span className="text-xs font-bold text-stone-200">
                            {r.sellingPriceEGP > 0 ? `${r.sellingPriceEGP} ج.م` : '—'}
                          </span>
                        </div>

                        <div>
                          <span className="text-[10px] text-stone-400 block">Food Cost</span>
                          <span
                            className={`text-xs font-bold ${
                              isOverBudget ? 'text-rose-400' : 'text-emerald-400'
                            }`}
                          >
                            {r.actualFoodCostPct}%
                          </span>
                        </div>
                      </div>

                      {/* ملخص المكونات ومعاملات الهدر */}
                      <div className="mt-3 space-y-1.5">
                        <div className="text-[11px] text-stone-400 font-semibold flex items-center justify-between">
                          <span>المكونات الأساسية ({r.ingredients.length})</span>
                          <span className="text-[10px] text-stone-400">صافي مع الهدر</span>
                        </div>
                        <div className="space-y-1 text-xs">
                          {r.ingredients.slice(0, 3).map((ing, idx) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between py-0.5 border-b border-stone-800/40 text-stone-300 text-[11px]"
                            >
                              <span className="truncate max-w-[170px]">{ing.productNameAr}</span>
                              <span className="font-mono text-stone-400">
                                {ing.quantityPerPortion} {ing.unit}{' '}
                                <span className="text-[9px] text-stone-400">
                                  ({Math.round((ing.yieldFactor || 1) * 100)}%)
                                </span>
                              </span>
                            </div>
                          ))}
                          {r.ingredients.length > 3 && (
                            <div className="text-[10px] text-stone-400 text-left">
                              + {r.ingredients.length - 3} مكونات أخرى...
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* زر تشغيل التحضير السريع */}
                    <button
                      onClick={() => {
                        setPrepTargetRecipeId(r.id);
                        setIsPrepModalOpen(true);
                      }}
                      className="w-full flex items-center justify-center gap-2 py-2 bg-stone-800 hover:bg-stone-700 text-emerald-400 rounded-lg text-xs font-bold transition border border-stone-700/60"
                    >
                      <Flame className="w-3.5 h-3.5" />
                      <span>تشغيل تحضير فوري للوجبة</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* تبويب سجل التشغيل اليومي */}
      {activeSubTab === 'prep-history' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-stone-200">سجل عمليات الإنتاج والتحضير المنفذة</h3>
              <p className="text-xs text-stone-400">
                توثيق الحصص المنفذة والخصومات اللحظية من المخزون بمبدأ FEFO
              </p>
            </div>
            <button
              onClick={loadData}
              className="p-1.5 text-stone-400 hover:text-stone-200 rounded-lg hover:bg-stone-800 transition"
              title="تحديث"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          <div className="border border-stone-800 rounded-xl overflow-hidden bg-stone-900">
            <table className="w-full text-right text-xs">
              <thead className="bg-stone-950/80 text-stone-400 border-b border-stone-800 font-medium">
                <tr>
                  <th className="p-3">تاريخ التشغيل</th>
                  <th className="p-3">اسم الوصفة / الوجبة</th>
                  <th className="p-3">عدد الحصص المنفذة</th>
                  <th className="p-3">الشيف المسؤول</th>
                  <th className="p-3">توقيت التنفيذ</th>
                  <th className="p-3 text-center">أثر المخزون</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/60 font-sans">
                {prepHistory.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-stone-500">
                      لم يتم تشغيل عمليات تحضير حتى الآن
                    </td>
                  </tr>
                ) : (
                  prepHistory.map((prep) => (
                    <tr key={prep.id} className="hover:bg-stone-800/40 transition">
                      <td className="p-3 font-mono text-stone-300">{prep.date}</td>
                      <td className="p-3 font-bold text-stone-100">{prep.dishNameAr}</td>
                      <td className="p-3 font-mono font-bold text-emerald-400 text-sm">
                        {prep.portionsProduced} وجبة
                      </td>
                      <td className="p-3 text-stone-300">{prep.actorName}</td>
                      <td className="p-3 font-mono text-stone-400 text-[11px]">
                        {new Date(prep.executedAt).toLocaleTimeString('ar-EG', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="p-3 text-center">
                        <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                          <CheckCircle className="w-3 h-3" />
                          <span>تم الخصم FEFO</span>
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* تبويب مقترحات التوريد الذكية وسد النواقص */}
      {activeSubTab === 'replenishment' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="text-sm font-bold text-stone-200">
                مقترحات سد النواقص والوصول للحد الأمثل (Par-Level Replenishment)
              </h3>
              <p className="text-xs text-stone-400">
                حساب آلي للنواقص بناء على الرصيد اللحظي والحد التشغيلي الأمثل (Ideal Par Level)
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleSelectAllReplenish}
                className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg text-xs transition"
              >
                {selectedReplenishIds.size === replenishmentItems.length ? 'إلغاء التحديد' : 'تحديد الكل'}
              </button>

              <button
                onClick={handleCreateReplenishmentOrder}
                disabled={creatingOrder || selectedReplenishIds.size === 0}
                className="flex items-center gap-2 px-4 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition shadow-sm"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>
                  {creatingOrder ? 'جاري التوليد...' : `إنشاء أمر شراء (${selectedReplenishIds.size})`}
                </span>
              </button>
            </div>
          </div>

          {orderCreatedSuccess && (
            <div className="p-3 bg-emerald-550/10 border border-emerald-500/30 rounded-lg text-emerald-400 text-xs flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{orderCreatedSuccess}</span>
            </div>
          )}

          <div className="border border-stone-800 rounded-xl overflow-hidden bg-stone-900">
            <table className="w-full text-right text-xs">
              <thead className="bg-stone-950/80 text-stone-400 border-b border-stone-800 font-medium">
                <tr>
                  <th className="p-3 w-10 text-center">اختيار</th>
                  <th className="p-3">اسم الصنف</th>
                  <th className="p-3">الرصيد اللحظي</th>
                  <th className="p-3">حد الأمان (Min)</th>
                  <th className="p-3">الحد الأمثل (Par Level)</th>
                  <th className="p-3">الكمية المقترحة للطلب</th>
                  <th className="p-3 text-center">مستوى الخطر</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/60 font-sans">
                {replenishmentItems.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-stone-500">
                      جميع الأصناف في المستوى التشغيلي الممتاز ولا توجد نواقص حالياً!
                    </td>
                  </tr>
                ) : (
                  replenishmentItems.map((item) => {
                    const isBelowMin = item.currentStock <= item.minThreshold;
                    const isSelected = selectedReplenishIds.has(item.productId);

                    return (
                      <tr
                        key={item.productId}
                        onClick={() => handleToggleSelectReplenish(item.productId)}
                        className={`cursor-pointer transition ${
                          isSelected ? 'bg-blue-500/10' : 'hover:bg-stone-800/40'
                        }`}
                      >
                        <td className="p-3 text-center" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleToggleSelectReplenish(item.productId)}
                            className="rounded bg-stone-950 border-stone-700 text-blue-500 focus:ring-0 w-4 h-4 cursor-pointer"
                          />
                        </td>
                        <td className="p-3 font-bold text-stone-200">{item.productNameAr}</td>
                        <td className="p-3 font-mono">
                          <span className={isBelowMin ? 'text-rose-400 font-bold' : 'text-stone-300'}>
                            {item.currentStock} {item.unit}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-stone-400">
                          {item.minThreshold} {item.unit}
                        </td>
                        <td className="p-3 font-mono text-stone-300">
                          {item.idealParLevel} {item.unit}
                        </td>
                        <td className="p-3 font-mono font-bold text-blue-400 text-sm">
                          + {item.suggestedOrderQty} {item.unit}
                        </td>
                        <td className="p-3 text-center">
                          {isBelowMin ? (
                            <span className="inline-flex items-center gap-1 text-[11px] text-rose-400 bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded-full font-bold">
                              <AlertTriangle className="w-3 h-3" />
                              <span>حرج (تحت الأمان)</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full">
                              <span>بحاجة لإعادة التوريد</span>
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* النوافذ المنبثقة */}
      {isRecipeModalOpen && (
        <RecipeModal
          recipe={editingRecipe}
          onClose={() => {
            setIsRecipeModalOpen(false);
            setEditingRecipe(null);
          }}
          onSaved={() => {
            loadData();
          }}
          actor={effectiveUser}
          availableProducts={products.map(p => ({
            id: p.id,
            nameAr: p.nameAr,
            unit: p.unit || 'كجم',
            currentPriceEGP: p.estimatedUnitPrice || 0,
          }))}
        />
      )}

      {isPrepModalOpen && (
        <DailyPrepModal
          recipes={recipes}
          initialRecipeId={prepTargetRecipeId}
          onClose={() => {
            setIsPrepModalOpen(false);
            setPrepTargetRecipeId(undefined);
          }}
          onSuccess={() => {
            loadData();
          }}
          actor={effectiveUser}
        />
      )}
    </div>
  );
};
