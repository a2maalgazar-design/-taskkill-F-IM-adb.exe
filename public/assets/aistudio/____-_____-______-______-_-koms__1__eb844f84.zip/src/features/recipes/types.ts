export interface RecipeIngredient {
  productId: string;
  productNameAr: string;
  unit: string; // كجم، لتر، حبة، جرام
  quantityPerPortion: number; // الكمية للوجبة الواحدة
  yieldFactor: number; // معامل الهدر والتنظيف (مثال: 0.85 = صافي بعد التنظيف 85%)
  unitCostEGP?: number; // تكلفة الوحدة المشتقة من آخر فاتورة معتمدة
}

export interface Recipe {
  id: string;
  dishNameAr: string;
  category: 'MAIN_COURSE' | 'APPETIZER' | 'DESSERT' | 'BAKERY' | 'BEVERAGE' | 'SUB_PREP';
  portionsYield: number; // عدد الحصص الناتجة من الوصفة
  sellingPriceEGP: number; // سعر البيع في المنيو (0 إذا كانت وصفة تحضير وسيطة)
  ingredients: RecipeIngredient[];
  calculatedPortionCostEGP: number; // تكلفة الحصة الواحدة المحسوبة آلياً
  targetFoodCostPct: number; // نسبة تكلفة الغذاء المستهدفة (مثال: 30%)
  actualFoodCostPct: number; // النسبة الفعلية المحسوبة
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DailyPrepExecution {
  id: string;
  date: string; // YYYY-MM-DD
  recipeId: string;
  dishNameAr: string;
  portionsProduced: number; // عدد الحصص المنفذة
  actorId: string;
  actorName: string;
  executedAt: string;
}

export interface SuggestedReplenishmentItem {
  productId: string;
  productNameAr: string;
  orderTypeId: string;
  currentStock: number;
  minThreshold: number;
  idealParLevel: number;
  suggestedOrderQty: number; // idealParLevel - currentStock
  unit: string;
  supplierId?: string;
  supplierNameAr?: string;
}
