import React from 'react';
import { BranchBudgetPeriod } from '../types';
import { DollarSign, AlertCircle, TrendingUp, CheckCircle, Clock } from 'lucide-react';

interface BudgetOverviewWidgetProps {
  budget: BranchBudgetPeriod | null;
  onOpenOverrides: () => void;
  pendingOverridesCount: number;
}

export const BudgetOverviewWidget: React.FC<BudgetOverviewWidgetProps> = ({
  budget,
  onOpenOverrides,
  pendingOverridesCount,
}) => {
  if (!budget) {
    return (
      <div className="p-4 bg-stone-900 border border-stone-800 rounded-xl text-center text-xs text-stone-500">
        لم يتم ضبط موازنة مالية نشطة لهذه الفترة. المشتريات تعمل بدون سقف مقيد.
      </div>
    );
  }

  const overallUtilization = budget.totalAllocatedBudgetEGP > 0
    ? Math.round(((budget.totalActualSpentEGP + budget.totalCommittedEGP) / budget.totalAllocatedBudgetEGP) * 100)
    : 0;

  return (
    <div className="bg-stone-900 border border-stone-800 rounded-xl p-4 shadow-sm space-y-4 text-xs text-stone-100">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-stone-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-stone-100 text-sm">موازنة المشتريات والسيولة النقدية — {budget.branchNameAr}</h3>
            <span className="text-[10px] bg-stone-950 border border-stone-800 text-amber-400 px-2 py-0.5 rounded font-mono">
              {budget.startDate} إلى {budget.endDate}
            </span>
          </div>
          <p className="text-stone-400 text-[11px] mt-0.5">مراقبة سقف السيولة النقدية والمصروفات المحجوزة لكل تصنيف توريد.</p>
        </div>

        {pendingOverridesCount > 0 && (
          <button
            type="button"
            onClick={onOpenOverrides}
            className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded-lg font-bold transition flex items-center gap-1.5 shadow-lg shadow-amber-500/20 animate-pulse"
          >
            <AlertCircle className="w-4 h-4" />
            <span>طلبات اعتماد مالي معلقة</span>
            <span className="bg-stone-950 text-amber-400 text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
              {pendingOverridesCount}
            </span>
          </button>
        )}
      </div>

      {/* المؤشرات العامة */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-3 bg-stone-950/60 border border-stone-800 rounded-lg">
          <span className="text-stone-400 text-[10px] block">الموازنة الكلية المعتمدة</span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="text-lg font-bold font-mono text-stone-100">{budget.totalAllocatedBudgetEGP.toLocaleString('en-US')}</span>
            <span className="text-stone-400 text-[10px]">ج.م</span>
          </div>
        </div>

        <div className="p-3 bg-stone-950/60 border border-stone-800 rounded-lg">
          <span className="text-stone-400 text-[10px] block">المنصرف الفعلي المحقق</span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="text-lg font-bold font-mono text-emerald-400">{budget.totalActualSpentEGP.toLocaleString('en-US')}</span>
            <span className="text-stone-400 text-[10px]">ج.م</span>
          </div>
        </div>

        <div className="p-3 bg-stone-950/60 border border-stone-800 rounded-lg">
          <span className="text-stone-400 text-[10px] block">المحجوز لأوامر جارية</span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="text-lg font-bold font-mono text-sky-400">{budget.totalCommittedEGP.toLocaleString('en-US')}</span>
            <span className="text-stone-400 text-[10px]">ج.م</span>
          </div>
        </div>

        <div className="p-3 bg-stone-950/60 border border-stone-800 rounded-lg">
          <span className="text-stone-400 text-[10px] block">الرصيد المتاح الحر</span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className={`text-lg font-bold font-mono ${budget.totalRemainingEGP < 0 ? 'text-rose-400' : 'text-amber-400'}`}>
              {budget.totalRemainingEGP.toLocaleString('en-US')}
            </span>
            <span className="text-stone-400 text-[10px]">ج.م</span>
          </div>
        </div>
      </div>

      {/* تفصيل الموازنات بحسب نوع التوريد مع شريط التقدم */}
      <div className="space-y-2 pt-2">
        <h4 className="font-bold text-stone-300 text-[11px]">معدل استهلاك الموازنة بحسب فئة التوريد:</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {budget.categories.map((cat) => (
            <div key={cat.orderTypeId} className="p-3 border border-stone-800 rounded-xl bg-stone-950/40 space-y-1.5">
              <div className="flex justify-between items-center">
                <span className="font-bold text-stone-200">{cat.orderTypeNameAr}</span>
                <span className={`font-mono font-bold text-[11px] ${cat.isExceeded ? 'text-rose-400' : 'text-stone-300'}`}>
                  {cat.utilizationRatePct}%
                </span>
              </div>

              {/* شريط التقدم الرسومي */}
              <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${
                    cat.utilizationRatePct > 100
                      ? 'bg-rose-500'
                      : cat.utilizationRatePct > 80
                      ? 'bg-amber-500'
                      : 'bg-emerald-500'
                  }`}
                  style={{ width: `${Math.min(100, cat.utilizationRatePct)}%` }}
                />
              </div>

              <div className="flex justify-between text-[10px] text-stone-400 font-mono">
                <span>المتبقي: {cat.remainingAmountEGP.toLocaleString('en-US')} ج.م</span>
                <span>المعتمد: {cat.allocatedAmountEGP.toLocaleString('en-US')} ج.م</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
