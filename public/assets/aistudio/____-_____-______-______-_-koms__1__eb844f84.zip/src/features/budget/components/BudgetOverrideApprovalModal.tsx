import React, { useState } from 'react';
import { BudgetOverrideRequest } from '../types';
import { budgetService } from '../api/budgetService';
import { UserProfile } from '@/features/auth/types';
import { X, AlertCircle, CheckCircle, XCircle } from 'lucide-react';

interface BudgetOverrideApprovalModalProps {
  requests: BudgetOverrideRequest[];
  currentUser: UserProfile;
  onClose: () => void;
  onActionComplete: () => void;
}

export const BudgetOverrideApprovalModal: React.FC<BudgetOverrideApprovalModalProps> = ({
  requests,
  currentUser,
  onClose,
  onActionComplete,
}) => {
  const [selectedRequest, setSelectedRequest] = useState<BudgetOverrideRequest | null>(requests[0] || null);
  const [decisionNote, setDecisionNote] = useState('');
  const [loading, setLoading] = useState(false);

  const handleDecision = async (decision: 'APPROVED' | 'REJECTED') => {
    if (!selectedRequest) return;
    if (!decisionNote.trim()) {
      alert('يرجى تدوين سبب ومبرر القرار المالي');
      return;
    }

    setLoading(true);
    try {
      await budgetService.decideBudgetOverride(
        selectedRequest.id,
        decision,
        decisionNote.trim(),
        currentUser
      );
      onActionComplete();
      onClose();
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء تسجيل القرار');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-stone-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-3 text-xs overflow-y-auto text-stone-100">
      <div className="bg-stone-900 border border-stone-800 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
        <div className="p-4 bg-stone-950 border-b border-stone-800 flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <AlertCircle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-100">اعتمادات تجاوز موازنة المشتريات (Financial Overrides)</h3>
              <span className="text-[11px] text-stone-400">طلبات الشراء المعلقة التي تجاوزت السقف المالي للفترة</span>
            </div>
          </div>
          <button onClick={onClose} className="text-stone-400 hover:text-stone-100 p-1 rounded hover:bg-stone-800 transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-4">
          {requests.length === 0 ? (
            <div className="p-8 text-center text-stone-500">لا توجد طلبات اعتماد مالي معلقة حالياً.</div>
          ) : (
            <div className="space-y-4">
              {/* قائمة الطلبات المعلقة للاختيار */}
              <div className="flex gap-2 overflow-x-auto pb-1">
                {requests.map(req => (
                  <button
                    key={req.id}
                    type="button"
                    onClick={() => { setSelectedRequest(req); setDecisionNote(''); }}
                    className={`px-3 py-2 rounded-lg border text-right whitespace-nowrap transition ${
                      selectedRequest?.id === req.id
                        ? 'border-amber-500 bg-amber-500/10 text-amber-300'
                        : 'border-stone-800 bg-stone-950 text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    <span className="font-bold block font-mono">{req.orderCode}</span>
                    <span className="text-[10px] opacity-80 font-mono">{req.orderTotalAmountEGP.toLocaleString('en-US')} ج.م</span>
                  </button>
                ))}
              </div>

              {selectedRequest && (
                <div className="border border-stone-800 rounded-xl p-4 bg-stone-950/60 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-stone-100 text-sm">أمر الشراء: {selectedRequest.orderCode}</h4>
                      <span className="text-[11px] text-stone-400">طلب بواسطة: {selectedRequest.requestedByName}</span>
                    </div>
                    <span className="bg-rose-500/15 text-rose-400 border border-rose-500/30 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                      قيد الاعتماد المالي
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 bg-stone-900 p-3 rounded-xl border border-stone-800 text-center font-mono">
                    <div>
                      <span className="text-stone-400 text-[10px] block">قيمة الطلب</span>
                      <span className="font-bold text-stone-100 text-sm">{selectedRequest.orderTotalAmountEGP.toLocaleString('en-US')} ج.م</span>
                    </div>
                    <div>
                      <span className="text-stone-400 text-[10px] block">المتبقي بالموازنة</span>
                      <span className="font-bold text-stone-400 text-sm">{selectedRequest.availableBudgetBeforeOrderEGP.toLocaleString('en-US')} ج.م</span>
                    </div>
                    <div>
                      <span className="text-stone-400 text-[10px] block">مقدار العجز</span>
                      <span className="font-bold text-rose-400 text-sm">+{selectedRequest.exceededAmountEGP.toLocaleString('en-US')} ج.م</span>
                    </div>
                  </div>

                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 text-[11px]">
                    <strong>مبرر التنبيه:</strong> {selectedRequest.reasonAr}
                  </div>

                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">تدوين مبررات وتوجيهات القرار المالي الإلزامية *</label>
                    <textarea
                      rows={2}
                      value={decisionNote}
                      onChange={(e) => setDecisionNote(e.target.value)}
                      placeholder="مثال: تمت الموافقة لتغطية حجوزات حفلات نهاية الأسبوع الاستثنائية..."
                      className="w-full p-2.5 bg-stone-900 border border-stone-800 rounded-lg text-stone-100 focus:outline-none focus:border-amber-500"
                      required
                    />
                  </div>

                  <div className="pt-2 flex gap-2">
                    <button
                      type="button"
                      onClick={() => handleDecision('APPROVED')}
                      disabled={loading}
                      className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-stone-950 rounded-lg font-bold transition flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-500/10"
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>{loading ? 'جاري المعالجة...' : 'الموافقة على التجاوز وتحويل الطلب لـ ORDERED'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDecision('REJECTED')}
                      disabled={loading}
                      className="flex-1 py-2.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 disabled:opacity-50 rounded-lg font-bold transition flex items-center justify-center gap-1.5"
                    >
                      <XCircle className="w-4 h-4" />
                      <span>{loading ? 'جاري المعالجة...' : 'رفض التجاوز وإلغاء الطلب (CANCEL)'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
