import React, { useState, useEffect } from 'react';
import { DollarSign, AlertCircle, Calendar, CheckCircle2, Clock, CreditCard } from 'lucide-react';
import { BranchBudgetPeriod, BudgetOverrideRequest, SupplierPaymentSchedule } from '../types';
import { budgetService } from '../api/budgetService';
import { BudgetOverviewWidget } from './BudgetOverviewWidget';
import { BudgetOverrideApprovalModal } from './BudgetOverrideApprovalModal';
import { useAuth } from '@/features/auth/components/AuthGuard';
import { UserProfile } from '@/features/auth/types';
import { INITIAL_BRANCHES } from '@/features/transfers/api/transferService';

export const BudgetView: React.FC = () => {
  const { user, currentUser } = useAuth();
  const [selectedBranchId, setSelectedBranchId] = useState<string>('br-zamalek');
  const [budget, setBudget] = useState<BranchBudgetPeriod | null>(null);
  const [overrideRequests, setOverrideRequests] = useState<BudgetOverrideRequest[]>([]);
  const [paymentSchedules, setPaymentSchedules] = useState<SupplierPaymentSchedule[]>([]);
  const [isOverrideModalOpen, setIsOverrideModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const effectiveUser: UserProfile = user || {
    uid: currentUser?.id || 'usr-manager',
    email: currentUser?.email || 'manager@kitchen.internal',
    displayName: currentUser?.name || 'المدير المالي والتشغيلي',
    role: currentUser?.role || 'manager',
    permissions: [],
    isActive: true,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [b, ovr, pay] = await Promise.all([
        budgetService.getCurrentActiveBudget(selectedBranchId),
        budgetService.getPendingOverrideRequests(selectedBranchId),
        budgetService.getPaymentSchedules(),
      ]);
      setBudget(b);
      setOverrideRequests(ovr);
      setPaymentSchedules(pay);
    } catch (err) {
      console.error('Failed to load budget data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedBranchId]);

  return (
    <div className="space-y-6 text-xs text-stone-100">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-stone-100">الموازنات المالية وسقوف المشتريات (Procurement Budget & Cash Flow)</h2>
            <span className="text-[10px] px-2.5 py-0.5 rounded-full font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
              Financial Control & AP Schedules
            </span>
          </div>
          <p className="text-xs text-stone-400 mt-1">
            إدارة موازنات الفروع التقديرية، التزامات الشراء المحجوزة، وجدولة استحقاقات الموردين (Net 15 / 30 / COD)
          </p>
        </div>

        <select
          value={selectedBranchId}
          onChange={(e) => setSelectedBranchId(e.target.value)}
          className="bg-stone-900 border border-stone-800 rounded-lg px-3 py-1.5 text-xs text-stone-100 focus:outline-none focus:border-amber-500"
        >
          {INITIAL_BRANCHES.map(b => (
            <option key={b.id} value={b.id}>{b.nameAr}</option>
          ))}
        </select>
      </div>

      {/* الودجت المالي الرئيسي للموازنة */}
      <BudgetOverviewWidget
        budget={budget}
        onOpenOverrides={() => setIsOverrideModalOpen(true)}
        pendingOverridesCount={overrideRequests.length}
      />

      {/* جدول استحقاقات سداد فواتير الموردين (AP Payment Schedules) */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl overflow-hidden shadow-sm space-y-0">
        <div className="p-3 bg-stone-950/80 border-b border-stone-800 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-amber-400" />
            <h4 className="font-bold text-stone-200">جدول استحقاقات سداد الموردين (Accounts Payable Payment Schedule)</h4>
          </div>
          <span className="text-[11px] text-stone-400 font-mono">
            {paymentSchedules.filter(p => !p.isPaid).length} فواتير قيد السداد
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-stone-950/60 border-b border-stone-800 text-stone-400 font-semibold">
              <tr>
                <th className="p-3">رقم الفاتورة</th>
                <th className="p-3">المورد</th>
                <th className="p-3">كود الطلب</th>
                <th className="p-3">المبلغ المستحق</th>
                <th className="p-3">شروط الدفع</th>
                <th className="p-3">تاريخ الاستحقاق</th>
                <th className="p-3 text-center">حالة السداد</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-800/60 font-sans">
              {paymentSchedules.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-stone-500">لا توجد فواتير مجدولة للسداد حالياً</td>
                </tr>
              ) : (
                paymentSchedules.map(pay => (
                  <tr key={pay.id} className="hover:bg-stone-800/40 transition">
                    <td className="p-3 font-mono font-bold text-stone-200">{pay.invoiceNumber}</td>
                    <td className="p-3 font-bold text-stone-100">{pay.supplierNameAr}</td>
                    <td className="p-3 font-mono text-stone-400">{pay.orderCode}</td>
                    <td className="p-3 font-mono font-bold text-amber-400">{pay.amountEGP.toLocaleString('en-US')} ج.م</td>
                    <td className="p-3">
                      <span className="font-mono text-[11px] bg-stone-800 text-stone-300 px-2 py-0.5 rounded">
                        {pay.paymentTerms === 'COD' && 'نقداً عند الاستلام (COD)'}
                        {pay.paymentTerms === 'NET_15' && 'آجل 15 يوم (Net 15)'}
                        {pay.paymentTerms === 'NET_30' && 'آجل 30 يوم (Net 30)'}
                      </span>
                    </td>
                    <td className="p-3 font-mono text-stone-300">{pay.dueDate}</td>
                    <td className="p-3 text-center">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold inline-flex items-center gap-1 ${
                        pay.isPaid
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}>
                        {pay.isPaid ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                        <span>{pay.isPaid ? 'تم السداد' : 'قيد الصرف'}</span>
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* نافذة اعتمادات تجاوز الموازنة */}
      {isOverrideModalOpen && (
        <BudgetOverrideApprovalModal
          requests={overrideRequests}
          currentUser={effectiveUser}
          onClose={() => setIsOverrideModalOpen(false)}
          onActionComplete={() => loadData()}
        />
      )}
    </div>
  );
};
