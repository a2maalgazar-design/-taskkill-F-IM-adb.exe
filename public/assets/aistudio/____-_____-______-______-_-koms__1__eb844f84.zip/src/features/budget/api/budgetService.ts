import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  addDoc, 
  runTransaction, 
  query, 
  where, 
  orderBy, 
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { BranchBudgetPeriod, BudgetOverrideRequest, SupplierPaymentSchedule } from '../types';
import { UserProfile } from '@/features/auth/types';

const LOCAL_BUDGET_KEY = 'koms_kitchen_budget_cache';
const LOCAL_OVERRIDES_KEY = 'koms_kitchen_overrides_cache';
const LOCAL_PAYMENTS_KEY = 'koms_kitchen_payments_cache';

const INITIAL_DEMO_BUDGET: BranchBudgetPeriod = {
  id: 'budget-2026-m10',
  branchId: 'br-zamalek',
  branchNameAr: 'فرع الزمالك (Zamalek Satellite)',
  periodType: 'MONTHLY',
  startDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
  endDate: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toISOString().split('T')[0],
  totalAllocatedBudgetEGP: 350000,
  totalActualSpentEGP: 168000,
  totalCommittedEGP: 42000,
  totalRemainingEGP: 140000,
  singleOrderApprovalThresholdEGP: 25000,
  isActive: true,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  categories: [
    {
      orderTypeId: 'cat-meat',
      orderTypeNameAr: 'اللحوم والدواجن الطازجة',
      allocatedAmountEGP: 140000,
      actualSpentAmountEGP: 78000,
      committedAmountEGP: 20000,
      remainingAmountEGP: 42000,
      utilizationRatePct: 70,
      isExceeded: false,
    },
    {
      orderTypeId: 'cat-veg',
      orderTypeNameAr: 'الخضار والفاكهة الطازجة',
      allocatedAmountEGP: 70000,
      actualSpentAmountEGP: 39000,
      committedAmountEGP: 9000,
      remainingAmountEGP: 22000,
      utilizationRatePct: 69,
      isExceeded: false,
    },
    {
      orderTypeId: 'cat-oils',
      orderTypeNameAr: 'الزيوت والصوصات والبقالة',
      allocatedAmountEGP: 60000,
      actualSpentAmountEGP: 32000,
      committedAmountEGP: 8000,
      remainingAmountEGP: 20000,
      utilizationRatePct: 67,
      isExceeded: false,
    },
    {
      orderTypeId: 'cat-bakery',
      orderTypeNameAr: 'العيش البلدي والبريوش',
      allocatedAmountEGP: 40000,
      actualSpentAmountEGP: 14000,
      committedAmountEGP: 3000,
      remainingAmountEGP: 23000,
      utilizationRatePct: 43,
      isExceeded: false,
    },
    {
      orderTypeId: 'cat-clean',
      orderTypeNameAr: 'المنظفات ومستلزمات التغليف',
      allocatedAmountEGP: 40000,
      actualSpentAmountEGP: 5000,
      committedAmountEGP: 2000,
      remainingAmountEGP: 33000,
      utilizationRatePct: 18,
      isExceeded: false,
    },
  ],
};

const INITIAL_DEMO_OVERRIDES: BudgetOverrideRequest[] = [
  {
    id: 'ovr-2026-001',
    orderId: 'PO-2026-902',
    orderCode: 'PO-2026-902',
    branchId: 'br-zamalek',
    orderTypeId: 'cat-meat',
    orderTotalAmountEGP: 48000,
    availableBudgetBeforeOrderEGP: 42000,
    exceededAmountEGP: 6000,
    reasonAr: 'تجاوز سقف الطلب الفردي المصرح به (25,000 ج.م) وتجاوز موازنة اللحوم لطلب حفل زفاف نهاية الأسبوع',
    status: 'PENDING',
    requestedBy: 'usr-chef',
    requestedByName: 'الشيف شادي أحمد',
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
];

const INITIAL_DEMO_PAYMENTS: SupplierPaymentSchedule[] = [
  {
    id: 'pay-001',
    invoiceId: 'inv-101',
    invoiceNumber: 'INV-2026-778',
    supplierId: 'sup-meat',
    supplierNameAr: 'الشركة العربية للحوم المبردة',
    orderCode: 'PO-2026-003',
    amountEGP: 24500,
    paymentTerms: 'NET_15',
    invoiceDate: new Date(Date.now() - 86400000 * 5).toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 86400000 * 10).toISOString().split('T')[0],
    isPaid: false,
  },
  {
    id: 'pay-002',
    invoiceId: 'inv-102',
    invoiceNumber: 'INV-2026-789',
    supplierId: 'sup-veg',
    supplierNameAr: 'مؤسسة الأهرام للخضار الطازج',
    orderCode: 'PO-2026-004',
    amountEGP: 12800,
    paymentTerms: 'COD',
    invoiceDate: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
    dueDate: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
    isPaid: true,
    paidAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    paymentReference: 'CASH-REC-4412',
  },
];

function getLocalBudget(): BranchBudgetPeriod {
  try {
    const raw = localStorage.getItem(LOCAL_BUDGET_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Could not read budget local cache:', e);
  }
  localStorage.setItem(LOCAL_BUDGET_KEY, JSON.stringify(INITIAL_DEMO_BUDGET));
  return INITIAL_DEMO_BUDGET;
}

function saveLocalBudget(budget: BranchBudgetPeriod): void {
  try {
    localStorage.setItem(LOCAL_BUDGET_KEY, JSON.stringify(budget));
  } catch (e) {
    console.warn('Could not save budget local cache:', e);
  }
}

function getLocalOverrides(): BudgetOverrideRequest[] {
  try {
    const raw = localStorage.getItem(LOCAL_OVERRIDES_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Could not read overrides local cache:', e);
  }
  localStorage.setItem(LOCAL_OVERRIDES_KEY, JSON.stringify(INITIAL_DEMO_OVERRIDES));
  return INITIAL_DEMO_OVERRIDES;
}

function saveLocalOverrides(overrides: BudgetOverrideRequest[]): void {
  try {
    localStorage.setItem(LOCAL_OVERRIDES_KEY, JSON.stringify(overrides));
  } catch (e) {
    console.warn('Could not save overrides local cache:', e);
  }
}

export const budgetService = {
  /**
   * استرجاع الموازنة الحالية النشطة للفرع
   */
  async getCurrentActiveBudget(branchId: string): Promise<BranchBudgetPeriod | null> {
    try {
      const today = new Date().toISOString().split('T')[0];
      const q = query(
        collection(db, `branches/${branchId}/budgets`),
        where('isActive', '==', true)
      );
      const snap = await getDocs(q);
      if (!snap.empty) {
        return { id: snap.docs[0].id, ...snap.docs[0].data() } as BranchBudgetPeriod;
      }
    } catch (err) {
      console.warn('getCurrentActiveBudget fallback:', err);
    }
    return getLocalBudget();
  },

  /**
   * جلب طلبات تجاوز الموازنة المعلقة
   */
  async getPendingOverrideRequests(branchId?: string): Promise<BudgetOverrideRequest[]> {
    try {
      const q = query(collection(db, 'budgetOverrides'), where('status', '==', 'PENDING'));
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs.map(d => ({ id: d.id, ...d.data() } as BudgetOverrideRequest));
      }
    } catch (err) {
      console.warn('getPendingOverrideRequests fallback:', err);
    }
    return getLocalOverrides().filter(o => o.status === 'PENDING');
  },

  /**
   * فحص الموازنة وحجز المبلغ المالي للطلب قبل تحويله إلى ORDERED:
   * إذا تجاوز الطلب الرصيد المتبقي أو تجاوز سقف الطلب الواحد، يوضع في حالة تعليق مالي
   */
  async validateAndReserveOrderBudget(
    branchId: string,
    orderId: string,
    orderCode: string,
    orderTypeId: string,
    orderTotalAmountEGP: number,
    actor: UserProfile
  ): Promise<{ canProceedDirectly: boolean; overrideRequestId?: string }> {
    const budget = await this.getCurrentActiveBudget(branchId);

    // في حال عدم تعيين موازنة، يتم السماح المؤقت افتراضياً
    if (!budget) {
      return { canProceedDirectly: true };
    }

    const categoryAlloc = budget.categories.find(c => c.orderTypeId === orderTypeId);
    const remainingBudget = categoryAlloc ? categoryAlloc.remainingAmountEGP : 50000;
    const isOverCategoryBudget = orderTotalAmountEGP > remainingBudget;
    const isOverSingleOrderLimit = orderTotalAmountEGP > budget.singleOrderApprovalThresholdEGP;

    // في حال وجود تجاوز مالي
    if (isOverCategoryBudget || isOverSingleOrderLimit) {
      const overrideColRef = collection(db, 'budgetOverrides');
      const exceededAmount = Math.max(0, orderTotalAmountEGP - remainingBudget);

      const overrideRecord: BudgetOverrideRequest = {
        id: `ovr-${Date.now()}`,
        orderId,
        orderCode,
        branchId,
        orderTypeId,
        orderTotalAmountEGP,
        availableBudgetBeforeOrderEGP: remainingBudget,
        exceededAmountEGP: exceededAmount,
        reasonAr: isOverCategoryBudget
          ? `تجاوز الموازنة المخصصة بمبلغ (${exceededAmount} ج.م)`
          : `تجاوز سقف الطلب الفردي المصرح به (${budget.singleOrderApprovalThresholdEGP} ج.م)`,
        status: 'PENDING',
        requestedBy: actor.uid,
        requestedByName: actor.displayName,
        createdAt: new Date().toISOString(),
      };

      try {
        await addDoc(overrideColRef, overrideRecord);
      } catch (e) {
        console.warn('addDoc budgetOverrides fallback:', e);
      }

      const overrides = getLocalOverrides();
      overrides.unshift(overrideRecord);
      saveLocalOverrides(overrides);

      return { canProceedDirectly: false, overrideRequestId: overrideRecord.id };
    }

    // إذا كان الطلب ضمن الموازنة، يتم حجز المبلغ كالتزام (Committed Spend)
    const updatedCategories = budget.categories.map((cat) => {
      if (cat.orderTypeId === orderTypeId) {
        const newCommitted = cat.committedAmountEGP + orderTotalAmountEGP;
        const newRemaining = cat.allocatedAmountEGP - (cat.actualSpentAmountEGP + newCommitted);
        const utilPct = cat.allocatedAmountEGP > 0 
          ? Math.round(((cat.actualSpentAmountEGP + newCommitted) / cat.allocatedAmountEGP) * 100) 
          : 0;

        return {
          ...cat,
          committedAmountEGP: newCommitted,
          remainingAmountEGP: newRemaining,
          utilizationRatePct: utilPct,
          isExceeded: newRemaining < 0,
        };
      }
      return cat;
    });

    const totalCommitted = budget.totalCommittedEGP + orderTotalAmountEGP;
    const totalRemaining = budget.totalAllocatedBudgetEGP - (budget.totalActualSpentEGP + totalCommitted);

    const updatedBudget: BranchBudgetPeriod = {
      ...budget,
      categories: updatedCategories,
      totalCommittedEGP: totalCommitted,
      totalRemainingEGP: totalRemaining,
      updatedAt: new Date().toISOString(),
    };

    saveLocalBudget(updatedBudget);

    return { canProceedDirectly: true };
  },

  /**
   * اعتماد أو رفض إذن تجاوز الموازنة من قبل المدير العام أو المدير المالي
   */
  async decideBudgetOverride(
    overrideRequestId: string,
    decision: 'APPROVED' | 'REJECTED',
    decisionNote: string,
    actor: UserProfile
  ): Promise<void> {
    const overrides = getLocalOverrides();
    const idx = overrides.findIndex(o => o.id === overrideRequestId);
    if (idx >= 0) {
      overrides[idx] = {
        ...overrides[idx],
        status: decision,
        approvedBy: actor.uid,
        approvedByName: actor.displayName,
        decisionNote,
        decidedAt: new Date().toISOString(),
      };
      saveLocalOverrides(overrides);
    }

    try {
      const overrideRef = doc(db, 'budgetOverrides', overrideRequestId);
      await setDoc(overrideRef, {
        status: decision,
        approvedBy: actor.uid,
        approvedByName: actor.displayName,
        decisionNote,
        decidedAt: new Date().toISOString(),
      }, { merge: true });
    } catch (err) {
      console.warn('decideBudgetOverride fallback:', err);
    }
  },

  /**
   * جدولة استحقاق سداد الفاتورة تلقائياً عند تدقيقها في المرحلة الرابعة
   */
  async scheduleSupplierPayment(
    invoiceData: { 
      invoiceId: string; 
      invoiceNumber: string; 
      supplierId: string; 
      supplierNameAr: string; 
      orderCode: string; 
      amountEGP: number; 
      paymentTerms: 'COD' | 'NET_15' | 'NET_30'; 
      invoiceDate: string;
    }
  ): Promise<string> {
    const invDate = new Date(invoiceData.invoiceDate);
    let daysToAdd = 0;
    if (invoiceData.paymentTerms === 'NET_15') daysToAdd = 15;
    if (invoiceData.paymentTerms === 'NET_30') daysToAdd = 30;

    invDate.setDate(invDate.getDate() + daysToAdd);
    const dueDate = invDate.toISOString().split('T')[0];

    const scheduleRecord: SupplierPaymentSchedule = {
      id: `pay-${Date.now()}`,
      ...invoiceData,
      dueDate,
      isPaid: false,
    };

    try {
      const colRef = collection(db, 'paymentSchedules');
      await addDoc(colRef, scheduleRecord);
    } catch (err) {
      console.warn('scheduleSupplierPayment fallback:', err);
    }

    return scheduleRecord.id;
  },

  async getPaymentSchedules(): Promise<SupplierPaymentSchedule[]> {
    try {
      const q = query(collection(db, 'paymentSchedules'), orderBy('dueDate', 'asc'));
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs.map(d => ({ id: d.id, ...d.data() } as SupplierPaymentSchedule));
      }
    } catch (err) {
      console.warn('getPaymentSchedules fallback:', err);
    }
    return INITIAL_DEMO_PAYMENTS;
  },
};
