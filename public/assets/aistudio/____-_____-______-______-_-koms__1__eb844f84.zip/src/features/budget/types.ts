export type BudgetPeriodType = 'WEEKLY' | 'MONTHLY';

export interface CategoryBudgetAllocation {
  orderTypeId: string;
  orderTypeNameAr: string;
  allocatedAmountEGP: number; // المبلغ المعتمد للموازنة
  actualSpentAmountEGP: number; // المنصرف الفعلي من واقع الفواتير المدققة VERIFIED
  committedAmountEGP: number; // المحجوز لأوامر الشراء المفتوحة الجارية
  remainingAmountEGP: number; // المتبقي المتاح = المعتمد - (المنصرف + المحجوز)
  utilizationRatePct: number; // نسبة الاستهلاك المئوية
  isExceeded: boolean;
}

export interface BranchBudgetPeriod {
  id: string;
  branchId: string;
  branchNameAr: string;
  periodType: BudgetPeriodType;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  totalAllocatedBudgetEGP: number;
  totalActualSpentEGP: number;
  totalCommittedEGP: number;
  totalRemainingEGP: number;
  singleOrderApprovalThresholdEGP: number; // الحد الأقصى للطلب الفردي قبل اشتراط موافقة إضافية (مثال: 15,000 ج.م)
  categories: CategoryBudgetAllocation[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export type BudgetApprovalStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface BudgetOverrideRequest {
  id: string;
  orderId: string;
  orderCode: string;
  branchId: string;
  orderTypeId: string;
  orderTotalAmountEGP: number;
  availableBudgetBeforeOrderEGP: number;
  exceededAmountEGP: number; // مقدار التجاوز فوق الموازنة
  reasonAr: string;
  status: BudgetApprovalStatus;
  requestedBy: string;
  requestedByName: string;
  approvedBy?: string;
  approvedByName?: string;
  decisionNote?: string;
  createdAt: string;
  decidedAt?: string;
}

export interface SupplierPaymentSchedule {
  id: string;
  invoiceId: string;
  invoiceNumber: string;
  supplierId: string;
  supplierNameAr: string;
  orderCode: string;
  amountEGP: number;
  paymentTerms: 'COD' | 'NET_15' | 'NET_30';
  invoiceDate: string;
  dueDate: string;
  isPaid: boolean;
  paymentReference?: string;
  paidAt?: string;
}
