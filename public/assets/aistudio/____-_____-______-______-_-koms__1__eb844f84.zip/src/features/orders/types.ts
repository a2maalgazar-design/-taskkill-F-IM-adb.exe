export type OrderStatus =
  | 'PLANNED'
  | 'DUE'
  | 'ORDERING'
  | 'ORDERED'
  | 'AWAITING_DELIVERY'
  | 'RECEIVING'
  | 'INVOICE_PENDING'
  | 'VERIFIED'
  | 'COMPLETED'
  | 'ON_HOLD'
  | 'DELAYED'
  | 'RESCHEDULED'
  | 'CANCELLED'
  | 'PARTIALLY_RECEIVED'
  | 'PARTIALLY_REJECTED';

export interface OrderItem {
  id?: string;
  productId?: string;
  productNameAr: string;
  ordered: number;
  received: number;
  unit: string;
  unitPriceEGP?: number;
  totalPriceEGP?: number;
  quantity?: number;
  requestedQty?: number;
  receivedQty?: number;
}

export interface Order {
  id: string;
  orderCode: string;
  code?: string;
  orderTypeId?: string;
  orderTypeNameAr?: string;
  supplierId?: string;
  supplierName?: string;
  supplierNameAr?: string;
  occurrenceDate?: string;
  targetDate?: string;
  isArchived?: boolean;
  status: OrderStatus | string;
  items: OrderItem[];
  assignedTo?: string;
  assignedToName?: string;
  totalAmountEGP?: number;
  createdAt?: string;
  updatedAt?: string;
}

/**
 * دالة مساعدة لتحويل طلب النظام الداخلي ActualOrder إلى هيكل Order المتوافق مع شاشات الذكاء الاصطناعي والمطابقة
 */
export function toReconciliationOrder(actualOrder: any): Order {
  return {
    id: actualOrder.id,
    orderCode: actualOrder.orderNumber || actualOrder.id,
    orderTypeId: actualOrder.orderTypeId,
    supplierId: actualOrder.supplierId,
    occurrenceDate: actualOrder.orderDate || new Date().toISOString().split('T')[0],
    status: actualOrder.status,
    items: (actualOrder.items || []).map((it: any) => ({
      id: it.id,
      productId: it.productId,
      productNameAr: it.productName || it.productNameAr || 'صنف غير مسمى',
      ordered: typeof it.ordered === 'number' ? it.ordered : (it.orderedQty ?? 0),
      received: typeof it.received === 'number' ? it.received : (it.receivedQty ?? 0),
      unit: it.unit || 'وحدة',
      unitPriceEGP: it.unitPriceEGP,
      totalPriceEGP: it.totalPriceEGP,
    })),
  };
}
