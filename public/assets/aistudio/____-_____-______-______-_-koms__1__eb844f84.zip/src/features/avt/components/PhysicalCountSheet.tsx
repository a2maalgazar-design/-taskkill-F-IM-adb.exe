import React, { useState } from 'react';
import { PhysicalCountItem, ShiftAvTReport } from '../types';
import { avtService } from '../api/avtService';
import { UserProfile } from '@/features/auth/types';
import { ClipboardCheck, Calculator } from 'lucide-react';

interface PhysicalCountSheetProps {
  branchId: string;
  inventoryList: { productId: string; productNameAr: string; unit: string; currentExpectedStock: number; unitCostEGP: number }[];
  currentUser: UserProfile;
  onReportGenerated: (report: ShiftAvTReport) => void;
}

export const PhysicalCountSheet: React.FC<PhysicalCountSheetProps> = ({
  branchId,
  inventoryList,
  currentUser,
  onReportGenerated,
}) => {
  const [counts, setCounts] = useState<Record<string, number>>(
    Object.fromEntries(inventoryList.map(item => [item.productId, item.currentExpectedStock]))
  );
  const [shiftType, setShiftType] = useState<'MORNING' | 'CLOSING'>('CLOSING');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleQtyChange = (productId: string, val: number) => {
    setCounts(prev => ({ ...prev, [productId]: val }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const itemsPayload: PhysicalCountItem[] = inventoryList.map(it => ({
        productId: it.productId,
        productNameAr: it.productNameAr,
        unit: it.unit,
        countedQty: counts[it.productId] ?? 0,
        unitCostEGP: it.unitCostEGP || 50,
      }));

      const today = new Date().toISOString().split('T')[0];
      const report = await avtService.computeAvTVariance(branchId, today, itemsPayload, currentUser);
      onReportGenerated(report);
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء معالجة الجرد');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-stone-900 border border-stone-800 rounded-xl p-4 shadow-sm space-y-4 text-xs text-stone-100">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-stone-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <ClipboardCheck className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-stone-100 text-sm">استمارة الجرد الفعلي للمخزون (Physical Count Sheet)</h3>
            <p className="text-stone-400 text-xs">حصر الكميات الموجودة فعلياً في ثلاجات ومستودع الفرع لمقارنتها بمبيعات الكاشير.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setShiftType('MORNING')}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition ${
              shiftType === 'MORNING'
                ? 'bg-amber-500 text-stone-950 border-amber-500 font-bold'
                : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200'
            }`}
          >
            وردية الصباح
          </button>
          <button
            type="button"
            onClick={() => setShiftType('CLOSING')}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition ${
              shiftType === 'CLOSING'
                ? 'bg-amber-500 text-stone-950 border-amber-500 font-bold'
                : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200'
            }`}
          >
            جرد الإغلاق الليلي
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="border border-stone-800 rounded-xl overflow-hidden bg-stone-950/40">
          <table className="w-full text-right text-xs">
            <thead className="bg-stone-950/80 border-b border-stone-800 text-stone-400 font-medium">
              <tr>
                <th className="p-2.5">الصنف</th>
                <th className="p-2.5 text-center">الرصيد الدفتري المتوقع</th>
                <th className="p-2.5 text-center">الكمية الفعلية بالجرد</th>
                <th className="p-2.5">الوحدة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-800/60 font-sans">
              {inventoryList.map((item) => (
                <tr key={item.productId} className="hover:bg-stone-900/40 transition">
                  <td className="p-2.5 font-bold text-stone-200">{item.productNameAr}</td>
                  <td className="p-2.5 text-center font-mono text-stone-400">{item.currentExpectedStock}</td>
                  <td className="p-2.5 text-center">
                    <input
                      type="number"
                      step="any"
                      min="0"
                      value={counts[item.productId] ?? ''}
                      onChange={(e) => handleQtyChange(item.productId, Number(e.target.value))}
                      className="w-24 p-1.5 bg-stone-900 border border-stone-800 rounded-lg text-center font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-500"
                      required
                    />
                  </td>
                  <td className="p-2.5 text-stone-400">{item.unit}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-stone-950 rounded-lg font-bold transition flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10"
        >
          <Calculator className="w-4 h-4" />
          <span>{isSubmitting ? 'جاري احتساب التباين الفعلي مقابل النظري...' : 'اعتماد الجرد واستخراج تقرير التباين (AvT Report)'}</span>
        </button>
      </form>
    </div>
  );
};
