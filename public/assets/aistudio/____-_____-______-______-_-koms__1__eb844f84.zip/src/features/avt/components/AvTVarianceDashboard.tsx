import React from 'react';
import { ShiftAvTReport, VarianceCategory } from '../types';
import { AlertTriangle, TrendingDown, CheckCircle, Flame, ShieldAlert } from 'lucide-react';

interface AvTVarianceDashboardProps {
  report: ShiftAvTReport;
  onClose?: () => void;
}

const CATEGORY_LABELS: Record<VarianceCategory, { label: string; color: string }> = {
  ACCEPTABLE: { label: 'ضمن الحدود الطبيعية', color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' },
  WASTE: { label: 'هدر تشغيلي في التحضير', color: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
  OVER_PORTIONING: { label: 'تجاوز في حجم الحصص', color: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
  SHRINKAGE_THEFT: { label: 'عجز حاد غير مبرر (شبهة فاقد/سرقة)', color: 'bg-rose-500/10 text-rose-400 border-rose-500/20' },
};

export const AvTVarianceDashboard: React.FC<AvTVarianceDashboardProps> = ({ report }) => {
  return (
    <div className="space-y-4 text-xs text-stone-100">
      {/* بطاقات الملخص المالي للتباين */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 bg-stone-900 border border-stone-800 rounded-xl shadow-sm">
          <span className="text-[11px] font-semibold text-stone-400 block mb-1">إجمالي الخسارة المالية للتباين</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-rose-400">{report.totalVarianceCostEGP.toLocaleString('en-US')}</span>
            <span className="text-stone-400 font-semibold">ج.م</span>
          </div>
          <span className="text-[10px] text-stone-500 block mt-1">تكلفة الفاقد الزائد عن المعيار النظري</span>
        </div>

        <div className="p-4 bg-stone-900 border border-stone-800 rounded-xl shadow-sm">
          <span className="text-[11px] font-semibold text-stone-400 block mb-1">أعلى صنف تكبيداً للخسائر</span>
          <span className="text-base font-bold text-stone-100 block truncate">
            {report.topLossItems[0]?.productNameAr || 'لا يوجد عجز'}
          </span>
          <span className="text-[10px] text-rose-400 font-mono font-bold block mt-1">
            {report.topLossItems[0] ? `-${report.topLossItems[0].varianceCostEGP} ج.م` : '0 ج.م'}
          </span>
        </div>

        <div className="p-4 bg-stone-900 border border-stone-800 rounded-xl shadow-sm">
          <span className="text-[11px] font-semibold text-stone-400 block mb-1">عدد الأصناف المتجاوزة للمعيار</span>
          <span className="text-2xl font-bold text-amber-400 font-mono">
            {report.itemsAnalysis.filter(i => i.variancePercentage > 5).length}
          </span>
          <span className="text-[10px] text-stone-500 block mt-1">أصناف تتطلب مراجعة فورية لطاقم الطهي</span>
        </div>
      </div>

      {/* تفاصيل بنود التباين */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl overflow-hidden shadow-sm">
        <div className="p-3 bg-stone-950/80 border-b border-stone-800 flex justify-between items-center">
          <h4 className="font-bold text-stone-200">جدول تحليل التباين الفعلي مقابل النظري (AvT Item Breakdown)</h4>
          <span className="font-mono text-[11px] text-stone-400">تاريخ التقرير: {report.date}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-stone-950/60 border-b border-stone-800 text-stone-400 font-semibold">
              <tr>
                <th className="p-2.5">الصنف</th>
                <th className="p-2.5">الاستهلاك الفعلي</th>
                <th className="p-2.5">الاستهلاك النظري (POS)</th>
                <th className="p-2.5">فارق الكمية</th>
                <th className="p-2.5">التكلفة المالية</th>
                <th className="p-2.5">نسبة التباين</th>
                <th className="p-2.5">التصنيف الرقابي</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-800/60 font-sans">
              {report.itemsAnalysis.map((item) => {
                const conf = CATEGORY_LABELS[item.category];

                return (
                  <tr key={item.productId} className="hover:bg-stone-800/40 transition">
                    <td className="p-2.5 font-bold text-stone-200">{item.productNameAr}</td>
                    <td className="p-2.5 font-mono text-stone-300">{item.actualConsumption} {item.unit}</td>
                    <td className="p-2.5 font-mono text-stone-300">{item.theoreticalConsumption} {item.unit}</td>
                    <td className={`p-2.5 font-mono font-bold ${item.varianceQty > 0 ? 'text-rose-400' : 'text-stone-400'}`}>
                      {item.varianceQty > 0 ? `+${item.varianceQty}` : item.varianceQty} {item.unit}
                    </td>
                    <td className="p-2.5 font-mono font-bold text-stone-100">
                      {item.varianceCostEGP.toLocaleString('en-US')} ج.م
                    </td>
                    <td className={`p-2.5 font-mono font-bold ${item.variancePercentage > 10 ? 'text-rose-400' : 'text-stone-400'}`}>
                      {item.variancePercentage}%
                    </td>
                    <td className="p-2.5">
                      <span className={`px-2 py-0.5 rounded border text-[10px] font-semibold ${conf.color}`}>
                        {conf.label}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
