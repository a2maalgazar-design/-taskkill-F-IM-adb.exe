import React, { useState, useEffect } from 'react';
import { ClipboardCheck, BarChart2, Zap, CheckCircle, RefreshCw } from 'lucide-react';
import { ShiftAvTReport } from '../types';
import { avtService } from '../api/avtService';
import { PhysicalCountSheet } from './PhysicalCountSheet';
import { AvTVarianceDashboard } from './AvTVarianceDashboard';
import { useAuth } from '@/features/auth/components/AuthGuard';
import { UserProfile } from '@/features/auth/types';
import { INITIAL_BRANCHES } from '@/features/transfers/api/transferService';
import { useData } from '@/context/DataContext';

export const AvTView: React.FC = () => {
  const { user, currentUser } = useAuth();
  const { products } = useData();

  const [activeTab, setActiveTab] = useState<'sheet' | 'dashboard'>('sheet');
  const [selectedBranchId, setSelectedBranchId] = useState<string>('br-zamalek');
  const [report, setReport] = useState<ShiftAvTReport | null>(null);
  const [webhookSimulated, setWebhookSimulated] = useState(false);

  const effectiveUser: UserProfile = user || {
    uid: currentUser?.id || 'usr-chef',
    email: currentUser?.email || 'manager@kitchen.internal',
    displayName: currentUser?.name || 'شيف الفرع المسؤول',
    role: currentUser?.role || 'manager',
    permissions: [],
    isActive: true,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  };

  useEffect(() => {
    async function loadInitial() {
      const rep = await avtService.getLatestReport(selectedBranchId);
      if (rep) setReport(rep);
    }
    loadInitial();
  }, [selectedBranchId]);

  const inventoryForCount = products.slice(0, 8).map(p => ({
    productId: p.id,
    productNameAr: p.nameAr,
    unit: p.defaultUnit || p.unit || 'كجم',
    currentExpectedStock: 45,
    unitCostEGP: p.estimatedUnitPrice || 65,
  }));

  const handleSimulatePOSSale = async () => {
    setWebhookSimulated(true);
    await avtService.processPOSSaleWebhook({
      posOrderId: `POS-ORD-${Date.now().toString().slice(-4)}`,
      branchId: selectedBranchId,
      orderSource: 'DINE_IN',
      totalSaleAmountEGP: 1250,
      timestamp: new Date().toISOString(),
      items: [
        { posDishId: 'dish-1', recipeId: 'rec-bamia-01', dishNameAr: 'طاجن بامية باللحمة', quantitySold: 8, unitPriceEGP: 260 },
        { posDishId: 'dish-2', recipeId: 'rec-kofta-02', dishNameAr: 'كفتة مشوية', quantitySold: 6, unitPriceEGP: 230 },
      ],
    });
    setTimeout(() => setWebhookSimulated(false), 3000);
  };

  return (
    <div className="space-y-6 text-xs text-stone-100">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-stone-100">
              التباين الفعلي مقابل النظري (Actual vs Theoretical - AvT)
            </h2>
            <span className="text-[10px] px-2.5 py-0.5 rounded-full font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
              BOM & POS Variance
            </span>
          </div>
          <p className="text-xs text-stone-400 mt-1">
            كشف فاقد التحضير، الهدر غير المصرح به، وتجاوز حجم الحصص (Over-portioning) مقارنة بمبيعات الكاشير
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedBranchId}
            onChange={(e) => setSelectedBranchId(e.target.value)}
            className="bg-stone-900 border border-stone-800 rounded-lg px-3 py-1.5 text-xs text-stone-100 focus:outline-none focus:border-amber-500"
          >
            {INITIAL_BRANCHES.map(b => (
              <option key={b.id} value={b.id}>{b.nameAr}</option>
            ))}
          </select>

          <button
            onClick={handleSimulatePOSSale}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 rounded-lg font-bold transition shadow-sm"
            title="محاكاة وصول فاتورة مبيعات من نظام الكاشير"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>محاكاة مبيعات POS</span>
          </button>
        </div>
      </div>

      {webhookSimulated && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 shrink-0" />
          <span>تم استقبال إشارة Webhook من الكاشير وتفكيك الوصفات وخصم المقادير الخام آلياً!</span>
        </div>
      )}

      {/* التبويبات */}
      <div className="flex border-b border-stone-800 gap-2">
        <button
          onClick={() => setActiveTab('sheet')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition ${
            activeTab === 'sheet'
              ? 'border-amber-500 text-amber-400 bg-amber-500/5'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <ClipboardCheck className="w-4 h-4" />
          <span>استمارة الجرد الفعلي للمخزون</span>
        </button>

        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition ${
            activeTab === 'dashboard'
              ? 'border-amber-500 text-amber-400 bg-amber-500/5'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <BarChart2 className="w-4 h-4" />
          <span>لوحة تقارير التباين والفاقد المالي (AvT Report)</span>
          {report && (
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
              {report.totalVarianceCostEGP} ج.م فاقد
            </span>
          )}
        </button>
      </div>

      {activeTab === 'sheet' && (
        <PhysicalCountSheet
          branchId={selectedBranchId}
          inventoryList={inventoryForCount}
          currentUser={effectiveUser}
          onReportGenerated={(rep) => {
            setReport(rep);
            setActiveTab('dashboard');
          }}
        />
      )}

      {activeTab === 'dashboard' && (
        report ? (
          <AvTVarianceDashboard report={report} />
        ) : (
          <div className="p-12 text-center border border-dashed border-stone-800 rounded-xl text-stone-500 text-xs">
            قم بإجراء جرد فعلي أولاً من تبويب "استمارة الجرد الفعلي" لاستخراج تقرير التباين
          </div>
        )
      )}
    </div>
  );
};
