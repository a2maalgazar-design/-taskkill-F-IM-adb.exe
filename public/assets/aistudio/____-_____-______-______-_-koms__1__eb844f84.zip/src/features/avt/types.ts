export interface POSSaleItem {
  posDishId: string;
  recipeId: string;
  dishNameAr: string;
  quantitySold: number;
  unitPriceEGP: number;
}

export interface POSOrderEvent {
  posOrderId: string;
  branchId: string;
  orderSource: 'DINE_IN' | 'TAKEAWAY' | 'DELIVERY_APP' | 'ONLINE';
  items: POSSaleItem[];
  totalSaleAmountEGP: number;
  timestamp: string;
}

export interface PhysicalCountItem {
  productId: string;
  productNameAr: string;
  unit: string;
  countedQty: number; // الكمية الفعلية المحصورة يدوياً بالجرد
  unitCostEGP: number;
}

export interface PhysicalStockCountRecord {
  id: string;
  branchId: string;
  countDate: string; // YYYY-MM-DD
  shiftType: 'MORNING' | 'CLOSING' | 'WEEKLY_FULL';
  countedBy: string;
  countedByName: string;
  items: PhysicalCountItem[];
  notes?: string;
  createdAt: string;
}

export type VarianceCategory = 'ACCEPTABLE' | 'OVER_PORTIONING' | 'WASTE' | 'SHRINKAGE_THEFT';

export interface AvTItemAnalysis {
  productId: string;
  productNameAr: string;
  unit: string;
  openingStock: number;
  receivedStock: number; // المشتريات والتحويلات المستلمة
  endingActualStock: number; // الجرد الفعلي
  actualConsumption: number; // Opening + Received - Ending
  theoreticalConsumption: number; // مجموع المقادير المستهلكة من مبيعات POS
  varianceQty: number; // Actual - Theoretical (القيمة الموجبة تعني استهلاكاً زائداً عن المعيار)
  varianceCostEGP: number; // varianceQty * unitCost
  variancePercentage: number; // (varianceQty / theoreticalConsumption) * 100
  category: VarianceCategory;
}

export interface ShiftAvTReport {
  id: string;
  branchId: string;
  date: string;
  totalVarianceCostEGP: number;
  topLossItems: AvTItemAnalysis[];
  itemsAnalysis: AvTItemAnalysis[];
  generatedAt: string;
}
