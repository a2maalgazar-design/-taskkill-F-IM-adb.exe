import React, { useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  ChevronRight,
  ShieldCheck,
  Users,
  Layers,
  ClipboardList,
  Truck,
  FileSpreadsheet,
  Search,
  Sparkles,
  HelpCircle,
  AlertTriangle,
  Send,
  Thermometer,
  CalendarDays,
  FileText,
  MessageSquare,
  Fingerprint,
  Smartphone,
  Laptop,
  TrendingUp,
  Bell,
  Clock,
  CreditCard,
  Hash,
} from 'lucide-react';
import { ActiveTab } from '@/components/common/Sidebar';

interface GuideSection {
  id: string;
  title: string;
  icon: any;
  category: 'core' | 'manager' | 'assistant' | 'quality';
  summary: string;
  steps: string[];
  tips: string[];
  bestPractices: string[];
  targetTab?: ActiveTab;
}

export const UserGuideView: React.FC<{ onNavigateTab?: (tab: ActiveTab) => void }> = ({
  onNavigateTab,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'core' | 'manager' | 'assistant' | 'quality'>('all');
  const [activeSectionId, setActiveSectionId] = useState<string>('overview');
  const [activeInfographicTab, setActiveInfographicTab] = useState<'assistant' | 'manager'>('assistant');

  const guideSections: GuideSection[] = [
    {
      id: 'columnar-order-sop',
      title: 'دليل واجهة الأعمدة السريعة للمساعدين الخمسة (5-Assistant Columnar Orders SOP)',
      icon: MessageSquare,
      category: 'assistant',
      summary: 'الدليل التشغيلي لحصر وطلب طلبيات المطبخ عبر واجهة الأعمدة السريعة والإرسال المزدوج للواتساب (للمورد وللشيف العمومي).',
      steps: [
        'اختيار اسم المساعد: اضغط على زر اسمك (المساعد 1 إلى 5) في أعلى الشاشة ليقوم النظام فورياً بتصفية الشاشة وعرض أعمدتك الموكلة حصراً وحجب طلبيات زملائك لمنع الخطأ.',
        'مراجعة رأس العمود: يوضح اسم الطلبية، الكود المميز، دوريتها (يومية أو أسبوعية)، واسم المساعد المسؤول، وعدد الأصناف.',
        'تسجيل الكميات المطلوبة: استرشد بخانة "المتوقع / رصيد الأمان" للقراءة فقط، وأدخل الكمية الفعلية المطلوبة في خانة الإدخال الرقمية البارزة عبر أزرار (+ / -) أو بالكتابة المباشرة.',
        'تحديد جهة الإرسال: اختر بالزر السريع بين [ 🏢 المورد المباشر ] أو [ 👔 مدير المشتريات ]، ويظهر لك رقم الهاتف المعتمد لكل فئة.',
        'الإرسال عبر WhatsApp: اضغط الزر الأخضر البارز في أسفل العمود "إرسال الطلبية عبر WhatsApp" ليقوم النظام بالتحقق من وجود كميات وصياغة رسالة رسمية ببنود الطلب فقط وفتح الواتساب مباشرة.',
        'إرسال نسخة مطابقة للشيف العمومي (Chef CC): يظهر لك زر إلحاقي فوري "إرسال نسخة مطابقة للشيف العمومي" لإرسال نفس نص الرسالة فوراً إلى رقم واتساب الشيف العمومي لعلمه والمتابعة.',
        'الأرشفة الأسبوعية التلقائية: يتم ترحيل تفاصيل الطلبية بالكامل إلى التخزين المحلي وتصنيفها تحت أسبوع العمل الحالي (مثال: أسبوع 43 — أكتوبر 2026).'
      ],
      tips: [
        'لن يرسل النظام أي صنف لم تدخل له كمية مطلوبة (كمية أكبر من صفر)، مما يضمن عدم حدوث أخطاء في التوريد.',
        'يمكنك دائماً نسخ نص الرسالة للحافظة بنقرة واحدة عبر زر "نسخ النص" كخيار بديل.'
      ],
      bestPractices: [
        'قم بجرد ثلاجات وأرفف القسم قبل إدخال الأرقام في الأعمدة.',
        'تأكد من إرسال النسخة المطابقة للشيف العمومي دائماً لضمان التنسيق التام بين الورديات.'
      ],
      targetTab: 'columnar-orders'
    },
    {
      id: 'chef-weekly-file-sop',
      title: 'دليل الشيف العمومي وإدارة الملف الأسبوعي (Head Chef Admin & Weekly File SOP)',
      icon: Users,
      category: 'manager',
      summary: 'صلاحيات الشيف العمومي في إدارة الأصناف، توزيع المهام على المساعدين، تعديل الهواتف، وأرشفة وطباعة الملف الأسبوعي.',
      steps: [
        'استعراض كافة الأعمدة: يتيح زر "الشيف العمومي (عرض الكل)" في واجهة الأعمدة مراجعة كافة طلبيات المطبخ في شاشة واحدة.',
        'إدارة الأصناف والطلبيات: من لوحة إدارة الشيف العمومي (Admin Panel)، يمكنك إضافة أصناف جديدة، تعديل وحدات القياس، ورصيد الأمان، أو إضافة فئات طلبيات جديدة وتحديد دوريتها (يومية أو أسبوعية).',
        'توزيع مهام المساعدين بالـ Checkboxes: يمكنك إسناد أو سحب أي طلبية من أي مساعد بمجرد النقر على مربع الاختيار التابع للفئة داخل بطاقته.',
        'إدارة أرقام الهواتف المحفوظة: تعديل رقم هاتف مدير المشتريات، رقم الشيف العمومي للنسخة المطابقة، وأرقام هواتف الموردين لكل فئة وحفظها بنقرة واحدة.',
        'الملف الأسبوعي التجميعي: الدخول لشاشة "الملف الأسبوعي للطلبيات" واستعراض الطلبيات مصنفة ومؤرشفة بحسب أسبوع العمل، مع إمكانية الفرز حسب اسم الطلبية، اسم المساعد، تاريخ اليوم، أو جهة الإرسال.',
        'طباعة ملخص الأسبوع بالكامل: ضغطة زر واحدة لطباعة تقرير أسبوعي رسمي مجهز بجداول الأصناف ومربعات التوقيع للشيف العمومي والمشتريات والاستلام.'
      ],
      tips: [
        'تنعكس تعديلات إسناد المهام في لوحة الشيف العمومي فورياً على واجهة الأعمدة عند اختيار أي مساعد.',
        'التقرير الأسبوعي المطبوع مصمم بنمط تباين عالي جاهز للأرشفة الورقية والتوقيعات الرسمية.'
      ],
      bestPractices: [
        'قم بطباعة ملخص الأسبوع في نهاية يوم العمل الأخير لمطابقة الفواتير مع المشتريات.',
        'تأكد من تحديث أرقام هواتف الموردين فور اعتماد أي تغيير في بيانات جهات التوريد.'
      ],
      targetTab: 'chef-admin'
    },
    {
      id: 'overview',
      title: 'نظرة عامة على نظام KOMS للمطابخ وسلاسل الإمداد',
      icon: BookOpen,
      category: 'core',
      summary: 'نظام تشغيل وإدارة دورة المشتريات والطلبيات بالمطابخ الاحترافية من إعداد المسودة إلى التحويل وسداد الموردين.',
      steps: [
        'تسجيل الدخول والتعرف على لوحة العمليات اليومية (Dashboard) لمتابعة المؤشرات اللحظية.',
        'متابعة الطلبيات المفتوحة وحالاتها في كانبان التوريد أو الجدول الزمني.',
        'استقبال الإشعارات الفورية عن الطلبيات المتأخرة، أو فروقات الفحص الميداني، أو نقص المخزون الحرج.',
        'التوافق الكامل مع وضع عدم الاتصال (Offline-First) لضمان استمرارية التشغيل داخل المطبخ دون انقطاع.'
      ],
      tips: [
        'يمكن الوصول لجميع أقسام النظام من القائمة الجانبية (Sidebar) بسهولة.',
        'يتم حفظ كافة الحركات في سجل تدقيق العمليات (Audit Log) تلقائياً.'
      ],
      bestPractices: [
        'راجع لوحة العمليات اليومية في بداية كل وردية للتأكد من وصول شحنات الصباح.',
        'تأكد من عدم مشاركة كلمات المرور والاعتماد على الصلاحيات المخصصة لكل دور.'
      ],
      targetTab: 'dashboard'
    },
    {
      id: 'manager-privileges',
      title: 'صلاحيات المدير الحصرية (Team & Administrative Privileges)',
      icon: Users,
      category: 'manager',
      summary: 'يمتلك المدير وحده الصلاحيات السيادية لإدارة فريق المساعدين، وتعيين مجالات التوريد، والتحكم بالفئات والكتالوج.',
      steps: [
        'إضافة مساعد جديد: ادخل الاسم، البريد، رقم الهاتف، وحدد دوره (مساعد، مستلم، معتمد).',
        'إسناد مجالات التوريد (Procurement Domains): حدد الفئات المسموح للمساعد إدارتها (مثل الخضار أو اللحوم).',
        'تعديل بيانات وإعادة تسمية المساعدين: اضغط زر "تعديل وإعادة تسمية" على بطاقة المساعد لتحديث الاسم أو رقم الهاتف.',
        'التعطيل المنطقي (Soft-Delete): عند مغادرة أحد المساعدين، اضغط زر التعطيل (Soft Delete) لحجب دخوله مع صيانة تاريخ طلباته السابقة في سجلات التدقيق.',
        'الاعتماد المالي النهائي: مراجعة الفواتير الموردة واعتماد السداد بعد استكمال محاضر الفحص.'
      ],
      tips: [
        'لا تقم بحذف حساب المساعد نهائياً إذا كانت له طلبيات أو محاضر استلام تاريخية، واستخدم التعطيل المنطقي بدلاً من ذلك.',
        'يمكن تعيين مساعدين بدلاء (Backup Assignees) لكل فئة لضمان عدم توقف الطلبيات أثناء الإجازات.'
      ],
      bestPractices: [
        'راجع مجالات التوريد دورياً للتأكد من توزيع أعباء العمل بشكل متوازن بين المساعدين.',
        'استخدم سجل التدقيق (Audit Logs) لمراجعة كافة القرارات الإدارية والتعديلات.'
      ],
      targetTab: 'staff'
    },
    {
      id: 'order-types-catalog',
      title: 'فئات الطلبيات الـ 10 ودليل الأصناف (Catalog & Categories)',
      icon: Layers,
      category: 'manager',
      summary: 'إدارة النواة الافتراضية لفئات التوريد الـ 10 وإنشاء فئات جديدة مع ضبط الكتالوج والمواصفات الفنية.',
      steps: [
        'الفئات الافتراضية الـ 10 المعتمدة: الخضار، اللحوم، العيش الفلاحي، البريوش، الدواجن، التغليف، العطارة، المنظفات، الصوصات والزيوت، البقالة.',
        'إضافة فئة جديدة: اضغط "إضافة فئة توريد جديدة"، أدخل الاسم العربي والإنجليزي، ومهلة التوريد، وحدد ما إذا كانت تتطلب تبريد أو صلاحية.',
        'إدارة الأصناف الـ 24 المخصصة للخضار: تسمية الأصناف التأسيسية (TBD) وتحديد وحدات القياس (كجم، شوال، كرتونة...).',
        'تحديد المواصفات الفنية والمورد المفضل: اكتب شروط الجودة لكل صنف والمورد المعتمد للطلب السريع.',
        'التعطيل المنطقي للأصناف: تعطيل الصنف الذي توقف استخدامه مؤقتاً دون حذف تاريخه من الطلبيات السابقة.'
      ],
      tips: [
        'تفعيل خيار "تتطلب فحص وقياس درجة الحرارة" يفرض على مستلم الشحنة تسجيل قراءة الثيرموميتر عند وصول الشاحنة.',
        'تفعيل خيار "تتطلب التحقق من تاريخ الصلاحية" يُلزم بإدخال تواريخ الإنتاج والانتهاء لتغذية نظام FEFO بالمخزون.'
      ],
      bestPractices: [
        'حدد مواصفات واضحة ودقيقة (مثل: نسبة دهن لا تتجاوز 15%، خالي من الضربات) لمنع النزاعات مع الموردين.',
        'راجع أسعار التوريد التقديرية شهرياً للحفاظ على دقة موازنات المطبخ.'
      ],
      targetTab: 'categories'
    },
    {
      id: 'order-lifecycle',
      title: 'واجهة طلب التوريد للمتخصصين ودورة إرسال الطلبيات (Specialist Order & Dispatch)',
      icon: ClipboardList,
      category: 'assistant',
      summary: 'الواجهة المبسطة لسهولة وسرعة الطلب لكل متخصص، مع تفريغ خانات الكميات، واعتماد متوسط الاستهلاك، ومواعيد الوصول الثابتة.',
      steps: [
        'واجهة المتخصص المباشرة: يظهر لكل مسؤول وردية رؤوس أعمدة واضحة ومنظمة بالخيارات التي يحتاجها (اسم الصنف، متوسط الطلب اليومي، الكمية المطلوبة، الوحدة، الملاحظات).',
        'طلبية الخضار والأقسام المتخصصة: تظهر أسماء المكونات بالكامل وتكون خانة الطلب فارغة تماماً؛ لكي يُسجل الموظف الكميات الفعلية المطلوبة بالكيلوجرام أو بالعدد بناءً على ما يراه متواجداً بالمطعم.',
        'خانة متوسط الطلب اليومي: تظهر في كل بند كمرجع استرشادي اختياري لمساعدة الموظف على مقارنة طلبه بالاستهلاك المعتاد.',
        'إلغاء البيانات الزائدة: تم إلغاء سطر المسؤول الاحتياطي، وإلغاء موعد الوصول المتوقع للاكتفاء بمواعيد التوريد الثابتة.',
        'موعد الوصول الثابت (01:00 م): الميعاد الثابت لوصول الطلبية اليومية هو الساعة الواحدة مساءً كحد أقصى. وفي حالة تأخر الوصول عن هذا الميعاد، يُعتمد الميعاد الخاص بالشيف المسؤول عن الاستلام.',
        'إنذار تأخر الخضار 24 ساعة: في حال تأخرت شحنة الخضار 24 ساعة كاملة عن الموعد الثابت، يُطلق النظام إنذاراً حرجاً للإدارة والمطبخ.',
        'إنذار الورديات والطلب الآني: ينبه النظام مسؤول الوردية بميعاد طلبه، وفي حال التأخير يظهر له إشعار فوري ويصل لمدير المطبخ إشعار بأن ميعاد الطلبية وصل ويجب عليه الطلب الآني فوراً.'
      ],
      tips: [
        'التبديل بين وحدة "كجم" و"بالعدد / حبة" أو "ربطة" متاح بمرونة لكل بند بحسب نوع الخضار أو المستلزم.',
        'إرسال أمر الشراء للمورد عبر WhatsApp يتم بضغطة واحدة متضمناً قائمة الأصناف والكميات وموعد الوصول الثابت (01:00 م).'
      ],
      bestPractices: [
        'عاين ثلاجة الخضار والمخزن الفعلي قبل إدخال الأرقام في الخانات الفارغة.',
        'احرص على تأكيد الطلب قبل حلول مهلة الوردية لتجنب إطلاق إنذار التأخر لمدير المطبخ.'
      ],
      targetTab: 'orders'
    },
    {
      id: 'veg-order-guide',
      title: 'واجهة طلب طلبيّة الخضروات والتحويل المباشر للواتساب (Vegetables WhatsApp Order)',
      icon: MessageSquare,
      category: 'assistant',
      summary: 'الواجهة المستقلة والسريعة لطلب الـ 24 مكوناً الأساسية من الخضار وتحويل ما يجب طلبه فوراً للمورد المعتمد عبر واتساب.',
      steps: [
        'الدخول على الشاشة: افتح قسم "طلبية الخضار (واتساب)" مباشرة من القائمة الجانبية أو من الزر الأخضر البارز في أعلى الشاشة.',
        'مراجعة المكونات الـ 24: تظهر المكونات كاملة في جدول صريح برؤوس أعمدة: (اسم المكون، المتوسط المطلوب، ما يجب طلبه، الوحدة، حذف).',
        'تحديد الاحتياج الفعلي: خانة "ما يجب طلبه" فارغة؛ قم بإدخال الكميات المطلوبة بالكيلوجرام أو بالعدد بناءً على ما تراه متواجداً في المطعم.',
        'الاسترشاد بالمتوسط المطلوب: تعرض كل خانة متوسط الاستهلاك اليومي للاسترشاد وتسهيل التقدير.',
        'التعبئة السريعة: يمكنك الضغط على زر "تعبئة بالمتوسط المطلوب" لملء جميع الخانات بالحصص اليومية المعتادة بنقرة واحدة.',
        'التحويل المباشر لواتساب: اضغط على الزر الأخضر "تحويل ما يجب طلبه مباشرة عبر الواتساب للمورد 💬" لتوليد أمر الشراء ببنود الطلب الفعلية فقط وفتح محادثة واتساب للمورد المعتمد (+201011122233) مع نسخ الرسالة تلقائياً.',
        'سياسة الوصول الثابتة: موعد الوصول الثابت هو الساعة 01:00 مساءً كحد أقصى للطلبية اليومية.'
      ],
      tips: [
        'لا تُرسل الأصناف التي لم يُحدد لها كمية؛ النظام يُحوّل فقط الأصناف التي أدخلت كمياتها في "ما يجب طلبه".',
        'يمكنك مراجعة الأصناف المدخلة بنقرة واحدة عبر زر "عرض ما تم إدخاله فقط".'
      ],
      bestPractices: [
        'قم بجرد ثلاجة الخضار في بداية الوردية وسجل الاحتياج بدقة لمنع الهدر وتلف الخضروات الورقية.',
        'احرص على إرسال الطلبية باكراً لضمان وصول التوريد قبل الموعد الثابت (الساعة 1:00 ظهراً).'
      ],
      targetTab: 'veg-order'
    },
    {
      id: 'haccp-receiving',
      title: 'محضر الاستلام الميداني وتدقيق سلسلة التبريد (HACCP Receiving)',
      icon: ShieldCheck,
      category: 'quality',
      summary: 'إجراءات الفحص الدقيقة للشحنات الغذائية الواردة لضمان سلامة الغذاء ومطابقة الكميات للمواصفات.',
      steps: [
        'فتح محضر الاستلام: عند وصول سيارة التوريد، انتقل لقسم "الاستلام وفحص الجودة" واختر الطلبية.',
        'قياس حرارة التبريد: قس حرارة المنتجات المبردة (يجب ألا تتعدى 4 درجات مئوية للحوم والدواجن، وأقل من -18 درجة للمجمدات).',
        'فحص تواريخ الصلاحية: التحقق من فترة الصلاحية المتبقية وفق سياسة الجودة بالمطبخ.',
        'مطابقة الأوزان والكميات: فحص الكمية الواردة وتحديد أي عجز أو تالف، مع تسجيل سبب الرفض إن وُجد.',
        'تأكيد الاستلام: النظام يقوم تلقائياً بزيادة رصيد المخزون الفعلي بالكميات المقبولة فقط، وإرسال تنبيه للمدير بأي نواقص أو مخالفات تبريد.'
      ],
      tips: [
        'أي شحنة لحوم تتجاوز 7 درجات مئوية يتم رفضها فوراً لحماية سمعة المطعم وصحة الرواد.',
        'يمكن رفع صورة الشحنة أو بوليصة الاستلام مباشرة كدليل مصور.'
      ],
      bestPractices: [
        'استخدم ثيرموميتر معاير ومعقم قبل الغرس في العينات الغذائية.',
        'لا تستلم أي عبوة مفتوحة أو تالفة في فئة التغليف أو المنظفات.'
      ],
      targetTab: 'receiving'
    },
    {
      id: 'schedules-recurring',
      title: 'جداول التوريد الدورية المؤتمتة (Master Order Schedules)',
      icon: CalendarDays,
      category: 'manager',
      summary: 'ضبط جداول التوريد المتكررة تلقائياً (يومي، أسبوعي، شهري) لضمان عدم نسيان أي طلبية وتوليد مسودات مسبقة.',
      steps: [
        'إنشاء جدول دوري: حدد اسم الجدول (مثل: طلبية الخضار اليومية صباحاً، توريد اللحوم يومي الإثنين والخميس).',
        'تحديد نمط التكرار: اختر بين دوري يومي، أيام محددة في الأسبوع، أو شهري مع تحديد ساعة التوليد التلقائي.',
        'تحديد الفئة والبنود: اختيار الفئة والأصناف والكميات النمطية المقترحة.',
        'إسناد المسؤولية: تحديد المساعد المسؤول عن متابعة الجدول وتأكيده مع المورد.',
        'التوليد التلقائي: يقوم النظام بإنشاء مسودة الطلبية في الموعد المحدد وإشعار المساعد بضرورة مراجعتها.'
      ],
      tips: [
        'الجداول الدورية توفر أكثر من 80% من الوقت المستغرق في كتابة الطلبيات الروتينية المتكررة.',
        'يمكن تجميد أو إيقاف أي جدول مؤقتاً خلال فترات العطلات أو الجرد.'
      ],
      bestPractices: [
        'راجع كميات الجداول الدورية كل أسبوعين لمواكبة التغير في معدل استهلاك المطبخ.',
        'تأكد من توافق مواعيد الجدول مع أيام وساعات عمل الموردين المعتمدين.'
      ],
      targetTab: 'schedules'
    },
    {
      id: 'suppliers-directory',
      title: 'دليل الموردين ومواعيد التسليم (Suppliers Directory)',
      icon: Truck,
      category: 'assistant',
      summary: 'قاعدة بيانات مركزية لكافة جهات التوريد المعتمدة، جهات الاتصال، أيام التسليم، وسجلات التواصل المباشر عبر واتساب.',
      steps: [
        'تسجيل الموردين: إدخال اسم المورد، المسؤول، رقم الهاتف للتواصل عبر واتساب، وتصنيف المنتجات.',
        'تحديد أيام وساعات التسليم: تسجيل المواعيد المتاحة لكل مورد لتفادي تأخر الشحنات.',
        'شروط السداد والفواتير: توثيق طريقة الدفع (آجل، نقدي، تحويل بنكي) والمهلة الممنوحة.',
        'التواصل السريع: النقر المباشر على رقم الهاتف لفتح محادثة واتساب وإرسال تفاصيل التوريد.'
      ],
      tips: [
        'ربط المورد بالأصناف في الكتالوج يجعل اختياره يتم تلقائياً عند إنشاء أي طلبية جديدة.',
        'احفظ دائماً رقم الهاتف بصيغة دولية صحيحة لتمكين الإرسال الفوري عبر واتساب.'
      ],
      bestPractices: [
        'احتفظ بأرقام هاتف بديلة لكل مورد لحالات الطوارئ أو عدم الرد.',
        'راجع سجلات المورد دورياً لمتابعة دقة مواعيده وجودة بضاعته.'
      ],
      targetTab: 'suppliers'
    },
    {
      id: 'reports-audit',
      title: 'التقارير والإحصائيات وسجل التدقيق (Reports & Audit Logs)',
      icon: FileText,
      category: 'manager',
      summary: 'تحليل دقيق لكافة حركات التوريد، ونسب إنجاز الطلبيات، وتصدير البيانات إلى إكسل، مع سجل تدقيق غير قابل للتعديل.',
      steps: [
        'تصفية التقارير: تصفية البيانات حسب النطاق الزمني، المساعد المسؤول، الفئة، أو المورد.',
        'تصدير ملفات إكسل (Excel Export): تنزيل تقارير تفصيلية بضغطة زر لمشاركتها مع الإدارة المالية.',
        'مؤشرات الأداء: استعراض إجمالي المبالغ المنفقة، عدد الطلبيات المكتملة، ونسب الالتزام بمواعيد التوريد.',
        'سجل العمليات والتدقيق (Audit Logs): تتبع زمني مفصل لأي عملية إنشاء، تعديل، إلغاء، استلام، أو اعتماد بالفواتير مع توثيق اسم المستخدم وساعة التنفيذ بدقة.'
      ],
      tips: [
        'سجل التدقيق يعمل بصيغة القراءة فقط (Append-Only) لضمان الشفافية والأمان ومنع أي تلاعب.',
        'يمكن للمدير تصفية سجل التدقيق بحسب المستخدم أو نوع الكيان (طلب، فاتورة، مورد، صنف).'
      ],
      bestPractices: [
        'صدّر تقرير نهاية الشهر المالي بانتظام لحفظ نسخة احتياطية معتمدة.',
        'راجع سجل التدقيق أسبوعياً لرصد أي تعديلات استثنائية على الأسعار أو الصلاحيات.'
      ],
      targetTab: 'reports'
    },
    {
      id: 'invoices-ocr',
      title: 'الفواتير والمطابقة واستخراج البيانات بالذكاء الاصطناعي (Invoice Verification & OCR)',
      icon: FileSpreadsheet,
      category: 'manager',
      summary: 'مراجعة الفواتير المالية ومطابقتها مع كميات الاستلام الفعلية، واستخدام الذكاء الاصطناعي لاستخراج البنود آلياً.',
      steps: [
        'رفع صورة الفاتورة: يقوم المساعد أو المدير بتصوير فاتورة المورد الورقية ورفعها للنظام.',
        'المعالجة الذكية عبر Gemini AI: استخراج رقم الفاتورة، اسم المورد، التاريخ، الإجمالي، والبنود بدقة عالية.',
        'المطابقة الآلية الثلاثية (3-Way Match): مطابقة أمر الشراء الأصلي + محضر الاستلام الفعلي + فاتورة المورد.',
        'رصد الفروقات (Discrepancy Notes): في حال وجود زيادة في السعر أو احتساب كميات مرفوضة، يُبرز النظام الفرق باللون الأحمر.',
        'الاعتماد والتحويل للمحاسبة: بعد التأكد، يضغط المدير "اعتماد الفاتورة نهائياً" لتسجيلها في مستحقات الموردين.'
      ],
      tips: [
        'الصور الواضحة ذات الإضاءة الجيدة تضمن دقة استخراج بنسبة 100% عبر الذكاء الاصطناعي.',
        'يمكن تعديل أي حقل مستخرج يدوياً قبل الحفظ لضمان الدقة التامة.'
      ],
      bestPractices: [
        'لا تعتمد أي فاتورة تحتوي على فرق سعري قبل الرجوع للمورد أو مراجعة عروض الأسعار المعتمدة.',
        'احرص على أرشفة الفواتير المعتمدة أولاً بأول للحفاظ على سجلات مالية نظيفة.'
      ],
      targetTab: 'invoices'
    }
  ];

  const filteredSections = guideSections.filter((section) => {
    const matchesCategory = selectedCategory === 'all' || section.category === selectedCategory;
    const matchesSearch =
      searchQuery.trim() === '' ||
      section.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      section.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      section.steps.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const currentSection = guideSections.find((s) => s.id === activeSectionId) || guideSections[0];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-stone-100 flex items-center gap-2">
                <span>دليل الاستخدام والتشغيل المبسط للمطبخ</span>
                <span className="text-[10px] px-2.5 py-0.5 rounded-full font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
                  Kitchen Operations Manual (KOMS)
                </span>
              </h1>
              <p className="text-xs text-stone-400 mt-0.5">
                دليل مرجعي تفصيلي للمدير التنفيذي وكوادر المساعدين لإدارة دورة الطلبيات وسلاسل الإمداد
              </p>
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-80">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث في دليل التشغيل والخطوات..."
            className="w-full bg-stone-950 border border-stone-800 rounded-xl py-2 ps-9 pe-3 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-none focus:border-amber-500 transition"
          />
          <Search className="w-4 h-4 text-stone-500 absolute top-2.5 start-3 pointer-events-none" />
        </div>
      </div>

      {/* ======================================================== */}
      {/* VISUAL INFOGRAPHIC SECTION: DAILY SOP & EXECUTIVE PLAYBOOK */}
      {/* ======================================================== */}
      <div className="bg-stone-900 border border-amber-500/30 rounded-2xl p-5 shadow-xl relative overflow-hidden">
        {/* Subtle Background Accent */}
        <div className="absolute top-0 end-0 -mt-8 -me-8 w-48 h-48 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-stone-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl">📊</span>
              <h2 className="text-base font-black text-stone-100 flex items-center gap-2">
                <span>إنفوجرافيك التشغيل اليومي والإدارة الاحترافية للمطبخ</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono font-bold">
                  SOP & Executive Playbook
                </span>
              </h2>
            </div>
            <p className="text-xs text-stone-400 mt-1">
              خريطة إرشادية مبسطة توضح الخطوات اليومية لكل موظف وكيفية تحقيق الشيف والمدير أقصى فائدة من البرنامج
            </p>
          </div>

          {/* Toggle between Assistant and Manager Infographics */}
          <div className="flex items-center gap-1.5 bg-stone-950 p-1 rounded-xl border border-stone-800 shrink-0">
            <button
              type="button"
              onClick={() => setActiveInfographicTab('assistant')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeInfographicTab === 'assistant'
                  ? 'bg-amber-500 text-stone-950 shadow-md'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <span>🧑‍🍳 الاستخدام اليومي للمساعدين</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveInfographicTab('manager')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeInfographicTab === 'manager'
                  ? 'bg-amber-500 text-stone-950 shadow-md'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <span>👨‍🍳 دليل المدير والشيف العمومي</span>
            </button>
          </div>
        </div>

        {/* TAB 1: ASSISTANT DAILY FLOW INFOGRAPHIC */}
        {activeInfographicTab === 'assistant' && (
          <div className="mt-5 space-y-4">
            <div className="flex items-center justify-between text-xs text-stone-300 bg-stone-950/60 p-3 rounded-xl border border-stone-800/80">
              <span className="font-bold text-amber-400 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>دورة العمل اليومية للمساعد (مجهزة للموبايل واللابتوب):</span>
              </span>
              <span className="text-[11px] text-stone-400 font-mono">5 خطوات سريعة ومباشرة</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
              {/* Step 1 */}
              <div className="bg-stone-950/70 border border-stone-800 hover:border-amber-500/40 rounded-xl p-3.5 flex flex-col justify-between transition">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 text-xs font-black flex items-center justify-center">
                      1
                    </span>
                    <Fingerprint className="w-4 h-4 text-emerald-400" />
                  </div>
                  <h4 className="font-bold text-stone-100 text-xs mb-1">تسجيل الدخول بالبصمة</h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed">
                    ادخل بكود الموظف (مثل <span className="font-mono text-amber-300">AST-01</span>) مع البصمة البيومترية الموثقة.
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-stone-850 text-[10px] text-emerald-400 font-medium">
                  ✓ طلبياتك الموكلة تظهر أولاً
                </div>
              </div>

              {/* Step 2 */}
              <div className="bg-stone-950/70 border border-stone-800 hover:border-amber-500/40 rounded-xl p-3.5 flex flex-col justify-between transition">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 text-xs font-black flex items-center justify-center">
                      2
                    </span>
                    <Layers className="w-4 h-4 text-blue-400" />
                  </div>
                  <h4 className="font-bold text-stone-100 text-xs mb-1">جرد الثلاجات والمخازن</h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed">
                    قارن الرصيد الفعلي في قسمك مع رصيد الأمان ومتوسط الاستهلاك الموضح بجانب كل صنف.
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-stone-850 text-[10px] text-blue-400 font-medium">
                  ✓ منع العجز والهدر الزائد
                </div>
              </div>

              {/* Step 3 */}
              <div className="bg-stone-950/70 border border-stone-800 hover:border-amber-500/40 rounded-xl p-3.5 flex flex-col justify-between transition">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 text-xs font-black flex items-center justify-center">
                      3
                    </span>
                    <ClipboardList className="w-4 h-4 text-amber-400" />
                  </div>
                  <h4 className="font-bold text-stone-100 text-xs mb-1">إدخال الكمية المطلوبة</h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed">
                    سجل الكميات عبر أزرار (+ / -) الفورية أو كتابة الرقم. الأصناف الصفرية لا تُطلب.
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-stone-850 text-[10px] text-amber-400 font-medium">
                  ✓ تحويل فقط ما تم طلبه
                </div>
              </div>

              {/* Step 4 */}
              <div className="bg-stone-950/70 border border-stone-800 hover:border-amber-500/40 rounded-xl p-3.5 flex flex-col justify-between transition">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 text-xs font-black flex items-center justify-center">
                      4
                    </span>
                    <Send className="w-4 h-4 text-emerald-400" />
                  </div>
                  <h4 className="font-bold text-stone-100 text-xs mb-1">إرسال الواتساب + الشيف</h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed">
                    ضغطة واحدة ترسل رسالة رسمية للمورد أو المشتريات، مع زر إرسال نسخة مطابقة للشيف.
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-stone-850 text-[10px] text-emerald-400 font-medium">
                  ✓ كود الطلبية + عدد البنود
                </div>
              </div>

              {/* Step 5 */}
              <div className="bg-stone-950/70 border border-stone-800 hover:border-amber-500/40 rounded-xl p-3.5 flex flex-col justify-between transition">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 text-xs font-black flex items-center justify-center">
                      5
                    </span>
                    <Truck className="w-4 h-4 text-purple-400" />
                  </div>
                  <h4 className="font-bold text-stone-100 text-xs mb-1">الفحص والاستلام HACCP</h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed">
                    مطابقة الأوزان مع المورد، فحص درجة حرارة التبريد والصلاحية عند الاستلام.
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-stone-850 text-[10px] text-purple-400 font-medium">
                  ✓ رصيد المخزن يُحدث آلياً
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: MANAGER & EXECUTIVE CHEF PLAYBOOK */}
        {activeInfographicTab === 'manager' && (
          <div className="mt-5 space-y-4">
            <div className="flex items-center justify-between text-xs text-stone-300 bg-stone-950/60 p-3 rounded-xl border border-stone-800/80">
              <span className="font-bold text-amber-400 flex items-center gap-1.5">
                <Laptop className="w-4 h-4 text-amber-400" />
                <span>ركائز تحقيق أقصى استفادة للشيف العمومي والمدير التنفيذي:</span>
              </span>
              <span className="text-[11px] text-stone-400 font-mono">4 محاور رقابية استراتيجية</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              {/* Pillar 1 */}
              <div className="bg-stone-950/70 border border-stone-800 hover:border-amber-500/40 rounded-xl p-4 flex flex-col justify-between transition">
                <div>
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-base mb-2">
                    🔔
                  </div>
                  <h4 className="font-bold text-stone-100 text-xs mb-1.5">
                    منبه الأحد ومراجعة المشرفين مرتين
                  </h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed">
                    تنبيه دوري يظهر يوم السبت (اليوم السابق) ويوم الأحد (يوم الطلب). تطلب كافة الطلبيات الأسبوعية حصرياً يوم الأحد مع مراجعة إشرافية مرتين أسبوعياً لكل مشرف.
                  </p>
                </div>
                <div className="mt-3 pt-2 border-t border-stone-850 flex items-center justify-between text-[10px] text-amber-300 font-mono">
                  <span>طلب: الأحد فقط</span>
                  <span>مراجعة: مرتان/أسبوع</span>
                </div>
              </div>

              {/* Pillar 2 */}
              <div className="bg-stone-950/70 border border-stone-800 hover:border-amber-500/40 rounded-xl p-4 flex flex-col justify-between transition">
                <div>
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-base mb-2">
                    📊
                  </div>
                  <h4 className="font-bold text-stone-100 text-xs mb-1.5">
                    الجداول الإحصائية الأسبوعية والشهرية
                  </h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed">
                    عمود إحصائي مستقل لكل طلبية يبرز إجمالي الكميات المطلوبة أسبوعياً وشهرياً لكل صنف. يمنحك رؤية فورية لمعدلات الاستهلاك والتكلفة التقديرية.
                  </p>
                </div>
                <div className="mt-3 pt-2 border-t border-stone-850 flex items-center justify-between text-[10px] text-emerald-400 font-mono">
                  <span>حصر أسبوعي 📅</span>
                  <span>حصر شهري 🗓️</span>
                </div>
              </div>

              {/* Pillar 3 */}
              <div className="bg-stone-950/70 border border-stone-800 hover:border-amber-500/40 rounded-xl p-4 flex flex-col justify-between transition">
                <div>
                  <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-base mb-2">
                    👥
                  </div>
                  <h4 className="font-bold text-stone-100 text-xs mb-1.5">
                    إدارة المساعدين والآيبان والبصمة
                  </h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed">
                    صلاحيات حصرية لتعديل أسماء وأدوار المساعدين أو تعطيلهم (Soft Delete)، مع تسجيل كود الموظف، رقم الآيبان البنكي، والبصمة البيومترية المعتمدة لكل مساعد.
                  </p>
                </div>
                <div className="mt-3 pt-2 border-t border-stone-850 flex items-center justify-between text-[10px] text-blue-400 font-mono">
                  <span>كود موظف #</span>
                  <span>آيبان IBAN</span>
                </div>
              </div>

              {/* Pillar 4 */}
              <div className="bg-stone-950/70 border border-stone-800 hover:border-amber-500/40 rounded-xl p-4 flex flex-col justify-between transition">
                <div>
                  <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-base mb-2">
                    📑
                  </div>
                  <h4 className="font-bold text-stone-100 text-xs mb-1.5">
                    الأرشيف التراكمي وطباعة التقارير
                  </h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed">
                    أرشفة آلية لكل أمر شراء تحت أسبوع العمل، مع إمكانية طباعة تقرير أسبوعي رسمي مجهز بمربعات التوقيعات للشيف العمومي والمشتريات والاستلام.
                  </p>
                </div>
                <div className="mt-3 pt-2 border-t border-stone-850 flex items-center justify-between text-[10px] text-purple-400 font-mono">
                  <span>جاهز للطباعة 🖨️</span>
                  <span>توقيعات رسمية ✍️</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Category Filter Pills */}
      <div className="flex flex-wrap items-center gap-2">
        {[
          { id: 'all', label: 'كافة الأقسام والمواضيع' },
          { id: 'manager', label: 'صلاحيات المدير الإدارية' },
          { id: 'assistant', label: 'دليل المساعدين والتشغيل' },
          { id: 'quality', label: 'معايير HACCP وسلسلة التبريد' },
          { id: 'core', label: 'المخزون والتحويلات العامة' },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id as any)}
            className={`text-xs px-3 py-1.5 rounded-xl font-medium transition ${
              selectedCategory === cat.id
                ? 'bg-amber-500 text-stone-950 font-bold shadow-sm'
                : 'bg-stone-900 border border-stone-800 text-stone-300 hover:bg-stone-850'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Main Grid: Navigation List on Left (RTL), Content on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-4 space-y-2">
          <h2 className="text-xs font-bold text-stone-400 uppercase tracking-wider px-1">
            فهرس الموضوعات ({filteredSections.length})
          </h2>
          <div className="space-y-1.5">
            {filteredSections.map((sec) => {
              const Icon = sec.icon;
              const isActive = sec.id === currentSection.id;
              return (
                <button
                  key={sec.id}
                  onClick={() => setActiveSectionId(sec.id)}
                  className={`w-full p-3 rounded-2xl border text-right transition flex items-start gap-3 ${
                    isActive
                      ? 'bg-amber-500/15 border-amber-500/40 text-stone-100 shadow-sm'
                      : 'bg-stone-900 border-stone-800/80 text-stone-400 hover:bg-stone-850 hover:text-stone-200'
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                      isActive
                        ? 'bg-amber-500 text-stone-950 font-bold'
                        : 'bg-stone-800 text-stone-400'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className={`text-xs font-bold truncate ${isActive ? 'text-amber-400' : 'text-stone-200'}`}>
                      {sec.title}
                    </h3>
                    <p className="text-[11px] text-stone-400 truncate mt-0.5">
                      {sec.summary}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Section Details */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-6 shadow-sm space-y-6">
            {/* Header of Section */}
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-stone-800">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase font-mono bg-amber-500/10 text-amber-400 border border-amber-500/20">
                    {currentSection.category === 'manager'
                      ? 'صلاحية إدارية حصرية'
                      : currentSection.category === 'quality'
                      ? 'جودة وسلامة غذاء HACCP'
                      : 'إجراءات تشغيلية'}
                  </span>
                </div>
                <h2 className="text-base font-bold text-stone-100 flex items-center gap-2">
                  <span>{currentSection.title}</span>
                </h2>
                <p className="text-xs text-stone-300 leading-relaxed">
                  {currentSection.summary}
                </p>
              </div>

              {currentSection.targetTab && onNavigateTab && (
                <button
                  onClick={() => onNavigateTab(currentSection.targetTab!)}
                  className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shrink-0 shadow-sm"
                >
                  <span>الانتقال للشاشة المباشرة</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Steps & Workflow */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wide flex items-center gap-2">
                <ClipboardList className="w-4 h-4" />
                <span>خطوات العمل والتنفيذ المباشرة:</span>
              </h3>
              <div className="space-y-2.5">
                {currentSection.steps.map((st, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-3 bg-stone-950/60 p-3 rounded-xl border border-stone-800/80 text-xs text-stone-200"
                  >
                    <div className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0 font-mono text-[11px] border border-amber-500/30">
                      {idx + 1}
                    </div>
                    <span className="leading-relaxed">{st}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Tips and Best Practices Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              {/* Operational Tips */}
              <div className="bg-stone-950/40 p-4 rounded-xl border border-stone-800/80 space-y-2.5">
                <h4 className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>تلميحات وسرعة الإنجاز:</span>
                </h4>
                <ul className="space-y-2 text-xs text-stone-300">
                  {currentSection.tips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-emerald-400 font-bold">•</span>
                      <span className="leading-relaxed">{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Best Practices & Quality Control */}
              <div className="bg-stone-950/40 p-4 rounded-xl border border-stone-800/80 space-y-2.5">
                <h4 className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>أفضل الممارسات الرقابية:</span>
                </h4>
                <ul className="space-y-2 text-xs text-stone-300">
                  {currentSection.bestPractices.map((bp, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold">•</span>
                      <span className="leading-relaxed">{bp}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
