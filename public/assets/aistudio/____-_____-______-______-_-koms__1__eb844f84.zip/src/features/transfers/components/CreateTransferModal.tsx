import React, { useState } from 'react';
import { Branch } from '../types';
import { transferService } from '../api/transferService';
import { UserProfile } from '@/features/auth/types';
import { X, Plus, Trash2, ArrowRightLeft } from 'lucide-react';

interface CreateTransferModalProps {
  currentBranch: Branch;
  commissaryBranch: Branch;
  availableProducts: { id: string; nameAr: string; unit: string }[];
  currentUser: UserProfile;
  onClose: () => void;
  onCreated: () => void;
}

export const CreateTransferModal: React.FC<CreateTransferModalProps> = ({
  currentBranch,
  commissaryBranch,
  availableProducts,
  currentUser,
  onClose,
  onCreated,
}) => {
  const [selectedItems, setSelectedItems] = useState<{ productId: string; productNameAr: string; unit: string; requestedQty: number }[]>([]);
  const [deliveryDate, setDeliveryDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState(availableProducts[0]?.id || '');
  const [inputQty, setInputQty] = useState<number>(10);

  const handleAddItem = () => {
    const prod = availableProducts.find(p => p.id === selectedProductId);
    if (!prod || inputQty <= 0) return;

    if (selectedItems.some(i => i.productId === prod.id)) {
      alert('الصنف مضاف بالفعل للقائمة');
      return;
    }

    setSelectedItems(prev => [
      ...prev,
      { productId: prod.id, productNameAr: prod.nameAr, unit: prod.unit, requestedQty: inputQty },
    ]);
  };

  const handleRemoveItem = (productId: string) => {
    setSelectedItems(prev => prev.filter(i => i.productId !== productId));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedItems.length === 0) return;

    setLoading(true);
    try {
      await transferService.createTransferRequest(
        commissaryBranch,
        currentBranch,
        selectedItems,
        deliveryDate,
        currentUser
      );
      onCreated();
      onClose();
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء إرسال طلب التحويل');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-stone-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-3 overflow-y-auto text-xs text-stone-100">
      <div className="bg-stone-900 border border-stone-800 rounded-xl shadow-2xl w-full max-w-lg flex flex-col overflow-hidden">
        <div className="p-4 bg-stone-950 border-b border-stone-800 flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <ArrowRightLeft className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-100">طلب احتياج داخلي من المطبخ المركزي</h3>
              <span className="text-[11px] text-stone-400">الفرع الطالب: {currentBranch.nameAr}</span>
            </div>
          </div>
          <button onClick={onClose} className="text-stone-400 hover:text-stone-100 p-1 rounded hover:bg-stone-800 transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          <div>
            <label className="block text-stone-300 font-semibold mb-1">تاريخ الاستلام المطلوب</label>
            <input
              type="date"
              value={deliveryDate}
              onChange={(e) => setDeliveryDate(e.target.value)}
              required
              className="w-full p-2 bg-stone-950 border border-stone-800 rounded-lg text-stone-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* إضافة أصناف */}
          <div className="p-3 bg-stone-950/60 border border-stone-800 rounded-xl space-y-2">
            <span className="font-bold text-stone-300 block text-xs">إضافة صنف للطلب</span>
            <div className="flex gap-2">
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="flex-1 p-2 bg-stone-900 border border-stone-800 rounded-lg text-stone-100 text-xs focus:outline-none focus:border-amber-500"
              >
                {availableProducts.map(p => (
                  <option key={p.id} value={p.id}>{p.nameAr} ({p.unit})</option>
                ))}
              </select>
              <input
                type="number"
                min="1"
                value={inputQty}
                onChange={(e) => setInputQty(Number(e.target.value))}
                className="w-20 p-2 bg-stone-900 border border-stone-800 rounded-lg text-stone-100 text-center font-bold font-mono focus:outline-none focus:border-amber-500"
              />
              <button
                type="button"
                onClick={handleAddItem}
                className="px-3 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded-lg font-bold flex items-center gap-1 transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة</span>
              </button>
            </div>
          </div>

          {/* قائمة الأصناف المختارة */}
          <div className="border border-stone-800 rounded-xl overflow-hidden bg-stone-950/40">
            <table className="w-full text-right text-xs">
              <thead className="bg-stone-950/80 text-stone-400 border-b border-stone-800 font-medium">
                <tr>
                  <th className="p-2.5">الصنف</th>
                  <th className="p-2.5">الكمية المطلوبة</th>
                  <th className="p-2.5 w-10 text-center">إجراء</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/60 font-sans">
                {selectedItems.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="p-4 text-center text-stone-500">لم يتم اختيار أي أصناف بعد</td>
                  </tr>
                ) : (
                  selectedItems.map((it) => (
                    <tr key={it.productId} className="hover:bg-stone-900/40 transition">
                      <td className="p-2.5 font-medium text-stone-200">{it.productNameAr}</td>
                      <td className="p-2.5 font-mono font-bold text-amber-400">{it.requestedQty} {it.unit}</td>
                      <td className="p-2.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(it.productId)}
                          className="text-stone-500 hover:text-rose-400 p-1 rounded hover:bg-stone-800 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="pt-2 border-t border-stone-800 flex gap-2">
            <button
              type="submit"
              disabled={loading || selectedItems.length === 0}
              className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-stone-950 rounded-lg font-bold transition shadow-lg shadow-amber-500/10"
            >
              {loading ? 'جاري إرسال الطلب...' : `تأكيد وإرسال طلب التحويل (${selectedItems.length})`}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-4 bg-stone-800 text-stone-300 rounded-lg font-semibold hover:bg-stone-700 transition"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
