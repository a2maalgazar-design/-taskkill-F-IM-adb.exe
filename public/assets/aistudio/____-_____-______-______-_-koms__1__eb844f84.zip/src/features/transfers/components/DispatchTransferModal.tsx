import React, { useState } from 'react';
import { InternalTransferRequest } from '../types';
import { transferService } from '../api/transferService';
import { UserProfile } from '@/features/auth/types';
import { Truck, X, AlertTriangle, Thermometer } from 'lucide-react';

interface DispatchTransferModalProps {
  transfer: InternalTransferRequest;
  currentUser: UserProfile;
  onClose: () => void;
  onDispatched: () => void;
}

export const DispatchTransferModal: React.FC<DispatchTransferModalProps> = ({
  transfer,
  currentUser,
  onClose,
  onDispatched,
}) => {
  const [driverName, setDriverName] = useState('');
  const [vehiclePlate, setVehiclePlate] = useState('');
  const [tempCelsius, setTempCelsius] = useState<number>(3.5);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!driverName.trim() || !vehiclePlate.trim()) {
      setError('يرجى تسجيل بيانات السائق ورقم لوحة السيارة');
      return;
    }

    if (tempCelsius > 4) {
      setError('حظر سلامة الغذاء HACCP: درجة الحرارة تتجاوز 4°م المسموحة للمبردات');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const dispatchedPayload = transfer.items.map(it => ({
        productId: it.productId,
        qty: it.requestedQty,
      }));

      await transferService.dispatchTransfer(
        transfer.id,
        dispatchedPayload,
        { driverName: driverName.trim(), vehiclePlate: vehiclePlate.trim(), tempCelsius },
        currentUser
      );
      onDispatched();
      onClose();
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء الشحن');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-stone-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-3 text-xs text-stone-100">
      <div className="bg-stone-900 border border-stone-800 rounded-xl shadow-2xl w-full max-w-md flex flex-col overflow-hidden">
        <div className="p-4 bg-stone-950 border-b border-stone-800 flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Truck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-100">شحن إذن تحويل داخلي — {transfer.transferCode}</h3>
              <span className="text-[11px] text-stone-400">الوجهة: {transfer.targetBranchNameAr}</span>
            </div>
          </div>
          <button onClick={onClose} className="text-stone-400 hover:text-stone-100 p-1 rounded hover:bg-stone-800 transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleDispatch} className="p-4 space-y-4">
          {error && (
            <div className="p-2.5 bg-rose-500/10 border border-rose-500/30 text-rose-400 rounded-lg text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-stone-300 font-semibold mb-1">اسم السائق المسؤول *</label>
              <input
                type="text"
                value={driverName}
                onChange={(e) => setDriverName(e.target.value)}
                placeholder="مثال: رمضان فتحي"
                required
                className="w-full p-2 bg-stone-950 border border-stone-800 rounded-lg text-stone-100 focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-stone-300 font-semibold mb-1">رقم لوحة الشاحنة *</label>
              <input
                type="text"
                value={vehiclePlate}
                onChange={(e) => setVehiclePlate(e.target.value)}
                placeholder="مثال: ط ر ج 7842"
                required
                className="w-full p-2 bg-stone-950 border border-stone-800 rounded-lg text-stone-100 focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-stone-300 font-semibold mb-1">درجة حرارة سيارة التبريد عند الانطلاق (°م) *</label>
            <div className="flex items-center gap-2">
              <div className="relative">
                <input
                  type="number"
                  step="0.1"
                  value={tempCelsius}
                  onChange={(e) => setTempCelsius(Number(e.target.value))}
                  required
                  className="w-28 p-2 bg-stone-950 border border-stone-800 rounded-lg text-center font-bold font-mono text-emerald-400 focus:outline-none focus:border-emerald-500"
                />
              </div>
              <span className="text-stone-400 text-[11px]">(الحد الأقصى المسموح للحوم والأغذية الحساسة 4.0°م)</span>
            </div>
          </div>

          <div className="bg-stone-950/60 p-3 rounded-xl border border-stone-800">
            <span className="font-semibold text-stone-300 block mb-1">الأصناف المصرح بشحنها:</span>
            <ul className="divide-y divide-stone-800/60 text-[11px]">
              {transfer.items.map(it => (
                <li key={it.productId} className="py-1 flex justify-between text-stone-300">
                  <span>{it.productNameAr}</span>
                  <span className="font-mono font-bold text-emerald-400">{it.requestedQty} {it.unit}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="pt-2 border-t border-stone-800 flex gap-2">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-stone-950 rounded-lg font-bold transition shadow-lg shadow-emerald-500/10"
            >
              {loading ? 'جاري الشحن وخصم المخزون...' : 'اعتماد الشحن والانطلاق'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-4 bg-stone-800 text-stone-300 rounded-lg font-semibold hover:bg-stone-700 transition"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
