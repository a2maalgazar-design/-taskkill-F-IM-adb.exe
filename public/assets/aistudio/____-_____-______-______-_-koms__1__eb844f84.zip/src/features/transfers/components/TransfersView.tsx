import React, { useState, useEffect } from 'react';
import { ArrowRightLeft, Plus, Truck, CheckCircle2, Clock, MapPin, AlertTriangle, ShieldCheck } from 'lucide-react';
import { InternalTransferRequest, Branch, TransferStatus } from '../types';
import { transferService, INITIAL_BRANCHES } from '../api/transferService';
import { CreateTransferModal } from './CreateTransferModal';
import { DispatchTransferModal } from './DispatchTransferModal';
import { ReceiveTransferModal } from './ReceiveTransferModal';
import { useAuth } from '@/features/auth/components/AuthGuard';
import { UserProfile } from '@/features/auth/types';
import { useData } from '@/context/DataContext';

export const TransfersView: React.FC = () => {
  const { user, currentUser, isManager } = useAuth();
  const { products } = useData();

  const [transfers, setTransfers] = useState<InternalTransferRequest[]>([]);
  const [selectedBranchId, setSelectedBranchId] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [loading, setLoading] = useState(true);

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [dispatchingTransfer, setDispatchingTransfer] = useState<InternalTransferRequest | null>(null);
  const [receivingTransfer, setReceivingTransfer] = useState<InternalTransferRequest | null>(null);

  const effectiveUser: UserProfile = user || {
    uid: currentUser?.id || 'usr-commissary',
    email: currentUser?.email || 'manager@kitchen.internal',
    displayName: currentUser?.name || 'مدير العمليات المركزية',
    role: currentUser?.role || 'manager',
    permissions: [],
    isActive: true,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  };

  const loadTransfers = async () => {
    setLoading(true);
    try {
      const data = await transferService.getTransfers(
        selectedBranchId === 'ALL' ? undefined : selectedBranchId,
        selectedStatus === 'ALL' ? undefined : (selectedStatus as TransferStatus)
      );
      setTransfers(data);
    } catch (err) {
      console.error('Failed to load transfers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTransfers();
  }, [selectedBranchId, selectedStatus]);

  const commissaryBranch = INITIAL_BRANCHES[0];
  const satelliteBranch = INITIAL_BRANCHES.find(b => b.id !== commissaryBranch.id) || INITIAL_BRANCHES[1];

  return (
    <div className="space-y-6 text-xs text-stone-100">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-stone-100">التحويلات الداخلية وسلاسل الإمداد (Central Commissary Transfers)</h2>
            <span className="text-[10px] px-2.5 py-0.5 rounded-full font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
              Multi-Branch Logistics
            </span>
          </div>
          <p className="text-xs text-stone-400 mt-1">
            إدارة أذونات الصرف والشحن اللحظي بين المطبخ المركزي والفروع التابعة مع رقابة درجات حرارة التبريد HACCP
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded-lg text-xs font-bold transition shadow-lg shadow-amber-500/10"
        >
          <Plus className="w-4 h-4" />
          <span>إنشاء طلب تحويل من المطبخ المركزي</span>
        </button>
      </div>

      {/* بطاقات الفروع والشبكة اللوجستية */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {INITIAL_BRANCHES.map(branch => (
          <div key={branch.id} className="p-3.5 bg-stone-900 border border-stone-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                branch.type === 'COMMISSARY'
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  : 'bg-stone-800 text-stone-400'
              }`}>
                {branch.type === 'COMMISSARY' ? 'المطبخ المركزي الرئيسي' : 'مطبخ فرعي تجميعي'}
              </span>
              <span className="font-mono text-stone-500 text-[11px]">{branch.code}</span>
            </div>
            <div>
              <h4 className="font-bold text-stone-200 text-xs truncate">{branch.nameAr}</h4>
              <p className="text-[11px] text-stone-400 flex items-center gap-1 mt-0.5">
                <MapPin className="w-3 h-3 shrink-0" />
                <span className="truncate">{branch.address}</span>
              </p>
            </div>
            <div className="pt-2 border-t border-stone-800/80 flex justify-between text-[10px] text-stone-400">
              <span>المسؤول: {branch.managerName}</span>
              <span className="font-mono text-emerald-400">نشط</span>
            </div>
          </div>
        ))}
      </div>

      {/* شريط الفلاتر والبحث */}
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <div className="flex flex-wrap gap-1.5">
          {['ALL', 'REQUESTED', 'DISPATCHED', 'RECEIVED'].map(status => (
            <button
              key={status}
              onClick={() => setSelectedStatus(status)}
              className={`px-3 py-1 rounded-lg text-xs transition ${
                selectedStatus === status
                  ? 'bg-amber-500 text-stone-950 font-bold'
                  : 'bg-stone-900 border border-stone-800 text-stone-400 hover:text-stone-200'
              }`}
            >
              {status === 'ALL' && 'كافة الحالات'}
              {status === 'REQUESTED' && 'بانتظار الشحن (Requested)'}
              {status === 'DISPATCHED' && 'في طريقها للفرع (Dispatched)'}
              {status === 'RECEIVED' && 'تم استلامها بالفرع (Received)'}
            </button>
          ))}
        </div>

        <select
          value={selectedBranchId}
          onChange={(e) => setSelectedBranchId(e.target.value)}
          className="bg-stone-900 border border-stone-800 rounded-lg px-3 py-1.5 text-xs text-stone-100 focus:outline-none focus:border-amber-500"
        >
          <option value="ALL">جميع الفروع</option>
          {INITIAL_BRANCHES.map(b => (
            <option key={b.id} value={b.id}>{b.nameAr}</option>
          ))}
        </select>
      </div>

      {/* جدول أذونات التحويل */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-right text-xs">
          <thead className="bg-stone-950/80 border-b border-stone-800 text-stone-400 font-semibold">
            <tr>
              <th className="p-3">كود التحويل</th>
              <th className="p-3">الفرع الطالب</th>
              <th className="p-3">تاريخ الاستحقاق</th>
              <th className="p-3">الأصناف والكميات</th>
              <th className="p-3">الشاحنة وحرارة التبريد</th>
              <th className="p-3 text-center">الحالة</th>
              <th className="p-3 text-center">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-800/60 font-sans">
            {loading ? (
              <tr>
                <td colSpan={7} className="p-8 text-center text-stone-500">جاري تحميل بيانات الشحن والتحويلات...</td>
              </tr>
            ) : transfers.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-8 text-center text-stone-500">لا توجد طلبات تحويل مطابقة</td>
              </tr>
            ) : (
              transfers.map(tr => {
                const isRequested = tr.status === 'REQUESTED';
                const isDispatched = tr.status === 'DISPATCHED';
                const isReceived = tr.status === 'RECEIVED';

                return (
                  <tr key={tr.id} className="hover:bg-stone-800/40 transition">
                    <td className="p-3 font-mono font-bold text-amber-400">{tr.transferCode}</td>
                    <td className="p-3 font-medium text-stone-200">{tr.targetBranchNameAr}</td>
                    <td className="p-3 font-mono text-stone-400">{tr.requestedDeliveryDate}</td>
                    <td className="p-3">
                      <div className="space-y-0.5">
                        {tr.items.slice(0, 2).map((it, i) => (
                          <div key={i} className="text-stone-300 text-[11px]">
                            {it.productNameAr} ({it.requestedQty} {it.unit})
                          </div>
                        ))}
                        {tr.items.length > 2 && (
                          <span className="text-[10px] text-stone-500">+ {tr.items.length - 2} أصناف أخرى</span>
                        )}
                      </div>
                    </td>
                    <td className="p-3">
                      {tr.driverName ? (
                        <div className="text-[11px] space-y-0.5">
                          <span className="text-stone-300 block">{tr.driverName} ({tr.vehiclePlate})</span>
                          <span className="font-mono text-emerald-400 text-[10px] block">
                            حرارة الشحن: {tr.dispatchTempCelsius}°م
                          </span>
                        </div>
                      ) : (
                        <span className="text-stone-500">—</span>
                      )}
                    </td>
                    <td className="p-3 text-center">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold inline-flex items-center gap-1 ${
                        isReceived
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : isDispatched
                          ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20 animate-pulse'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}>
                        {isReceived && <CheckCircle2 className="w-3 h-3" />}
                        {isDispatched && <Truck className="w-3 h-3" />}
                        {isRequested && <Clock className="w-3 h-3" />}
                        <span>
                          {isReceived && 'تم الاستلام'}
                          {isDispatched && 'في الطريق'}
                          {isRequested && 'قيد التجهيز'}
                        </span>
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      {isRequested && (
                        <button
                          onClick={() => setDispatchingTransfer(tr)}
                          className="px-3 py-1 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 rounded font-bold transition flex items-center gap-1 mx-auto"
                        >
                          <Truck className="w-3.5 h-3.5" />
                          <span>شحن الآن</span>
                        </button>
                      )}
                      {isDispatched && (
                        <button
                          onClick={() => setReceivingTransfer(tr)}
                          className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded font-bold transition flex items-center gap-1 mx-auto"
                        >
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>استلام وفحص</span>
                        </button>
                      )}
                      {isReceived && (
                        <span className="text-stone-500 text-[11px] font-mono">مكتمل</span>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* النوافذ المنبثقة */}
      {isCreateModalOpen && (
        <CreateTransferModal
          currentBranch={satelliteBranch}
          commissaryBranch={commissaryBranch}
          availableProducts={products.map(p => ({ id: p.id, nameAr: p.nameAr, unit: p.defaultUnit || p.unit || 'كجم' }))}
          currentUser={effectiveUser}
          onClose={() => setIsCreateModalOpen(false)}
          onCreated={() => loadTransfers()}
        />
      )}

      {dispatchingTransfer && (
        <DispatchTransferModal
          transfer={dispatchingTransfer}
          currentUser={effectiveUser}
          onClose={() => setDispatchingTransfer(null)}
          onDispatched={() => loadTransfers()}
        />
      )}

      {receivingTransfer && (
        <ReceiveTransferModal
          transfer={receivingTransfer}
          currentUser={effectiveUser}
          onClose={() => setReceivingTransfer(null)}
          onReceived={() => loadTransfers()}
        />
      )}
    </div>
  );
};
