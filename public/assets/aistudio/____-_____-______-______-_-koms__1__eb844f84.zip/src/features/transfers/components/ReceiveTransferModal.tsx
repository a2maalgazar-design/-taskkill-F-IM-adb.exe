import React, { useState } from 'react';
import { InternalTransferRequest } from '../types';
import { transferService } from '../api/transferService';
import { UserProfile } from '@/features/auth/types';
import { ShieldCheck, X, AlertTriangle, CheckCircle2, Thermometer, Check } from 'lucide-react';

interface ReceiveTransferModalProps {
  transfer: InternalTransferRequest;
  currentUser: UserProfile;
  onClose: () => void;
  onReceived: () => void;
}

interface ItemState {
  productId: string;
  productNameAr: string;
  unit: string;
  dispatchedQty: number;
  receivedQty: number;
  rejectedQty: number;
  reason: string;
}

export const ReceiveTransferModal: React.FC<ReceiveTransferModalProps> = ({
  transfer,
  currentUser,
  onClose,
  onReceived,
}) => {
  const [receivingTempCelsius, setReceivingTempCelsius] = useState<number>(3.8);
  const [itemsState, setItemsState] = useState<ItemState[]>(() =>
    transfer.items.map(it => ({
      productId: it.productId,
      productNameAr: it.productNameAr,
      unit: it.unit,
      dispatchedQty: it.dispatchedQty || it.requestedQty,
      receivedQty: it.dispatchedQty || it.requestedQty,
      rejectedQty: 0,
      reason: '',
    }))
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleItemChange = (
    productId: string,
    field: 'receivedQty' | 'rejectedQty' | 'reason',
    value: string | number
  ) => {
    setItemsState(prev =>
      prev.map(it => {
        if (it.productId !== productId) return it;
        if (field === 'receivedQty') {
          const rQty = Math.max(0, Number(value) || 0);
          const rej = Math.max(0, it.dispatchedQty - rQty);
          return { ...it, receivedQty: rQty, rejectedQty: rej };
        }
        if (field === 'rejectedQty') {
          const rej = Math.max(0, Number(value) || 0);
          const rQty = Math.max(0, it.dispatchedQty - rej);
          return { ...it, rejectedQty: rej, receivedQty: rQty };
        }
        if (field === 'reason') {
          return { ...it, reason: String(value) };
        }
        return it;
      })
    );
  };

  const handleAcceptAll = () => {
    setItemsState(prev =>
      prev.map(it => ({
        ...it,
        receivedQty: it.dispatchedQty,
        rejectedQty: 0,
        reason: '',
      }))
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isNaN(receivingTempCelsius)) {
      setError('يرجى تحديد درجة حرارة وصول الشحنة بدقة');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const payload = itemsState.map(it => ({
        productId: it.productId,
        receivedQty: it.receivedQty,
        rejectedQty: it.rejectedQty,
        reason: it.reason.trim(),
      }));

      await transferService.receiveTransferAtBranch(
        transfer.id,
        payload,
        receivingTempCelsius,
        currentUser
      );

      onReceived();
      onClose();
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء اعتماد الاستلام بالفرع');
    } finally {
      setLoading(false);
    }
  };

  const isTempCritical = receivingTempCelsius > 4.0;

  return (
    <div className="fixed inset-0 bg-stone-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-3 text-xs text-stone-100">
      <div className="bg-stone-900 border border-stone-800 rounded-xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-stone-950 border-b border-stone-800 flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-100">
                فحص واستلام إذن التحويل بالفرع — <span className="font-mono text-amber-400">{transfer.transferCode}</span>
              </h3>
              <div className="flex items-center gap-3 text-[11px] text-stone-400 mt-0.5">
                <span>الفرع المستلم: <strong className="text-stone-300">{transfer.targetBranchNameAr}</strong></span>
                {transfer.vehiclePlate && (
                  <span>مركبة: <strong className="text-stone-300 font-mono">{transfer.vehiclePlate}</strong></span>
                )}
                {transfer.dispatchTempCelsius !== undefined && (
                  <span>حرارة الشحن: <strong className="text-emerald-400 font-mono">{transfer.dispatchTempCelsius}°م</strong></span>
                )}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-stone-100 p-1.5 rounded-lg hover:bg-stone-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 space-y-4">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-400 rounded-lg flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* قياس درجة الحرارة وسلسلة التبريد */}
          <div className="p-3.5 bg-stone-950 border border-stone-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-stone-300 font-bold flex items-center gap-1.5">
                <Thermometer className="w-4 h-4 text-sky-400" />
                <span>درجة حرارة الشحنة المقاسة عند الوصول بالفرع (°م) *</span>
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  step="0.1"
                  value={receivingTempCelsius}
                  onChange={(e) => setReceivingTempCelsius(parseFloat(e.target.value) || 0)}
                  className={`w-24 p-2 text-center font-mono font-bold text-sm rounded-lg border bg-stone-900 focus:outline-none ${
                    isTempCritical
                      ? 'border-rose-500 text-rose-400 bg-rose-950/20'
                      : 'border-emerald-500 text-emerald-400'
                  }`}
                  required
                />
                <span className="text-stone-400 text-xs font-mono">°م</span>
              </div>
            </div>

            {isTempCritical ? (
              <div className="flex items-center gap-2 text-rose-400 bg-rose-500/10 p-2 rounded-lg text-[11px] border border-rose-500/20">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>
                  تحذير HACCP: درجة الحرارة المقاسة ({receivingTempCelsius}°م) تتجاوز حد التبريد الآمن (4.0°م). يرجى فحص جودة اللحوم والألبان قبل القبول.
                </span>
              </div>
            ) : (
              <p className="text-[11px] text-emerald-400/90 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>سلسلة التبريد آمنة ومطابقة لمعايير سلامة الأغذية (تحت 4.0°م).</span>
              </p>
            )}
          </div>

          {/* فحص الأصناف */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-stone-200">فحص ومطابقة أصناف الشحنة:</span>
              <button
                type="button"
                onClick={handleAcceptAll}
                className="text-[11px] px-2.5 py-1 bg-stone-800 hover:bg-stone-700 text-amber-400 rounded-lg font-bold flex items-center gap-1 transition"
              >
                <Check className="w-3.5 h-3.5" />
                <span>قبول ومطابقة كافة الكميات</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {itemsState.map(it => {
                const hasRejection = it.rejectedQty > 0;
                return (
                  <div
                    key={it.productId}
                    className={`p-3 rounded-xl border transition ${
                      hasRejection
                        ? 'bg-rose-950/15 border-rose-500/30'
                        : 'bg-stone-950/70 border-stone-800'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-2">
                      <div>
                        <span className="font-bold text-stone-200">{it.productNameAr}</span>
                        <span className="text-stone-400 text-[11px] mr-2">
                          (المشحون: <strong className="text-emerald-400 font-mono">{it.dispatchedQty} {it.unit}</strong>)
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1">
                          <label className="text-[11px] text-stone-400">المستلم:</label>
                          <input
                            type="number"
                            step="0.1"
                            min="0"
                            max={it.dispatchedQty}
                            value={it.receivedQty}
                            onChange={(e) => handleItemChange(it.productId, 'receivedQty', e.target.value)}
                            className="w-20 p-1.5 text-center font-mono font-bold bg-stone-900 border border-stone-700 rounded text-emerald-400 focus:outline-none focus:border-emerald-500"
                          />
                          <span className="text-stone-400 text-[10px]">{it.unit}</span>
                        </div>

                        <div className="flex items-center gap-1">
                          <label className="text-[11px] text-rose-400">التالف/المرفوض:</label>
                          <input
                            type="number"
                            step="0.1"
                            min="0"
                            max={it.dispatchedQty}
                            value={it.rejectedQty}
                            onChange={(e) => handleItemChange(it.productId, 'rejectedQty', e.target.value)}
                            className="w-16 p-1.5 text-center font-mono font-bold bg-stone-900 border border-stone-700 rounded text-rose-400 focus:outline-none focus:border-rose-500"
                          />
                        </div>
                      </div>
                    </div>

                    {hasRejection && (
                      <div className="mt-2 pt-2 border-t border-rose-500/20">
                        <input
                          type="text"
                          value={it.reason}
                          onChange={(e) => handleItemChange(it.productId, 'reason', e.target.value)}
                          placeholder="يرجى توضيح سبب الرفض أو العجز (مثال: تلف أثناء النقل، سوء تبريد، وزن ناقص)..."
                          className="w-full p-1.5 bg-stone-900 border border-rose-500/30 rounded text-stone-200 text-xs focus:outline-none focus:border-rose-500"
                          required={hasRejection}
                        />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-stone-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg font-semibold transition"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-stone-950 rounded-lg font-bold transition flex items-center gap-1.5 shadow-lg shadow-amber-500/10"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{loading ? 'جاري اعتماد وإيداع المخزون...' : 'تأكيد الاستلام وإيداع المخزون'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
