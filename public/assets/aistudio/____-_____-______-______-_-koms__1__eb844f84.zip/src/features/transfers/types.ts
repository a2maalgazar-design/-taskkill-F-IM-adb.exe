export type BranchType = 'COMMISSARY' | 'SATELLITE_KITCHEN' | 'OUTLET';

export interface Branch {
  id: string;
  code: string; // مثال: "BR-MAIN", "BR-ZAMALEK", "BR-TAGAMOA"
  nameAr: string;
  type: BranchType;
  address: string;
  phone: string;
  managerName: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export type TransferStatus =
  | 'REQUESTED'
  | 'APPROVED'
  | 'PREPARING'
  | 'DISPATCHED'
  | 'RECEIVED'
  | 'CANCELLED';

export interface TransferItem {
  productId: string;
  productNameAr: string;
  unit: string;
  requestedQty: number;
  dispatchedQty: number;
  receivedQty: number;
  rejectedQty: number;
  rejectionReason?: string;
}

export interface InternalTransferRequest {
  id: string;
  transferCode: string; // KOMS-TR-YYYY-XXXX
  sourceBranchId: string; // عادة المطبخ المركزي
  sourceBranchNameAr: string;
  targetBranchId: string; // الفرع الطالب
  targetBranchNameAr: string;
  status: TransferStatus;
  items: TransferItem[];
  requestedDeliveryDate: string; // YYYY-MM-DD
  // بيانات الشحن الميداني وسلسلة التبريد
  driverName?: string;
  vehiclePlate?: string;
  dispatchTempCelsius?: number; // حرارة الشحن
  receivingTempCelsius?: number; // حرارة الوصول
  statusHistory: {
    actorId: string;
    actorName: string;
    from: TransferStatus;
    to: TransferStatus;
    note?: string;
    ts: string;
  }[];
  createdAt: string;
  updatedAt: string;
}

export interface ConsolidatedProcurementDemand {
  productId: string;
  productNameAr: string;
  orderTypeId: string;
  unit: string;
  totalBranchesDemand: number;
  commissaryAvailableStock: number;
  netProcurementRequired: number; // Max(0, TotalDemand - CommissaryStock)
  supplierId?: string;
}
