import { 
  collection, 
  doc, 
  getDocs, 
  runTransaction, 
  query, 
  where, 
  orderBy, 
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { InternalTransferRequest, TransferItem, TransferStatus, Branch } from '../types';
import { UserProfile } from '@/features/auth/types';

export const INITIAL_BRANCHES: Branch[] = [
  {
    id: 'br-commissary',
    code: 'BR-MAIN',
    nameAr: 'المطبخ المركزي الرئيسي (Commissary Central)',
    type: 'COMMISSARY',
    address: 'المنطقة الصناعية - التجمع الخامس، القاهرة',
    phone: '01012345678',
    managerName: 'الشيف محمد عبد الحميد',
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'br-zamalek',
    code: 'BR-ZAMALEK',
    nameAr: 'فرع الزمالك (Zamalek Satellite Kitchen)',
    type: 'SATELLITE_KITCHEN',
    address: 'شارع 26 يوليو، الزمالك، القاهرة',
    phone: '01123456789',
    managerName: 'أحمد غازي',
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'br-tagamoa',
    code: 'BR-TAGAMOA',
    nameAr: 'فرع التجمع (Tagamoa Kitchen)',
    type: 'SATELLITE_KITCHEN',
    address: 'شارع التسعين الشمالي، التجمع الخامس',
    phone: '01234567890',
    managerName: 'سامح إبراهيم',
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'br-maadi',
    code: 'BR-MAADI',
    nameAr: 'منفذ المعادي (Maadi Express Outlet)',
    type: 'OUTLET',
    address: 'شارع النصر، المعادي، القاهرة',
    phone: '01512345678',
    managerName: 'كريم محمود',
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

const LOCAL_TRANSFERS_KEY = 'koms_kitchen_transfers_cache';

function getLocalTransfers(): InternalTransferRequest[] {
  try {
    const raw = localStorage.getItem(LOCAL_TRANSFERS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Could not read transfers local cache:', e);
  }
  const initial: InternalTransferRequest[] = [
    {
      id: 'tr-seed-01',
      transferCode: 'KOMS-TR-2026-0001',
      sourceBranchId: 'br-commissary',
      sourceBranchNameAr: 'المطبخ المركزي الرئيسي (Commissary Central)',
      targetBranchId: 'br-zamalek',
      targetBranchNameAr: 'فرع الزمالك (Zamalek Satellite Kitchen)',
      status: 'DISPATCHED',
      requestedDeliveryDate: new Date().toISOString().split('T')[0],
      driverName: 'رمضان فتحي',
      vehiclePlate: 'ط ر ج 7842',
      dispatchTempCelsius: 3.2,
      items: [
        {
          productId: 'prod-meat-01',
          productNameAr: 'لحم بقري بلدي طازج (قطع موزة)',
          unit: 'كجم',
          requestedQty: 25,
          dispatchedQty: 25,
          receivedQty: 0,
          rejectedQty: 0,
        },
        {
          productId: 'prod-veg-01',
          productNameAr: 'طماطم بلدي طازجة درجة أولى',
          unit: 'كجم',
          requestedQty: 30,
          dispatchedQty: 30,
          receivedQty: 0,
          rejectedQty: 0,
        },
      ],
      statusHistory: [
        {
          actorId: 'usr-1',
          actorName: 'مدير فرع الزمالك',
          from: 'REQUESTED',
          to: 'REQUESTED',
          note: 'طلب احتياج لتغطية غداء اليوم',
          ts: new Date(Date.now() - 7200000).toISOString(),
        },
        {
          actorId: 'usr-commissary',
          actorName: 'شيف المطبخ المركزي',
          from: 'REQUESTED',
          to: 'DISPATCHED',
          note: 'شحن الطلب بسيارة (ط ر ج 7842) وحرارة (3.2°م)',
          ts: new Date(Date.now() - 3600000).toISOString(),
        },
      ],
      createdAt: new Date(Date.now() - 7200000).toISOString(),
      updatedAt: new Date(Date.now() - 3600000).toISOString(),
    },
  ];
  localStorage.setItem(LOCAL_TRANSFERS_KEY, JSON.stringify(initial));
  return initial;
}

function saveLocalTransfers(transfers: InternalTransferRequest[]): void {
  try {
    localStorage.setItem(LOCAL_TRANSFERS_KEY, JSON.stringify(transfers));
  } catch (e) {
    console.warn('Could not save transfers local cache:', e);
  }
}

export const transferService = {
  getBranches(): Branch[] {
    return INITIAL_BRANCHES;
  },

  async getTransfers(branchId?: string, statusFilter?: TransferStatus): Promise<InternalTransferRequest[]> {
    try {
      const colRef = collection(db, 'transfers');
      let q;

      if (branchId) {
        q = query(
          colRef,
          where('targetBranchId', '==', branchId),
          orderBy('createdAt', 'desc')
        );
      } else {
        q = query(colRef, orderBy('createdAt', 'desc'));
      }

      const snap = await getDocs(q);
      if (!snap.empty) {
        let results = snap.docs.map(d => ({ id: d.id, ...d.data() } as InternalTransferRequest));
        if (statusFilter) {
          results = results.filter(r => r.status === statusFilter);
        }
        return results;
      }
    } catch (err) {
      console.warn('Firestore getTransfers fallback:', err);
    }

    let transfers = getLocalTransfers();
    if (branchId) {
      transfers = transfers.filter(t => t.targetBranchId === branchId || t.sourceBranchId === branchId);
    }
    if (statusFilter) {
      transfers = transfers.filter(t => t.status === statusFilter);
    }
    return transfers;
  },

  /**
   * إنشاء طلب تحويل داخلي من فرع تابع إلى المطبخ المركزي
   */
  async createTransferRequest(
    sourceBranch: { id: string; nameAr: string },
    targetBranch: { id: string; nameAr: string },
    items: { productId: string; productNameAr: string; unit: string; requestedQty: number }[],
    deliveryDate: string,
    actor: UserProfile
  ): Promise<string> {
    const yearStr = new Date().getFullYear().toString();
    const nextSeq = Math.floor(Math.random() * 9000) + 1000;
    const transferCode = `KOMS-TR-${yearStr}-${String(nextSeq).padStart(4, '0')}`;

    const transferItems: TransferItem[] = items.map(it => ({
      productId: it.productId,
      productNameAr: it.productNameAr,
      unit: it.unit,
      requestedQty: it.requestedQty,
      dispatchedQty: 0,
      receivedQty: 0,
      rejectedQty: 0,
    }));

    const newRecord: InternalTransferRequest = {
      id: `tr-${Date.now()}`,
      transferCode,
      sourceBranchId: sourceBranch.id,
      sourceBranchNameAr: sourceBranch.nameAr,
      targetBranchId: targetBranch.id,
      targetBranchNameAr: targetBranch.nameAr,
      status: 'REQUESTED',
      items: transferItems,
      requestedDeliveryDate: deliveryDate,
      statusHistory: [
        {
          actorId: actor.uid,
          actorName: actor.displayName,
          from: 'REQUESTED',
          to: 'REQUESTED',
          note: 'إنشاء طلب احتياج داخلي من الفرع',
          ts: new Date().toISOString(),
        },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      await runTransaction(db, async (transaction) => {
        const counterRef = doc(db, 'counters', `TR_${yearStr}`);
        const counterSnap = await transaction.get(counterRef);

        let seq = 1;
        if (counterSnap.exists()) {
          seq = (counterSnap.data().lastSeq || 0) + 1;
          transaction.update(counterRef, { lastSeq: seq });
        } else {
          transaction.set(counterRef, { lastSeq: 1 });
        }

        const formattedCode = `KOMS-TR-${yearStr}-${String(seq).padStart(4, '0')}`;
        newRecord.transferCode = formattedCode;
        const newTransferRef = doc(collection(db, 'transfers'));
        newRecord.id = newTransferRef.id;

        transaction.set(newTransferRef, {
          ...newRecord,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
    } catch (err) {
      console.warn('Firestore createTransferRequest fallback:', err);
    }

    const local = getLocalTransfers();
    local.unshift(newRecord);
    saveLocalTransfers(local);

    return newRecord.id;
  },

  /**
   * شحن الشحنة من المطبخ المركزي مع فحص حرارة التبريد وخصم المخزون المحجوز
   */
  async dispatchTransfer(
    transferId: string,
    dispatchedItems: { productId: string; qty: number }[],
    shippingDetails: { driverName: string; vehiclePlate: string; tempCelsius: number },
    actor: UserProfile
  ): Promise<void> {
    // فحص درجات حرارة النقل الآمن للمبردات
    if (shippingDetails.tempCelsius > 4) {
      throw new Error('تنبيه HACCP: درجة حرارة سيارة النقل تتجاوز 4 درجات مئوية. يُحظر الشحن.');
    }

    try {
      const transferRef = doc(db, 'transfers', transferId);
      await runTransaction(db, async (transaction) => {
        const snap = await transaction.get(transferRef);
        if (!snap.exists()) throw new Error('طلب التحويل غير موجود');

        const transfer = snap.data() as InternalTransferRequest;

        // 1. خصم الكميات المشحونة من مخزون المطبخ المركزي
        for (const item of dispatchedItems) {
          const stockRef = doc(db, `branches/${transfer.sourceBranchId}/inventory`, item.productId);
          const stockSnap = await transaction.get(stockRef);

          if (stockSnap.exists()) {
            const current = stockSnap.data().currentStock || 0;
            if (current < item.qty) {
              throw new Error(`رصيد المطبخ المركزي لا يكفي لشحن صنف (${item.productId})`);
            }
            transaction.update(stockRef, {
              currentStock: current - item.qty,
              updatedAt: serverTimestamp(),
            });
          }
        }

        // 2. تحديث حالة الطلب إلى مشحون
        const updatedItems = transfer.items.map(it => {
          const found = dispatchedItems.find(d => d.productId === it.productId);
          return {
            ...it,
            dispatchedQty: found ? found.qty : it.requestedQty,
          };
        });

        transaction.update(transferRef, {
          status: 'DISPATCHED',
          items: updatedItems,
          driverName: shippingDetails.driverName,
          vehiclePlate: shippingDetails.vehiclePlate,
          dispatchTempCelsius: shippingDetails.tempCelsius,
          statusHistory: [
            ...transfer.statusHistory,
            {
              actorId: actor.uid,
              actorName: actor.displayName,
              from: transfer.status,
              to: 'DISPATCHED',
              note: `شحن الطلب بسيارة (${shippingDetails.vehiclePlate}) وحرارة (${shippingDetails.tempCelsius}°م)`,
              ts: new Date().toISOString(),
            },
          ],
          updatedAt: serverTimestamp(),
        });
      });
    } catch (err) {
      console.warn('Firestore dispatchTransfer fallback:', err);
    }

    // Local fallback update
    const local = getLocalTransfers();
    const idx = local.findIndex(t => t.id === transferId);
    if (idx >= 0) {
      const transfer = local[idx];
      const updatedItems = transfer.items.map(it => {
        const found = dispatchedItems.find(d => d.productId === it.productId);
        return {
          ...it,
          dispatchedQty: found ? found.qty : it.requestedQty,
        };
      });
      local[idx] = {
        ...transfer,
        status: 'DISPATCHED',
        items: updatedItems,
        driverName: shippingDetails.driverName,
        vehiclePlate: shippingDetails.vehiclePlate,
        dispatchTempCelsius: shippingDetails.tempCelsius,
        statusHistory: [
          ...transfer.statusHistory,
          {
            actorId: actor.uid,
            actorName: actor.displayName,
            from: transfer.status,
            to: 'DISPATCHED',
            note: `شحن الطلب بسيارة (${shippingDetails.vehiclePlate}) وحرارة (${shippingDetails.tempCelsius}°م)`,
            ts: new Date().toISOString(),
          },
        ],
        updatedAt: new Date().toISOString(),
      };
      saveLocalTransfers(local);
    }
  },

  /**
   * استلام الشحنة في الفرع المستهدف وإيداعها في مخزون الفرع ذرّياً
   */
  async receiveTransferAtBranch(
    transferId: string,
    receivedQuantities: { productId: string; receivedQty: number; rejectedQty: number; reason?: string }[],
    receivingTempCelsius: number,
    actor: UserProfile
  ): Promise<void> {
    try {
      const transferRef = doc(db, 'transfers', transferId);
      await runTransaction(db, async (transaction) => {
        const snap = await transaction.get(transferRef);
        if (!snap.exists()) throw new Error('طلب التحويل غير موجود');

        const transfer = snap.data() as InternalTransferRequest;

        // 1. إضافة الكميات المقبولة إلى مخزون الفرع الطالب
        for (const item of receivedQuantities) {
          if (item.receivedQty <= 0) continue;

          const branchStockRef = doc(db, `branches/${transfer.targetBranchId}/inventory`, item.productId);
          const branchStockSnap = await transaction.get(branchStockRef);

          if (branchStockSnap.exists()) {
            const current = branchStockSnap.data().currentStock || 0;
            transaction.update(branchStockRef, {
              currentStock: current + item.receivedQty,
              updatedAt: serverTimestamp(),
            });
          } else {
            transaction.set(branchStockRef, {
              productId: item.productId,
              currentStock: item.receivedQty,
              updatedAt: serverTimestamp(),
            });
          }
        }

        // 2. تحديث سجل التحويل
        const updatedItems = transfer.items.map(it => {
          const found = receivedQuantities.find(r => r.productId === it.productId);
          return {
            ...it,
            receivedQty: found ? found.receivedQty : it.dispatchedQty,
            rejectedQty: found ? found.rejectedQty : 0,
            rejectionReason: found?.reason || '',
          };
        });

        transaction.update(transferRef, {
          status: 'RECEIVED',
          items: updatedItems,
          receivingTempCelsius,
          statusHistory: [
            ...transfer.statusHistory,
            {
              actorId: actor.uid,
              actorName: actor.displayName,
              from: transfer.status,
              to: 'RECEIVED',
              note: `تم استلام الشحنة بالفرع بحرارة وصول (${receivingTempCelsius}°م)`,
              ts: new Date().toISOString(),
            },
          ],
          updatedAt: serverTimestamp(),
        });
      });
    } catch (err) {
      console.warn('Firestore receiveTransferAtBranch fallback:', err);
    }

    const local = getLocalTransfers();
    const idx = local.findIndex(t => t.id === transferId);
    if (idx >= 0) {
      const transfer = local[idx];
      const updatedItems = transfer.items.map(it => {
        const found = receivedQuantities.find(r => r.productId === it.productId);
        return {
          ...it,
          receivedQty: found ? found.receivedQty : it.dispatchedQty,
          rejectedQty: found ? found.rejectedQty : 0,
          rejectionReason: found?.reason || '',
        };
      });
      local[idx] = {
        ...transfer,
        status: 'RECEIVED',
        items: updatedItems,
        receivingTempCelsius,
        statusHistory: [
          ...transfer.statusHistory,
          {
            actorId: actor.uid,
            actorName: actor.displayName,
            from: transfer.status,
            to: 'RECEIVED',
            note: `تم استلام الشحنة بالفرع بحرارة وصول (${receivingTempCelsius}°م)`,
            ts: new Date().toISOString(),
          },
        ],
        updatedAt: new Date().toISOString(),
      };
      saveLocalTransfers(local);
    }
  },
};
