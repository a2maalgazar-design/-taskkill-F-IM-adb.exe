import {
  collection,
  doc,
  addDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
  writeBatch,
} from 'firebase/firestore';
import { db } from '../../../lib/firebase';
import { AppNotification, NotificationSeverity, NotificationType } from '../types';

const NOTIFICATIONS_COLLECTION = 'notifications';
const LOCAL_STORAGE_KEY = 'koms_notifications_cache';

function getLocalNotifications(): AppNotification[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Failed to parse local notifications cache:', e);
  }
  return [
    {
      id: 'notif-seed-01',
      recipientId: 'ALL_MANAGERS',
      type: 'LATE_ORDER',
      title: 'طلبية متأخرة عن مهلة الإرسال',
      message: 'الطلبية رقم PO-VEG-9021 تجاوزت المهلة المحددة للإرسال دون تعميد.',
      severity: 'critical',
      orderId: 'order-veg-01',
      orderCode: 'PO-VEG-9021',
      isRead: false,
      createdAt: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
    },
    {
      id: 'notif-seed-02',
      recipientId: 'ALL_MANAGERS',
      type: 'CRITICAL_INVENTORY',
      title: 'تنبيه هبوط مخزون حرج (Safety Stock)',
      message: 'رصيد "لحم بقري بلدي طازج" هبط إلى 14 كجم (الحد الأدنى الآمن: 25 كجم).',
      severity: 'warning',
      productId: 'prod-meat-01',
      productNameAr: 'لحم بقري بلدي طازج',
      isRead: false,
      createdAt: new Date(Date.now() - 120 * 60 * 1000).toISOString(),
    },
  ];
}

function saveLocalNotifications(list: AppNotification[]): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(list));
  } catch (e) {
    console.warn('Failed to save notifications cache:', e);
  }
}

export const NotificationService = {
  /**
   * الاستماع للتنبيهات والإشعارات في الوقت الفعلي عبر Firestore Realtime Listener
   */
  subscribeToAlerts(
    recipientId: string,
    isManager: boolean,
    onAlertsUpdate: (alerts: AppNotification[]) => void,
    onError?: (error: Error) => void
  ): () => void {
    try {
      const colRef = collection(db, NOTIFICATIONS_COLLECTION);
      
      // Managers receive their own alerts + ALL_MANAGERS + ALL_STAFF
      // Assistants receive their own alerts + ALL_STAFF
      const allowedRecipients = isManager
        ? [recipientId, 'ALL_MANAGERS', 'ALL_STAFF', 'user-manager-01']
        : [recipientId, 'ALL_STAFF'];

      const q = query(
        colRef,
        where('recipientId', 'in', allowedRecipients),
        orderBy('createdAt', 'desc')
      );

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const list: AppNotification[] = [];
          snapshot.forEach((d) => {
            const data = d.data();
            list.push({
              id: d.id,
              recipientId: data.recipientId,
              type: data.type,
              title: data.title,
              message: data.message,
              severity: data.severity || 'info',
              orderId: data.orderId,
              orderCode: data.orderCode,
              productId: data.productId,
              productNameAr: data.productNameAr,
              isRead: data.isRead ?? false,
              createdAt: data.createdAt?.toDate
                ? data.createdAt.toDate().toISOString()
                : data.createdAt || new Date().toISOString(),
              metadata: data.metadata,
            });
          });

          // Update local cache as mirror
          saveLocalNotifications(list);
          onAlertsUpdate(list);
        },
        (error) => {
          console.warn('Firestore notifications real-time fallback active:', error);
          // Fallback to local memory / local storage
          const local = getLocalNotifications().filter((n) =>
            allowedRecipients.includes(n.recipientId)
          );
          onAlertsUpdate(local);
          if (onError) onError(error);
        }
      );

      return unsubscribe;
    } catch (err: any) {
      console.warn('Firestore subscribeToAlerts error, using local fallback:', err);
      const local = getLocalNotifications();
      onAlertsUpdate(local);
      return () => {};
    }
  },

  /**
   * إنشاء إشعار جديد في Firestore
   */
  async createNotification(
    notification: Omit<AppNotification, 'id' | 'createdAt' | 'isRead'>
  ): Promise<string> {
    const newDocId = `notif-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const nowIso = new Date().toISOString();

    const notifData: AppNotification = {
      ...notification,
      id: newDocId,
      isRead: false,
      createdAt: nowIso,
    };

    try {
      const docRef = doc(db, NOTIFICATIONS_COLLECTION, newDocId);
      await setDoc(docRef, {
        ...notifData,
        createdAtServer: serverTimestamp(),
      });
    } catch (err) {
      console.warn('Firestore createNotification fallback to local:', err);
    }

    // Always update local cache
    const current = getLocalNotifications();
    const updated = [notifData, ...current.filter((n) => n.id !== newDocId)];
    saveLocalNotifications(updated);

    // Trigger system browser notification if allowed
    this.sendBrowserPushNotification(notifData.title, notifData.message);

    return newDocId;
  },

  /**
   * تمييز إشعار كمقروء
   */
  async markAsRead(notificationId: string): Promise<void> {
    try {
      const docRef = doc(db, NOTIFICATIONS_COLLECTION, notificationId);
      await updateDoc(docRef, { isRead: true });
    } catch (err) {
      console.warn('Firestore markAsRead fallback:', err);
    }

    const current = getLocalNotifications();
    const updated = current.map((n) =>
      n.id === notificationId ? { ...n, isRead: true } : n
    );
    saveLocalNotifications(updated);
  },

  /**
   * تمييز كافة التنبيهات كمقروءة
   */
  async markAllAsRead(recipientId: string, isManager: boolean): Promise<void> {
    const allowedRecipients = isManager
      ? [recipientId, 'ALL_MANAGERS', 'ALL_STAFF', 'user-manager-01']
      : [recipientId, 'ALL_STAFF'];

    try {
      const colRef = collection(db, NOTIFICATIONS_COLLECTION);
      const q = query(
        colRef,
        where('recipientId', 'in', allowedRecipients),
        where('isRead', '==', false)
      );
      const snap = await getDocs(q);
      const batch = writeBatch(db);
      snap.forEach((d) => {
        batch.update(d.ref, { isRead: true });
      });
      await batch.commit();
    } catch (err) {
      console.warn('Firestore markAllAsRead fallback:', err);
    }

    const current = getLocalNotifications();
    const updated = current.map((n) =>
      allowedRecipients.includes(n.recipientId) ? { ...n, isRead: true } : n
    );
    saveLocalNotifications(updated);
  },

  /**
   * حذف إشعار
   */
  async deleteNotification(notificationId: string): Promise<void> {
    try {
      const docRef = doc(db, NOTIFICATIONS_COLLECTION, notificationId);
      await deleteDoc(docRef);
    } catch (err) {
      console.warn('Firestore deleteNotification fallback:', err);
    }

    const current = getLocalNotifications();
    const updated = current.filter((n) => n.id !== notificationId);
    saveLocalNotifications(updated);
  },

  /**
   * فحص وتوليد تنبيهات الطلبيات المتأخرة وهبوط المخزون وتأخر الورديات والخضار آلياً
   */
  async checkAndDispatchOperationalAlerts(
    orders: Array<{
      id: string;
      orderNumber?: string;
      orderTypeId?: string;
      orderDate?: string;
      status: string;
      orderingDeadline: string;
      expectedDeliveryTime?: string;
      primaryAssigneeId?: string;
      fixedArrivalHour?: string;
      receivingChefArrivalTime?: string;
    }>,
    inventory: Array<{
      productId: string;
      productNameAr: string;
      currentStock: number;
      minThreshold: number;
      unit: string;
    }>
  ): Promise<void> {
    const now = Date.now();
    const local = getLocalNotifications();

    // 1. فحص مواعيد إرسال الورديات والطلبيات المتأخرة
    for (const ord of orders) {
      if (['COMPLETED', 'VERIFIED', 'CANCELLED'].includes(ord.status)) continue;

      const deadline = new Date(ord.orderingDeadline).getTime();

      // أ) إنذار مسؤول الوردية ومدير المطبخ عند حلول أو تأخر موعد الطلب
      if (['PLANNED', 'DUE', 'ORDERING'].includes(ord.status)) {
        if (deadline <= now) {
          const diffMinutes = Math.max(1, Math.round((now - deadline) / 60000));
          const categoryLabel = ord.orderTypeId === 'cat-veg' ? 'الخضار اليومية' : 'المشتريات';

          // تنبيه لمسؤول الوردية
          if (ord.primaryAssigneeId) {
            const alreadyAlertedAssignee = local.some(
              (n) => n.orderId === ord.id && n.recipientId === ord.primaryAssigneeId && n.type === 'SHIFT_DEADLINE_ALERT' && !n.isRead
            );
            if (!alreadyAlertedAssignee) {
              await this.createNotification({
                recipientId: ord.primaryAssigneeId,
                type: 'SHIFT_DEADLINE_ALERT',
                title: `⚠️ تنبيه لمسؤول الوردية: حان موعد طلبية ${categoryLabel}`,
                message: `حان موعد إرسال طلبيتك (${ord.orderNumber || ord.id}) وتأخرت عن الموعد المحدد منذ ${diffMinutes} دقيقة. يرجى مراجعة النواقص وإرسال الطلب فوراً.`,
                severity: 'warning',
                orderId: ord.id,
                orderCode: ord.orderNumber || ord.id,
              });
            }
          }

          // تنبيه فوري لمدير المطبخ
          const alreadyAlertedManager = local.some(
            (n) => n.orderId === ord.id && n.recipientId === 'ALL_MANAGERS' && n.type === 'SHIFT_DEADLINE_ALERT' && !n.isRead
          );
          if (!alreadyAlertedManager) {
            await this.createNotification({
              recipientId: 'ALL_MANAGERS',
              type: 'SHIFT_DEADLINE_ALERT',
              title: `🚨 تنبيه لمدير المطبخ: ميعاد طلبية ${categoryLabel} وصل`,
              message: `ميعاد طلبية [${categoryLabel} - ${ord.orderNumber || ord.id}] وصل وتأخر عن الإرسال بمقدار ${diffMinutes} دقيقة، ويجب عليه الطلب الآني فوراً!`,
              severity: 'critical',
              orderId: ord.id,
              orderCode: ord.orderNumber || ord.id,
            });
          }
        }
      }

      // ب) إنذار تأخر وصول طلبية الخضار لأكثر من 24 ساعة عن موعد الوصول الثابت (1:00 م)
      const isVegOrder = ord.orderTypeId === 'cat-veg' || (ord.orderNumber && ord.orderNumber.includes('VEG'));
      if (isVegOrder && !['INVOICE_PENDING', 'VERIFIED', 'COMPLETED'].includes(ord.status)) {
        // موعد الوصول الثابت: الساعة 1:00 مساءً (13:00) من تاريخ الطلب أو اليوم
        const baseDateStr = ord.orderDate || new Date(ord.orderingDeadline).toISOString().split('T')[0];
        const fixedArrivalMs = new Date(`${baseDateStr}T13:00:00`).getTime();
        const hoursDelayedFromFixedArrival = (now - fixedArrivalMs) / (1000 * 3600);

        if (hoursDelayedFromFixedArrival >= 24) {
          const alreadyAlertedVeg24h = local.some(
            (n) => n.orderId === ord.id && n.type === 'VEG_24H_DELAY_ALERT' && !n.isRead
          );

          if (!alreadyAlertedVeg24h) {
            await this.createNotification({
              recipientId: 'ALL_MANAGERS',
              type: 'VEG_24H_DELAY_ALERT',
              title: `🚨 إنذار حرج: تأخر طلبية الخضار 24 ساعة!`,
              message: `تجاوزت طلبية الخضار (${ord.orderNumber || ord.id}) أكثر من 24 ساعة عن موعد الوصول الثابت (الساعة 01:00 مساءً) دون استلام. يجب اتخاذ إجراء فوري مع المورد!`,
              severity: 'critical',
              orderId: ord.id,
              orderCode: ord.orderNumber || ord.id,
            });
          }
        }
      }

      // ج) فحص الطلبيات المتأخرة العامة
      if (deadline < now) {
        const diffMinutes = Math.round((now - deadline) / 60000);
        const alreadyAlerted = local.some(
          (n) => n.orderId === ord.id && n.type === 'LATE_ORDER' && !n.isRead
        );

        if (!alreadyAlerted) {
          await this.createNotification({
            recipientId: ord.primaryAssigneeId || 'ALL_MANAGERS',
            type: 'LATE_ORDER',
            title: `طلبية متأخرة: ${ord.orderNumber || ord.id}`,
            message: `تجاوزت هذه الطلبية مهلة التوريد المحددة منذ ${diffMinutes} دقيقة بحالة [${ord.status}]. يرجى سرعة المتابعة.`,
            severity: diffMinutes > 120 ? 'critical' : 'warning',
            orderId: ord.id,
            orderCode: ord.orderNumber || ord.id,
          });
        }
      }
    }

    // 2. فحص المخزون الحرج
    for (const item of inventory) {
      if (item.currentStock <= item.minThreshold) {
        const isOutOfStock = item.currentStock <= 0;
        const alreadyAlerted = local.some(
          (n) => n.productId === item.productId && n.type === 'CRITICAL_INVENTORY' && !n.isRead
        );

        if (!alreadyAlerted) {
          await this.createNotification({
            recipientId: 'ALL_MANAGERS',
            type: isOutOfStock ? 'STOCK_OUT' : 'CRITICAL_INVENTORY',
            title: isOutOfStock
              ? `نفاد تام للصنف: ${item.productNameAr}`
              : `رصيد حرج للصنف: ${item.productNameAr}`,
            message: isOutOfStock
              ? `الرصيد المتاح 0 ${item.unit}. توقف الصرف فوراً وسد الاحتياج مطلوب.`
              : `الرصيد الحالي (${item.currentStock} ${item.unit}) أقل من حد الأمان الأدنى (${item.minThreshold} ${item.unit}).`,
            severity: isOutOfStock ? 'critical' : 'warning',
            productId: item.productId,
            productNameAr: item.productNameAr,
          });
        }
      }
    }
  },

  /**
   * إرسال إشعار متصفح نظامي
   */
  sendBrowserPushNotification(title: string, body: string): void {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(`KOMS — ${title}`, {
          body,
          icon: '/favicon.ico',
        });
      } catch (e) {
        // Ignore mobile browser restrictions
      }
    }
  },

  async requestPermission(): Promise<boolean> {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      const res = await Notification.requestPermission();
      return res === 'granted';
    }
    return false;
  },
};
