export type NotificationSeverity = 'info' | 'warning' | 'critical';

export type NotificationType =
  | 'LATE_ORDER'
  | 'CRITICAL_INVENTORY'
  | 'STOCK_OUT'
  | 'HACCP_ALERT'
  | 'ASSIGNMENT'
  | 'INVOICE_DISCREPANCY'
  | 'PRICE_SPIKE'
  | 'TRANSFER_RECEIVED'
  | 'SHIFT_DEADLINE_ALERT'
  | 'VEG_24H_DELAY_ALERT'
  | 'REJECTION';

export interface AppNotification {
  id: string;
  recipientId: string; // User UID, 'ALL_MANAGERS', or 'ALL_STAFF'
  type: NotificationType;
  title: string;
  message: string;
  severity: NotificationSeverity;
  orderId?: string;
  orderCode?: string;
  productId?: string;
  productNameAr?: string;
  isRead: boolean;
  createdAt: string;
  metadata?: Record<string, any>;
}

export interface AlertFilterOptions {
  severity?: NotificationSeverity;
  type?: NotificationType;
  onlyUnread?: boolean;
}
