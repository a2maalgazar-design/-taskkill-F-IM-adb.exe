import React from 'react';
import { useNotifications } from '../context/NotificationProvider';
import { AlertCircle, AlertTriangle, Bell, CheckCircle2, Clock, PackageX, X } from 'lucide-react';

export const NotificationToastBanner: React.FC = () => {
  const { activeToast, dismissToast, markAsRead } = useNotifications();

  if (!activeToast) return null;

  const getIcon = () => {
    switch (activeToast.type) {
      case 'LATE_ORDER':
        return <Clock className="w-5 h-5 text-rose-400 shrink-0" />;
      case 'CRITICAL_INVENTORY':
      case 'STOCK_OUT':
        return <PackageX className="w-5 h-5 text-amber-400 shrink-0" />;
      default:
        return activeToast.severity === 'critical' ? (
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
        ) : (
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
        );
    }
  };

  const getBorderBg = () => {
    if (activeToast.severity === 'critical') {
      return 'bg-stone-900 border-rose-500/50 shadow-rose-950/40 text-stone-100';
    }
    return 'bg-stone-900 border-amber-500/50 shadow-amber-950/40 text-stone-100';
  };

  return (
    <div className="fixed top-16 left-4 right-4 sm:left-auto sm:right-6 sm:w-96 z-50 animate-in slide-in-from-top-4 duration-200">
      <div className={`p-4 rounded-2xl border shadow-2xl flex items-start gap-3 backdrop-blur-md ${getBorderBg()}`}>
        <div className="mt-0.5">{getIcon()}</div>
        <div className="flex-1 text-right text-xs">
          <div className="flex items-center justify-between mb-1">
            <span className="font-bold text-sm text-stone-100">{activeToast.title}</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
              تنبيه فوري
            </span>
          </div>
          <p className="text-stone-300 text-xs leading-relaxed">{activeToast.message}</p>
          <div className="flex items-center gap-2 mt-2.5 pt-2 border-t border-stone-800">
            <button
              onClick={() => markAsRead(activeToast.id)}
              className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-lg font-bold text-[11px] transition"
            >
              تمت المتابعة (قراءة)
            </button>
            <button
              onClick={dismissToast}
              className="text-stone-400 hover:text-stone-200 text-[11px] px-2 py-1"
            >
              إخفاء مؤقت
            </button>
          </div>
        </div>
        <button
          onClick={dismissToast}
          className="text-stone-400 hover:text-white p-1 rounded-lg hover:bg-stone-800 transition"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
