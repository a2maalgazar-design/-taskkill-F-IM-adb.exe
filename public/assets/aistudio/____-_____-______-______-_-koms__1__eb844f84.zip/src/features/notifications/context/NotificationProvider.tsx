import React, { createContext, useContext, useEffect, useState, useMemo, useCallback } from 'react';
import { NotificationService } from '../services/NotificationService';
import { AppNotification } from '../types';
import { useAuth } from '../../../context/AuthContext';
import { useData } from '../../../context/DataContext';

interface NotificationContextType {
  notifications: AppNotification[];
  unreadCount: number;
  criticalAlerts: AppNotification[];
  lateOrdersCount: number;
  lowStockCount: number;
  activeToast: AppNotification | null;
  loading: boolean;
  markAsRead: (id: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;
  sendNotification: (notif: Omit<AppNotification, 'id' | 'createdAt' | 'isRead'>) => Promise<string>;
  requestBrowserPermission: () => Promise<boolean>;
  dismissToast: () => void;
}

const NotificationContext = createContext<NotificationContextType>({
  notifications: [],
  unreadCount: 0,
  criticalAlerts: [],
  lateOrdersCount: 0,
  lowStockCount: 0,
  activeToast: null,
  loading: true,
  markAsRead: async () => {},
  markAllAsRead: async () => {},
  deleteNotification: async () => {},
  sendNotification: async () => '',
  requestBrowserPermission: async () => false,
  dismissToast: () => {},
});

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, isManager } = useAuth();
  const { orders, products } = useData();

  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [activeToast, setActiveToast] = useState<AppNotification | null>(null);
  const [loading, setLoading] = useState(true);

  // Subscribe to real-time Firestore alerts
  useEffect(() => {
    if (!currentUser?.id) return;

    setLoading(true);
    const unsubscribe = NotificationService.subscribeToAlerts(
      currentUser.id,
      isManager,
      (updatedList) => {
        setNotifications(updatedList);
        setLoading(false);

        // If a new critical alert arrived, show toast banner
        const latestUnreadCritical = updatedList.find(
          (n) => !n.isRead && n.severity === 'critical'
        );
        if (latestUnreadCritical) {
          setActiveToast(latestUnreadCritical);
        }
      },
      (err) => {
        setLoading(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [currentUser?.id, isManager]);

  // Periodic automatic operational scanning for late orders and critical inventory
  useEffect(() => {
    if (!orders.length) return;

    const runChecks = async () => {
      const orderInputs = orders.map((o) => ({
        id: o.id,
        orderNumber: o.orderNumber || o.id,
        orderTypeId: o.orderTypeId,
        orderDate: o.orderDate,
        status: o.status,
        orderingDeadline: o.orderingDeadline,
        expectedDeliveryTime: o.expectedDeliveryTime,
        primaryAssigneeId: o.primaryAssigneeId,
        fixedArrivalHour: o.fixedArrivalHour || '13:00',
        receivingChefArrivalTime: o.receivingChefArrivalTime,
      }));

      // Approximate inventory from products
      const inventoryInputs = products.map((p) => ({
        productId: p.id,
        productNameAr: p.nameAr || p.name || 'صنف',
        currentStock: p.minStockAlert ? Math.max(0, p.minStockAlert - 5) : 10,
        minThreshold: p.minStockAlert || 15,
        unit: p.defaultUnit || p.unit || 'كجم',
      }));

      await NotificationService.checkAndDispatchOperationalAlerts(orderInputs, inventoryInputs);
    };

    runChecks();
    const interval = setInterval(runChecks, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [orders, products]);

  const unreadCount = useMemo(() => notifications.filter((n) => !n.isRead).length, [notifications]);

  const criticalAlerts = useMemo(
    () => notifications.filter((n) => !n.isRead && n.severity === 'critical'),
    [notifications]
  );

  const lateOrdersCount = useMemo(
    () => notifications.filter((n) => !n.isRead && n.type === 'LATE_ORDER').length,
    [notifications]
  );

  const lowStockCount = useMemo(
    () =>
      notifications.filter(
        (n) => !n.isRead && (n.type === 'CRITICAL_INVENTORY' || n.type === 'STOCK_OUT')
      ).length,
    [notifications]
  );

  const markAsRead = useCallback(async (id: string) => {
    await NotificationService.markAsRead(id);
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
    setActiveToast((prev) => (prev?.id === id ? null : prev));
  }, []);

  const markAllAsRead = useCallback(async () => {
    if (!currentUser?.id) return;
    await NotificationService.markAllAsRead(currentUser.id, isManager);
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    setActiveToast(null);
  }, [currentUser?.id, isManager]);

  const deleteNotification = useCallback(async (id: string) => {
    await NotificationService.deleteNotification(id);
    setNotifications((prev) => prev.filter((n) => n.id !== id));
    setActiveToast((prev) => (prev?.id === id ? null : prev));
  }, []);

  const sendNotification = useCallback(
    async (notif: Omit<AppNotification, 'id' | 'createdAt' | 'isRead'>) => {
      return await NotificationService.createNotification(notif);
    },
    []
  );

  const requestBrowserPermission = useCallback(async () => {
    return await NotificationService.requestPermission();
  }, []);

  const dismissToast = useCallback(() => {
    setActiveToast(null);
  }, []);

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        criticalAlerts,
        lateOrdersCount,
        lowStockCount,
        activeToast,
        loading,
        markAsRead,
        markAllAsRead,
        deleteNotification,
        sendNotification,
        requestBrowserPermission,
        dismissToast,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => useContext(NotificationContext);
