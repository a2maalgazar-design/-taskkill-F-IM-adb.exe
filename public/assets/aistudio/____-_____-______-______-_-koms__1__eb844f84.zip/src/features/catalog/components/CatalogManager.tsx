export * from '../../../components/categories/CatalogManager';
export { default } from '../../../components/categories/CatalogManager';
