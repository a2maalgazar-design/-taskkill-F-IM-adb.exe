import { OrderStatus } from '@/features/orders/types';

export interface DashboardKPIs {
  totalActiveOrders: number;
  pendingReceivingCount: number;
  overdueOrdersCount: number;
  totalCompletedOrders: number;
  totalSpendEGP: number;
  fulfillmentRatePct: number; // نسبة استيفاء الأصناف المستلمة مقارنة بالمطلوبة
}

export interface AuditLogEntry {
  id: string;
  action: string;
  entityType: 'ORDER' | 'RECEIVING' | 'INVOICE' | 'USER' | 'SCHEDULE';
  entityId: string;
  entityCode?: string;
  actorId: string;
  actorName: string;
  actorRole: string;
  details: string;
  metadata?: Record<string, any>;
  timestamp: string;
}

export type NotificationType = 'INFO' | 'WARNING' | 'ALERT' | 'SUCCESS';

export interface InAppNotification {
  id: string;
  recipientId: string; // 'ALL_MANAGERS' أو UID مستخدم محدد
  title: string;
  message: string;
  type: NotificationType;
  relatedOrderId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface ArchiveFilterOptions {
  searchQuery: string;
  startDate?: string;
  endDate?: string;
  orderTypeId?: string;
  supplierId?: string;
  status?: 'COMPLETED' | 'CANCELLED' | 'ALL_ARCHIVED';
}
