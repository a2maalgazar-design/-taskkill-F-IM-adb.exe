import { 
  collection, 
  doc, 
  getDocs, 
  addDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  updateDoc, 
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Order } from '@/features/orders/types';
import { InvoiceRecord } from '@/types';
import { DashboardKPIs, AuditLogEntry, InAppNotification, ArchiveFilterOptions } from './types';

export const reportingService = {
  /**
   * حساب مؤشرات الأداء الفعلية بناءً على البيانات المخزنة حصرًا
   * تخضع لمعايير رياضية صارمة دون افتراضات عشوائية
   */
  computeDashboardKPIs(orders: Order[], invoices: InvoiceRecord[]): DashboardKPIs {
    const todayStr = new Date().toISOString().split('T')[0];

    let totalActiveOrders = 0;
    let pendingReceivingCount = 0;
    let overdueOrdersCount = 0;
    let totalCompletedOrders = 0;
    let totalSpendEGP = 0;
    let totalOrderedQty = 0;
    let totalReceivedQty = 0;

    for (const order of orders) {
      const isArchivedOrCompleted = order.isArchived || order.status === 'COMPLETED' || order.status === 'CANCELLED';

      if (!isArchivedOrCompleted) {
        totalActiveOrders++;

        if (order.status === 'AWAITING_DELIVERY' || order.status === 'RECEIVING' || order.status === 'ORDERED') {
          pendingReceivingCount++;
        }

        const dueDate = order.targetDate || order.occurrenceDate;
        if (dueDate && dueDate < todayStr) {
          overdueOrdersCount++;
        }
      }

      if (order.status === 'COMPLETED') {
        totalCompletedOrders++;
      }

      if (order.items && Array.isArray(order.items)) {
        for (const item of order.items) {
          const req = item.requestedQty ?? item.quantity ?? item.ordered ?? 0;
          const rec = item.receivedQty ?? item.received ?? (order.status === 'COMPLETED' ? req : 0);
          totalOrderedQty += req;
          totalReceivedQty += rec;
        }
      }
    }

    // حساب الإنفاق الإجمالي من الفواتير المعتمدة أو المسجلة
    for (const inv of invoices) {
      if (inv.verificationStatus !== 'DISCREPANCY') {
        totalSpendEGP += Number(inv.invoiceTotal || 0);
      }
    }

    const fulfillmentRatePct = totalOrderedQty > 0 
      ? Math.round((Math.min(totalReceivedQty, totalOrderedQty) / totalOrderedQty) * 100)
      : 100;

    return {
      totalActiveOrders,
      pendingReceivingCount,
      overdueOrdersCount,
      totalCompletedOrders,
      totalSpendEGP,
      fulfillmentRatePct,
    };
  },

  /**
   * تصفية وفلترة الأرشيف التاريخي للطلبات
   */
  filterArchivedOrders(orders: Order[], filters: ArchiveFilterOptions): Order[] {
    return orders.filter((order) => {
      const isArchived = order.isArchived || order.status === 'COMPLETED' || order.status === 'CANCELLED';
      if (!isArchived) return false;

      if (filters.status && filters.status !== 'ALL_ARCHIVED') {
        if (order.status !== filters.status) return false;
      }

      if (filters.orderTypeId && order.orderTypeId !== filters.orderTypeId) {
        return false;
      }

      if (filters.supplierId && order.supplierId !== filters.supplierId) {
        return false;
      }

      const orderDate = order.targetDate || order.occurrenceDate || '';
      if (filters.startDate && orderDate < filters.startDate) {
        return false;
      }
      if (filters.endDate && orderDate > filters.endDate) {
        return false;
      }

      if (filters.searchQuery.trim()) {
        const queryLower = filters.searchQuery.toLowerCase();
        const codeMatch = (order.orderCode || order.code || order.id)?.toLowerCase().includes(queryLower);
        const nameMatch = order.orderTypeNameAr?.toLowerCase().includes(queryLower);
        const supplierMatch = (order.supplierName || order.supplierNameAr)?.toLowerCase().includes(queryLower);
        if (!codeMatch && !nameMatch && !supplierMatch) {
          return false;
        }
      }

      return true;
    });
  },

  /**
   * تسجيل حركة في سجل الرقابة والتدقيق (Audit Log)
   */
  async logAuditEvent(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>): Promise<string> {
    try {
      const docRef = await addDoc(collection(db, 'auditLogs'), {
        ...entry,
        timestamp: new Date().toISOString(),
        createdAt: serverTimestamp(),
      });
      return docRef.id;
    } catch (error) {
      console.warn('Could not write audit log to Firestore:', error);
      return `local-${Date.now()}`;
    }
  },

  /**
   * إرسال تنبيه داخلي لمديري النظام أو مستخدم محدد
   */
  async sendInAppNotification(notification: Omit<InAppNotification, 'id' | 'createdAt' | 'isRead'>): Promise<string> {
    try {
      const docRef = await addDoc(collection(db, 'notifications'), {
        ...notification,
        isRead: false,
        createdAt: new Date().toISOString(),
      });
      return docRef.id;
    } catch (error) {
      console.warn('Could not save notification to Firestore:', error);
      return `local-${Date.now()}`;
    }
  },
};
