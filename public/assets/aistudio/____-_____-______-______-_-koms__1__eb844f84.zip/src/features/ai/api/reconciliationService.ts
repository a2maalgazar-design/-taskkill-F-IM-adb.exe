import { Order, OrderItem } from '@/features/orders/types';
import { 
  ExtractedInvoiceData, 
  InvoiceReconciliationReport, 
  ItemReconciliationResult, 
  MatchStatus 
} from '../types';

export const reconciliationService = {
  /**
   * مطابقة الأصناف المكتشفة بالذكاء الاصطناعي مع بنود الطلب الفعلي
   */
  reconcile(order: Order, extracted: ExtractedInvoiceData): InvoiceReconciliationReport {
    const comparisonResults: ItemReconciliationResult[] = [];

    // فحص بنود الطلب ومقارنتها بالمستخرج من الفاتورة
    (order.items || []).forEach((orderItem: OrderItem) => {
      // البحث عن أقرب تطابق في البنود المستخرجة
      const matched = (extracted.items || []).find((ext) => {
        const nameA = (ext.rawName || '').toLowerCase().trim();
        const nameB = (orderItem.productNameAr || '').toLowerCase().trim();
        return nameA.includes(nameB) || nameB.includes(nameA);
      });

      if (!matched) {
        comparisonResults.push({
          productId: orderItem.productId,
          productNameAr: orderItem.productNameAr,
          orderedQty: orderItem.ordered,
          receivedQty: orderItem.received,
          invoicedQty: 0,
          unit: orderItem.unit,
          status: 'MISSING_IN_INVOICE',
          discrepancyQty: orderItem.ordered,
        });
      } else {
        const discrepancy = matched.quantity - orderItem.ordered;
        let status: MatchStatus = 'EXACT_MATCH';

        if (discrepancy !== 0) {
          status = 'QTY_MISMATCH';
        }

        comparisonResults.push({
          productId: orderItem.productId,
          productNameAr: orderItem.productNameAr,
          orderedQty: orderItem.ordered,
          receivedQty: orderItem.received,
          invoicedQty: matched.quantity,
          unit: orderItem.unit,
          status,
          discrepancyQty: discrepancy,
        });
      }
    });

    // حصر البنود الإضافية المفوترة غير الموجودة في أمر الشراء الأساسي
    (extracted.items || []).forEach((extItem) => {
      const existsInOrder = (order.items || []).some((it: OrderItem) => {
        const nameA = (extItem.rawName || '').toLowerCase().trim();
        const nameB = (it.productNameAr || '').toLowerCase().trim();
        return nameA.includes(nameB) || nameB.includes(nameA);
      });

      if (!existsInOrder) {
        comparisonResults.push({
          productNameAr: extItem.rawName,
          orderedQty: 0,
          receivedQty: 0,
          invoicedQty: extItem.quantity,
          unit: extItem.unit,
          status: 'UNEXPECTED_ITEM',
          discrepancyQty: extItem.quantity,
        });
      }
    });

    const hasDiscrepancies = comparisonResults.some((r) => r.status !== 'EXACT_MATCH');

    return {
      orderId: order.id,
      orderCode: order.orderCode,
      extractedInvoiceNumber: extracted.invoiceNumber || '',
      extractedTotalEGP: extracted.totalAmountEGP || 0,
      itemsComparison: comparisonResults,
      hasDiscrepancies,
    };
  },
};
