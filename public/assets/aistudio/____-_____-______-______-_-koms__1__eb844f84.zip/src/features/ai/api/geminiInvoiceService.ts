import { GoogleGenAI, Type, Schema } from '@google/genai';
import { ExtractedInvoiceData } from '../types';

// تهيئة العميل بمفتاح واجهة برمجة التطبيقات المخزن بأمان في لوحة الأسرار
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

const invoiceExtractionSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    invoiceNumber: { type: Type.STRING, description: 'رقم الفاتورة المطبوع أو المكتوب' },
    invoiceDate: { type: Type.STRING, description: 'تاريخ الفاتورة بصيغة YYYY-MM-DD' },
    supplierNameRaw: { type: Type.STRING, description: 'اسم المورد أو الشركة المطبوع' },
    totalAmountEGP: { type: Type.NUMBER, description: 'القيمة المالية الإجمالية للفاتورة' },
    items: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          rawName: { type: Type.STRING, description: 'اسم الصنف كما هو مدون في الفاتورة' },
          quantity: { type: Type.NUMBER, description: 'الكمية المستلمة أو المفوترة' },
          unit: { type: Type.STRING, description: 'وحدة القياس (كجم، كرتونة، لتر، إلخ)' },
          unitPriceEGP: { type: Type.NUMBER, description: 'سعر الوحدة إن وجد' },
          totalPriceEGP: { type: Type.NUMBER, description: 'إجمالي سعر البند' },
          confidence: { type: Type.NUMBER, description: 'درجة التيقن من قراءة الخط من 0.0 إلى 1.0' },
        },
        required: ['rawName', 'quantity'],
      },
    },
    rawNotes: { type: Type.STRING, description: 'أي ملاحظات أو أختام مدونة بخط اليد' },
  },
  required: ['items'],
};

export async function processInvoiceImageBuffer(
  imageBase64: string,
  mimeType: string,
  expectedItemsContext: { id?: string; nameAr: string }[]
): Promise<ExtractedInvoiceData> {
  const prompt = `
أنت خبير تدقيق محاسبي واستلام بضائع لمطابخ تجارية.
قم بفحص صورة فاتورة التوريد أو إذن الاستلام المرفقة واستخرج البيانات بدقة متناهية.

قائمة الأصناف المعتمدة المتوقعة في أمر الشراء الحالي لمساعدتك في الربط وتصحيح الأخطاء الإملائية:
${JSON.stringify(expectedItemsContext, null, 2)}

شروط الاستخراج:
1. استخرج أسماء الأصناف والكميات الصافية بدقة.
2. إذا كان الخط يدوياً أو غير واضح، سجل درجة الثقة المقدرة (confidence).
3. استخرج القيمة الإجمالية ورقم الفاتورة وتاريخها.
4. الإخراج يجب أن يلتزم حرفياً بمخطط JSON المحدد دون أي نصوص تمهيدية.
`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: [
      {
        role: 'user',
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType,
              data: imageBase64,
            },
          },
        ],
      },
    ],
    config: {
      responseMimeType: 'application/json',
      responseSchema: invoiceExtractionSchema,
      temperature: 0.1, // أقصى درجات الدقة والصرامة الرياضية
    },
  });

  const rawJson = typeof (response as any).text === 'function' ? (response as any).text() : response.text;
  if (!rawJson) {
    throw new Error('لم يتمكن النموذج من استخراج أي بيانات مقروءة من الصورة');
  }

  return JSON.parse(rawJson) as ExtractedInvoiceData;
}
