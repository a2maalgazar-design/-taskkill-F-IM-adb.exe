import React, { useState, useRef } from 'react';
import { Order, OrderItem } from '@/features/orders/types';
import { ExtractedInvoiceData, InvoiceReconciliationReport } from '../types';
import { reconciliationService } from '../api/reconciliationService';
import { Camera, Upload, AlertCircle, CheckCircle, RefreshCw, X, Sparkles } from 'lucide-react';

interface InvoiceCameraScannerModalProps {
  order: Order;
  onClose: () => void;
  onApplyVerifiedData: (data: { invoiceNumber: string; totalAmountEGP: number; notes: string }) => void;
}

export const InvoiceCameraScannerModal: React.FC<InvoiceCameraScannerModalProps> = ({
  order,
  onClose,
  onApplyVerifiedData,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [report, setReport] = useState<InvoiceReconciliationReport | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleCaptureImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMessage(null);
    setPreviewUrl(URL.createObjectURL(file));
    setAnalyzing(true);
    setReport(null);

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = async () => {
      try {
        const resultStr = reader.result as string;
        const base64Content = resultStr.includes(',') ? resultStr.split(',')[1] : resultStr;

        // استدعاء خادم المعالجة البصرية
        const res = await fetch('/api/ocr/invoice', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64Content,
            mimeType: file.type || 'image/jpeg',
            expectedItems: (order.items || []).map((it: OrderItem) => ({
              id: it.productId,
              nameAr: it.productNameAr,
            })),
          }),
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || errData.message || 'تعذر معالجة الفاتورة عبر الذكاء الاصطناعي');
        }

        const extractedData: ExtractedInvoiceData = await res.json();
        const reconReport = reconciliationService.reconcile(order, extractedData);
        setReport(reconReport);
      } catch (err: any) {
        setErrorMessage(err.message || 'حدث خطأ أثناء المسح البصري للفاتورة');
      } finally {
        setAnalyzing(false);
      }
    };

    reader.onerror = () => {
      setErrorMessage('فشل في قراءة ملف الصورة');
      setAnalyzing(false);
    };
  };

  const handleAcceptReconciliation = () => {
    if (!report) return;
    const discrepancyNotes = report.itemsComparison
      .filter((i) => i.status !== 'EXACT_MATCH')
      .map((i) => `${i.productNameAr}: مطلوب ${i.orderedQty} / بالفاتورة ${i.invoicedQty}`)
      .join(' | ');

    onApplyVerifiedData({
      invoiceNumber: report.extractedInvoiceNumber,
      totalAmountEGP: report.extractedTotalEGP,
      notes: discrepancyNotes ? `فوارق المسح الذكي: ${discrepancyNotes}` : 'تمت المطابقة البصرية بنجاح وبدون فوارق',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-stone-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-stone-900 border border-stone-800 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden text-stone-100">
        {/* رأس النافذة */}
        <div className="p-4 bg-stone-950 border-b border-stone-800 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-100">الفحص والمطابقة البصرية للفاتورة (Gemini AI)</h3>
              <span className="text-[11px] text-stone-400">الطلب المستهدف: <span className="font-mono text-amber-400">{order.orderCode}</span></span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-4 text-xs">
          {errorMessage && (
            <div className="p-3 bg-rose-950/50 border border-rose-800/80 text-rose-300 rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* زر التقاط الصورة بواسطة الكاميرا أو رفع ملف */}
          <div className="flex flex-col items-center justify-center border-2 border-dashed border-stone-700/80 rounded-2xl p-6 bg-stone-950/40 hover:bg-stone-950/60 transition">
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              capture="environment"
              onChange={handleCaptureImage}
              className="hidden"
            />
            {previewUrl ? (
              <div className="space-y-3 text-center w-full">
                <img
                  src={previewUrl}
                  alt="صورة الفاتورة"
                  className="max-h-48 rounded-xl shadow-md border border-stone-800 mx-auto object-contain bg-stone-950"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={analyzing}
                  className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 rounded-lg text-xs font-medium inline-flex items-center gap-1.5 transition"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  إعادة التقاط أو اختيار صورة أخرى
                </button>
              </div>
            ) : (
              <div className="text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
                  <Camera className="w-6 h-6" />
                </div>
                <div>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-xl font-bold shadow-lg shadow-amber-500/20 transition inline-flex items-center gap-2"
                  >
                    <Camera className="w-4 h-4" />
                    فتح الكاميرا لتصوير الفاتورة / رفع صورة
                  </button>
                </div>
                <p className="text-[11px] text-stone-400">
                  يدعم الفواتير الورقية المطبوعة أو المكتوبة بخط اليد مع تصحيح ذكي
                </p>
              </div>
            )}
          </div>

          {analyzing && (
            <div className="p-4 bg-sky-950/40 border border-sky-800/60 text-sky-200 rounded-xl text-center space-y-1.5 animate-pulse">
              <div className="flex items-center justify-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin text-sky-400" />
                <p className="font-bold">جاري تحليل بنود الفاتورة بالذكاء الاصطناعي (Gemini 2.5 Flash)...</p>
              </div>
              <p className="text-[11px] text-sky-400">
                يتم قراءة النصوص والأرقام ومطابقتها آلياً مع أصناف أمر الشراء
              </p>
            </div>
          )}

          {/* تقرير المطابقة الآلي */}
          {report && (
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-3 gap-2 bg-stone-950/80 p-3 rounded-xl border border-stone-800">
                <div>
                  <span className="text-stone-400 block text-[10px]">رقم الفاتورة المستخرج:</span>
                  <span className="font-mono font-bold text-amber-400">
                    {report.extractedInvoiceNumber || 'غير محدد'}
                  </span>
                </div>
                <div>
                  <span className="text-stone-400 block text-[10px]">إجمالي القيمة:</span>
                  <span className="font-mono font-bold text-emerald-400">
                    {report.extractedTotalEGP.toLocaleString('ar-EG')} ج.م
                  </span>
                </div>
                <div>
                  <span className="text-stone-400 block text-[10px]">حالة المطابقة:</span>
                  <span
                    className={`font-bold inline-flex items-center gap-1 ${
                      report.hasDiscrepancies ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {report.hasDiscrepancies ? (
                      <>
                        <AlertCircle className="w-3.5 h-3.5" />
                        يوجد فوارق كميات
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-3.5 h-3.5" />
                        مطابقة تامة
                      </>
                    )}
                  </span>
                </div>
              </div>

              {/* جدول الفوارق */}
              <div className="border border-stone-800 rounded-xl overflow-hidden bg-stone-950/40">
                <table className="w-full text-right text-xs">
                  <thead className="bg-stone-950 border-b border-stone-800 text-stone-400">
                    <tr>
                      <th className="p-2.5">الصنف</th>
                      <th className="p-2.5">المطلوب</th>
                      <th className="p-2.5">المفوتر</th>
                      <th className="p-2.5">الفارق</th>
                      <th className="p-2.5">التقييم</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-800/60">
                    {report.itemsComparison.map((row, idx) => (
                      <tr
                        key={idx}
                        className={row.status !== 'EXACT_MATCH' ? 'bg-amber-950/20' : 'hover:bg-stone-900/40'}
                      >
                        <td className="p-2.5 font-medium text-stone-200">
                          {row.productNameAr}
                          <span className="text-[10px] text-stone-500 mr-1">({row.unit})</span>
                        </td>
                        <td className="p-2.5 text-stone-400 font-mono">{row.orderedQty}</td>
                        <td className="p-2.5 font-bold text-stone-100 font-mono">{row.invoicedQty}</td>
                        <td
                          className={`p-2.5 font-mono font-bold ${
                            row.discrepancyQty !== 0 ? 'text-rose-400' : 'text-stone-500'
                          }`}
                        >
                          {row.discrepancyQty > 0 ? `+${row.discrepancyQty}` : row.discrepancyQty}
                        </td>
                        <td className="p-2.5">
                          {row.status === 'EXACT_MATCH' && (
                            <span className="text-[10px] text-emerald-400 bg-emerald-950/80 border border-emerald-800 px-1.5 py-0.5 rounded font-semibold">
                              مطابق
                            </span>
                          )}
                          {row.status === 'QTY_MISMATCH' && (
                            <span className="text-[10px] text-rose-300 bg-rose-950/80 border border-rose-800 px-1.5 py-0.5 rounded font-semibold">
                              فارق بالكمية
                            </span>
                          )}
                          {row.status === 'UNEXPECTED_ITEM' && (
                            <span className="text-[10px] text-purple-300 bg-purple-950/80 border border-purple-800 px-1.5 py-0.5 rounded font-semibold">
                              بند غير مطلوب
                            </span>
                          )}
                          {row.status === 'MISSING_IN_INVOICE' && (
                            <span className="text-[10px] text-amber-300 bg-amber-950/80 border border-amber-800 px-1.5 py-0.5 rounded font-semibold">
                              لم يدرج بالفاتورة
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={handleAcceptReconciliation}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-stone-950 font-bold rounded-xl transition text-xs shadow-md shadow-emerald-900/30 flex items-center justify-center gap-1.5"
                >
                  <CheckCircle className="w-4 h-4" />
                  اعتماد البيانات المستخرجة وترحيلها لنموذج الفاتورة
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="py-2.5 px-4 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-xl font-semibold transition"
                >
                  إلغاء
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
