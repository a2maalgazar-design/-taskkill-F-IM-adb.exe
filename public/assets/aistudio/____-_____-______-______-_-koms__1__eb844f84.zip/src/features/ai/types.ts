export interface ExtractedInvoiceItem {
  rawName: string;
  matchedProductId?: string;
  matchedProductNameAr?: string;
  quantity: number;
  unit: string;
  unitPriceEGP?: number;
  totalPriceEGP?: number;
  confidence: number; // مقياس الثقة من 0 إلى 1
}

export interface ExtractedInvoiceData {
  invoiceNumber?: string;
  invoiceDate?: string;
  supplierNameRaw?: string;
  totalAmountEGP?: number;
  items: ExtractedInvoiceItem[];
  rawNotes?: string;
}

export type MatchStatus = 'EXACT_MATCH' | 'QTY_MISMATCH' | 'UNEXPECTED_ITEM' | 'MISSING_IN_INVOICE';

export interface ItemReconciliationResult {
  productId?: string;
  productNameAr: string;
  orderedQty: number;
  receivedQty: number;
  invoicedQty: number;
  unit: string;
  status: MatchStatus;
  discrepancyQty: number; // الفرق الحسابي
}

export interface InvoiceReconciliationReport {
  orderId: string;
  orderCode: string;
  extractedInvoiceNumber: string;
  extractedTotalEGP: number;
  systemExpectedTotalEGP?: number;
  itemsComparison: ItemReconciliationResult[];
  hasDiscrepancies: boolean;
}
