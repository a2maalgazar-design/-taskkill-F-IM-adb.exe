export type RFQStatus = 'DRAFT' | 'OPEN' | 'EVALUATION' | 'AWARDED' | 'EXPIRED' | 'CANCELLED';

export interface RFQItem {
  productId: string;
  productNameAr: string;
  unit: string;
  estimatedQuantity: number;
  benchmarkTargetPriceEGP?: number; // السعر التقديري المستهدف
}

export interface RFQBidItemQuote {
  productId: string;
  productNameAr: string;
  unitPriceEGP: number;
  minOrderQuantity: number;
  isAvailable: boolean;
  notes?: string;
}

export interface SupplierBidSubmission {
  id: string;
  rfqId: string;
  rfqCode: string;
  supplierId: string;
  supplierNameAr: string;
  supplierPhone: string;
  accessToken: string; // رمز سري فريد لدخول المورد دون كلمة مرور
  itemQuotes: RFQBidItemQuote[];
  totalBidAmountEGP: number;
  paymentTermsOffered: 'COD' | 'NET_15' | 'NET_30';
  bidValidUntil: string; // YYYY-MM-DD
  status: 'INVITED' | 'SUBMITTED' | 'AWARDED' | 'DECLINED';
  submittedAt?: string;
  notes?: string;
}

export interface RFQBidEvaluationScore {
  supplierId: string;
  supplierNameAr: string;
  bidId: string;
  totalBidAmountEGP: number;
  priceScore: number; // درجة السعر من 100
  qualityScore: number; // درجة الجودة المشتقة من بطاقة المورد من 100
  termsScore: number; // درجة شروط السداد (COD = 70, Net 15 = 85, Net 30 = 100)
  compositeWeightedScore: number; // الدرجة الموزونة الإجمالية (مثال: 50% سعر + 35% جودة + 15% شروط)
  isRecommended: boolean;
  savingsVsBenchmarkEGP: number;
}

export interface RequestForQuotation {
  id: string;
  rfqCode: string; // KOMS-RFQ-YYYY-XXXX
  titleAr: string;
  orderTypeId: string;
  orderTypeNameAr: string;
  status: RFQStatus;
  items: RFQItem[];
  invitedSupplierIds: string[];
  submissionDeadline: string; // YYYY-MM-DD
  bids: SupplierBidSubmission[];
  awardedSupplierId?: string;
  awardedSupplierNameAr?: string;
  awardedBidId?: string;
  awardedOrderId?: string;
  awardedAt?: string;
  notes?: string;
  createdById: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
}
