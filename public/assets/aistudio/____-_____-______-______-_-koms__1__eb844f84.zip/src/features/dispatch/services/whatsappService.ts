import { PurchaseOrderPayload } from '../types';
import { formatKitchenWhatsAppMessage, sanitizeEgyptianPhone } from '../../../utils/whatsappFormatter';

export const whatsappService = {
  /**
   * صياغة نص رسالة أمر الشراء بتنسيق موحد ومبسط لمطبخ نانا الشيخ زايد
   */
  buildOrderMessage(payload: PurchaseOrderPayload): string {
    return formatKitchenWhatsAppMessage({
      orderCode: payload.orderCode,
      requesterName: 'فريق مطبخ نانا الشيخ زايد',
      items: payload.items.map((it) => ({
        name: it.productNameAr,
        qty: it.quantity,
        unit: it.unit,
      })),
    });
  },

  /**
   * تنظيف وتجهيز رقم الهاتف المصري للربط مع واجهة WhatsApp Click-to-Chat
   * تحويل الصيغ المحلية (010, 011, 012, 015) إلى الصيغة الدولية (+20)
   */
  sanitizeEgyptianPhoneNumber(phone: string): string {
    const digitsOnly = phone.replace(/\D/g, '');
    if (digitsOnly.startsWith('01') && digitsOnly.length === 11) {
      return `20${digitsOnly.substring(1)}`;
    }
    if (digitsOnly.startsWith('201') && digitsOnly.length === 12) {
      return digitsOnly;
    }
    if (digitsOnly.length === 10 && digitsOnly.startsWith('1')) {
      return `20${digitsOnly}`;
    }
    return digitsOnly;
  },

  /**
   * إنشاء رابط WhatsApp Click-to-Chat
   */
  generateWhatsAppUrl(payload: PurchaseOrderPayload): string {
    const phone = this.sanitizeEgyptianPhoneNumber(payload.supplierPhone);
    const message = encodeURIComponent(this.buildOrderMessage(payload));
    return `https://wa.me/${phone}?text=${message}`;
  },

  /**
   * إرسال الأمر مباشرة للمورد عبر واتساب
   */
  openWhatsAppChat(payload: PurchaseOrderPayload): void {
    const url = this.generateWhatsAppUrl(payload);
    window.open(url, '_blank', 'noopener,noreferrer');
  },
};
