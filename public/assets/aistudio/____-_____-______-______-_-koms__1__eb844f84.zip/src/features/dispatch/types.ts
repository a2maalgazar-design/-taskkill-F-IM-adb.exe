export interface PurchaseOrderPayload {
  orderId: string;
  orderCode: string;
  orderTypeNameAr: string;
  supplierNameAr: string;
  supplierPhone: string;
  targetDate: string;
  notes?: string;
  items: {
    productNameAr: string;
    unit: string;
    quantity: number;
  }[];
}

export interface DispatchLog {
  id: string;
  orderId: string;
  channel: 'WHATSAPP' | 'PDF_DOWNLOAD' | 'GOOGLE_SHEETS_SYNC';
  recipient: string;
  status: 'SENT' | 'FAILED' | 'PENDING';
  actorId: string;
  actorName: string;
  sentAt: string;
}

export interface GoogleSheetsSyncConfig {
  spreadsheetId: string;
  sheetName: string;
  lastSyncedAt?: string;
}
