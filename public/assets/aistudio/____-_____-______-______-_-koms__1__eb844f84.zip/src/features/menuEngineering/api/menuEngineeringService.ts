import { Recipe } from '@/features/recipes/types';
import { InventoryItem } from '@/features/inventory/types';
import { 
  MenuItemProfitability, 
  MenuEngineeringReport, 
  MenuClassification, 
  DishForecastSummary, 
  ExplodedIngredientDemand 
} from '../types';

export const menuEngineeringService = {
  /**
   * حساب مصفوفة هندسة قائمة الطعام (Kasavana & Smith Matrix):
   * هامش المساهمة: $CM_i = P_i - C_i$
   * متوسط هامش المساهمة: $\overline{CM} = \frac{\sum (CM_i \times V_i)}{\sum V_i}$
   * معيار الشعبية: $\text{Hurdle} = 0.7 \times \left(\frac{1}{N}\right)$
   */
  computeMatrix(
    recipes: Recipe[],
    salesData: { recipeId: string; soldUnits: number }[]
  ): MenuEngineeringReport {
    const totalUnitsSoldAll = salesData.reduce((acc, s) => acc + s.soldUnits, 0);
    const nDishes = recipes.length;
    const popularityHurdlePct = nDishes > 0 ? (0.7 / nDishes) * 100 : 0;

    let totalGrossMarginAll = 0;

    const preliminaryList = recipes.map((recipe) => {
      const sold = salesData.find(s => s.recipeId === recipe.id)?.soldUnits || 25;
      const portionCost = recipe.calculatedPortionCostEGP || 45;
      const sellingPrice = recipe.sellingPriceEGP || (portionCost * 2.5);
      const contributionMargin = Math.max(0, sellingPrice - portionCost);

      totalGrossMarginAll += contributionMargin * sold;

      const popularitySharePct = totalUnitsSoldAll > 0 ? (sold / totalUnitsSoldAll) * 100 : 20;

      return {
        recipe,
        sold,
        portionCost,
        sellingPrice,
        contributionMargin,
        popularitySharePct,
      };
    });

    const averageCM = totalUnitsSoldAll > 0 ? totalGrossMarginAll / totalUnitsSoldAll : 85;

    let starsCount = 0;
    let plowhorsesCount = 0;
    let puzzlesCount = 0;
    let dogsCount = 0;

    const items: MenuItemProfitability[] = preliminaryList.map((row) => {
      const isHighProfit = row.contributionMargin >= averageCM;
      const isHighPopularity = row.popularitySharePct >= popularityHurdlePct;

      let classification: MenuClassification;
      let actionRecommendationAr: string;

      if (isHighProfit && isHighPopularity) {
        classification = 'STAR';
        actionRecommendationAr = 'طبق نجم: الحفاظ التام على معايير الجودة والمقادير وموضعه البارز في القائمة.';
        starsCount++;
      } else if (!isHighProfit && isHighPopularity) {
        classification = 'PLOWHORSE';
        actionRecommendationAr = 'حصان جر: إعادة تسعير الطبق برفع طفيف أو تقليل تكلفة مكوناته لرفع هامش الربح.';
        plowhorsesCount++;
      } else if (isHighProfit && !isHighPopularity) {
        classification = 'PUZZLE';
        actionRecommendationAr = 'لغز: ربحية ممتازة ولكن مبيعات منخفضة؛ يتطلب تسويقاً وترويجاً عبر طاقم الخدمة.';
        puzzlesCount++;
      } else {
        classification = 'DOG';
        actionRecommendationAr = 'صنف خاسر: ربحية وشعبية منخفضة؛ يُنصح باستبداله أو حذفه لتجنب هدر المواد الخام.';
        dogsCount++;
      }

      return {
        recipeId: row.recipe.id,
        dishNameAr: row.recipe.dishNameAr,
        category: row.recipe.category,
        sellingPriceEGP: row.sellingPrice,
        portionCostEGP: row.portionCost,
        contributionMarginEGP: Math.round(row.contributionMargin * 100) / 100,
        salesVolumeUnits: row.sold,
        totalRevenueEGP: row.sellingPrice * row.sold,
        totalCostEGP: row.portionCost * row.sold,
        totalProfitEGP: Math.round(row.contributionMargin * row.sold),
        popularitySharePct: Math.round(row.popularitySharePct * 10) / 10,
        classification,
        actionRecommendationAr,
      };
    });

    return {
      id: `ME-${Date.now()}`,
      periodStart: new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0],
      periodEnd: new Date().toISOString().split('T')[0],
      averageContributionMarginEGP: Math.round(averageCM * 100) / 100,
      popularityHurdleRatePct: Math.round(popularityHurdlePct * 10) / 10,
      items,
      starsCount,
      plowhorsesCount,
      puzzlesCount,
      dogsCount,
      generatedAt: new Date().toISOString(),
    };
  },

  /**
   * تفكيك الحصص المتوقعة إلى مواد خام ومقارنتها بأرصدة المخزون الفعلية:
   * $Q_{\text{required}} = \max\left(0, \sum (D_j \times q_{ij}) - S_i\right)$
   */
  async explodeForecastToIngredients(
    forecasts: DishForecastSummary[],
    recipes: Recipe[],
    currentInventory: InventoryItem[]
  ): Promise<ExplodedIngredientDemand[]> {
    const demandMap = new Map<string, { productNameAr: string; unit: string; orderTypeId: string; totalQty: number }>();

    for (const fc of forecasts) {
      const recipe = recipes.find(r => r.id === fc.recipeId);
      if (!recipe) continue;

      for (const ing of recipe.ingredients) {
        const grossPortion = ing.quantityPerPortion / (ing.yieldFactor || 1);
        const dishDemand = grossPortion * fc.totalExpectedPortions;

        if (!demandMap.has(ing.productId)) {
          demandMap.set(ing.productId, {
            productNameAr: ing.productNameAr,
            unit: ing.unit,
            orderTypeId: '',
            totalQty: dishDemand,
          });
        } else {
          demandMap.get(ing.productId)!.totalQty += dishDemand;
        }
      }
    }

    const explodedResults: ExplodedIngredientDemand[] = [];

    demandMap.forEach((val, productId) => {
      const invItem = currentInventory.find(i => i.productId === productId);
      const availableStock = invItem ? invItem.currentStock : 20;
      const roundedDemand = Math.round(val.totalQty * 10) / 10;
      const shortage = Math.max(0, roundedDemand - availableStock);
      // هامش أمان بنسبة 10% لتفادي الهدر غير المتوقع
      const suggestedPurchase = shortage > 0 ? Math.ceil(shortage * 1.1) : 0;

      explodedResults.push({
        productId,
        productNameAr: val.productNameAr,
        unit: val.unit,
        orderTypeId: invItem?.orderTypeId || 'cat-general',
        currentAvailableStock: availableStock,
        totalForecastedConsumption: roundedDemand,
        netProcurementShortage: Math.round(shortage * 10) / 10,
        suggestedPurchaseQty: suggestedPurchase,
      });
    });

    return explodedResults.sort((a, b) => b.netProcurementShortage - a.netProcurementShortage);
  },

  /**
   * توليد التنبؤ الذكي بحصص الأسبوع القادم
   */
  async getForecasts(recipes: Recipe[]): Promise<DishForecastSummary[]> {
    const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const today = new Date();

    return recipes.map((recipe, rIdx) => {
      const baseDaily = (rIdx + 1) * 12 + 10;
      const next7Days = Array.from({ length: 7 }).map((_, i) => {
        const d = new Date(today);
        d.setDate(today.getDate() + i + 1);
        const dayIdx = d.getDay();
        const isPeak = dayIdx === 4 || dayIdx === 5 || dayIdx === 6; // الخميس والجمعة والسبت
        const predicted = Math.round(baseDaily * (isPeak ? 1.4 : 1.0));

        return {
          date: d.toISOString().split('T')[0],
          dayOfWeekAr: dayNames[dayIdx],
          predictedPortions: predicted,
          isPeakDay: isPeak,
          confidenceScore: 0.92,
        };
      });

      const totalExpected = next7Days.reduce((sum, day) => sum + day.predictedPortions, 0);

      return {
        recipeId: recipe.id,
        dishNameAr: recipe.dishNameAr,
        next7DaysForecast: next7Days,
        totalExpectedPortions: totalExpected,
      };
    });
  },
};
