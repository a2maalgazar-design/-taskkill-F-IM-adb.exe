import React, { useState } from 'react';
import { MenuEngineeringReport, MenuClassification } from '../types';
import { Star, ShieldAlert, HelpCircle, Flame } from 'lucide-react';

interface MenuEngineeringMatrixViewProps {
  report: MenuEngineeringReport;
}

const CLASSIFICATION_CONFIG: Record<MenuClassification, { title: string; color: string; badge: string; desc: string }> = {
  STAR: {
    title: 'النجوم (Stars)',
    color: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    desc: 'ربحية عالية + شعبية عالية',
  },
  PLOWHORSE: {
    title: 'أحصنة الجر (Plowhorses)',
    color: 'border-sky-500/40 bg-sky-500/10 text-sky-300',
    badge: 'bg-sky-500/20 text-sky-300 border-sky-500/30',
    desc: 'ربحية منخفضة + شعبية عالية',
  },
  PUZZLE: {
    title: 'الألغاز (Puzzles)',
    color: 'border-amber-500/40 bg-amber-500/10 text-amber-300',
    badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    desc: 'ربحية عالية + شعبية منخفضة',
  },
  DOG: {
    title: 'الأصناف الخاسرة (Dogs)',
    color: 'border-rose-500/40 bg-rose-500/10 text-rose-300',
    badge: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
    desc: 'ربحية منخفضة + شعبية منخفضة',
  },
};

export const MenuEngineeringMatrixView: React.FC<MenuEngineeringMatrixViewProps> = ({ report }) => {
  const [selectedQuadrant, setSelectedQuadrant] = useState<MenuClassification | 'ALL'>('ALL');

  const filteredItems = selectedQuadrant === 'ALL'
    ? report.items
    : report.items.filter(i => i.classification === selectedQuadrant);

  return (
    <div className="space-y-5 text-xs text-stone-100">
      {/* ملخص المؤشرات المرجعية */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-stone-800 pb-3">
        <div>
          <h2 className="font-bold text-stone-100 text-base">مصفوفة هندسة قائمة الطعام والربحية (Menu Engineering)</h2>
          <p className="text-stone-400 text-xs">تحليل ربحية الأطباق ومطابقتها بمعدلات الشراء لتوجيه قرارات تسعير وتوريد المواد الخام.</p>
        </div>
        <div className="flex gap-2">
          <div className="bg-stone-900 border border-stone-800 px-3 py-1.5 rounded-lg text-center font-mono">
            <span className="text-[10px] text-stone-400 block">متوسط هامش الربح</span>
            <span className="font-bold text-amber-400">{report.averageContributionMarginEGP} ج.م</span>
          </div>
          <div className="bg-stone-900 border border-stone-800 px-3 py-1.5 rounded-lg text-center font-mono">
            <span className="text-[10px] text-stone-400 block">معيار الشعبية الأدنى</span>
            <span className="font-bold text-emerald-400">{report.popularityHurdleRatePct}%</span>
          </div>
        </div>
      </div>

      {/* المربعات الأربعة (4-Quadrant Grid) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {(['STAR', 'PLOWHORSE', 'PUZZLE', 'DOG'] as MenuClassification[]).map((cat) => {
          const cfg = CLASSIFICATION_CONFIG[cat];
          const count = report.items.filter(i => i.classification === cat).length;
          const isSelected = selectedQuadrant === cat;

          return (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedQuadrant(isSelected ? 'ALL' : cat)}
              className={`p-3.5 rounded-xl border text-right transition ${cfg.color} ${
                isSelected ? 'ring-2 ring-amber-500 shadow-md' : 'shadow-sm hover:border-stone-600'
              }`}
            >
              <div className="flex justify-between items-center mb-1">
                <span className="font-bold text-sm">{cfg.title}</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${cfg.badge}`}>
                  {count} أطباق
                </span>
              </div>
              <span className="text-[10px] text-stone-300 block">{cfg.desc}</span>
            </button>
          );
        })}
      </div>

      {/* جدول الأطباق والتوصيات الإجرائية */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl overflow-hidden shadow-sm">
        <div className="p-3 bg-stone-950/80 border-b border-stone-800 flex justify-between items-center">
          <h4 className="font-bold text-stone-200">
            قائمة تصنيف الوجبات ({filteredItems.length} طبق)
          </h4>
          {selectedQuadrant !== 'ALL' && (
            <button
              type="button"
              onClick={() => setSelectedQuadrant('ALL')}
              className="text-stone-400 hover:text-stone-100 font-bold"
            >
              عرض الكل ✕
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-stone-950/60 border-b border-stone-800 text-stone-400 font-semibold">
              <tr>
                <th className="p-2.5">الطبق</th>
                <th className="p-2.5">سعر البيع</th>
                <th className="p-2.5">تكلفة الحصة</th>
                <th className="p-2.5">هامش الربح</th>
                <th className="p-2.5">الحصص المباعة</th>
                <th className="p-2.5">نسبة الشعبية</th>
                <th className="p-2.5 text-center">التصنيف</th>
                <th className="p-2.5">التوصية التشغيلية</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-800/60 font-sans">
              {filteredItems.map((item) => {
                const cfg = CLASSIFICATION_CONFIG[item.classification];

                return (
                  <tr key={item.recipeId} className="hover:bg-stone-800/40 transition">
                    <td className="p-2.5 font-bold text-stone-100">{item.dishNameAr}</td>
                    <td className="p-2.5 font-mono text-stone-300">{item.sellingPriceEGP} ج.م</td>
                    <td className="p-2.5 font-mono text-rose-400">{item.portionCostEGP} ج.م</td>
                    <td className="p-2.5 font-mono font-bold text-emerald-400">+{item.contributionMarginEGP} ج.م</td>
                    <td className="p-2.5 font-mono text-stone-300">{item.salesVolumeUnits}</td>
                    <td className="p-2.5 font-mono font-bold text-amber-400">{item.popularitySharePct}%</td>
                    <td className="p-2.5 text-center">
                      <span className={`px-2 py-0.5 rounded border text-[10px] font-bold ${cfg.badge}`}>
                        {item.classification}
                      </span>
                    </td>
                    <td className="p-2.5 text-stone-300 text-[11px] leading-relaxed max-w-xs">
                      {item.actionRecommendationAr}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
