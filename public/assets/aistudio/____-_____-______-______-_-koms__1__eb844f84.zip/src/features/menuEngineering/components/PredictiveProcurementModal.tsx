import React, { useState } from 'react';
import { ExplodedIngredientDemand } from '../types';
import { UserProfile } from '@/features/auth/types';
import { useData } from '@/context/DataContext';
import { X, Sparkles, ShoppingCart, CheckCircle } from 'lucide-react';

interface PredictiveProcurementModalProps {
  demands: ExplodedIngredientDemand[];
  currentUser: UserProfile;
  onClose: () => void;
  onOrdersCreated: () => void;
}

export const PredictiveProcurementModal: React.FC<PredictiveProcurementModalProps> = ({
  demands,
  currentUser,
  onClose,
  onOrdersCreated,
}) => {
  const { suppliers, orderTypes, createOrder } = useData();
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>(
    demands.filter(d => d.netProcurementShortage > 0).map(d => d.productId)
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const toggleSelect = (id: string) => {
    setSelectedProductIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleGenerateOrders = async () => {
    const selectedDemands = demands.filter(d => selectedProductIds.includes(d.productId));
    if (selectedDemands.length === 0) return;

    setIsSubmitting(true);
    setSuccessMsg(null);

    try {
      const orderItems = selectedDemands.map((d, i) => ({
        id: `item-pred-${Date.now()}-${i}`,
        productId: d.productId,
        productName: d.productNameAr,
        requestedQty: d.suggestedPurchaseQty,
        orderedQty: d.suggestedPurchaseQty,
        receivedQty: 0,
        rejectedQty: 0,
        outstandingQty: d.suggestedPurchaseQty,
        unit: d.unit,
        itemStatus: 'pending' as const,
      }));

      const defaultSupplier = suppliers[0];
      const todayStr = new Date().toISOString().split('T')[0];
      const now = new Date();
      const deadline = new Date(now.getTime() + 6 * 3600000).toISOString();
      const expectedDelivery = new Date(now.getTime() + 24 * 3600000).toISOString();

      await createOrder({
        orderTypeId: selectedDemands[0]?.orderTypeId || orderTypes[0]?.id || 'cat-general',
        supplierId: defaultSupplier?.id || undefined,
        orderDate: todayStr,
        orderingDeadline: deadline,
        expectedDeliveryTime: expectedDelivery,
        primaryAssigneeId: currentUser.uid,
        purchasingChannel: 'واتساب',
        priority: 'normal',
        requiresApproval: false,
        items: orderItems,
        notes: `أمر شراء استباقي لتغطية استهلاك الأسبوع القادم بناء على تنبؤات الذكاء الاصطناعي (AI Predictive Procurement)`,
      });

      setSuccessMsg(`تم توليد أمر الشراء الاستباقي بنجاح لـ ${selectedDemands.length} صنف!`);
      setTimeout(() => {
        onOrdersCreated();
        onClose();
      }, 1500);
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء إنشاء أوامر الشراء الاستباقية');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-stone-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-3 text-xs overflow-y-auto text-stone-100">
      <div className="bg-stone-900 border border-stone-800 rounded-xl shadow-2xl w-full max-w-3xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* شريط العنوان */}
        <div className="p-4 bg-stone-950 border-b border-stone-800 flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-100">توليد أوامر الشراء الاستباقية (AI Predictive Procurement)</h3>
              <span className="text-[11px] text-stone-400">تغطية استهلاك الأسبوع القادم وتفادي نفاد المخزون مسبقاً</span>
            </div>
          </div>
          <button onClick={onClose} className="text-stone-400 hover:text-stone-100 p-1 rounded hover:bg-stone-800 transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-4">
          {successMsg && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400 text-xs flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <div className="p-3 bg-sky-500/10 border border-sky-500/20 rounded-xl text-sky-200 flex items-center justify-between">
            <span>
              تم حساب الاحتياجات عبر تفكيك حصص الأطباق المتوقعة للسبعة أيام القادمة وخصم الأرصدة المتوفرة حالياً.
            </span>
            <span className="font-bold text-sky-400 font-mono">
              {demands.filter(d => d.netProcurementShortage > 0).length} أصناف بها عجز متوقع
            </span>
          </div>

          <div className="border border-stone-800 rounded-xl overflow-hidden bg-stone-950/40">
            <table className="w-full text-right text-xs">
              <thead className="bg-stone-950/80 border-b border-stone-800 text-stone-400 font-semibold">
                <tr>
                  <th className="p-2.5 w-8"></th>
                  <th className="p-2.5">المادة الخام</th>
                  <th className="p-2.5 text-center">الرصيد المتاح</th>
                  <th className="p-2.5 text-center">الاستهلاك المتوقع (7 أيام)</th>
                  <th className="p-2.5 text-center">العجز المحتسب</th>
                  <th className="p-2.5 text-center">الكمية المقترح شراؤها (+10%)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/60 font-sans">
                {demands.map((item) => {
                  const hasShortage = item.netProcurementShortage > 0;
                  const isChecked = selectedProductIds.includes(item.productId);

                  return (
                    <tr key={item.productId} className={hasShortage ? 'bg-amber-500/5' : 'hover:bg-stone-800/40'}>
                      <td className="p-2.5 text-center">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleSelect(item.productId)}
                          className="rounded bg-stone-900 border-stone-700 text-amber-500 focus:ring-0 cursor-pointer"
                        />
                      </td>
                      <td className="p-2.5 font-bold text-stone-200">{item.productNameAr}</td>
                      <td className="p-2.5 text-center font-mono text-stone-400">{item.currentAvailableStock} {item.unit}</td>
                      <td className="p-2.5 text-center font-mono font-bold text-stone-200">{item.totalForecastedConsumption} {item.unit}</td>
                      <td className={`p-2.5 text-center font-mono font-bold ${hasShortage ? 'text-rose-400' : 'text-emerald-400'}`}>
                        {hasShortage ? `-${item.netProcurementShortage}` : 'مستوفى'} {item.unit}
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-amber-400">
                        {item.suggestedPurchaseQty > 0 ? `+${item.suggestedPurchaseQty} ${item.unit}` : '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="pt-2 border-t border-stone-800 flex gap-2">
            <button
              type="button"
              onClick={handleGenerateOrders}
              disabled={isSubmitting || selectedProductIds.length === 0}
              className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-stone-950 rounded-lg font-bold transition shadow-lg shadow-amber-500/10 flex items-center justify-center gap-2"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>
                {isSubmitting ? 'جاري توليد أوامر الشراء...' : `توليد أوامر شراء استباقية للأصناف المحددة (${selectedProductIds.length})`}
              </span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-4 bg-stone-800 text-stone-300 rounded-lg font-semibold hover:bg-stone-700 transition"
            >
              إلغاء
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
