import React, { useState, useEffect } from 'react';
import { Sparkles, BarChart3, Calendar, ShoppingCart, RefreshCw } from 'lucide-react';
import { MenuEngineeringReport, DishForecastSummary, ExplodedIngredientDemand } from '../types';
import { menuEngineeringService } from '../api/menuEngineeringService';
import { MenuEngineeringMatrixView } from './MenuEngineeringMatrixView';
import { PredictiveProcurementModal } from './PredictiveProcurementModal';
import { recipeService } from '@/features/recipes/api/recipeService';
import { inventoryService } from '@/features/inventory/api/inventoryService';
import { useAuth } from '@/features/auth/components/AuthGuard';
import { UserProfile } from '@/features/auth/types';

export const MenuEngineeringView: React.FC = () => {
  const { user, currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'matrix' | 'forecast'>('matrix');
  const [report, setReport] = useState<MenuEngineeringReport | null>(null);
  const [forecasts, setForecasts] = useState<DishForecastSummary[]>([]);
  const [explodedDemands, setExplodedDemands] = useState<ExplodedIngredientDemand[]>([]);
  const [isProcurementModalOpen, setIsProcurementModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const effectiveUser: UserProfile = user || {
    uid: currentUser?.id || 'usr-manager',
    email: currentUser?.email || 'manager@kitchen.internal',
    displayName: currentUser?.name || 'مدير التشغيل والمطاعم',
    role: currentUser?.role || 'manager',
    permissions: [],
    isActive: true,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [recipes, inventory] = await Promise.all([
        recipeService.getRecipes(),
        inventoryService.getInventory(),
      ]);

      const salesData = recipes.map((r, i) => ({
        recipeId: r.id,
        soldUnits: (i + 1) * 35 + 20,
      }));

      const rep = menuEngineeringService.computeMatrix(recipes, salesData);
      setReport(rep);

      const fc = await menuEngineeringService.getForecasts(recipes);
      setForecasts(fc);

      const demands = await menuEngineeringService.explodeForecastToIngredients(fc, recipes, inventory);
      setExplodedDemands(demands);
    } catch (err) {
      console.error('Failed to load menu engineering data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div className="space-y-6 text-xs text-stone-100">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-stone-100">هندسة المنيو والتنبؤ الذكي بالطلب (Menu Engineering & AI Forecast)</h2>
            <span className="text-[10px] px-2.5 py-0.5 rounded-full font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
              Kasavana & Smith Matrix
            </span>
          </div>
          <p className="text-xs text-stone-400 mt-1">
            تصنيف الوجبات بحسب الربحية والشعبية، وتقدير استهلاك الأسبوع القادم استباقياً لمنع نفاد المخزون
          </p>
        </div>

        <button
          onClick={() => setIsProcurementModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded-lg text-xs font-bold transition shadow-lg shadow-amber-500/10"
        >
          <Sparkles className="w-4 h-4" />
          <span>توليد أوامر الشراء الاستباقية (AI Demand)</span>
        </button>
      </div>

      {/* شريط التبويبات */}
      <div className="flex border-b border-stone-800 gap-2">
        <button
          onClick={() => setActiveTab('matrix')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition ${
            activeTab === 'matrix'
              ? 'border-amber-500 text-amber-400 bg-amber-500/5'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>مصفوفة هندسة المنيو والربحية (4 Quadrants)</span>
        </button>

        <button
          onClick={() => setActiveTab('forecast')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition ${
            activeTab === 'forecast'
              ? 'border-amber-500 text-amber-400 bg-amber-500/5'
              : 'border-transparent text-stone-400 hover:text-stone-200'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>توقعات الطلب للـ 7 أيام القادمة (Next 7-Days Forecast)</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-stone-800 text-stone-300">
            {forecasts.length} وجبات
          </span>
        </button>
      </div>

      {/* محتوى التبويب */}
      {loading ? (
        <div className="p-12 text-center text-stone-500 text-xs">جاري تحليل بيانات المبيعات والتنبؤ بالاستهلاك...</div>
      ) : activeTab === 'matrix' && report ? (
        <MenuEngineeringMatrixView report={report} />
      ) : (
        <div className="space-y-4">
          <div className="bg-stone-900 border border-stone-800 rounded-xl overflow-hidden shadow-sm">
            <div className="p-3 bg-stone-950/80 border-b border-stone-800 flex justify-between items-center">
              <h4 className="font-bold text-stone-200">جدول تقديرات الحصص اليومية للأطباق (مع مضاعف ذروة عطلات نهاية الأسبوع)</h4>
              <span className="text-[11px] text-amber-400 font-mono">الخميس، الجمعة، السبت: +40%</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-stone-950/60 border-b border-stone-800 text-stone-400 font-semibold">
                  <tr>
                    <th className="p-3">الوجبة</th>
                    <th className="p-3 text-center">إجمالي الأسبوع</th>
                    {forecasts[0]?.next7DaysForecast.map((d, i) => (
                      <th key={i} className={`p-3 text-center ${d.isPeakDay ? 'text-amber-400 font-bold' : ''}`}>
                        {d.dayOfWeekAr}
                        <span className="text-[9px] block text-stone-500 font-normal">{d.date.slice(5)}</span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-800/60 font-sans">
                  {forecasts.map(fc => (
                    <tr key={fc.recipeId} className="hover:bg-stone-800/40 transition">
                      <td className="p-3 font-bold text-stone-100">{fc.dishNameAr}</td>
                      <td className="p-3 text-center font-mono font-bold text-amber-400 text-sm">
                        {fc.totalExpectedPortions} وجبة
                      </td>
                      {fc.next7DaysForecast.map((day, idx) => (
                        <td
                          key={idx}
                          className={`p-3 text-center font-mono ${
                            day.isPeakDay ? 'bg-amber-500/5 font-bold text-amber-300' : 'text-stone-300'
                          }`}
                        >
                          {day.predictedPortions}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* نافذة التوليد الاستباقي للأوامر */}
      {isProcurementModalOpen && (
        <PredictiveProcurementModal
          demands={explodedDemands}
          currentUser={effectiveUser}
          onClose={() => setIsProcurementModalOpen(false)}
          onOrdersCreated={() => loadData()}
        />
      )}
    </div>
  );
};
