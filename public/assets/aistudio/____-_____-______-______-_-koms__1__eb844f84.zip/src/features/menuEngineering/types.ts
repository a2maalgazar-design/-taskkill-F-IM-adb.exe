export type MenuClassification = 'STAR' | 'PLOWHORSE' | 'PUZZLE' | 'DOG';

export interface MenuItemProfitability {
  recipeId: string;
  dishNameAr: string;
  category: string;
  sellingPriceEGP: number;
  portionCostEGP: number;
  contributionMarginEGP: number; // sellingPrice - portionCost
  salesVolumeUnits: number; // إجمالي الحصص المباعة في الفترة
  totalRevenueEGP: number;
  totalCostEGP: number;
  totalProfitEGP: number;
  popularitySharePct: number; // نسبة حصة مبيعات الطبق من إجمالي الأطباق المباعة
  classification: MenuClassification;
  actionRecommendationAr: string;
}

export interface DayForecast {
  date: string; // YYYY-MM-DD
  dayOfWeekAr: string;
  predictedPortions: number;
  isPeakDay: boolean;
  confidenceScore: number;
}

export interface DishForecastSummary {
  recipeId: string;
  dishNameAr: string;
  next7DaysForecast: DayForecast[];
  totalExpectedPortions: number;
}

export interface ExplodedIngredientDemand {
  productId: string;
  productNameAr: string;
  unit: string;
  orderTypeId: string;
  supplierId?: string;
  supplierNameAr?: string;
  currentAvailableStock: number;
  totalForecastedConsumption: number; // الكمية المطلوبة لتغطية توقعات الأسبوع
  netProcurementShortage: number; // Max(0, ForecastedConsumption - AvailableStock)
  suggestedPurchaseQty: number; // Shortage + SafetyBuffer
}

export interface MenuEngineeringReport {
  id: string;
  periodStart: string;
  periodEnd: string;
  averageContributionMarginEGP: number;
  popularityHurdleRatePct: number; // معيار الشعبية: (1/N) * 70%
  items: MenuItemProfitability[];
  starsCount: number;
  plowhorsesCount: number;
  puzzlesCount: number;
  dogsCount: number;
  generatedAt: string;
}
