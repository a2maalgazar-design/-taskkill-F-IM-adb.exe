export interface BatchLot {
  batchId: string;
  orderId: string;
  orderCode: string;
  receivedDate: string; // YYYY-MM-DD
  expiryDate?: string;   // YYYY-MM-DD
  initialQty: number;
  remainingQty: number;
  unitCostEGP?: number;
}

export interface InventoryItem {
  id: string; // مطابق لـ productId
  productId: string;
  productNameAr: string;
  orderTypeId: string;
  currentStock: number;
  unit: string;
  minThreshold: number; // حد إعادة الطلب الأدنى (Safety Stock)
  idealParLevel: number; // الحد التشغيلي الأمثل
  batches: BatchLot[];
  lastRestockedAt: string;
  updatedAt: string;
}

export type MovementType = 'RECEIPT' | 'USAGE' | 'WASTE' | 'ADJUSTMENT';

export interface StockMovement {
  id: string;
  productId: string;
  productNameAr: string;
  movementType: MovementType;
  qtyChange: number; // موجب في الاستلام، سالب في الاستهلاك أو الهدر
  previousStock: number;
  newStock: number;
  batchId?: string;
  reason?: string;
  actorId: string;
  actorName: string;
  timestamp: string;
}

export interface ReorderAlert {
  productId: string;
  productNameAr: string;
  orderTypeId: string;
  currentStock: number;
  minThreshold: number;
  shortageQty: number; // minThreshold - currentStock
  unit: string;
}
