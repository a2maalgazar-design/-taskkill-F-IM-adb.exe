import React, { useState } from 'react';
import { InventoryItem } from '../types';
import { UserProfile } from '@/features/auth/types';
import { inventoryService } from '../api/inventoryService';

interface StockUsageModalProps {
  item: InventoryItem;
  currentUser: UserProfile;
  onClose: () => void;
  onSuccess: () => void;
}

export const StockUsageModal: React.FC<StockUsageModalProps> = ({
  item,
  currentUser,
  onClose,
  onSuccess,
}) => {
  const [qty, setQty] = useState<number | ''>('');
  const [movementType, setMovementType] = useState<'USAGE' | 'WASTE'>('USAGE');
  const [reason, setReason] = useState('استهلاك وردية الطهي الصباحية');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!qty || Number(qty) <= 0) {
      setError('يرجى تحديد كمية صحيحة');
      return;
    }
    if (Number(qty) > item.currentStock) {
      setError(`الكمية المدخلة تتجاوز الرصيد الحالي (${item.currentStock} ${item.unit})`);
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await inventoryService.consumeStock(
        item.productId,
        Number(qty),
        movementType,
        reason.trim(),
        currentUser
      );
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'فشلت عملية الصرف');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden flex flex-col text-xs">
        <div className="p-4 bg-slate-900 text-white flex justify-between items-center">
          <div>
            <h3 className="font-bold text-sm">صرف مخزني — {item.productNameAr}</h3>
            <span className="text-[11px] text-slate-300">الرصيد المتاح: {item.currentStock} {item.unit}</span>
          </div>
          <button onClick={onClose} className="text-slate-300 hover:text-white font-bold text-lg">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {error && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded text-xs">
              {error}
            </div>
          )}

          {/* نوع الصرف */}
          <div>
            <label className="block text-slate-700 font-semibold mb-1">نوع الحركة</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => { setMovementType('USAGE'); setReason('استهلاك تحضير وطهي'); }}
                className={`py-2 text-center rounded border font-semibold transition ${
                  movementType === 'USAGE'
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-slate-50 text-slate-700 border-slate-200'
                }`}
              >
                استهلاك تشغيلي
              </button>
              <button
                type="button"
                onClick={() => { setMovementType('WASTE'); setReason('هدر / تلف أثناء التشغيل'); }}
                className={`py-2 text-center rounded border font-semibold transition ${
                  movementType === 'WASTE'
                    ? 'bg-rose-700 text-white border-rose-700'
                    : 'bg-slate-50 text-slate-700 border-slate-200'
                }`}
              >
                تسجيل هدر / تلف
              </button>
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">الكمية المصروفة ({item.unit})</label>
            <input
              type="number"
              step="any"
              min="0.1"
              max={item.currentStock}
              value={qty}
              onChange={(e) => setQty(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="0.00"
              required
              className="w-full p-2 border border-slate-300 rounded text-center text-sm font-bold text-slate-900 focus:outline-slate-900"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">سبب أو وجهة الصرف</label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
              className="w-full p-2 border border-slate-300 rounded focus:outline-slate-900"
            />
          </div>

          <div className="pt-2 border-t border-slate-100 flex gap-2">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white rounded font-bold transition"
            >
              {loading ? 'جاري الخصم...' : 'تأكيد الصرف من المخزون'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-4 bg-slate-100 text-slate-700 rounded font-semibold hover:bg-slate-200"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
