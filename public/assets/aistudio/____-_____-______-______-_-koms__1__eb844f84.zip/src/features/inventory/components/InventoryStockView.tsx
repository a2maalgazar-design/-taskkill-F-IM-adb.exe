import React, { useState, useEffect } from 'react';
import { InventoryItem, ReorderAlert } from '../types';
import { inventoryService } from '../api/inventoryService';
import { StockUsageModal } from './StockUsageModal';
import { useAuth } from '@/features/auth/components/AuthGuard';
import { UserProfile } from '@/features/auth/types';

export const InventoryStockView: React.FC = () => {
  const { user, currentUser } = useAuth();
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [alerts, setAlerts] = useState<ReorderAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedItemForUsage, setSelectedItemForUsage] = useState<InventoryItem | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrderType, setSelectedOrderType] = useState<string>('ALL');

  const effectiveUser: UserProfile = user || {
    uid: currentUser?.id || 'user-manager-01',
    email: currentUser?.email || 'manager@kitchen.internal',
    displayName: currentUser?.name || 'مدير المطبخ والمشتريات',
    role: currentUser?.role || 'manager',
    permissions: [],
    isActive: true,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [inv, reorderItems] = await Promise.all([
        inventoryService.getInventory(selectedOrderType === 'ALL' ? undefined : selectedOrderType),
        inventoryService.getReorderAlerts(),
      ]);
      setInventory(inv);
      setAlerts(reorderItems);
    } catch (err) {
      console.error('Error loading inventory:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedOrderType]);

  const filteredInventory = inventory.filter((item) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return item.productNameAr.toLowerCase().includes(q) || item.productId.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-5">
      {/* رأس الصفحة والموجز */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h2 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <span>مخزون المطبخ اللحظي</span>
            <span className="text-[11px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full font-medium border border-emerald-200">
              متابعة حية (Live Inventory)
            </span>
          </h2>
          <p className="text-xs text-slate-500">متابعة الأرصدة الحية، تواريخ الصلاحية، والتنبيه التلقائي لإعادة الطلب.</p>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="بحث في أصناف المخزون..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="text-xs px-3 py-1.5 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-slate-900"
          />
          <button
            onClick={loadData}
            className="text-xs px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold transition"
          >
            تحديث الأرصدة
          </button>
        </div>
      </div>

      {/* شريط تنبيهات حد إعادة الطلب */}
      {alerts.length > 0 && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-amber-800 font-bold text-xs">
            <span>⚠️</span>
            <span>تنبيه أصناف قاربت على النفاد (وصلت لحد إعادة الطلب):</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
            {alerts.map(a => (
              <div key={a.productId} className="p-2 bg-white/80 border border-amber-300 rounded text-xs flex justify-between items-center">
                <div>
                  <span className="font-bold text-slate-800 block">{a.productNameAr}</span>
                  <span className="text-[10px] text-slate-500">الرصيد: {a.currentStock} / الحد الأدنى: {a.minThreshold} {a.unit}</span>
                </div>
                <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  نقص: {a.shortageQty} {a.unit}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* قائمة بطاقات المخزون */}
      {loading ? (
        <div className="p-12 text-center text-slate-400 text-xs">جاري جلب بيانات المخزون...</div>
      ) : filteredInventory.length === 0 ? (
        <div className="p-8 border border-dashed border-slate-200 rounded-xl text-center text-slate-500 bg-white text-xs">
          لا توجد بضائع مخزنة مطابقة. يتم ترحيل الأصناف هنا تلقائياً عند اعتماد أذونات الاستلام في مرحلة التوريد.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredInventory.map((item) => {
            const isLow = item.currentStock <= item.minThreshold;
            const nearestExpiry = item.batches
              .filter(b => b.expiryDate)
              .sort((a, b) => new Date(a.expiryDate!).getTime() - new Date(b.expiryDate!).getTime())[0];

            return (
              <div
                key={item.id}
                className={`bg-white border rounded-xl p-4 shadow-sm flex flex-col justify-between transition ${
                  isLow ? 'border-amber-300 ring-1 ring-amber-200' : 'border-slate-200'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{item.productNameAr}</h4>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        آخر توريد: {item.lastRestockedAt ? item.lastRestockedAt.split('T')[0] : '—'}
                      </span>
                    </div>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                      isLow ? 'bg-amber-100 text-amber-800' : 'bg-emerald-50 text-emerald-700'
                    }`}>
                      {isLow ? 'منخفض' : 'متوفر'}
                    </span>
                  </div>

                  {/* العداد والرصيد */}
                  <div className="p-2.5 bg-slate-50 rounded-lg flex justify-between items-center">
                    <div>
                      <span className="text-[10px] text-slate-400 block">الرصيد المتاح</span>
                      <div className="flex items-baseline gap-1">
                        <span className="text-xl font-bold font-mono text-slate-900">{item.currentStock}</span>
                        <span className="text-xs text-slate-600">{item.unit}</span>
                      </div>
                    </div>
                    <div className="text-left">
                      <span className="text-[10px] text-slate-400 block">حد الأمان</span>
                      <span className="text-xs font-mono font-semibold text-slate-700">{item.minThreshold} {item.unit}</span>
                    </div>
                  </div>

                  {/* تنبيه الصلاحية الأقرب */}
                  {nearestExpiry && (
                    <div className="text-[11px] flex items-center justify-between text-slate-600 pt-1">
                      <span>أقرب تاريخ انتهاء:</span>
                      <span className="font-mono font-bold text-rose-600">{nearestExpiry.expiryDate}</span>
                    </div>
                  )}

                  {/* عدد الدفعات المسجلة */}
                  {item.batches && item.batches.length > 0 && (
                    <div className="text-[10px] text-slate-400 flex items-center justify-between">
                      <span>عدد الدفعات النشطة:</span>
                      <span className="font-mono font-medium text-slate-600">{item.batches.length} دفعات (FEFO)</span>
                    </div>
                  )}
                </div>

                <div className="pt-3 mt-3 border-t border-slate-100 flex gap-2">
                  <button
                    onClick={() => setSelectedItemForUsage(item)}
                    className="flex-1 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-semibold transition"
                  >
                    تسجيل استهلاك / صرف
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* نافذة تسجيل الصرف */}
      {selectedItemForUsage && (
        <StockUsageModal
          item={selectedItemForUsage}
          currentUser={effectiveUser}
          onClose={() => setSelectedItemForUsage(null)}
          onSuccess={() => {
            setSelectedItemForUsage(null);
            loadData();
          }}
        />
      )}
    </div>
  );
};
