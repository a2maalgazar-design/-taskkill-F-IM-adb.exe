import { 
  collection, 
  doc, 
  getDocs, 
  runTransaction, 
  query, 
  where, 
  orderBy, 
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { UserProfile } from '@/features/auth/types';
import { InventoryItem, BatchLot, StockMovement, ReorderAlert } from '../types';

// ذاكرة محلية احتياطية تضمن استمرار العمل بسلاسة حتى في بيئات التجربة السريعة أو انقطاع الشبكة
const LOCAL_STORAGE_KEY = 'koms_kitchen_inventory_cache';

const INITIAL_FALLBACK_INVENTORY: InventoryItem[] = [
  {
    id: 'prod-veg-01',
    productId: 'prod-veg-01',
    productNameAr: 'طماطم بلدي طازجة درجة أولى',
    orderTypeId: 'cat-veg',
    currentStock: 45,
    unit: 'كجم',
    minThreshold: 20,
    idealParLevel: 60,
    lastRestockedAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
    batches: [
      {
        batchId: 'BATCH-TOMATO-101',
        orderId: 'PO-2026-001',
        orderCode: 'PO-2026-001',
        receivedDate: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
        expiryDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
        initialQty: 25,
        remainingQty: 15,
        unitCostEGP: 22,
      },
      {
        batchId: 'BATCH-TOMATO-102',
        orderId: 'PO-2026-008',
        orderCode: 'PO-2026-008',
        receivedDate: new Date(Date.now() - 86400000).toISOString().split('T')[0],
        expiryDate: new Date(Date.now() + 86400000 * 6).toISOString().split('T')[0],
        initialQty: 30,
        remainingQty: 30,
        unitCostEGP: 20,
      },
    ],
  },
  {
    id: 'prod-poultry-01',
    productId: 'prod-poultry-01',
    productNameAr: 'صدور دجاج مخلية مبردة (Fresh Breast)',
    orderTypeId: 'cat-poultry',
    currentStock: 12,
    unit: 'كجم',
    minThreshold: 25,
    idealParLevel: 50,
    lastRestockedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date().toISOString(),
    batches: [
      {
        batchId: 'BATCH-CHICKEN-201',
        orderId: 'PO-2026-003',
        orderCode: 'PO-2026-003',
        receivedDate: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
        expiryDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
        initialQty: 20,
        remainingQty: 12,
        unitCostEGP: 165,
      },
    ],
  },
  {
    id: 'prod-oil-01',
    productId: 'prod-oil-01',
    productNameAr: 'زيت قلي طهي نقي عبوة 20 لتر',
    orderTypeId: 'cat-sauces-oils',
    currentStock: 8,
    unit: 'عبوة',
    minThreshold: 10,
    idealParLevel: 25,
    lastRestockedAt: new Date(Date.now() - 86400000 * 4).toISOString(),
    updatedAt: new Date().toISOString(),
    batches: [
      {
        batchId: 'BATCH-OIL-301',
        orderId: 'PO-2026-005',
        orderCode: 'PO-2026-005',
        receivedDate: new Date(Date.now() - 86400000 * 4).toISOString().split('T')[0],
        expiryDate: new Date(Date.now() + 86400000 * 90).toISOString().split('T')[0],
        initialQty: 15,
        remainingQty: 8,
        unitCostEGP: 950,
      },
    ],
  },
];

function getLocalStore(): InventoryItem[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    // ignore
  }
  return INITIAL_FALLBACK_INVENTORY;
}

function saveLocalStore(items: InventoryItem[]): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(items));
  } catch (e) {
    // ignore
  }
}

export const inventoryService = {
  /**
   * استرجاع كامل أرصدة المخزون الحالية
   */
  async getInventory(orderTypeId?: string): Promise<InventoryItem[]> {
    try {
      const colRef = collection(db, 'inventory');
      const q = orderTypeId 
        ? query(colRef, where('orderTypeId', '==', orderTypeId))
        : query(colRef, orderBy('productNameAr', 'asc'));

      const snap = await getDocs(q);
      if (!snap.empty) {
        const items = snap.docs.map(d => ({ id: d.id, ...d.data() } as InventoryItem));
        saveLocalStore(items);
        return items;
      }
    } catch (err) {
      console.warn('Firestore getInventory fallback to local storage:', err);
    }

    const localItems = getLocalStore();
    if (orderTypeId) {
      return localItems.filter(i => i.orderTypeId === orderTypeId);
    }
    return localItems;
  },

  /**
   * إدخال كميات البضائع المستلمة فعلياً من إذن الاستلام إلى المخزون
   */
  async recordOrderReceiptToInventory(
    orderId: string,
    orderCode: string,
    orderTypeId: string,
    receivedItems: { productId: string; productNameAr: string; unit: string; qty: number; expiryDate?: string }[],
    actor: UserProfile
  ): Promise<void> {
    try {
      await runTransaction(db, async (transaction) => {
        for (const item of receivedItems) {
          if (item.qty <= 0) continue;

          const invDocRef = doc(db, 'inventory', item.productId);
          const invSnap = await transaction.get(invDocRef);

          const newBatch: BatchLot = {
            batchId: `BATCH-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            orderId,
            orderCode,
            receivedDate: new Date().toISOString().split('T')[0],
            expiryDate: item.expiryDate || undefined,
            initialQty: item.qty,
            remainingQty: item.qty,
          };

          let previousStock = 0;
          let newStock = item.qty;
          let currentBatches: BatchLot[] = [newBatch];
          let minThreshold = 10; // قيمة افتراضية قابلة للتعديل
          let idealParLevel = 50;

          if (invSnap.exists()) {
            const existing = invSnap.data() as InventoryItem;
            previousStock = existing.currentStock;
            newStock = previousStock + item.qty;
            currentBatches = [...existing.batches, newBatch];
            minThreshold = existing.minThreshold;
            idealParLevel = existing.idealParLevel;

            transaction.update(invDocRef, {
              currentStock: newStock,
              batches: currentBatches,
              lastRestockedAt: new Date().toISOString(),
              updatedAt: serverTimestamp(),
            });
          } else {
            transaction.set(invDocRef, {
              productId: item.productId,
              productNameAr: item.productNameAr,
              orderTypeId,
              unit: item.unit,
              currentStock: newStock,
              minThreshold,
              idealParLevel,
              batches: currentBatches,
              lastRestockedAt: new Date().toISOString(),
              updatedAt: serverTimestamp(),
            });
          }

          // تسجيل حركة استلام مخزنية
          const movementRef = doc(collection(db, 'stockMovements'));
          const movementData: Omit<StockMovement, 'id'> = {
            productId: item.productId,
            productNameAr: item.productNameAr,
            movementType: 'RECEIPT',
            qtyChange: item.qty,
            previousStock,
            newStock,
            batchId: newBatch.batchId,
            reason: `توريد بموجب أمر الشراء ${orderCode}`,
            actorId: actor.uid,
            actorName: actor.displayName,
            timestamp: new Date().toISOString(),
          };
          transaction.set(movementRef, movementData);
        }
      });
    } catch (err) {
      console.warn('Firestore transaction error, performing local fallback update:', err);
      // Fallback locally
      const store = getLocalStore();
      for (const item of receivedItems) {
        if (item.qty <= 0) continue;
        const newBatch: BatchLot = {
          batchId: `BATCH-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          orderId,
          orderCode,
          receivedDate: new Date().toISOString().split('T')[0],
          expiryDate: item.expiryDate || undefined,
          initialQty: item.qty,
          remainingQty: item.qty,
        };

        const existingIndex = store.findIndex(s => s.productId === item.productId);
        if (existingIndex >= 0) {
          const existing = store[existingIndex];
          store[existingIndex] = {
            ...existing,
            currentStock: existing.currentStock + item.qty,
            batches: [...existing.batches, newBatch],
            lastRestockedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
        } else {
          store.push({
            id: item.productId,
            productId: item.productId,
            productNameAr: item.productNameAr,
            orderTypeId,
            unit: item.unit,
            currentStock: item.qty,
            minThreshold: 10,
            idealParLevel: 50,
            batches: [newBatch],
            lastRestockedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
        }
      }
      saveLocalStore(store);
    }
  },

  /**
   * تسجيل صرف استهلاك الطهي أو الهدر وفق مبدأ (FEFO - الأقرب انتهاءً يصرف أولاً)
   */
  async consumeStock(
    productId: string,
    consumeQty: number,
    type: 'USAGE' | 'WASTE',
    reason: string,
    actor: UserProfile
  ): Promise<void> {
    if (consumeQty <= 0) throw new Error('الكمية المصروفة يجب أن تكون أكبر من الصفر');

    try {
      const invDocRef = doc(db, 'inventory', productId);

      await runTransaction(db, async (transaction) => {
        const snap = await transaction.get(invDocRef);
        if (!snap.exists()) throw new Error('الصنف غير مسجل في المخزون');

        const inv = snap.data() as InventoryItem;
        if (inv.currentStock < consumeQty) {
          throw new Error(`الرصيد المتاح (${inv.currentStock} ${inv.unit}) لا يكفي لصرف ${consumeQty}`);
        }

        // فرز الدفعات بحسب تاريخ الانتهاء أولاً ثم تاريخ الورود (FEFO)
        const sortedBatches = [...inv.batches].sort((a, b) => {
          if (a.expiryDate && b.expiryDate) {
            return new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime();
          }
          if (a.expiryDate) return -1;
          if (b.expiryDate) return 1;
          return new Date(a.receivedDate).getTime() - new Date(b.receivedDate).getTime();
        });

        let remainingToDeduct = consumeQty;
        const updatedBatches: BatchLot[] = [];

        for (const batch of sortedBatches) {
          if (remainingToDeduct === 0) {
            updatedBatches.push(batch);
            continue;
          }

          if (batch.remainingQty <= remainingToDeduct) {
            remainingToDeduct -= batch.remainingQty;
            // تم استنفاد الدفعة بالكامل فتصبح remainingQty = 0
          } else {
            updatedBatches.push({
              ...batch,
              remainingQty: batch.remainingQty - remainingToDeduct,
            });
            remainingToDeduct = 0;
          }
        }

        const previousStock = inv.currentStock;
        const newStock = previousStock - consumeQty;

        transaction.update(invDocRef, {
          currentStock: newStock,
          batches: updatedBatches.filter(b => b.remainingQty > 0),
          updatedAt: serverTimestamp(),
        });

        // توثيق حركة الصرف
        const movementRef = doc(collection(db, 'stockMovements'));
        const movementData: Omit<StockMovement, 'id'> = {
          productId,
          productNameAr: inv.productNameAr,
          movementType: type,
          qtyChange: -consumeQty,
          previousStock,
          newStock,
          reason,
          actorId: actor.uid,
          actorName: actor.displayName,
          timestamp: new Date().toISOString(),
        };
        transaction.set(movementRef, movementData);
      });
    } catch (err: any) {
      console.warn('Firestore transaction fallback for consumeStock:', err);
      // Fallback locally
      const store = getLocalStore();
      const existing = store.find(i => i.productId === productId);
      if (!existing) throw new Error('الصنف غير مسجل في المخزون');
      if (existing.currentStock < consumeQty) {
        throw new Error(`الرصيد المتاح (${existing.currentStock} ${existing.unit}) لا يكفي لصرف ${consumeQty}`);
      }

      const sortedBatches = [...existing.batches].sort((a, b) => {
        if (a.expiryDate && b.expiryDate) {
          return new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime();
        }
        if (a.expiryDate) return -1;
        if (b.expiryDate) return 1;
        return new Date(a.receivedDate).getTime() - new Date(b.receivedDate).getTime();
      });

      let remainingToDeduct = consumeQty;
      const updatedBatches: BatchLot[] = [];

      for (const batch of sortedBatches) {
        if (remainingToDeduct === 0) {
          updatedBatches.push(batch);
          continue;
        }

        if (batch.remainingQty <= remainingToDeduct) {
          remainingToDeduct -= batch.remainingQty;
        } else {
          updatedBatches.push({
            ...batch,
            remainingQty: batch.remainingQty - remainingToDeduct,
          });
          remainingToDeduct = 0;
        }
      }

      existing.currentStock = existing.currentStock - consumeQty;
      existing.batches = updatedBatches.filter(b => b.remainingQty > 0);
      existing.updatedAt = new Date().toISOString();
      saveLocalStore(store);
    }
  },

  /**
   * استخراج الأصناف التي بلغت أو تجاوزت حد الأمان الأدنى
   */
  async getReorderAlerts(): Promise<ReorderAlert[]> {
    const all = await this.getInventory();
    return all
      .filter(item => item.currentStock <= item.minThreshold)
      .map(item => ({
        productId: item.productId,
        productNameAr: item.productNameAr,
        orderTypeId: item.orderTypeId,
        currentStock: item.currentStock,
        minThreshold: item.minThreshold,
        shortageQty: Math.max(0, item.idealParLevel - item.currentStock),
        unit: item.unit,
      }));
  },

  /**
   * تعديل حدود إعادة الطلب لصنف محدد بواسطة المدير
   */
  async updateThresholds(productId: string, minThreshold: number, idealParLevel: number): Promise<void> {
    try {
      const docRef = doc(db, 'inventory', productId);
      await runTransaction(db, async (transaction) => {
        transaction.update(docRef, {
          minThreshold,
          idealParLevel,
          updatedAt: serverTimestamp(),
        });
      });
    } catch (err) {
      console.warn('Firestore updateThresholds fallback:', err);
      const store = getLocalStore();
      const item = store.find(i => i.productId === productId);
      if (item) {
        item.minThreshold = minThreshold;
        item.idealParLevel = idealParLevel;
        item.updatedAt = new Date().toISOString();
        saveLocalStore(store);
      }
    }
  },
};
