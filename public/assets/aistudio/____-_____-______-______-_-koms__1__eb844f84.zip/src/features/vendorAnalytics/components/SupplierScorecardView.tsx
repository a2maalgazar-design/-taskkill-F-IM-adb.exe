import React, { useState, useEffect } from 'react';
import { ShieldAlert, Award, Truck, AlertTriangle, TrendingUp, DollarSign, CheckCircle } from 'lucide-react';
import { vendorAnalyticsService } from '../api/vendorAnalyticsService';
import { SupplierScorecard, HACCPViolationLog, ProductPriceTrend } from '../types';
import { useData } from '@/context/DataContext';

export const SupplierScorecardView: React.FC = () => {
  const { suppliers } = useData();
  const [scorecards, setScorecards] = useState<SupplierScorecard[]>([]);
  const [violations, setViolations] = useState<HACCPViolationLog[]>([]);
  const [priceTrend, setPriceTrend] = useState<ProductPriceTrend | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadAnalytics = async () => {
      setLoading(true);
      try {
        const cards = await Promise.all(
          suppliers.map(s => vendorAnalyticsService.computeSupplierScorecard(s.id, s.nameAr))
        );
        setScorecards(cards);

        const haccpLogs = await vendorAnalyticsService.getHACCPViolations();
        setViolations(haccpLogs);

        const trend = await vendorAnalyticsService.getProductPriceTrend('prod-meat-01', 'لحم بقري بلدي مبرد');
        setPriceTrend(trend);
      } catch (err) {
        console.error('Failed to load vendor analytics:', err);
      } finally {
        setLoading(false);
      }
    };
    loadAnalytics();
  }, [suppliers]);

  if (loading) {
    return <div className="p-8 text-center text-stone-500 text-xs">جاري تحليل بيانات وأداء الموردين...</div>;
  }

  return (
    <div className="space-y-6 text-xs">
      {/* رأس الصفحة */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-bold text-stone-100 text-base">تقييم أداء الموردين ومعايير الجودة (Vendor Scorecard)</h2>
            <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
              HACCP & SLA Analytics
            </span>
          </div>
          <p className="text-stone-400 text-xs mt-1">مؤشرات دقيقة حول جودة البضائع، دقة المواعيد، ومخالفات درجات حرارة التبريد.</p>
        </div>
      </div>

      {/* سجل تنبيهات سلامة الغذاء HACCP */}
      {violations.length > 0 && (
        <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-xl space-y-2 text-stone-200">
          <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
            <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0" />
            <span>تنبيه مخالفات سلسلة التبريد HACCP (تجاوز سقف 4°م أثناء الاستلام):</span>
          </div>
          <div className="divide-y divide-rose-500/20 max-h-48 overflow-y-auto">
            {violations.map((v, idx) => (
              <div key={idx} className="py-2.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs">
                <div>
                  <span className="font-bold text-stone-100 font-mono">{v.orderCode}</span> — <span className="text-stone-300">{v.categoryNameAr}</span>
                  <span className="text-stone-400 mr-2 text-[11px]">({v.supplierNameAr})</span>
                  <span className="text-stone-500 mr-2 text-[10px]">بواسطة: {v.receiverName} ({v.timestamp.split('T')[0]})</span>
                </div>
                <div className="font-mono font-bold text-rose-400 bg-rose-500/20 border border-rose-500/30 px-2.5 py-1 rounded text-xs">
                  حرارة مسجلة: {v.recordedTempCelsius}°م (الحد: {v.maxAllowedTempCelsius}°م)
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* بطاقة تقلب أسعار السلع المرجعية */}
      {priceTrend && (
        <div className="p-4 bg-stone-900 border border-stone-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-stone-200 font-bold">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>مؤشر تتبع أسعار التوريد: {priceTrend.productNameAr}</span>
            </div>
            <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
              priceTrend.fluctuationPercentage > 0 
                ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' 
                : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
            }`}>
              {priceTrend.fluctuationPercentage > 0 ? `+${priceTrend.fluctuationPercentage}%` : `${priceTrend.fluctuationPercentage}%`} تذبذب
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {priceTrend.history.map((pt, i) => (
              <div key={i} className="p-2.5 bg-stone-950/60 border border-stone-800/80 rounded-lg text-center font-mono">
                <span className="text-[10px] text-stone-500 block">{pt.date}</span>
                <span className="text-sm font-bold text-stone-200 block mt-0.5">{pt.unitPriceEGP} ج.م</span>
                <span className="text-[10px] text-stone-400 truncate block mt-0.5">{pt.orderCode}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* جدول بطاقات الأداء للموردين */}
      <div className="bg-stone-900 border border-stone-800 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-right text-xs">
          <thead className="bg-stone-950/80 border-b border-stone-800 text-stone-400 font-semibold">
            <tr>
              <th className="p-3">المورد</th>
              <th className="p-3">إجمالي التوريدات</th>
              <th className="p-3">نسبة قبول البضائع</th>
              <th className="p-3">الالتزام بالمواعيد</th>
              <th className="p-3">مخالفات التبريد</th>
              <th className="p-3">الأصناف المرفوضة</th>
              <th className="p-3 text-center">التقييم الإجمالي</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-800/60">
            {scorecards.map((card) => {
              const isExcellent = card.overallRatingScore >= 85;
              const isWarning = card.overallRatingScore < 70;

              return (
                <tr key={card.supplierId} className="hover:bg-stone-800/40 transition">
                  <td className="p-3 font-bold text-stone-100">{card.supplierNameAr}</td>
                  <td className="p-3 font-mono text-stone-300">{card.totalOrdersDelivered} طلب</td>
                  <td className="p-3">
                    <span className="font-mono font-bold text-emerald-400">{card.qualityAcceptanceRatePct}%</span>
                  </td>
                  <td className="p-3">
                    <span className="font-mono font-bold text-sky-400">{card.onTimeDeliveryRatePct}%</span>
                  </td>
                  <td className="p-3">
                    <span className={`font-mono font-bold ${card.haccpViolationCount > 0 ? 'text-rose-400' : 'text-stone-500'}`}>
                      {card.haccpViolationCount}
                    </span>
                  </td>
                  <td className="p-3 font-mono text-rose-400">{card.totalItemsRejected} صنف</td>
                  <td className="p-3 text-center">
                    <span className={`px-2.5 py-1 rounded-full font-mono font-bold text-[11px] inline-block ${
                      isExcellent
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : isWarning
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    }`}>
                      {card.overallRatingScore} / 100
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
