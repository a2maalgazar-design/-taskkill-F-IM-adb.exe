export interface SupplierScorecard {
  supplierId: string;
  supplierNameAr: string;
  orderTypeId: string;
  totalOrdersDelivered: number;
  totalItemsOrdered: number;
  totalItemsReceived: number;
  totalItemsRejected: number;
  qualityAcceptanceRatePct: number; // نسبة البضائع المقبولة بدون رفض
  onTimeDeliveryRatePct: number; // نسبة الوصول في الموعد المحدد
  haccpViolationCount: number; // عدد مرات مخالفة درجات الحرارة
  averageDiscrepancyAmountEGP: number; // متوسط فوارق الفواتير
  overallRatingScore: number; // تقييم إجمالي من 100
}

export interface PriceHistoryPoint {
  date: string; // YYYY-MM-DD
  orderCode: string;
  unitPriceEGP: number;
  supplierId: string;
  supplierNameAr: string;
}

export interface ProductPriceTrend {
  productId: string;
  productNameAr: string;
  currentPriceEGP: number;
  baselinePriceEGP: number; // السعر المرجعي الأساسي
  fluctuationPercentage: number; // نسبة التغير (+ أو -)
  history: PriceHistoryPoint[];
}

export interface HACCPViolationLog {
  orderId: string;
  orderCode: string;
  supplierNameAr: string;
  categoryNameAr: string;
  recordedTempCelsius: number;
  maxAllowedTempCelsius: number;
  receiverName: string;
  timestamp: string;
}
